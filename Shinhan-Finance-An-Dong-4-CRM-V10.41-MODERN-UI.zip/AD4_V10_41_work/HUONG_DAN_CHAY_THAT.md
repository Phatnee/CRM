# Hướng dẫn chạy thật – Cloudflare Workers / D1 (CRM V10.36)

## Đây là bản nào?
- **Bản production**, dùng Workers với D1 trong `wrangler.jsonc` và dữ liệu thật hiện có;
  không phải bản local có tài khoản mẫu.
- 24 migration cũ được giữ nguyên; phiên bản V10.36 bổ sung API và giao diện mới nhưng không yêu cầu chạy lại migrations lịch sử; chỉ bổ sung hướng dẫn và công cụ
  triển khai. Không chứa file backup, dữ liệu khách hàng, mật khẩu hoặc token của người dùng.
- Script không tự sửa lịch sử `d1_migrations` hoặc xóa database. Không dùng với D1 trống.

## Chạy trên Windows
1. Giải nén ZIP vào **thư mục mới** (không ghi đè thư mục web cũ).
2. Kiểm tra cấu hình `wrangler.jsonc`, đặc biệt `database_id`. Nếu đang chọn sai tài khoản/DB,
   ngừng tại đây. Tài khoản Cloudflare phải có quyền Worker & D1.
3. Chạy `CAP_NHAT_WEB_THAT.cmd` bằng cách nhấp đúp, hoặc mở terminal tại thư mục và chạy:

   ```cmd
   CAP_NHAT_WEB_THAT.cmd
   ```

4. Script thực hiện `npm.cmd install`, sau đó
   `npx.cmd wrangler d1 export an-dong-4-crm --remote --output <duong-dan-backup>`.
   Chỉ sau khi xác minh có file sao lưu và bạn xác nhận, script mới chạy `npx.cmd wrangler deploy`.
5. Nếu backup lỗi, **script dừng, không deploy**. Đừng bỏ qua bước backup.
6. Khi deploy xong, Ctrl+F5. Thử Admin → Team Leader → Sales, rồi kiểm tra Team M3 trước
   khi chia số lượng lớn; xác nhận dữ liệu hiện tại không bị thay đổi ngoài dự kiến.

## Vì sao không chạy migrations apply --remote?
Lần trước Cloudflare đã thông báo `duplicate column name: has_prior_shinhan`
trong migration `0019_v10_5_topup_login.sql`. Điều này chứng tỏ cấu trúc bảng đang có cột
nhưng `d1_migrations` chưa đồng bộ. Lặp lại migration có thể tiếp tục lỗi ở các cột khác.
Không nên xóa/cập nhật `d1_migrations` thủ công hoặc chạy lại ALTER TABLE hàng loạt.
Mã Worker đã có các bước kiểm tra tồn tại cột ở Login App/loan_profiles,
`CREATE TABLE IF NOT EXISTS` với KPI doanh số, audit undo và quyền tài khoản.
Phương án tạm thời là deploy code mà không gọi lệnh migration lịch sử.

### Để đối soát migration an toàn
Chạy `KIEM_TRA_D1_CHI_DOC.cmd` (chỉ SELECT/PRAGMA), rồi gửi log hiển thị.
Khi đủ thông tin, mới thiết kế một gói migration tương thích chính xác với schema production.

## Nếu cần triển khai thủ công

```cmd
npm.cmd install
npx.cmd wrangler d1 export an-dong-4-crm --remote --output BACKUP_D1_BEFORE_V10_36.sql
npx.cmd wrangler deploy
```

**Chỉ chạy dòng deploy nếu lệnh export thành công và file backup không rỗng.**

## Bảo mật và thử nghiệm
- File `BACKUP_D1_*.sql` có thể chứa dữ liệu cá nhân nhạy cảm của khách hàng;
  không gửi công khai, không commit vào GitHub, chỉ lưu tại máy an toàn có phân quyền.
- Deploy lên Workers có thể kích hoạt cập nhật schema kiểu `IF NOT EXISTS` lúc dùng chức năng;
  hãy thử có kiểm soát và theo dõi logs. Không cam kết tương thích mọi D1 thiếu migration
  khi chưa có kết quả đối soát thực tế.
- Nếu gặp lỗi mới, dừng nhập/sửa dữ liệu và dùng backup để hỗ trợ phục hồi theo quy trình phù hợp.

## Kiểm tra sau khi triển khai V10.36

- Chia Kho: Mở Nhập/Xuất dữ liệu, chọn Kho Mobility 3 và đối chiếu số chưa gọi/đã gọi; thử chia vài khách cho nhân viên Mobility 3, không chạy ngay số lượng lớn.
- KPI doanh số: chọn 2 nhân viên thuộc Team, đặt chỉ tiêu tháng, đăng nhập bằng Team Leader để xác nhận đúng phạm vi.
- Nhân sự: khóa tài khoản Sales thử nghiệm (nếu có), xác nhận phiên cũ bị vô hiệu hóa, thử thu hồi Data và mở khóa.
- Nhật ký: hoàn tác thử 1 thao tác phân loại mới sau khi đã sao lưu; các thao tác lịch sử không có bản ghi dữ liệu trước/sau sẽ không có nút hoàn tác.
- Dashboard Login App: so sánh tháng hiện tại với tháng trước; kiểm tra bảng lọc theo Team/NV.
- Lead và Follow-up Login App: kiểm tra Y01/Y02 xuất hiện và lịch hẹn riêng.
- Nếu thấy lỗi hoặc số liệu sai, dừng các thao tác thay đổi dữ liệu và gửi log (không gửi dữ liệu khách hàng).
