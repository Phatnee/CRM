/* V10.38 – Team-scoped workspaces; dashboard rankings; Lead/Follow-up control. */
const v1038IsManager=()=>['admin','sup'].includes(state.session?.user?.role);
const v1038TeamId=()=>String(state.session?.user?.team_id||'');
const v1038Teams=()=>v1038IsManager()?state.teamObjects||[]:(state.teamObjects||[]).filter(t=>String(t.id)===v1038TeamId());
function v1038TeamTabs(selected,callback,counts=null){
 const role=state.session?.user?.role,teams=v1038Teams();
 const wrap=document.createElement('div');wrap.className='v1038-team-tabs';wrap.setAttribute('role','group');wrap.setAttribute('aria-label','Lọc theo Team');
 const full=v1038IsManager()?`<button type="button" class="v1038-team-tab ${!selected?'active':''}" data-v1038-team="" aria-pressed="${!selected}">Tất cả Team${counts?` <small>${Number(counts.all||0).toLocaleString('vi-VN')}</small>`:''}</button>`:'';
 wrap.innerHTML=full+teams.map(t=>`<button type="button" class="v1038-team-tab ${String(selected)===String(t.id)||!v1038IsManager()?'active':''}" data-v1038-team="${t.id}" aria-pressed="${String(selected)===String(t.id)||!v1038IsManager()}">${esc(t.name)}${counts?` <small>${Number(counts[t.id]||0).toLocaleString('vi-VN')}</small>`:''}</button>`).join('');
 if(role==='sale'){wrap.innerHTML='<span class="v1038-my-scope">Dữ liệu cá nhân</span>';return wrap;}
 wrap.querySelectorAll('[data-v1038-team]').forEach(b=>b.onclick=()=>callback(b.dataset.v1038Team));return wrap;
}
function v1038InsertTeamTabs(main,tabs,afterSelector='.premium-page-head'){
 const anchor=main.querySelector(afterSelector);if(anchor&&!main.querySelector('.v1038-team-tabs'))anchor.insertAdjacentElement('afterend',tabs);
}
function v1038Currency(n){return Number(n||0).toLocaleString('vi-VN')+' đ';}

// Rename the customer management accordion. Keep stable route IDs and all existing permissions.
const v1038Names={loginDashboard:'Dashboard',loginApp:'App Login',loginLead:'Lead',appFollowup:'Follow-up'};
const v1038OriginalPageTitle=pageTitleForRole;
pageTitleForRole=function(page,role){return v1038Names[page]||v1038OriginalPageTitle(page,role);};
const v1038OriginalPremiumTitle=premiumPageTitle;
premiumPageTitle=function(page,role){return v1038Names[page]||v1038OriginalPremiumTitle(page,role);};
const v1038OriginalLoginAppRender=renderLoginApps;
renderLoginApps=function(main,...args){v1038OriginalLoginAppRender(main,...args);if(state.page==='loginApp'){const title=main.querySelector('.loginapp-page h1');if(title)title.textContent='App Login';}};
const v1038OrigSidebar=renderSidebar;
renderSidebar=function(active){
 v1038OrigSidebar(active);
 const menu=document.getElementById('sidebar-menu');if(!menu)return;
 const heading=menu.querySelector('[data-workspace="login"] .v1035-workspace-heading');
 if(heading){const last=heading.lastChild;if(last?.nodeType===3)last.nodeValue=' QUẢN LÝ KHÁCH HÀNG';else heading.appendChild(document.createTextNode(' QUẢN LÝ KHÁCH HÀNG'));}
 menu.querySelectorAll('[data-nav]').forEach(b=>{
  const name=v1038Names[b.dataset.nav];if(!name)return;
  const label=b.querySelector('.menu-item-label');if(label)label.textContent=name;
 });
};

// Revenue dashboards: keep the top revenue totals and add Team performance + sales ranking.
const v1038BaseRevenue=v1035RenderPerformance;
v1035RenderPerformance=function(main,kpi=false){
 v1038BaseRevenue(main,kpi);
 const page=kpi?'revenueKpi':'loginDashboard';if(state.page!==page)return;
 if(!kpi){const title=main.querySelector('.v1035-perf-head h1');if(title)title.textContent='Dashboard';}
 const data=state.v1035Performance?.get?.(v1035PerfKey())?.data;
 const role=state.session?.user?.role;
 const tabs=v1038TeamTabs(state.v1035RevenueTeam||'',team=>{state.v1035RevenueTeam=team;state.v1035RevenueUser='';v1035RenderPerformance(main,kpi);});
 v1038InsertTeamTabs(main,tabs,'.v1035-perf-head');
 if(!data)return;
 const cards=main.querySelector('.v1035-perf-cards');if(cards&&!kpi){cards.classList.add('v1038-revenue-top');const cap=cards.querySelector('article:nth-child(3)>span');if(cap)cap.textContent='Tổng doanh số giải ngân';}
 const rows=(data.items||[]).slice(),userMap=new Map(),teamMap=new Map();
 rows.forEach(u=>{
  const key=String(u.team_id||'');const entry=teamMap.get(key)||{id:key,name:u.team||'Chưa có Team',staff:0,apps:0,loans:0,volume:0};
  entry.staff++;entry.apps+=Number(u.apps||0);entry.loans+=Number(u.loans||0);entry.volume+=Number(u.volume||0);teamMap.set(key,entry);userMap.set(u.id,u);
 });
 const list=main.querySelector('.v1035-perf-list');if(!list)return;
 if(!kpi){
  const block=document.createElement('section');block.className='crm-panel v1038-team-performance';
  const teams=[...teamMap.values()].sort((a,b)=>b.volume-a.volume||String(a.name).localeCompare(String(b.name),'vi'));
  block.innerHTML=`<div class="crm-panel-head"><h2>Hiệu suất đội ngũ</h2><small>${v1038IsManager()?'Bấm vào Team để xem Dashboard riêng':'Thống kê trong phạm vi được phép'}</small></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Team</th><th>Nhân viên</th><th>APP</th><th>Loan</th><th>Doanh số giải ngân</th><th>Chi tiết</th></tr></thead><tbody>${teams.map(t=>`<tr><td><strong>${esc(t.name)}</strong></td><td>${t.staff}</td><td>${t.apps}</td><td>${t.loans}</td><td><strong>${v1038Currency(t.volume)}</strong></td><td>${v1038IsManager()?`<button class="btn small" data-v1038-open-team="${esc(t.id)}">Xem Team ›</button>`:'<span class="muted">Team của bạn</span>'}</td></tr>`).join('')||'<tr><td colspan="6">Chưa có doanh số của Team trong tháng.</td></tr>'}</tbody></table></div>`;
  if(cards)cards.after(block);else list.before(block);
  block.querySelectorAll('[data-v1038-open-team]').forEach(b=>b.onclick=()=>{state.v1035RevenueTeam=b.dataset.v1038OpenTeam;state.v1035RevenueUser='';v1035RenderPerformance(main,false);});
 }
 const ranks=rows.slice().sort((a,b)=>Number(b.volume||0)-Number(a.volume||0)||Number(b.loans||0)-Number(a.loans||0)||Number(b.apps||0)-Number(a.apps||0));
 const section=document.createElement('section');section.className='crm-panel v1038-sales-ranking';
 section.innerHTML=`<div class="crm-panel-head"><h2>Xếp hạng doanh số Sales & Freelancer</h2><small>Tháng ${esc(state.v1035RevenueMonth)} · sắp xếp theo doanh số giải ngân thực đạt</small></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Hạng</th><th>Nhân viên</th><th>Team</th><th>APP</th><th>Loan</th><th>Doanh số</th></tr></thead><tbody>${ranks.map((u,i)=>`<tr><td><span class="v1038-rank ${i<3?'top':''}">${i+1}</span></td><td><strong>${esc(u.display_name||'')}</strong><small>${u.staff_type==='freelancer'?'Freelancer':'Sales'}</small></td><td>${esc(u.team||'—')}</td><td>${Number(u.apps||0)}</td><td>${Number(u.loans||0)}</td><td><strong>${v1038Currency(u.volume)}</strong></td></tr>`).join('')||'<tr><td colspan="6">Chưa có nhân viên trong phạm vi này.</td></tr>'}</tbody></table></div>`;
 list.after(section);
};

// Telesales: direct Team tabs rather than forcing a separate dropdown.
const v1038BaseDashboard=renderDashboard;
renderDashboard=function(main){
 v1038BaseDashboard(main);if(state.page!=='dashboard'||!main.querySelector('.v81-dashboard'))return;
 const selected=v1038IsManager()?String(state.dashboardDrillTeamId||''):v1038TeamId();
 v1038InsertTeamTabs(main,v1038TeamTabs(selected,team=>{state.dashboardDrillTeamId=team;state.dashboardDrillUserId='';renderDashboard(main);}));
};
const v1038BaseKPI=renderKPI;
renderKPI=function(main){
 v1038BaseKPI(main);if(state.page!=='kpi'||!main.querySelector('.premium-page'))return;
 v1038InsertTeamTabs(main,v1038TeamTabs(state.premiumKpiTeam||v1038TeamId(),team=>{state.premiumKpiTeam=team;state.premiumKpiUser='';renderKPI(main);}));
};
const v1038BaseTelesalesFollowup=renderFollowup;
renderFollowup=function(main){
 const team=String(state.v1038FollowupTeam||'');let previous=null;
 if(v1038IsManager()&&team){previous=state.customers;state.customers=state.customers.filter(c=>String(c.team_id)===team);}
 try{v1038BaseTelesalesFollowup(main);}finally{if(previous)state.customers=previous;}
 if(state.page!=='followup'||!main.querySelector('.followup-page'))return;
 const sel=v1038IsManager()?team:v1038TeamId();
 v1038InsertTeamTabs(main,v1038TeamTabs(sel,selected=>{state.v1038FollowupTeam=selected;state.followupOwner='';renderFollowup(main);}));
};

// Manual Login App Lead: scoped Team tabs, clickable summaries, edit/delete actions.
const v1038BaseCustomerLead=v1037RenderLoginLeads;
v1037RenderLoginLeads=function(main){
 const team=String(state.v1038CustomerTeam||'');const previous=state.v1036LoginLeads;
 if(v1038IsManager()&&team)state.v1036LoginLeads=previous.filter(x=>String(x.team_id)===team);
 try{v1038BaseCustomerLead(main);}finally{state.v1036LoginLeads=previous;}
 if(state.page!=='loginLead')return;const leadH=main.querySelector('h1');if(leadH)leadH.textContent='Lead';
 const counts={all:previous.length};(state.teamObjects||[]).forEach(t=>counts[t.id]=previous.filter(x=>String(x.team_id)===String(t.id)).length);
 v1038InsertTeamTabs(main,v1038TeamTabs(v1038IsManager()?team:v1038TeamId(),sel=>{state.v1038CustomerTeam=sel;v1037RenderLoginLeads(main);},counts));
 main.querySelectorAll('.loginapp-summary article').forEach((card,i)=>{
  card.classList.add('v1038-click-summary');card.setAttribute('role','button');card.tabIndex=0;
  card.onclick=()=>{state.v1037LeadStatus=['','PENDING','LOGIN_APP','NO_LOGIN'][i];v1037RenderLoginLeads(main);main.querySelector('.lead-card')?.scrollIntoView({behavior:'smooth',block:'start'});};
  card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();card.click()}};
 });
 const allowedDelete=state.session?.user?.role!=='sale';
 main.querySelectorAll('.v1037-lead-source').forEach(sel=>{
  const x=previous.find(r=>String(r.id)===String(sel.dataset.id));const actions=sel.closest('tr')?.querySelector('.lead-actions');if(!actions||!x)return;
  actions.insertAdjacentHTML('beforeend',`<button class="btn small" data-v1038-lead-edit="${x.id}">Sửa</button>${allowedDelete?`<button class="btn small danger" data-v1038-lead-delete="${x.id}">Xóa</button>`:''}`);
 });
 main.querySelectorAll('[data-v1038-lead-edit]').forEach(b=>b.onclick=()=>{
  const x=previous.find(u=>Number(u.id)===Number(b.dataset.v1038LeadEdit));if(!x)return;
  const owners=v1037LoginLeadVisibleUsers().filter(u=>!v1038IsManager()||!team||String(u.team_id)===team);
  openAdminModal('Sửa Lead · '+x.customer_name,`<div class="v1035-target-form"><label>Họ tên khách<input id="v1038-lname" value="${esc(x.customer_name||'')}"></label><label>Số điện thoại<input id="v1038-lphone" inputmode="numeric" maxlength="10" value="${esc(x.phone||'')}"></label><label>Nguồn<select id="v1038-lsource">${v1036AppLeadSources.map(s=>`<option value="${esc(s)}" ${x.source===s?'selected':''}>${esc(s)}</option>`).join('')}</select></label>${state.session.user.role!=='sale'?`<label>Nhân viên<select id="v1038-lowner">${owners.map(u=>`<option value="${u.id}" ${Number(u.id)===Number(x.assigned_user_id)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select></label>`:''}<label>Ghi chú<textarea id="v1038-lnote" rows="3">${esc(x.note||'')}</textarea></label><div class="call-actions"><button class="btn" id="v1038-lcancel">Hủy</button><button class="btn primary" id="v1038-lsave">Lưu chỉnh sửa</button></div></div>`);
  document.getElementById('v1038-lcancel').onclick=closeAdminModal;
  document.getElementById('v1038-lsave').onclick=async()=>{const payload={customer_name:document.getElementById('v1038-lname').value,phone:document.getElementById('v1038-lphone').value,source:document.getElementById('v1038-lsource').value,note:document.getElementById('v1038-lnote').value};const owner=document.getElementById('v1038-lowner');if(owner)payload.assigned_user_id=Number(owner.value);try{await API.request(`/login-leads/${x.id}`,{method:'PATCH',body:JSON.stringify(payload)});closeAdminModal();toast('Đã chỉnh Lead.');v1037LoadLoginLeads(main);}catch(e){toast(e.message,'bad');}};
 });
 main.querySelectorAll('[data-v1038-lead-delete]').forEach(b=>b.onclick=async()=>{const x=previous.find(u=>Number(u.id)===Number(b.dataset.v1038LeadDelete));if(!x||!confirm(`Xóa Lead ${x.customer_name}? Hồ sơ Login App đã chuyển (nếu có) vẫn được giữ.`))return;try{await API.request(`/login-leads/${x.id}`,{method:'DELETE'});toast('Đã xóa Lead.');v1037LoadLoginLeads(main);}catch(e){toast(e.message,'bad')}});
};

// Follow-up Login App: mirrors the Telesales cards and filter layout; Team tabs,
// complete/edit/delete actions. Only Admin/Sup see all Teams (API is scoped).
const v1038BaseAppFollowup=v1037RenderAppFollowups;
v1037RenderAppFollowups=function(main){
 const team=String(state.v1038CustomerTeam||'');const original=state.v1036AppFollowups;
 if(v1038IsManager()&&team)state.v1036AppFollowups=original.filter(x=>String(x.team_id)===team);
 try{v1038BaseAppFollowup(main);}finally{state.v1036AppFollowups=original;}
 if(state.page!=='appFollowup')return;const followH=main.querySelector('h1');if(followH)followH.textContent='Follow-up';
 const counts={all:original.length};(state.teamObjects||[]).forEach(t=>counts[t.id]=original.filter(x=>String(x.team_id)===String(t.id)).length);
 const icons=['calendar','alert','clock'];main.querySelectorAll('.followup-summary-card').forEach((card,i)=>{card.insertAdjacentHTML('afterbegin',`<span class="v1038-fu-icon v1038-fu-icon-${i}">${uiIcon(icons[i]||'calendar')}</span>`);const sub=card.querySelector('small');if(i===0&&sub)sub.textContent=Number(card.querySelector('strong')?.textContent||0)>0?'Cần chăm sóc trong hôm nay':'Không có lịch hôm nay';});
 v1038InsertTeamTabs(main,v1038TeamTabs(v1038IsManager()?team:v1038TeamId(),sel=>{state.v1038CustomerTeam=sel;v1037RenderAppFollowups(main);},counts));
 const rows=main.querySelectorAll('.followup-panel .data-table tbody tr');
 rows.forEach(tr=>{
  const done=tr.querySelector('[data-v1037-fu-done]');let id=Number(done?.dataset.v1037FuDone||0);
  if(!id){const name=tr.querySelector('td:nth-child(2) strong')?.textContent||'';const date=tr.querySelector('td:first-child')?.textContent||'';const match=original.find(x=>x.customer_name===name&&shortDate(x.follow_date)===date);id=Number(match?.id||0);}
  if(!id)return;const x=original.find(v=>Number(v.id)===id);if(!x)return;const cell=tr.lastElementChild;
  cell.insertAdjacentHTML('beforeend',` <button class="btn small" data-v1038-fu-edit="${id}">Sửa</button>${state.session.user.role!=='sale'?` <button class="btn small danger" data-v1038-fu-delete="${id}">Xóa</button>`:''}`);
 });
 main.querySelectorAll('[data-v1037-bucket]').forEach(b=>{const action=b.onclick;b.onclick=()=>{action?.();requestAnimationFrame(()=>main.querySelector('.followup-panel')?.scrollIntoView({behavior:'smooth',block:'start'}));};});
 main.querySelectorAll('[data-v1038-fu-edit]').forEach(b=>b.onclick=()=>{
  const x=original.find(u=>Number(u.id)===Number(b.dataset.v1038FuEdit));if(!x)return;
  const types={REJECTED:'Hồ sơ bị từ chối',CALLBACK:'Khách hẹn gọi lại',DOCUMENT:'Bổ sung hồ sơ',RELOGIN:'Đăng nhập App lại'};
  openAdminModal('Chỉnh lịch Follow-up · '+x.customer_name,`<div class="v1035-target-form"><label>Ngày hẹn<input type="date" id="v1038-fdate" value="${esc(dateKey(x.follow_date))}"></label><label>Loại lịch<select id="v1038-ftype">${Object.entries(types).map(([v,t])=>`<option value="${v}" ${v===x.category?'selected':''}>${t}</option>`).join('')}</select></label><label>Trạng thái<select id="v1038-fstatus"><option value="PENDING" ${x.status==='PENDING'?'selected':''}>Chờ chăm sóc</option><option value="DONE" ${x.status==='DONE'?'selected':''}>Đã chăm sóc</option></select></label><label>Ghi chú<textarea id="v1038-fnote" rows="3">${esc(x.note||'')}</textarea></label><div class="call-actions"><button class="btn" id="v1038-fcancel">Hủy</button><button class="btn primary" id="v1038-fsave">Lưu</button></div></div>`);
  document.getElementById('v1038-fcancel').onclick=closeAdminModal;
  document.getElementById('v1038-fsave').onclick=async()=>{const payload={follow_date:document.getElementById('v1038-fdate').value,category:document.getElementById('v1038-ftype').value,status:document.getElementById('v1038-fstatus').value,note:document.getElementById('v1038-fnote').value};try{await API.request(`/app-followups/${x.id}`,{method:'PATCH',body:JSON.stringify(payload)});closeAdminModal();toast('Đã cập nhật Follow-up.');v1037LoadAppFollowups(main);}catch(e){toast(e.message,'bad');}};
 });
 main.querySelectorAll('[data-v1038-fu-delete]').forEach(b=>b.onclick=async()=>{const x=original.find(u=>Number(u.id)===Number(b.dataset.v1038FuDelete));if(!x||!confirm(`Xóa lịch Follow-up của ${x.customer_name}? Hồ sơ Login App vẫn được giữ.`))return;try{await API.request(`/app-followups/${x.id}`,{method:'DELETE'});toast('Đã xóa lịch hẹn.');v1037LoadAppFollowups(main);}catch(e){toast(e.message,'bad');}});
};

V1032_AUDIT_LABELS.LOGIN_LEAD_UPDATE='Chỉnh Lead Login App';
V1032_AUDIT_LABELS.LOGIN_LEAD_DELETE='Xóa Lead Login App';
V1032_AUDIT_LABELS.APP_FOLLOWUP_UPDATE='Chỉnh lịch Follow-up App';
V1032_AUDIT_LABELS.APP_FOLLOWUP_DELETE='Xóa lịch Follow-up App';
