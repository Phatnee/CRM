const STATUS_LABELS = {
  NEW: 'Data mới',
  Y01: 'Y01 - KH có nhu cầu',
  Y02: 'Y02 - KH suy nghĩ',
  Y03: 'Y03 - KH không nhu cầu',
  Y04: 'Y04 - KH cúp ngang',
  Y05: 'Y05 - Khác: Bận/Dư nợ cao',
  Y06: 'Y06 - Thỏa CTY khác',
  N01: 'N01 - Sai số',
  N02: 'N02 - KH không nghe máy',
  N03: 'N03 - KH khóa máy',
  N04: 'N04 - KH nợ xấu'
};

const LEAD_STATUS_LABELS={
  LOGIN_APP:'Khách hàng đã login app',
  SIGNED:'Đã giải ngân',
  HIGH_DEBT:'KH dư nợ cao',
  BAD_DEBT:'KH nợ xấu',
  NEW_DEBT:'KH mới phát sinh dư nợ',
  OTHER:'Lý do khác',
  NO_LOGIN:'Không login'
};
const LEAD_SELECTABLE_STATUSES=['LOGIN_APP','NO_LOGIN'];
const LEAD_NEGATIVE_STATUSES=new Set(['HIGH_DEBT','BAD_DEBT','NEW_DEBT']);

const KHTN_BUILTIN_ORDER=['customer_name','phone','birth_year','area','occupation','average_income','cccd','source','note','expected_login_date'];
const KHTN_CORE_FIELDS=new Set(['customer_name','phone','source']);
const KHTN_DEFAULT_CONFIG = {
  fields: {
    customer_name:{label:'Họ và tên khách hàng',enabled:true,required:true,type:'text'},
    phone:{label:'Số điện thoại',enabled:true,required:true,type:'text'},
    birth_year:{label:'Năm sinh',enabled:true,required:false,type:'number'},
    area:{label:'Khu vực sinh sống',enabled:true,required:false,type:'text'},
    occupation:{label:'Nghề nghiệp',enabled:true,required:false,type:'text'},
    average_income:{label:'Thu nhập trung bình',enabled:true,required:false,type:'text'},
    cccd:{label:'CCCD',enabled:true,required:false,type:'text'},
    source:{label:'Nguồn KHTN',enabled:true,required:true,type:'select'},
    note:{label:'Ghi chú',enabled:true,required:false,type:'textarea'},
    expected_login_date:{label:'Dự kiến login',enabled:true,required:false,type:'date'}
  },
  field_order:[...KHTN_BUILTIN_ORDER],
  source_options:['Telesale','CTV','Khách giới thiệu','Facebook','TikTok','Khác']
};
const KHTN_FIELD_ORDER=KHTN_BUILTIN_ORDER;


const demoSeed = {
  user: null,
  teams: ['Mobility 1','Mobility 3','Mobility 5','Mobility 6'],
  users: [
    {id:1,username:'admin',display_name:'Quản trị An Đông 4',role:'admin',team:'Tất cả'},
    {id:2,username:'lead5',display_name:'Teamlead Mobility 5',role:'teamlead',team:'Mobility 5'},
    {id:3,username:'sale5',display_name:'Phan Thị Đan Vy',role:'sale',team:'Mobility 5'},
    {id:4,username:'vy',display_name:'Nguyễn Thị Tường Vy',role:'sale',team:'Mobility 5'},
    {id:5,username:'viet',display_name:'Lữ Quốc Việt',role:'sale',team:'Mobility 5'},
    {id:6,username:'minhanh',display_name:'Lương Tuệ Minh Anh',role:'sale',team:'Mobility 5'},
    {id:7,username:'nhu',display_name:'Võ Tường Như',role:'sale',team:'Mobility 5'},
    {id:8,username:'nha',display_name:'Hồ Phan Hồng Nhã',role:'sale',team:'Mobility 5'},
    {id:9,username:'ly',display_name:'Đỗ Thị Trúc Ly',role:'sale',team:'Mobility 5'}
  ],
  customers: [
    {id:101,code:'KH0001',name:'Nguyễn Văn An',phone:'0901 23x xxx',source:'LNL',team:'Mobility 5',owner:'Phan Thị Đan Vy',status:'Y01',received:'2026-10-01',follow_up:'2026-10-05T15:30',note:'Khách cần tư vấn khoản vay 100 triệu.'},
    {id:102,code:'KH0002',name:'Trần Thị Bình',phone:'0932 41x xxx',source:'FLC',team:'Mobility 5',owner:'Đỗ Thị Trúc Ly',status:'N02',received:'2026-10-01',follow_up:'2026-10-05T16:00',note:'Không nghe máy, gọi lại chiều.'},
    {id:103,code:'KH0003',name:'Lê Quốc Cường',phone:'0987 60x xxx',source:'CTV',team:'Mobility 3',owner:'Trần Thanh Tâm',status:'Y02',received:'2026-10-02',follow_up:'2026-10-06T09:00',note:'Đang suy nghĩ.'},
    {id:104,code:'KH0004',name:'Phạm Minh Đức',phone:'0918 55x xxx',source:'LNL',team:'Mobility 6',owner:'Nguyễn Hoàng Nam',status:'NEW',received:'2026-10-02',follow_up:'',note:''},
    {id:105,code:'KH0005',name:'Võ Thị Hạnh',phone:'0977 12x xxx',source:'FLC',team:'Mobility 5',owner:'Lương Tuệ Minh Anh',status:'Y01',received:'2026-10-02',follow_up:'2026-10-05T14:45',note:'Đã gửi thông tin hồ sơ.'},
    {id:106,code:'KH0006',name:'Đặng Quốc Huy',phone:'0964 90x xxx',source:'CTV',team:'Mobility 5',owner:'Nguyễn Thị Tường Vy',status:'N03',received:'2026-10-03',follow_up:'',note:'Khóa máy.'},
    {id:107,code:'KH0007',name:'Bùi Thu Lan',phone:'0909 83x xxx',source:'LNL',team:'Mobility 3',owner:'Trần Thanh Tâm',status:'Y01',received:'2026-10-03',follow_up:'2026-10-05T17:00',note:'Có nhu cầu, cần kiểm tra điều kiện.'},
    {id:108,code:'KH0008',name:'Huỳnh Gia Minh',phone:'0888 73x xxx',source:'FLC',team:'Mobility 5',owner:'Lữ Quốc Việt',status:'NEW',received:'2026-10-03',follow_up:'',note:''},
    {id:109,code:'KH0009',name:'Đỗ Ngọc Mai',phone:'0923 67x xxx',source:'LNL',team:'Mobility 5',owner:'Hồ Phan Hồng Nhã',status:'Y05',received:'2026-10-04',follow_up:'2026-10-06T13:30',note:'Khách đang bận.'},
    {id:110,code:'KH0010',name:'Ngô Thành Nam',phone:'0945 20x xxx',source:'CTV',team:'Mobility 6',owner:'Lê Anh Tú',status:'N01',received:'2026-10-04',follow_up:'',note:'Sai số.'},
    {id:111,code:'KH0011',name:'Trương Khánh Ngọc',phone:'0938 94x xxx',source:'FLC',team:'Mobility 5',owner:'Võ Tường Như',status:'N02',received:'2026-10-05',follow_up:'2026-10-05T15:10',note:'Gọi lại sau 15h.'},
    {id:112,code:'KH0012',name:'Nguyễn Hoài Phương',phone:'0906 44x xxx',source:'LNL',team:'Mobility 5',owner:'Phan Thị Đan Vy',status:'NEW',received:'2026-10-05',follow_up:'',note:''}
  ],
  calls: [
    {id:1,customer_id:101,owner:'Phan Thị Đan Vy',status:'N02',note:'Lần 1 không nghe máy.',created_at:'2026-10-05T09:10'},
    {id:2,customer_id:101,owner:'Phan Thị Đan Vy',status:'Y01',note:'Khách có nhu cầu, hẹn gọi lại.',created_at:'2026-10-05T14:25'},
    {id:3,customer_id:105,owner:'Lương Tuệ Minh Anh',status:'Y01',note:'Đã gửi thông tin hồ sơ.',created_at:'2026-10-05T10:15'},
    {id:4,customer_id:102,owner:'Đỗ Thị Trúc Ly',status:'N02',note:'Không nghe máy.',created_at:'2026-10-05T10:40'}
  ]
};

const state = {
  session: JSON.parse(localStorage.getItem('a4_session') || 'null'),
  page: 'apps',
  app: null,
  crmView: 'list',
  selectedCustomerId: null,
  customers: [],
  calls: [],
  callsLoadedFrom: '',
  callsLoadedTo: '',
  callsLoadedRanges: [],
  users: [],
  teams: [],
  teamObjects: [],
  kpiTargets: [],
  completionAlerts: [],
  kpiAlerts: [],
  notificationTimer: null,
  chatNotifyTimer: null,
  chatNotifyCursor: 0,
  chatNotifyInitialized: false,
  chatNotifications: [],
  loanCareReminders: [],
  loanCareReminderTimer: null,
  loanCareReminderLoadedAt: 0,
  dashboardDate: null,
  dashboardViewDate: null,
  dashboardDrillTeamId: '',
  dashboardDrillUserId: '',
  dashboardRangeLoading: false,
  dashboardFrom: null,
  dashboardTo: null,
  dashboardTeamTab: '',
  dashboardPeriodView: 'range',
  dashboardScopeView: 'all',
  dashboardSearch: '',
  dashboardSort: 'calls',
  dashboardSortDir: 'desc',
  callMode: 'queue',
  callStatusFilter: '',
  employeeTeamFilter: '',
  warehouseView: 'POOL',
  warehouseTeamFilter: '',
  warehouseStatusFilter: '',
  transferFrom:'',transferTo:'',transferStatus:'N02',recallFrom:'',recallStatus:'ALL',
  warehouseSection:'categories',staffPending:null,staffPendingAt:0,staffPendingLoading:false,
  staffPendingError:'',staffTeamFilter:'',staffSearch:'',staffSelected:'',staffKind:'all',staffOffset:0,
  staffDetail:null,staffDetailLoading:false,
  dataCategories: [],
  warehouseAnalytics: [],
  warehouseRoundAnalytics: [],
  categoryTab: '',
  categoryStateFilter: '',
  categoryCallStatusFilter: '',
  categorySearch: '',
  categorySelectedIds: [],
  monitorTeam: '',
  monitorDate: null,
  callDetailTeam: '',
  callDetailFrom: null,
  callDetailTo: null,
  callDetailEmployee: '',
  callDetailStatus: '',
  khtnEntries: [],
  khtnConfig: structuredClone(KHTN_DEFAULT_CONFIG),
  khtnDateFrom: null,
  khtnDateTo: null,
  khtnTeam: '',
  khtnEmployee: '',
  khtnSource: '',
  khtnSearch: '',
  dailyReports: [], dailyDateFrom:'', dailyDateTo:'', dailyTeam:'', dailyEmployee:'', dailySearch:'',
  leads: [], leadLoadedAt:0, leadLoading:false, leadError:'', leadSearch:'', leadStatusFilter:'', leadTeamFilter:'', leadEmployeeFilter:'', leadDateFrom:'', leadDateTo:'',
  chatContacts:[],chatContactsAt:0,chatContactsLoading:false,chatError:'',chatContactSearch:'',chatSelectedUserId:'',chatMessages:[],chatLoading:false,chatHasOlder:false,chatOldestId:0,chatNewestId:0,chatPollTimer:null,
  leadReminderSending:{},leadReminderSent:{},
  auditLogs:[],auditLoading:false,auditLoadedAt:0,auditSearch:'',auditActionFilter:'',
  mode: 'connecting',
  v84PrefetchTimer:null,
  v84CallMemo:new Map(),
  filters: {q:'',team:'',owner:'',status:'',source:''}
};

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const initials = name => String(name||'AD').split(/\s+/).slice(-2).map(x=>x[0]).join('').toUpperCase();
function staffRoleKey(u){
  if(!u)return 'sales';
  if(u.role==='sup'||(u.role==='admin'&&u.staff_type==='supervisor'))return 'sup';
  if(u.role==='admin')return 'admin';
  if(u.role==='teamlead')return 'teamlead';
  if(u.role==='sale'&&String(u.staff_type||'sales').toLowerCase()==='freelancer')return 'freelancer';
  return 'sales';
}
function staffRoleLabel(u){
  const k=staffRoleKey(u);
  return {admin:'Admin',sup:'Sup',teamlead:'Team Leader',sales:'Sales',freelancer:'Freelancer'}[k]||'Sales';
}
function matchesStaffRoleFilter(u,filter){
  if(!filter)return true;
  const f=String(filter).toLowerCase();
  if(f==='admin'||f==='sup'||f==='teamlead')return staffRoleKey(u)===f;
  if(f==='freelancer')return staffRoleKey(u)==='freelancer';
  if(f==='sale'||f==='sales'||f==='agent')return staffRoleKey(u)==='sales';
  return false;
}
const v1032RoleOrder={admin:0,sup:1,teamlead:2,sales:3,freelancer:4};
const UI_ICON_PATHS={
  dashboard:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  customers:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  call:'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.78.62 2.63a2 2 0 0 1-.45 2.11L8 9.73a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.85.29 1.73.5 2.63.62A2 2 0 0 1 22 16.92z"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
  lead:'<path d="m12 3 1.9 4.1L18 9l-4.1 1.9L12 15l-1.9-4.1L6 9l4.1-1.9L12 3Z"/><path d="m5 15 .9 2.1L8 18l-2.1.9L5 21l-.9-2.1L2 18l2.1-.9L5 15ZM19 13l.9 2.1L22 16l-2.1.9L19 19l-.9-2.1L16 16l2.1-.9L19 13Z"/>',
  chat:'<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/>',
  broadcast:'<path d="m3 10.5 17-5v13l-17-5z"/><path d="M7 14.7 8.8 21h4.4l-2.1-5.1"/><path d="M20 10v4"/>',
  kpi:'<path d="M3 3v18h18"/><path d="m7 16 4-5 3 2 5-7"/><circle cx="19" cy="6" r="1.5"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M20 8v6M23 11h-6"/>',
  import:'<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
  warehouse:'<path d="M3 9 12 4l9 5v11H3z"/><path d="M3 9h18M8 20v-6h8v6"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.2 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2.4v-4h.1A1.7 1.7 0 0 0 4.2 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8.6 4.2a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V2.4h4v.1A1.7 1.7 0 0 0 15 4.2a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 8.6a1.7 1.7 0 0 0 .6 1 1.7 1.7 0 0 0 1.1.4h.1v4h-.1a1.7 1.7 0 0 0-1.7 1Z"/>',
  apps:'<rect x="3" y="3" width="5" height="5" rx="1"/><rect x="10" y="3" width="5" height="5" rx="1"/><rect x="17" y="3" width="4" height="5" rx="1"/><rect x="3" y="10" width="5" height="5" rx="1"/><rect x="10" y="10" width="5" height="5" rx="1"/><rect x="17" y="10" width="4" height="5" rx="1"/><rect x="3" y="17" width="5" height="4" rx="1"/><rect x="10" y="17" width="5" height="4" rx="1"/><rect x="17" y="17" width="4" height="4" rx="1"/>',
  target:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
  close:'<path d="M18 6 6 18M6 6l12 12"/>'
};
function uiIcon(name,cls='ui-svg'){return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${UI_ICON_PATHS[name]||UI_ICON_PATHS.apps}</svg>`;}
const parseCrmTime = v => {
  if(!v) return null;
  const raw=String(v).trim();
  // D1: datetime('now') = UTC, không có Z. Các ô hẹn gọi nhập ở web là giờ Việt Nam.
  let iso=raw;
  if(/^\d{4}-\d\d-\d\d \d\d:\d\d/.test(raw)) iso=raw.replace(' ','T')+'Z';
  else if(/^\d{4}-\d\d-\d\dT\d\d:\d\d/.test(raw) && !/(Z|[+-]\d\d:\d\d)$/i.test(raw)) iso=raw+'+07:00';
  const d=new Date(iso);
  return Number.isNaN(d.getTime())?null:d;
};
const vnParts = v => {
  const d=parseCrmTime(v); if(!d)return null;
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(d).map(x=>[x.type,x.value]));
  return {date:`${parts.year}-${parts.month}-${parts.day}`,time:`${parts.hour}:${parts.minute}:${parts.second}`,short:`${parts.hour}:${parts.minute} ${parts.day}/${parts.month}`};
};
const fmtDate = v => v ? (vnParts(v)?.short||'—') : '—';
const todayISO = () => new Date(Date.now()+7*3600*1000).toISOString().slice(0,10);
const todayVN = () => new Date(Date.now()+7*3600*1000).toISOString().slice(0,10);

function toast(msg, kind='ok'){
  const el=document.createElement('div'); el.className=`toast ${kind}`; el.textContent=msg; $('#toast-root').appendChild(el); setTimeout(()=>el.remove(),2800);
}

const DemoStore = {
  load(){
    const saved=JSON.parse(localStorage.getItem('a4_demo_data')||'null');
    const data=saved||demoSeed;
    state.customers=structuredClone(data.customers);
    state.calls=structuredClone(data.calls);
    state.users=structuredClone(data.users);
    state.teams=structuredClone(data.teams);
  },
  save(){localStorage.setItem('a4_demo_data',JSON.stringify({customers:state.customers,calls:state.calls,users:state.users,teams:state.teams}));}
};

const explicitDemoMode = () => new URLSearchParams(location.search).get('demo')==='1';
const isLocalHost = () => ['localhost','127.0.0.1','::1'].includes(location.hostname);
const sleep = ms => new Promise(r=>setTimeout(r,ms));

const API = {
  async request(path, opts={}){
    const headers={'Content-Type':'application/json',...(opts.headers||{})};
    if(state.session?.token && state.session.token!=='demo') headers.Authorization=`Bearer ${state.session.token}`;
    const controller=new AbortController();
    const timeoutMs=Number(opts.timeoutMs||12000);
    const timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{
      const r=await fetch('/api'+path,{...opts,headers,signal:opts.signal||controller.signal});
      if(!r.ok){
        const e=await r.json().catch(()=>({error:r.statusText}));
        const err=new Error(e.error||'API error');err.status=r.status;err.payload=e;throw err;
      }
      return await r.json();
    }catch(err){
      if(err?.name==='AbortError'){const e=new Error('Kết nối máy chủ quá thời gian.');e.status=0;throw e;}
      throw err;
    }finally{clearTimeout(timer);}
  },
  async probe(retries=3){
    if(explicitDemoMode()){state.mode='demo';return false;}
    state.mode='connecting';
    for(let i=0;i<Math.max(1,retries);i++){
      try{await this.request('/health',{timeoutMs:5000});state.mode='d1';return true;}
      catch{if(i<retries-1)await sleep(350*(i+1));}
    }
    state.mode='offline';return false;
  }
};

function clearStaleDemoSession(){
  if(state.session?.token==='demo'&&!explicitDemoMode()){
    localStorage.removeItem('a4_session');state.session=null;
  }
}

async function bootstrap(){
  clearStaleDemoSession();
  if(explicitDemoMode()){
    DemoStore.load();state.mode='demo';
    if(state.session?.token!=='demo'){localStorage.removeItem('a4_session');state.session=null;}
    return state.session?showApp():showLogin();
  }
  const online=await API.probe(3);
  if(!online){
    // Production never silently falls back to Demo Local. This prevents a transient network error
    // from sticking a user's browser in demo mode while another browser works normally.
    if(state.session){localStorage.removeItem('a4_session');state.session=null;}
    showLogin();updateMode();toast('Chưa kết nối được hệ thống D1. Hãy thử đăng nhập lại sau vài giây.','bad');return;
  }
  if(state.session?.token){
    try{await syncFromApi({fast:true});showApp();return;}
    catch(err){
      localStorage.removeItem('a4_session');state.session=null;
      if(!(err?.status===401||err?.status===403))toast('Không thể đồng bộ dữ liệu lúc khởi động. Vui lòng đăng nhập lại.','bad');
    }
  }
  showLogin();updateMode();
}

async function v1029OptionalBootstrapRead(path){
 try{return await API.request(path)}catch(e){if(e?.status===403)return {items:[]};throw e}
}
async function syncFromApi(options={}){
  const fast=options.fast!==false;
  const callsTo=todayISO(),callsFrom=addDays(callsTo,fast?-13:-30);
  if(options.lightweight){
    const [customers,calls]=await Promise.all([API.request('/customers'),v1029OptionalBootstrapRead(`/calls?from=${callsFrom}&to=${callsTo}`)]);
    state.customers=customers.items||customers;
    state.calls=calls.items||calls;state.callsLoadedFrom=callsFrom;state.callsLoadedTo=callsTo;state.callsLoadedRanges=[[callsFrom,callsTo]];state.v84CallMemo?.clear?.();
    state.kpiAlerts=buildKpiAlerts();state.lastSaleRefresh=Date.now();updateNotifications();return;
  }
  const [customers,users,teams,calls,kpis] = await Promise.all([
    API.request('/customers'),v1029OptionalBootstrapRead('/users'),v1029OptionalBootstrapRead('/teams'),v1029OptionalBootstrapRead(`/calls?from=${callsFrom}&to=${callsTo}`),API.request('/kpi-targets').catch(()=>({items:[]}))
  ]);
  state.customers=customers.items||customers;
  state.users=users.items||users;
  state.teamObjects=teams.items||teams;state.teams=state.teamObjects.map(x=>x.name||x);
  state.calls=calls.items||calls;state.callsLoadedFrom=callsFrom;state.callsLoadedTo=callsTo;state.callsLoadedRanges=[[callsFrom,callsTo]];state.v84CallMemo?.clear?.();
  state.kpiTargets=kpis.items||kpis||[];
  state.lastSaleRefresh=Date.now();state.lastAlertRefresh=Date.now();state.kpiAlerts=buildKpiAlerts();
  if(!state.dashboardDate)state.dashboardDate=todayISO();
  if(!state.dashboardTo)state.dashboardTo=todayISO();if(!state.dashboardFrom)state.dashboardFrom=addDays(state.dashboardTo,-6);
  if(!state.monitorDate)state.monitorDate=todayISO();
  updateNotifications();
}



function scheduleV84BackgroundPrefetch(){
  if(state.mode!=='d1'||!state.session)return;
  if(state.v84PrefetchTimer)clearTimeout(state.v84PrefetchTimer);
  state.v84PrefetchTimer=setTimeout(async()=>{
    if(state.mode!=='d1'||!state.session)return;
    const role=state.session.user.role;
    const tasks=[];
    // Prepare the common 30-day reporting window after the first screen is already visible.
    if(state.page==='dashboard' && !isCallsRangeLoaded(addDays(todayISO(),-29),todayISO()))tasks.push(ensureCallsRange(addDays(todayISO(),-29),todayISO()));
    if(!(state.leads||[]).length&&!state.leadLoading)tasks.push(loadLeads(false));
    if(['admin','sup','teamlead'].includes(role)&&!(state.dataCategories||[]).length){
      tasks.push(API.request('/data-categories').then(r=>{state.dataCategories=r.items||[]}).catch(()=>{}));
    }
    if((role==='admin'||role==='sup'))tasks.push(refreshCompletionAlerts().catch(()=>{}));
    await Promise.allSettled(tasks);
  },2500);
}

// V6.0: refresh only the customer rows after Data assignment/import operations.
// Avoids re-reading call logs and KPI targets unnecessarily.
async function refreshCustomersOnly(){
  if(state.mode!=='d1') return;
  const customers=await API.request('/customers');
  state.customers=customers.items||customers;
  state.lastSaleRefresh=Date.now();
}
function normalizeCallLoadedRanges(){
  const ranges=(state.callsLoadedRanges||[]).filter(x=>Array.isArray(x)&&x[0]&&x[1]).sort((a,b)=>String(a[0]).localeCompare(String(b[0])));
  const merged=[];
  for(const [from,to] of ranges){
    const last=merged[merged.length-1];
    if(!last||from>addDays(last[1],1)) merged.push([from,to]);
    else if(to>last[1]) last[1]=to;
  }
  state.callsLoadedRanges=merged;
  state.callsLoadedFrom=merged.length?merged[0][0]:'';
  state.callsLoadedTo=merged.length?merged[merged.length-1][1]:'';
}
function isCallsRangeLoaded(from,to){
  return (state.callsLoadedRanges||[]).some(([a,b])=>from>=a&&to<=b);
}
async function ensureCallsRange(from,to){
  if(state.mode!=='d1'||!from||!to) return;
  if(from>to){const t=from;from=to;to=t;}
  if(isCallsRangeLoaded(from,to))return;
  state._v1031CallRequests=state._v1031CallRequests||new Map();
  const key=`${from}|${to}`;
  if(state._v1031CallRequests.has(key))return state._v1031CallRequests.get(key);
  const request=(async()=>{
    const r=await API.request(`/calls?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`),incoming=r.items||[];
    const byId=new Map(state.calls.map(x=>[String(x.id),x]));
    for(const row of incoming)byId.set(String(row.id),row);
    state.calls=[...byId.values()].sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))||Number(b.id)-Number(a.id));state.v84CallMemo?.clear?.();
    state.callsLoadedRanges=[...(state.callsLoadedRanges||[]),[from,to]];
    normalizeCallLoadedRanges();
  })();
  state._v1031CallRequests.set(key,request);
  try{return await request;}finally{state._v1031CallRequests.delete(key)}
}

async function refreshCompletionAlerts(){
  if(state.mode!=='d1'||!['admin','sup'].includes(state.session?.user?.role)) return;
  try{const res=await API.request('/data-completion');state.completionAlerts=res.items||[];state.lastAlertRefresh=Date.now();updateNotifications();}catch{}
}
document.addEventListener('visibilitychange',()=>{
  if(document.hidden||state.mode!=='d1')return;
  // Check chat immediately when the user returns to the CRM instead of waiting for the next polling interval.
  if(state.session?.user){pollChatNotifications().catch(()=>{});refreshLoanCareReminders(false).catch(()=>{});}
  if(['admin','sup'].includes(state.session?.user?.role) && Date.now()-(state.lastAlertRefresh||0)>300000){
    refreshCompletionAlerts();
  }
});
function buildKpiAlerts(){
  if(state.session?.user?.role!=='sale') return [];
  const user=state.session.user, date=addDays(todayISO(),-1), target=userKpiTarget(user.id);
  const calls=state.calls.filter(x=>dateKey(x.created_at)===date && (Number(x.user_id)===Number(user.id)||(!x.user_id&&x.owner===user.display_name)));
  const y01=latestCallsByCustomer(calls).filter(x=>x.status==='Y01').length;
  const missing=[];
  if(calls.length<Number(target.calls_daily||0)) missing.push(`Calls ${calls.length}/${Number(target.calls_daily||0)}`);
  if(y01<Number(target.y01_daily||0)) missing.push(`Y01 ${y01}/${Number(target.y01_daily||0)}`);
  if(!missing.length) return [];
  return [{type:'KPI_MISSED',user_id:user.id,date,display_name:user.display_name,missing,detail:missing.join(' · ')}];
}
async function refreshLoanCareReminders(showToast=false){
  if(state.mode!=='d1'||!state.session?.user)return;
  try{
    const prev=new Set((state.loanCareReminders||[]).map(x=>String(x.id)));
    const r=await API.request('/loan-care/reminders');
    const items=(r.items||[]).map(x=>({...x,type:'LOAN_CARE_REMINDER'}));
    state.loanCareReminders=items;state.loanCareReminderLoadedAt=Date.now();updateNotifications();
    const fresh=items.filter(x=>!prev.has(String(x.id)));
    if(showToast&&fresh.length){const x=fresh[fresh.length-1];toast(`${x.reminder_type==='DUE'?'🔔':'📅'} ${x.customer_name||'Khách hàng'}: ${x.reminder_type==='DUE'?'đến hạn chăm sóc hôm nay':'còn 3 ngày đến lịch chăm sóc'}`);}
  }catch(_e){}
}

function startNotificationPolling(){
  if(state.notificationTimer) clearInterval(state.notificationTimer);
  if(state.chatNotifyTimer) clearInterval(state.chatNotifyTimer);
  if(state.loanCareReminderTimer) clearInterval(state.loanCareReminderTimer);
  state.notificationTimer=null;state.chatNotifyTimer=null;state.loanCareReminderTimer=null;
  if(state.mode!=='d1') return;
  if(['admin','sup'].includes(state.session?.user?.role)) state.notificationTimer=setInterval(()=>{
    if(!document.hidden) refreshCompletionAlerts();
  },300000);
  if(state.session?.user?.role==='sale') state.notificationTimer=setInterval(()=>{
    state.kpiAlerts=buildKpiAlerts();updateNotifications();
    // One light sync per ~10 minutes while app is visible; new assignments/other users' updates remain discoverable.
    if(!document.hidden && Date.now()-(state.lastSaleRefresh||0)>600000){
      state.lastSaleRefresh=Date.now();
      syncFromApi({lightweight:true}).then(()=>{if(state.page!=='telesale')render()}).catch(()=>{});
    }
  },60000);
  // Chat notification polling is lightweight and indexed by recipient_user_id + id.
  // It runs for every role, but only while the browser tab is visible.
  pollChatNotifications().catch(()=>{});
  refreshLoanCareReminders(false).catch(()=>{});
  state.chatNotifyTimer=setInterval(()=>{if(!document.hidden)pollChatNotifications().catch(()=>{});},30000);
  state.loanCareReminderTimer=setInterval(()=>{if(!document.hidden)refreshLoanCareReminders(true).catch(()=>{});},60000);
}
async function pollChatNotifications(){
  if(state.mode!=='d1'||!state.session?.user)return;
  const r=await API.request('/chat/notifications');
  const incoming=(r.items||[]).map(x=>({...x,type:'CHAT_MESSAGE'}));
  const previousIds=new Set((state.chatNotifications||[]).map(x=>Number(x.id)));
  const fresh=incoming.filter(x=>!previousIds.has(Number(x.id)));
  state.chatNotifyInitialized=true;
  state.chatNotifyCursor=Number(r.last_id||0);
  state.chatNotifications=incoming.slice().reverse();
  updateNotifications();
  updateFloatingChatBadge();
  if(!$('#floating-chat-panel')?.classList.contains('hidden')){
    const draft=$('#floating-chat-input')?.value||'';
    renderFloatingChat();
    if(draft&&$('#floating-chat-input'))$('#floating-chat-input').value=draft;
  }
  if(fresh.length){
    const newest=fresh[fresh.length-1];
    const preview=String(newest.message||'').replace(/\s+/g,' ').slice(0,90);
    toast(`💬 ${newest.sender_name||'Tin nhắn mới'}: ${preview}${String(newest.message||'').length>90?'…':''}`);
  }
}

function notificationItems(){
  const role=state.session?.user?.role;
  const chat=state.chatNotifications||[];
  const care=state.loanCareReminders||[];
  const base=(role==='admin'||role==='sup')?(state.completionAlerts||[]):role==='sale'?(state.kpiAlerts||[]):[];
  return [...chat,...care,...base];
}
function notificationStorageKey(){
  const u=state.session?.user||{};
  return `a4_notification_reads_${u.role||'user'}_${u.id||u.username||'unknown'}`;
}
function notificationAlertKey(x){
  if(x?.type==='CHAT_MESSAGE') return ['CHAT_MESSAGE',x.id||''].join('|');
  if(x?.type==='LOAN_CARE_REMINDER') return ['LOAN_CARE_REMINDER',x.id||'',x.reminder_type||'',x.due_date||''].join('|');
  if(x?.type==='KPI_MISSED') return ['KPI_MISSED',x.user_id||'',x.date||''].join('|');
  return ['DATA_COMPLETE',x.user_id||x.username||x.display_name||'',x.last_call_at||'',Number(x.archived_count||0)].join('|');
}
function notificationReadSet(){
  try{return new Set(JSON.parse(localStorage.getItem(notificationStorageKey())||'[]'));}catch{return new Set();}
}
function saveNotificationReadSet(set){
  localStorage.setItem(notificationStorageKey(),JSON.stringify([...set].slice(-500)));
}
function markNotificationRead(item){
  const set=notificationReadSet(); set.add(notificationAlertKey(item)); saveNotificationReadSet(set);
}
function markAllNotificationsRead(){
  const set=notificationReadSet(); notificationItems().forEach(x=>set.add(notificationAlertKey(x))); saveNotificationReadSet(set); updateNotifications();
}
function updateNotifications(){
  const wrap=$('#notification-wrap'), count=$('#notification-count'), panel=$('#notification-panel'), button=$('#notification-button');
  if(!wrap||!count||!panel||!button) return;
  const role=state.session?.user?.role, enabled=!!state.session?.user;
  wrap.classList.toggle('hidden',!enabled);
  if(!enabled){panel.classList.add('hidden');button.classList.remove('has-unread');return;}
  const items=notificationItems(), read=notificationReadSet();
  const unread=items.filter(x=>!read.has(notificationAlertKey(x)));
  count.textContent=unread.length; count.classList.toggle('hidden',unread.length===0);
  button.classList.toggle('has-unread',unread.length>0);
  const empty='Chưa có thông báo mới.';
  panel.innerHTML=`<div class="notification-head"><div><strong>Thông báo</strong><span>${unread.length} chưa đọc · ${items.length} tổng</span></div><button type="button" class="notification-read-all" id="notification-read-all" ${unread.length?'':'disabled'}>Đọc tất cả</button></div>${items.map(x=>{const isRead=read.has(notificationAlertKey(x));if(x.type==='CHAT_MESSAGE')return `<button class="notification-item ${isRead?'is-read':'is-unread'}" data-chat-alert-user="${x.sender_user_id||''}" data-chat-alert-id="${x.id||''}"><strong>${isRead?'✓':'💬'} ${esc(x.sender_name||'Tin nhắn mới')}</strong><span>${esc(String(x.message||'').slice(0,120))}</span><small>${x.created_at?fmtDate(x.created_at):''} · Bấm để mở Chat nội bộ.</small></button>`;if(x.type==='LOAN_CARE_REMINDER')return `<button class="notification-item ${isRead?'is-read':'is-unread'}" data-care-alert-id="${x.id||''}" data-care-alert-name="${esc(x.customer_name||'')}"><strong>${isRead?'✓':x.reminder_type==='DUE'?'🔔':'📅'} ${x.reminder_type==='DUE'?'Đến hạn chăm sóc hôm nay':'Còn 3 ngày đến lịch chăm sóc'}</strong><span>${esc(x.customer_name||'Khách hàng')}${x.phone?` · ${esc(x.phone)}`:''}</span><small>Ngày chăm sóc: ${esc(String(x.due_date||'').split('-').reverse().join('/'))} · Bấm để mở Chăm sóc khách hàng.</small></button>`;if(x.type==='KPI_MISSED')return `<button class="notification-item ${isRead?'is-read':'is-unread'}" data-kpi-alert-date="${esc(x.date)}"><strong>${isRead?'✓':'⚠'} KPI ngày ${shortDate(x.date)} chưa đạt</strong><span>${esc(x.detail)}</span><small>Bấm để xem chi tiết KPI của ngày này.</small></button>`;return `<button class="notification-item ${isRead?'is-read':'is-unread'}" data-alert-user="${x.user_id||''}" data-alert-team="${x.team_id||''}"><strong>${isRead?'✓':'●'} ${esc(x.display_name)}</strong><span>${esc(x.team||'Chưa có Team')} · Đã gọi hết Data</span><small>${Number(x.archived_count||0)} Data đã gọi/lưu trữ${x.last_call_at?` · Lần gọi cuối ${fmtDate(x.last_call_at)}`:''}</small></button>`}).join('')||`<div class="notification-empty">${empty}</div>`}`;
  const readAll=$('#notification-read-all',panel); if(readAll) readAll.onclick=async e=>{e.stopPropagation();markAllNotificationsRead();try{await API.request('/loan-care/reminders/read-all',{method:'POST'});state.loanCareReminders=[];}catch(_e){}updateNotifications();toast('Đã đánh dấu tất cả thông báo là đã đọc.');};
  $$('[data-alert-user]',panel).forEach(b=>b.onclick=()=>{const item=items.find(x=>String(x.user_id||'')===String(b.dataset.alertUser||''));if(item) markNotificationRead(item);state.monitorTeam=b.dataset.alertTeam||'';updateNotifications();panel.classList.add('hidden');navigate('crm');});
  $$('[data-kpi-alert-date]',panel).forEach(b=>b.onclick=()=>{const item=items.find(x=>x.type==='KPI_MISSED'&&x.date===b.dataset.kpiAlertDate);if(item) markNotificationRead(item);state.dashboardDate=b.dataset.kpiAlertDate||addDays(todayISO(),-1);updateNotifications();panel.classList.add('hidden');navigate('kpi');});
  $$('[data-chat-alert-user]',panel).forEach(b=>b.onclick=async()=>{const item=items.find(x=>x.type==='CHAT_MESSAGE'&&String(x.id)===String(b.dataset.chatAlertId));if(item)markNotificationRead(item);updateNotifications();panel.classList.add('hidden');await openFloatingChatWith(b.dataset.chatAlertUser);});
  $$('[data-care-alert-id]',panel).forEach(b=>b.onclick=async()=>{const item=items.find(x=>x.type==='LOAN_CARE_REMINDER'&&String(x.id)===String(b.dataset.careAlertId));if(item){markNotificationRead(item);try{await API.request(`/loan-care/reminders/${item.id}/read`,{method:'POST'})}catch(_e){} state.loanCareReminders=(state.loanCareReminders||[]).filter(x=>String(x.id)!==String(item.id));}state.loanCareSearch=b.dataset.careAlertName||'';updateNotifications();panel.classList.add('hidden');navigate('loanCare');});
}

function isMobileLayout(){return window.matchMedia&&window.matchMedia('(max-width:1024px)').matches;}
function closeMobileSidebar(){
  const sidebar=$('#sidebar'),backdrop=$('#mobile-sidebar-backdrop'),btn=$('#mobile-menu-button');
  if(sidebar) sidebar.classList.remove('mobile-open');
  if(backdrop) backdrop.classList.add('hidden');
  if(btn) btn.setAttribute('aria-expanded','false');
}
function toggleMobileSidebar(force){
  if(!isMobileLayout()||state.page==='apps') return;
  const sidebar=$('#sidebar'),backdrop=$('#mobile-sidebar-backdrop'),btn=$('#mobile-menu-button');
  if(!sidebar||!backdrop||!btn) return;
  const open=typeof force==='boolean'?force:!sidebar.classList.contains('mobile-open');
  sidebar.classList.toggle('mobile-open',open);
  backdrop.classList.toggle('hidden',!open);
  btn.setAttribute('aria-expanded',open?'true':'false');
}
function mobileNavItems(){
  const role=state.session?.user?.role||'sale';
  if((role==='admin'||role==='sup')) return [['dashboard',uiIcon('dashboard'),'Tổng quan'],['crm',uiIcon('call'),'Cuộc gọi'],['warehouseAdmin',uiIcon('warehouse'),'Kho'],['kpi',uiIcon('kpi'),'KPI']];
  if(role==='teamlead') return [['dashboard',uiIcon('dashboard'),'Tổng quan'],['crm',uiIcon('call'),'Cuộc gọi'],['lead',uiIcon('lead'),'Lead'],['followup',uiIcon('calendar'),'Gọi lại']];
  return [['dashboard',uiIcon('dashboard'),'Tổng quan'],['telesale',uiIcon('call'),'Bàn gọi'],['lead',uiIcon('lead'),'Lead'],['followup',uiIcon('calendar'),'Gọi lại']];
}
function renderMobileBottomNav(active){
  const nav=$('#mobile-bottom-nav'); if(!nav) return;
  if(!isMobileLayout()||!state.session||state.page==='apps'){nav.classList.add('hidden');nav.innerHTML='';return;}
  const items=mobileNavItems();
  nav.innerHTML=items.map(([id,ic,label])=>`<button type="button" class="mobile-nav-item ${active===id?'active':''}" data-mobile-nav="${id}"><span class="mobile-nav-icon">${ic}</span><span class="mobile-nav-label">${label}</span></button>`).join('')+`<button type="button" class="mobile-nav-item" data-mobile-menu="1"><span class="mobile-nav-icon">☰</span><span class="mobile-nav-label">Thêm</span></button>`;
  nav.classList.remove('hidden');
  $$('[data-mobile-nav]',nav).forEach(b=>b.onclick=()=>navigate(b.dataset.mobileNav));
  const more=$('[data-mobile-menu]',nav); if(more) more.onclick=()=>toggleMobileSidebar();
}

function showLogin(){ closeMobileSidebar(); stopFloatingChatPolling?.(); document.getElementById('floating-chat-root')?.remove(); const nav=$('#mobile-bottom-nav'); if(nav) nav.classList.add('hidden'); $('#login-screen').classList.remove('hidden'); $('#app').classList.add('hidden'); }
function showApp(){
  // Do not carry Admin's staff statistics into another user's session on the same browser.
  invalidateWarehousePending();state.staffTeamFilter='';state.staffSearch='';state.warehouseSection='categories';state.warehouseAnalytics=[];state.warehouseRoundAnalytics=[];state.lastWarehouseAnalyticsRefresh=0;
  // V6.4: never carry Lead rows/filters between Admin, Teamlead and Sale sessions on the same browser.
  state.leads=[];state.leadLoadedAt=0;state.leadLoading=false;state.leadError='';state.leadSearch='';state.leadStatusFilter='';state.leadTeamFilter='';state.leadEmployeeFilter='';state.leadDateFrom='';state.leadDateTo='';
  state.dashboardViewDate=todayISO();state.dashboardDrillTeamId='';state.dashboardDrillUserId='';state.dashboardRangeLoading=false;
  stopChatPolling();state.chatContacts=[];state.chatContactsAt=0;state.chatContactsLoading=false;state.chatError='';state.chatContactSearch='';state.chatSelectedUserId='';state.chatMessages=[];state.chatLoading=false;state.chatHasOlder=false;state.chatOldestId=0;state.chatNewestId=0;
  state.chatNotifyCursor=0;state.chatNotifyInitialized=false;state.chatNotifications=[];if(state.chatNotifyTimer)clearInterval(state.chatNotifyTimer);state.chatNotifyTimer=null;
  $('#login-screen').classList.add('hidden'); $('#app').classList.remove('hidden');
  state.filters={q:'',team:'',owner:'',status:'',source:''}; state.crmView='list'; state.monitorTeam=''; state.employeeTeamFilter='';
  const u=state.session.user; $('#user-name').textContent=u.display_name; $('#avatar').textContent=initials(u.display_name); const roleHint=$('.user-button-copy small'); if(roleHint) roleHint.textContent=staffRoleLabel(u); updateMode(); updateNotifications(); startNotificationPolling(); navigate('dashboard'); scheduleV84BackgroundPrefetch(); setTimeout(()=>resumePersistentBulkJob(),500);
}
function updateMode(){ const p=$('#mode-pill'); if(!p)return; const map={d1:['● D1 Online','rgba(0,190,130,.18)'],connecting:['● Đang kết nối','rgba(22,119,255,.12)'],offline:['● Mất kết nối','rgba(225,76,76,.14)'],demo:['● Demo Local','rgba(245,166,35,.14)']}; const v=map[state.mode]||map.offline;p.textContent=v[0];p.style.background=v[1]; }

$('#login-form').addEventListener('submit',async e=>{
  e.preventDefault();const username=$('#login-username').value.trim(),password=$('#login-password').value;
  if(explicitDemoMode()){
    DemoStore.load();state.mode='demo';updateMode();
    const pass={admin:'admin123',lead5:'lead123',sale5:'sale123'}[username],user=state.users.find(x=>x.username===username);
    if(!user||password!==pass){toast('Sai tài khoản hoặc mật khẩu demo.','bad');return;}
    state.session={token:'demo',user};localStorage.setItem('a4_session',JSON.stringify(state.session));return showApp();
  }
  if(state.mode!=='d1'){
    updateMode();const ok=await API.probe(2);updateMode();
    if(!ok){toast('Không kết nối được máy chủ D1. Hệ thống không chuyển sang Demo Local.','bad');return;}
  }
  try{
    const res=await API.request('/login',{method:'POST',body:JSON.stringify({username,password})});
    state.session=res;state.lastWarehouseAnalyticsRefresh=0;localStorage.setItem('a4_session',JSON.stringify(res));
    await syncFromApi({fast:true});showApp();
  }catch(err){
    if(err?.status===401||err?.status===403){localStorage.removeItem('a4_session');state.session=null;}
    toast('Đăng nhập thất bại: '+err.message,'bad');
  }
});

$('#logout-btn').addEventListener('click',()=>{stopChatPolling();localStorage.removeItem('a4_session');state.session=null;state.leads=[];state.leadLoadedAt=0;state.leadTeamFilter='';state.leadEmployeeFilter='';state.leadDateFrom='';state.leadDateTo='';state.warehouseAnalytics=[];state.warehouseRoundAnalytics=[];state.lastWarehouseAnalyticsRefresh=0;invalidateWarehousePending();if(state.notificationTimer)clearInterval(state.notificationTimer);state.notificationTimer=null;if(state.chatNotifyTimer)clearInterval(state.chatNotifyTimer);state.chatNotifyTimer=null;if(state.loanCareReminderTimer)clearInterval(state.loanCareReminderTimer);state.loanCareReminderTimer=null;state.loanCareReminders=[];state.chatNotifyCursor=0;state.chatNotifyInitialized=false;state.chatNotifications=[];$('#user-menu').classList.add('hidden');$('#notification-panel')?.classList.add('hidden');showLogin();});
$('#change-password-btn').addEventListener('click',()=>{ $('#user-menu').classList.add('hidden'); openChangePasswordForm(); });
$('#user-menu-button').addEventListener('click',()=>$('#user-menu').classList.toggle('hidden'));
$('#notification-button').addEventListener('click',()=>$('#notification-panel').classList.toggle('hidden'));
document.addEventListener('click',e=>{const wrap=$('#notification-wrap');if(wrap&&!wrap.contains(e.target))$('#notification-panel').classList.add('hidden');});
$('#apps-button').addEventListener('click',()=>navigate('apps'));
const mobileMenuButton=$('#mobile-menu-button'); if(mobileMenuButton) mobileMenuButton.addEventListener('click',()=>toggleMobileSidebar());
const mobileBackdrop=$('#mobile-sidebar-backdrop'); if(mobileBackdrop) mobileBackdrop.addEventListener('click',closeMobileSidebar);
window.addEventListener('resize',()=>{if(!isMobileLayout()) closeMobileSidebar(); renderMobileBottomNav(state.page);});
$('[data-close-modal]').addEventListener('click',closeCustomerModal);
$('#customer-modal').addEventListener('click',e=>{if(e.target.id==='customer-modal')closeCustomerModal();});
$('[data-close-admin-modal]').addEventListener('click',closeAdminModal);
$('#admin-modal').addEventListener('click',e=>{if(e.target.id==='admin-modal')closeAdminModal();});

const APPS = [
  {id:'dashboard',icon:uiIcon('dashboard'),title:'Bảng điều khiển',desc:'Tổng quan hoạt động theo khoảng ngày'},
  {id:'customerdb',icon:uiIcon('customers'),title:'Chi tiết cuộc gọi',desc:'Theo dõi cuộc gọi theo Team, nhân viên và khoảng ngày'},
  {id:'callhistory',icon:uiIcon('call'),title:'Lịch sử cuộc gọi',desc:'Tra cứu lịch sử xử lý và kết quả gọi'},
  {id:'lead',icon:uiIcon('lead'),title:'Quản lý Lead',desc:'Kiểm soát Lead → Login App → Giải ngân'},
  {id:'followup',icon:uiIcon('calendar'),title:'Follow-up',desc:'Khách cần gọi lại và lịch hẹn sắp tới'},
  {id:'teamManagement',icon:uiIcon('users'),title:'Quản lý nhóm và nhân viên',desc:'Team, tài khoản và quyền truy cập'},
  {id:'kpi',icon:uiIcon('kpi'),title:'KPI & Hiệu suất',desc:'Theo dõi hiệu suất theo khoảng ngày, Team và nhân viên'},
  {id:'warehouseAdmin',icon:uiIcon('warehouse'),title:'Kho dữ liệu',desc:'Kho tổng hoặc Kho Team theo quyền tài khoản'},
  {id:'io',icon:uiIcon('import'),title:'Nhập / Xuất dữ liệu',desc:'Import dữ liệu và quản lý luồng dữ liệu'},
  {id:'audit',icon:uiIcon('settings'),title:'Nhật ký thao tác',desc:'Theo dõi các thay đổi quan trọng'},
  {id:'settings',icon:uiIcon('settings'),title:'Cài đặt hệ thống',desc:'Cấu hình hệ thống và trạng thái nghiệp vụ'}
];


function normalizeGlobalSearch(value){
  return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLowerCase().trim();
}
function renderGlobalSearchResults(){
  const input=$('#global-search'),panel=$('#global-search-panel');
  if(!input||!panel||!state.session){return;}
  const q=normalizeGlobalSearch(input.value);
  const role=state.session.user.role,allowed=allowedPagesForRole(role);
  const modules=APPS.filter(a=>allowed.has(a.id)).map(a=>appMetaForRole(a,role)).filter(a=>!q||normalizeGlobalSearch(`${a.title} ${a.desc}`).includes(q)).slice(0,6);
  let customers=[];
  if(q.length>=2){
    customers=visibleCustomers().filter(c=>normalizeGlobalSearch(`${c.name} ${c.phone} ${c.owner} ${c.code||''}`).includes(q)).slice(0,5);
  }
  if(!modules.length&&!customers.length){panel.innerHTML='<div class="global-search-empty">Không tìm thấy kết quả phù hợp.</div>';panel.classList.remove('hidden');return;}
  panel.innerHTML=`${modules.length?`<div class="global-search-group"><span>CHỨC NĂNG</span>${modules.map(a=>`<button type="button" class="global-search-result" data-gs-page="${a.id}"><i>${a.icon}</i><div><strong>${esc(a.title)}</strong><small>${esc(a.desc)}</small></div><b>→</b></button>`).join('')}</div>`:''}${customers.length?`<div class="global-search-group"><span>KHÁCH HÀNG TRONG PHẠM VI</span>${customers.map(c=>`<button type="button" class="global-search-result customer" data-gs-customer="${c.id}"><i>${uiIcon('customers')}</i><div><strong>${esc(c.name||'Khách hàng')}</strong><small>${esc(c.phone||'')} · ${esc(c.owner||'Chưa phân')}</small></div><b>↗</b></button>`).join('')}</div>`:''}`;
  panel.classList.remove('hidden');
  $$('[data-gs-page]',panel).forEach(b=>b.onclick=()=>{panel.classList.add('hidden');input.value='';navigate(b.dataset.gsPage)});
  $$('[data-gs-customer]',panel).forEach(b=>b.onclick=()=>{panel.classList.add('hidden');input.value='';openCustomerModal(Number(b.dataset.gsCustomer))});
}
function setupGlobalSearch(){
  const input=$('#global-search'),wrap=$('.global-search-wrap'),panel=$('#global-search-panel');
  if(!input||!panel)return;
  input.addEventListener('focus',renderGlobalSearchResults);
  input.addEventListener('input',renderGlobalSearchResults);
  input.addEventListener('keydown',e=>{
    if(e.key==='Escape'){panel.classList.add('hidden');input.blur();}
    if(e.key==='Enter'){
      const first=panel.querySelector('[data-gs-page],[data-gs-customer]');
      if(first){e.preventDefault();first.click();}
    }
  });
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&String(e.key).toLowerCase()==='k'){e.preventDefault();input.focus();input.select();renderGlobalSearchResults();}});
  document.addEventListener('click',e=>{if(wrap&&!wrap.contains(e.target))panel.classList.add('hidden');});
}
setupGlobalSearch();
const topAppsIcon=$('.topbar-grid-icon');if(topAppsIcon)topAppsIcon.innerHTML=uiIcon('apps');

function appMetaForRole(app,role){
  if(app.id==='crm'&&role!=='sale') return {...app,icon:uiIcon('call'),title:'Chi tiết cuộc gọi',desc:'Tổng hợp lượt gọi và kết quả theo nhân viên'};
  if(app.id==='import'&&role==='teamlead') return {...app,icon:uiIcon('import'),title:'Nhập Data vào Team',desc:'Đưa dữ liệu mới vào Kho riêng của Team'};
  if(app.id==='warehouseAdmin'&&role==='teamlead') return {...app,icon:uiIcon('warehouse'),title:'Kho Data Team',desc:'Kho dữ liệu và phân bổ trong phạm vi Team'};
  return app;
}
function pageTitleForRole(page,role){
  const app=APPS.find(x=>x.id===page);
  return app?appMetaForRole(app,role).title:'An Đông 4';
}

function legacyAllowedPagesForRole(role){
  if((role==='admin'||role==='sup')) return new Set(['apps','dashboard','crm','followup','lead','chat','kpi','employees','import','warehouseAdmin','audit','settings']);
  if(role==='teamlead') return new Set(['apps','dashboard','crm','followup','lead','chat','kpi','employees','import','warehouseAdmin']);
  return new Set(['apps','dashboard','crm','telesale','followup','lead','chat','kpi']);
}
function legacyNavigate(page){
  closeMobileSidebar();
  if(page!=='chat') stopChatPolling();
  const role=state.session?.user?.role||'sale';
  if(!allowedPagesForRole(role).has(page)) page='dashboard';
  state.page=page; state.app=page==='apps'?null:page;
  $('#sidebar').classList.remove('hidden');
  $('#current-app-title').textContent=page==='apps'?'Tất cả chức năng':pageTitleForRole(page,role);
  $('#breadcrumb').textContent='An Đông 4';
  renderSidebar(page);
  renderMobileBottomNav(page);
  render();
}
function legacyRenderSidebar(active){
  const role=state.session.user.role;
  const crmLabel=role==='sale'?'Data khách hàng':'Chi tiết cuộc gọi';
  const telesaleGroup=role==='sale'
    ? [['crm',uiIcon('customers'),crmLabel],['telesale',uiIcon('call'),'Call Workspace'],['followup',uiIcon('calendar'),'Follow-up'],['lead',uiIcon('lead'),'Lead'],['chat',uiIcon('chat'),'Trao đổi nội bộ']]
    : [['crm',uiIcon('call'),crmLabel],['followup',uiIcon('calendar'),'Follow-up'],['lead',uiIcon('lead'),'Lead'],['chat',uiIcon('chat'),'Trao đổi nội bộ']];
  const adminManage=[['kpi',uiIcon('kpi'),'KPI & Báo cáo'],['employees',uiIcon('users'),'Nhân viên & Nhóm'],['import',uiIcon('import'),'Nhập dữ liệu'],['warehouseAdmin',uiIcon('warehouse'),'Kho & Phân bổ'],['audit',uiIcon('settings'),'Nhật ký thao tác'],['settings',uiIcon('settings'),'Cài đặt hệ thống']];
  const teamleadManage=[['kpi',uiIcon('kpi'),'KPI & Báo cáo'],['employees',uiIcon('users'),'Nhân viên & Nhóm'],['warehouseAdmin',uiIcon('warehouse'),'Kho Data Team']];
  const items=[
    ['Tổng quan',[['dashboard',uiIcon('dashboard'),'Dashboard']]],
    ['Vận hành',telesaleGroup],
    ['Quản trị',role==='teamlead'?teamleadManage:adminManage]
  ];
  const allowed=allowedPagesForRole(role);
  const roleLabel=staffRoleLabel(state.session.user);
  const teamLabel=state.session.user.team&&state.session.user.team!=='Tất cả'?state.session.user.team:'Toàn hệ thống';
  $('#sidebar-menu').innerHTML=`
    <div class="sidebar-brand"><div class="sidebar-brand-mark">A4</div><div><strong>An Đông 4</strong><span>Shinhan Finance</span></div></div>
    <div class="sidebar-context"><span>PHẠM VI LÀM VIỆC</span><strong>${esc(teamLabel)}</strong><small>${esc(roleLabel)}</small></div>
    <div class="sidebar-nav-scroll">${items.map(([title,group])=>{const visible=group.filter(([id])=>allowed.has(id));return visible.length?`<div class="menu-section"><div class="menu-title">${title}</div>${visible.map(([id,ic,label])=>`<button class="menu-item ${id===active?'active':''}" data-nav="${id}"><span class="menu-item-icon">${ic}</span><span class="menu-item-label">${label}</span><span class="menu-item-arrow">›</span></button>`).join('')}</div>`:'';}).join('')}</div>
    <div class="sidebar-foot"><span class="sidebar-foot-dot"></span><div><strong>${state.mode==='d1'?'D1 Database đang kết nối':'Chế độ Demo Local'}</strong><small>Phân quyền backend đang được áp dụng</small></div></div>`;
  $$('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
}
function legacyRender(){
  const main=$('#main');
  $('#app')?.classList.remove('dashboard-redesign');
  ({apps:renderApps,dashboard:renderDashboard,crm:renderCRM,telesale:renderTelesale,followup:renderFollowup,lead:renderLeads,chat:renderChat,kpi:renderKPI,employees:renderEmployees,import:renderImport,warehouseAdmin:renderWarehouseAdmin,audit:renderAuditLogs,settings:renderSettings}[state.page]||renderApps)(main);
}

function isAssignmentExpired(c){return c?.data_state==='ASSIGNED'&&c?.assignment_deadline&&String(c.assignment_deadline).slice(0,10)<todayISO();}
function visibleCustomers(){
  const u=state.session.user;
  let list=[...state.customers];
  if(u.role==='teamlead') list=list.filter(c=>c.team===u.team);
  if(u.role==='sale') list=list.filter(c=>c.owner===u.display_name&&!isAssignmentExpired(c));
  return list;
}
function renderApps(main){
  const role=state.session.user.role;
  const allowed=allowedPagesForRole(role);
  const apps=APPS.filter(a=>allowed.has(a.id)&&!(role==='teamlead'&&a.id==='import')).map(a=>appMetaForRole(a,role));
  const roleLabel=staffRoleLabel(state.session.user);
  main.innerHTML=`<div class="app-launcher enterprise-launcher">
    <section class="launcher-hero">
      <div class="launcher-hero-copy"><span class="launcher-kicker">AN ĐÔNG 4 · WORKSPACE</span><h1>An Đông 4</h1><p>Chọn chức năng cần sử dụng.</p><div class="launcher-badges"><span>${esc(roleLabel)}</span><span>${esc(state.session.user.team||'Toàn hệ thống')}</span></div></div>
      <div class="launcher-hero-mark"><span>CC</span><small>CRM</small></div>
    </section>
    <div class="launcher-section-head"><div><span>CHỨC NĂNG</span><h2>Không gian làm việc</h2></div><small>${apps.length} module khả dụng theo quyền</small></div>
    <div class="app-grid">${apps.map((a,i)=>`<button class="app-tile" data-open-app="${a.id}"><div class="app-tile-top"><div class="app-icon">${a.icon}</div><span class="app-index">${String(i+1).padStart(2,'0')}</span></div><div class="app-tile-copy"><h3>${a.title}</h3><p>${a.desc}</p></div><span class="app-tile-open">Mở chức năng <b>→</b></span></button>`).join('')}</div>
  </div>`;
  $$('[data-open-app]').forEach(x=>x.onclick=()=>navigate(x.dataset.openApp));
}

function dateKey(v){if(!v)return '';const s=String(v);if(/^\d{4}-\d\d-\d\d$/.test(s))return s;return vnParts(v)?.date||s.slice(0,10);}
function addDays(dateStr,delta){const d=new Date(dateStr+'T12:00:00');d.setDate(d.getDate()+delta);return d.toISOString().slice(0,10);}
function shortDate(dateStr){const [y,m,d]=String(dateStr).split('-');return `${d}/${m}`;}
function latestCallsByCustomer(rows){
  const latest=new Map();
  for(const row of rows||[]){
    const key=Number(row.customer_id)||String(row.customer_id||'');
    const prev=latest.get(key);
    if(!prev||String(row.created_at||'')>String(prev.created_at||'')||(String(row.created_at||'')===String(prev.created_at||'')&&Number(row.id||0)>Number(prev.id||0))) latest.set(key,row);
  }
  return [...latest.values()];
}
function dailyStats(dateStr){
  const customers=visibleCustomers();
  const ids=new Set(customers.map(c=>Number(c.id)));
  const calls=state.calls.filter(x=>dateKey(x.created_at)===dateStr && ids.has(Number(x.customer_id)));
  // Mỗi KH chỉ tính một lần theo kết quả mới nhất trong ngày. Tỷ lệ kết nối dùng KH đã gọi,
  // không dùng tổng số lượt gọi vì một KH có thể phát sinh nhiều lần gọi.
  const latest=latestCallsByCustomer(calls);
  const connected=latest.filter(x=>String(x.status).startsWith('Y')).length;
  const called=latest.length;
  const y01=latest.filter(x=>x.status==='Y01').length;
  const y02=latest.filter(x=>x.status==='Y02').length;
  return {date:dateStr,calls:calls.length,called,connected,rate:called?Math.round(connected/called*100):0,y01,y02};
}
function dateRange(start,end,maxDays=366){
  const out=[]; let cur=start; let guard=0;
  while(cur<=end && guard<maxDays){out.push(cur);cur=addDays(cur,1);guard++;}
  return out;
}
function rangeStats(from,to){
  const days=dateRange(from,to); const rows=days.map(d=>dailyStats(d));
  const calls=rows.reduce((a,x)=>a+x.calls,0);
  const ids=new Set(visibleCustomers().map(c=>Number(c.id)));
  const rangeCalls=state.calls.filter(x=>{const d=dateKey(x.created_at);return d>=from&&d<=to&&ids.has(Number(x.customer_id));});
  const latest=latestCallsByCustomer(rangeCalls);
  const called=latest.length;
  const connected=latest.filter(x=>String(x.status).startsWith('Y')).length;
  const y01=latest.filter(x=>x.status==='Y01').length, y02=latest.filter(x=>x.status==='Y02').length;
  return {days,rows,calls,called,connected,rate:called?Math.round(connected/called*100):0,y01,y02};
}
function callStatusCounts(rows){
  const out={}; Object.keys(STATUS_LABELS).filter(k=>k!=='NEW').forEach(k=>out[k]=0);
  rows.forEach(x=>{if(out[x.status]!==undefined)out[x.status]++;});
  return out;
}
function statusSummaryCells(counts){
  return Object.keys(STATUS_LABELS).filter(k=>k!=='NEW').map(k=>`<td><span class="status ${k.toLowerCase()}">${counts[k]||0}</span></td>`).join('');
}
function startOfWeekISO(dateStr=todayISO()){
  const d=new Date(dateStr+'T12:00:00');
  const offset=(d.getDay()+6)%7;
  d.setDate(d.getDate()-offset);
  return d.toISOString().slice(0,10);
}
function startOfMonthISO(dateStr=todayISO()){
  return String(dateStr).slice(0,8)+'01';
}
function endOfMonthISO(dateStr=todayISO()){
  const d=new Date(startOfMonthISO(dateStr)+'T12:00:00');
  d.setMonth(d.getMonth()+1);d.setDate(0);
  return d.toISOString().slice(0,10);
}
function monthLabelVI(dateStr){
  const [y,m]=String(dateStr||todayISO()).split('-');
  return `Tháng ${Number(m)}/${y}`;
}
function periodMini(title,from,to,stats){
  return `<div class="period-mini"><div class="period-mini-head"><strong>${esc(title)}</strong><span>${shortDate(from)} → ${shortDate(to)}</span></div><div class="period-mini-values"><div><b>${stats.calls}</b><span>Calls</span></div><div><b>${stats.rate}%</b><span>Kết nối</span></div><div><b>${stats.y01}</b><span>Y01</span></div><div><b>${stats.y02}</b><span>Y02</span></div></div></div>`;
}
function dashboardMetricTrend(current,previous,{inverse=false}={}){
  const c=Number(current||0),p=Number(previous||0);
  if(!p&&!c)return {text:'Không đổi so với kỳ trước',dir:'flat'};
  if(!p&&c)return {text:'+100% so với kỳ trước',dir:inverse?'bad':'good'};
  const delta=Math.round((c-p)/Math.max(1,Math.abs(p))*100);
  const good=inverse?delta<=0:delta>=0;
  return {text:`${delta>0?'+':''}${delta}% so với kỳ trước`,dir:delta===0?'flat':good?'good':'bad'};
}
function dashboardKpiCard(icon,label,value,sub,trend,tone='plum'){
  return `<div class="dash-kpi-card tone-${tone}"><div class="dash-kpi-icon">${icon}</div><div class="dash-kpi-copy"><span class="dash-kpi-label">${esc(label)}</span><strong class="dash-kpi-value">${esc(value)}</strong><div class="dash-kpi-meta">${sub?`<span>${esc(sub)}</span>`:''}${trend?`<span class="dash-trend ${trend.dir}">${trend.dir==='good'?'↑':trend.dir==='bad'?'↓':'•'} ${esc(trend.text)}</span>`:''}</div></div></div>`;
}
function aggregateDashboardRows(rows,mode){
  const source=rows||[];
  if(mode==='range')return source.map(r=>({...r,label:shortDate(r.date)}));
  const map=new Map();
  for(const r of source){
    let key,label;
    if(mode==='week'){
      const ws=startOfWeekISO(r.date); key=ws; label=`${shortDate(ws)}–${shortDate(addDays(ws,6))}`;
    }else{
      key=String(r.date).slice(0,7); const [y,m]=key.split('-'); label=`T${Number(m)}/${y}`;
    }
    if(!map.has(key))map.set(key,{key,label,calls:0,connected:0,y01:0,y02:0});
    const b=map.get(key); b.calls+=Number(r.calls||0);b.connected+=Number(r.connected||0);b.y01+=Number(r.y01||0);b.y02+=Number(r.y02||0);
  }
  return [...map.values()].map(x=>({...x,rate:x.calls?Math.round(x.connected*100/x.calls):0}));
}
function dashboardGroupedBarChart(rows){
  const data=rows||[];
  if(!data.length)return `<div class="dash-chart-empty">Chưa có dữ liệu trong khoảng đang chọn.</div>`;
  const W=Math.max(980,data.length*108),H=300,padL=52,padR=24,padT=32,padB=52,plotH=H-padT-padB,plotW=W-padL-padR;
  const maxValue=Math.max(10,...data.flatMap(r=>[Number(r.calls||0),Number(r.connected||0),Number(r.y01||0),Number(r.y02||0)]));
  const roundedMax=Math.max(10,Math.ceil(maxValue/10)*10);
  const xStep=plotW/Math.max(1,data.length), groupW=Math.min(74,Math.max(44,xStep*.70)), gap=3, barW=(groupW-gap*3)/4;
  const y=v=>padT+plotH-(Number(v||0)/roundedMax*plotH);
  const grid=[0,.25,.5,.75,1].map(fr=>{const yy=padT+plotH-plotH*fr;return `<line x1="${padL}" x2="${W-padR}" y1="${yy}" y2="${yy}" class="dash-grid-line"/><text x="${padL-10}" y="${yy+4}" text-anchor="end" class="dash-axis-text">${Math.round(roundedMax*fr)}</text>`}).join('');
  const keys=[['calls','calls'],['connected','connect'],['y01','y01'],['y02','y02']];
  const groups=data.map((r,i)=>{
    const center=padL+xStep*(i+.5), left=center-groupW/2;
    const bars=keys.map(([key,cls],j)=>{const v=Number(r[key]||0),x=left+j*(barW+gap),yy=y(v),h=padT+plotH-yy;return `<g><rect class="dash-group-bar ${cls}" x="${x.toFixed(1)}" y="${yy.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(v?2:0,h).toFixed(1)}" rx="3"><title>${esc(r.label||'')}: ${key==='calls'?'Calls':key==='connected'?'Kết nối':key.toUpperCase()} ${v}</title></rect>${v?`<text x="${(x+barW/2).toFixed(1)}" y="${Math.max(12,yy-5).toFixed(1)}" text-anchor="middle" class="dash-bar-value ${cls}">${v}</text>`:''}</g>`}).join('');
    return `${bars}<text x="${center.toFixed(1)}" y="${H-18}" text-anchor="middle" class="dash-axis-text dash-x-label">${esc(r.label||'')}</text>`;
  }).join('');
  return `<div class="dash-chart-scroll"><svg class="dash-grouped-chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMinYMid meet" role="img" aria-label="Biểu đồ cột hiệu suất cuộc gọi">${grid}${groups}<text x="16" y="${padT+plotH/2}" transform="rotate(-90 16 ${padT+plotH/2})" text-anchor="middle" class="dash-axis-title">Số lượng</text></svg></div>`;
}
function dashboardStatusChip(key,value){return `<span class="dash-status-chip ${String(key).toLowerCase()}" title="${esc(STATUS_LABELS[key]||key)}">${Number(value||0)}</span>`;}
function dashboardTeamShortName(team){
  const name=String(team?.name||team||'').trim();
  const m=name.match(/(?:mobility|team|m)\s*[-_. ]*([0-9]+)/i);
  return m?`M${Number(m[1])}`:name;
}
function dashboardTeamSortValue(team){
  const m=dashboardTeamShortName(team).match(/M(\d+)/i);
  return m?Number(m[1]):999;
}
function dashboardStats(rows){
  const source=rows||[],latest=latestCallsByCustomer(source),counts=callStatusCounts(latest);
  const connected=latest.filter(x=>String(x.status||'').startsWith('Y')).length,called=latest.length;
  return {calls:source.length,called,connected,rate:called?Math.round(connected*100/called):0,y01:Number(counts.Y01||0),y02:Number(counts.Y02||0),y03:Number(counts.Y03||0)};
}
function dashboardCallsForTeam(rows,team){
  if(!team)return [];
  return (rows||[]).filter(x=>Number(x.team_id)===Number(team.id)||String(x.team||'')===String(team.name||''));
}
function dashboardCallsForUser(rows,user){
  if(!user)return [];
  return (rows||[]).filter(x=>Number(x.user_id)===Number(user.id)||(!x.user_id&&String(x.owner||'')===String(user.display_name||'')));
}
function dashboardPrimaryMetric(icon,label,value,sub,tone='plum'){
  return `<div class="dash711-metric tone-${tone}"><div class="dash711-metric-top"><span class="dash711-metric-label">${esc(label)}</span><div class="dash711-metric-icon">${icon}</div></div><div class="dash711-metric-body"><strong>${esc(value)}</strong><small>${esc(sub||'')}</small></div><span class="dash711-metric-accent"></span></div>`;
}
function dashboardPairMetric(stats){
  return `<div class="dash711-break-cell dash711-pair"><span class="dash711-cell-label">Y01 / Y02</span><div class="dash711-pair-values"><div><b>${stats.y01}</b><small>Y01</small></div><i></i><div><b>${stats.y02}</b><small>Y02</small></div></div></div>`;
}
function dashboardTeamBreakdownRow(team,stats){
  const short=dashboardTeamShortName(team)||team.name;
  return `<div class="dash711-break-row">
    <button type="button" class="dash711-break-cell dash711-open-cell" data-dashboard-team="${team.id}"><div class="dash713-entity-head"><span class="dash713-entity-avatar">${esc(short)}</span><div><span class="dash711-cell-kicker">TEAM</span><strong>Team ${esc(short)}</strong></div></div><div class="dash711-cell-main">${stats.calls.toLocaleString('vi-VN')}</div><small>Tổng cuộc gọi · bấm để xem dashboard</small><span class="dash711-open-arrow">→</span></button>
    ${dashboardPairMetric(stats)}
    <div class="dash711-break-cell"><span class="dash711-cell-label">Y03</span><div class="dash711-cell-main">${stats.y03}</div><small>KH không nhu cầu</small></div>
    <div class="dash711-break-cell dash711-rate-cell"><span class="dash711-cell-label">Tỷ lệ kết nối</span><div class="dash711-cell-main">${stats.rate}%</div><div class="dash711-progress"><span style="width:${Math.max(0,Math.min(100,stats.rate))}%"></span></div><small>${stats.connected}/${stats.called} KH đã gọi</small></div>
  </div>`;
}
function dashboardEmployeeBreakdownRow(user,stats){
  return `<div class="dash711-break-row">
    <button type="button" class="dash711-break-cell dash711-open-cell" data-dashboard-user="${user.id}"><div class="dash713-entity-head"><span class="dash713-entity-avatar person">${esc(initials(user.display_name))}</span><div><span class="dash711-cell-kicker">NHÂN VIÊN</span><strong>${esc(user.display_name)}</strong></div></div><div class="dash711-cell-main">${stats.calls.toLocaleString('vi-VN')}</div><small>Tổng cuộc gọi · bấm để xem dashboard</small><span class="dash711-open-arrow">→</span></button>
    ${dashboardPairMetric(stats)}
    <div class="dash711-break-cell"><span class="dash711-cell-label">Y03</span><div class="dash711-cell-main">${stats.y03}</div><small>KH không nhu cầu</small></div>
    <div class="dash711-break-cell dash711-rate-cell"><span class="dash711-cell-label">Tỷ lệ kết nối</span><div class="dash711-cell-main">${stats.rate}%</div><div class="dash711-progress"><span style="width:${Math.max(0,Math.min(100,stats.rate))}%"></span></div><small>${stats.connected}/${stats.called} KH đã gọi</small></div>
  </div>`;
}
function dashboardFollowupCount(user,monthFrom,monthTo){
  if(!user)return 0;
  return state.customers.filter(c=>{
    const owned=Number(c.assigned_user_id)===Number(user.id)||(!c.assigned_user_id&&String(c.owner||'')===String(user.display_name||''));
    const d=dateKey(c.follow_up||'');
    return owned&&d&&d>=monthFrom&&d<=monthTo;
  }).length;
}
function dashboardLeadCount(user,monthFrom,monthTo){
  if(!user||!state.leadLoadedAt)return null;
  return (state.leads||[]).filter(x=>{
    const ownerMatch=Number(x.lead_created_by)===Number(user.id)||(!x.lead_created_by&&(Number(x.assigned_user_id)===Number(user.id)||String(x.owner||'')===String(user.display_name||'')));
    const d=dateKey(x.lead_created_at||'');
    return ownerMatch&&d&&d>=monthFrom&&d<=monthTo;
  }).length;
}
function dashboardDateToolbar(viewDate){
  return `<div class="dash711-date-tools"><label><span>Ngày báo cáo</span><input type="date" id="dashboard-view-date" value="${esc(viewDate)}"></label><button type="button" class="btn" id="dashboard-today">Hôm nay</button></div>`;
}
function legacyRenderDashboard(main){
  const role=state.session.user.role;
  const viewDate=state.dashboardViewDate||todayISO();state.dashboardViewDate=viewDate;
  const monthFrom=startOfMonthISO(viewDate),monthTo=endOfMonthISO(viewDate);
  if(state.mode==='d1'&&!isCallsRangeLoaded(monthFrom,monthTo)&&!state.dashboardRangeLoading){
    state.dashboardRangeLoading=true;
    main.innerHTML=`<div class="dashboard-v711"><div class="dash711-loading"><div class="dash711-spinner"></div><strong>Đang tải dữ liệu Dashboard…</strong><span>${esc(monthLabelVI(viewDate))}</span></div></div>`;
    ensureCallsRange(monthFrom,monthTo).then(()=>{state.dashboardRangeLoading=false;if(state.page==='dashboard')renderDashboard(main)}).catch(err=>{state.dashboardRangeLoading=false;toast(err.message,'bad')});
    return;
  }
  const monthRows=state.calls.filter(x=>{const d=dateKey(x.created_at);return d>=monthFrom&&d<=monthTo;});
  const dayRows=monthRows.filter(x=>dateKey(x.created_at)===viewDate);
  const allTeams=[...state.teamObjects].sort((a,b)=>dashboardTeamSortValue(a)-dashboardTeamSortValue(b)||String(a.name).localeCompare(String(b.name),'vi'));

  let drillTeam=null,drillUser=null,view='overview';
  if(role==='sale'){
    drillUser=state.session.user;view='person';state.dashboardDrillTeamId=String(state.session.user.team_id||'');state.dashboardDrillUserId=String(state.session.user.id);
  }else if(role==='teamlead'){
    drillTeam=allTeams.find(t=>Number(t.id)===Number(state.session.user.team_id))||{id:state.session.user.team_id,name:state.session.user.team||'Team'};
    const candidate=state.users.find(u=>u.role==='sale'&&Number(u.id)===Number(state.dashboardDrillUserId)&&Number(u.team_id)===Number(drillTeam.id));
    if(candidate){drillUser=candidate;view='person'}else{state.dashboardDrillUserId='';view='team'}
    state.dashboardDrillTeamId=String(drillTeam.id||'');
  }else{
    drillTeam=allTeams.find(t=>String(t.id)===String(state.dashboardDrillTeamId||''))||null;
    if(!drillTeam){state.dashboardDrillTeamId='';state.dashboardDrillUserId='';view='overview'}
    else{
      const candidate=state.users.find(u=>u.role==='sale'&&Number(u.id)===Number(state.dashboardDrillUserId)&&Number(u.team_id)===Number(drillTeam.id));
      if(candidate){drillUser=candidate;view='person'}else{state.dashboardDrillUserId='';view='team'}
    }
  }

  let scopeDay=dayRows,title='Dashboard Tổng',subtitle=`Tổng hợp theo ngày ${shortDate(viewDate)} và theo ${monthLabelVI(viewDate).toLowerCase()}`;
  let back='';
  if(view==='team'){
    scopeDay=dashboardCallsForTeam(dayRows,drillTeam);const short=dashboardTeamShortName(drillTeam);
    title=`Dashboard Team ${esc(short||drillTeam?.name||'')}`;subtitle=`Hiệu suất Team ${esc(drillTeam?.name||'')} · dữ liệu ngày và tháng`;
    if((role==='admin'||role==='sup'))back='<button class="dash711-back" id="dashboard-back-overview">← Dashboard Tổng</button>';
  }else if(view==='person'){
    scopeDay=dashboardCallsForUser(dayRows,drillUser);title=`Dashboard ${esc(drillUser.display_name)}`;subtitle=`Hiệu suất cá nhân · ${esc(drillUser.team||drillTeam?.name||state.session.user.team||'')}`;
    if(role!=='sale')back='<button class="dash711-back" id="dashboard-back-team">← Dashboard Team</button>';
  }
  const dayStats=dashboardStats(scopeDay);
  const personTop=view==='person';
  const topMetrics=personTop
    ? `${dashboardPrimaryMetric(uiIcon('call'),'Số lượng gọi',dayStats.calls,`Ngày ${shortDate(viewDate)}`,'plum')}${dashboardPrimaryMetric(uiIcon('target'),'Y01',dayStats.y01,'KH có nhu cầu','green')}${dashboardPrimaryMetric(uiIcon('calendar'),'Y02',dayStats.y02,'KH suy nghĩ','amber')}${dashboardPrimaryMetric(uiIcon('close'),'Y03',dayStats.y03,'KH không nhu cầu','blue')}`
    : `${dashboardPrimaryMetric(uiIcon('call'),'Tổng cuộc gọi',dayStats.calls,`Ngày ${shortDate(viewDate)}`,'plum')}${dashboardPrimaryMetric(uiIcon('target'),'Y01',dayStats.y01,'KH có nhu cầu','green')}${dashboardPrimaryMetric(uiIcon('calendar'),'Y02',dayStats.y02,'KH suy nghĩ','amber')}${dashboardPrimaryMetric(uiIcon('kpi'),'Tỷ lệ kết nối',dayStats.rate+'%',`${dayStats.connected}/${dayStats.called} KH đã gọi`,'teal')}`;

  let scopeMonth=monthRows;
  if(view==='team')scopeMonth=dashboardCallsForTeam(monthRows,drillTeam);
  if(view==='person')scopeMonth=dashboardCallsForUser(monthRows,drillUser);
  const chartFrom=addDays(viewDate,-6)<monthFrom?monthFrom:addDays(viewDate,-6);
  const chartRows=dateRange(chartFrom,viewDate,7).map(d=>{const st=dashboardStats(scopeMonth.filter(x=>dateKey(x.created_at)===d));return {...st,date:d,label:shortDate(d)};});
  const otherDay=Math.max(0,dayStats.called-dayStats.y01-dayStats.y02-dayStats.y03);
  const dayBase=Math.max(1,dayStats.called);
  const outcomeRows=[['Y01','Có nhu cầu',dayStats.y01,'good'],['Y02','Đang cân nhắc',dayStats.y02,'warn'],['Y03','Không nhu cầu',dayStats.y03,'neutral'],['Khác','Trạng thái khác',otherDay,'muted']];

  let lower='';
  if(view==='overview'){
    const rows=allTeams.map(team=>dashboardTeamBreakdownRow(team,dashboardStats(dashboardCallsForTeam(monthRows,team)))).join('');
    lower=`<section class="dash711-section"><div class="dash711-section-head"><div><span class="dash711-section-eyebrow">THEO THÁNG</span><h2>Hiệu suất theo Team</h2><p>${esc(monthLabelVI(viewDate))} · bấm ô đầu tiên của Team để mở Dashboard Team.</p></div><span class="dash711-period-badge">${esc(monthLabelVI(viewDate))}</span></div><div class="dash711-break-list">${rows||'<div class="dash711-empty">Chưa có Team.</div>'}</div></section>`;
  }else if(view==='team'){
    const employees=state.users.filter(u=>u.role==='sale'&&Number(u.team_id)===Number(drillTeam.id)).sort((a,b)=>String(a.display_name).localeCompare(String(b.display_name),'vi'));
    const rows=employees.map(user=>dashboardEmployeeBreakdownRow(user,dashboardStats(dashboardCallsForUser(monthRows,user)))).join('');
    lower=`<section class="dash711-section"><div class="dash711-section-head"><div><span class="dash711-section-eyebrow">THEO THÁNG</span><h2>Hiệu suất nhân viên</h2><p>${esc(monthLabelVI(viewDate))} · bấm tên nhân viên để mở Dashboard cá nhân.</p></div><span class="dash711-period-badge">${esc(monthLabelVI(viewDate))}</span></div><div class="dash711-break-list">${rows||'<div class="dash711-empty">Team chưa có nhân viên Sale.</div>'}</div></section>`;
  }else{
    if(!state.leadLoadedAt&&!state.leadLoading){loadLeads().then(()=>{if(state.page==='dashboard'&&String(state.dashboardDrillUserId)===String(drillUser.id))renderDashboard(main)});}
    const followups=dashboardFollowupCount(drillUser,monthFrom,monthTo),leads=dashboardLeadCount(drillUser,monthFrom,monthTo);
    lower=`<section class="dash711-section dash711-person-month"><div class="dash711-section-head"><div><span class="dash711-section-eyebrow">THEO THÁNG</span><h2>Chăm sóc khách hàng</h2><p>${esc(monthLabelVI(viewDate))} · Follow-up và Lead của ${esc(drillUser.display_name)}.</p></div><span class="dash711-period-badge">${esc(monthLabelVI(viewDate))}</span></div><div class="dash711-person-grid"><div class="dash711-big-card followup"><div class="dash711-big-icon">📅</div><div><span>Follow up</span><strong>${followups}</strong><small>Lịch hẹn trong ${esc(monthLabelVI(viewDate).toLowerCase())}</small></div></div><div class="dash711-big-card lead"><div class="dash711-big-icon">✨</div><div><span>Lead</span><strong>${leads===null?'…':leads}</strong><small>Lead phát sinh trong ${esc(monthLabelVI(viewDate).toLowerCase())}</small></div></div></div></section>`;
  }

  main.innerHTML=`<div class="dashboard-v711 dashboard-v713 dashboard-v714">
    <header class="dash714-head">
      <div class="dash714-head-copy">${back}<span class="dash714-eyebrow">SHINHAN FINANCE · AN ĐÔNG 4</span><h1>${title}</h1><p>${subtitle}</p></div>
      <div class="dash714-head-tools"><span class="dash714-live"><i></i>${state.mode==='d1'?'D1 Online':'Demo Local'}</span>${dashboardDateToolbar(viewDate)}</div>
    </header>
    <section class="dash714-kpi-section"><div class="dash714-section-label"><span>HIỆU SUẤT TRONG NGÀY</span><small>Dữ liệu ghi nhận ngày ${shortDate(viewDate)}</small></div><div class="dash711-metric-grid">${topMetrics}</div></section>
    <section class="dash714-analytics-grid">
      <article class="dash714-panel dash714-chart-panel"><div class="dash714-panel-head"><div><span>7 NGÀY GẦN NHẤT</span><h2>Xu hướng cuộc gọi</h2></div><div class="dash714-legend"><span><i class="calls"></i>Cuộc gọi</span><span><i class="connect"></i>Kết nối</span><span><i class="y01"></i>Y01</span><span><i class="y02"></i>Y02</span></div></div>${dashboardGroupedBarChart(chartRows)}</article>
      <aside class="dash714-panel dash714-outcome-panel"><div class="dash714-panel-head"><div><span>PHÂN BỔ KẾT QUẢ</span><h2>${shortDate(viewDate)}</h2></div><strong class="dash714-total">${dayStats.called}</strong></div><div class="dash714-outcome-list">${outcomeRows.map(([code,label,value,tone])=>`<div class="dash714-outcome-row"><div><b>${code}</b><span>${label}</span></div><div class="dash714-outcome-value"><strong>${value}</strong><small>${Math.round(Number(value||0)*100/dayBase)}%</small></div><div class="dash714-outcome-bar"><i class="${tone}" style="width:${Math.min(100,Math.round(Number(value||0)*100/dayBase))}%"></i></div></div>`).join('')}</div></aside>
    </section>
    ${lower}
  </div>`;

  const dateInput=$('#dashboard-view-date');if(dateInput)dateInput.onchange=async e=>{state.dashboardViewDate=e.target.value||todayISO();state.dashboardDrillUserId=view==='person'&&role!=='sale'?state.dashboardDrillUserId:'';const mf=startOfMonthISO(state.dashboardViewDate),mt=endOfMonthISO(state.dashboardViewDate);await ensureCallsRange(mf,mt);renderDashboard(main)};
  const todayBtn=$('#dashboard-today');if(todayBtn)todayBtn.onclick=async()=>{state.dashboardViewDate=todayISO();const mf=startOfMonthISO(state.dashboardViewDate),mt=endOfMonthISO(state.dashboardViewDate);await ensureCallsRange(mf,mt);renderDashboard(main)};
  const backOverview=$('#dashboard-back-overview');if(backOverview)backOverview.onclick=()=>{state.dashboardDrillTeamId='';state.dashboardDrillUserId='';renderDashboard(main)};
  const backTeam=$('#dashboard-back-team');if(backTeam)backTeam.onclick=()=>{state.dashboardDrillUserId='';renderDashboard(main)};
  $$('[data-dashboard-team]').forEach(b=>b.onclick=()=>{state.dashboardDrillTeamId=b.dataset.dashboardTeam;state.dashboardDrillUserId='';renderDashboard(main)});
  $$('[data-dashboard-user]').forEach(b=>b.onclick=()=>{state.dashboardDrillUserId=b.dataset.dashboardUser;renderDashboard(main)});
}

function kpi(label,value,sub,cls=''){return `<div class="kpi ${cls}"><div class="label">${label}</div><div class="value">${value}</div><div class="sub">${sub}</div></div>`}
function pageHead(title,desc,actions=''){return `<div class="page-head"><div><h1>${title}</h1><p>${desc}</p></div><div class="actions">${actions}</div></div>`}

function filteredCustomers(){
  const f=state.filters, q=f.q.toLowerCase();
  return visibleCustomers().filter(c=>(!q||[c.name,c.phone,c.owner].some(v=>String(v).toLowerCase().includes(q)))&&(!f.team||c.team===f.team)&&(!f.owner||c.owner===f.owner)&&(!f.status||c.status===f.status)&&(!f.source||c.source===f.source));
}
// V5.2: Xuất toàn bộ lượt gọi theo ngày, Team, nhân viên từ D1; không bị giới hạn bởi danh sách 10.000 calls khi tải dashboard.
function safeExcelSheetName(value,used){
  const base=String(value||'Nhân viên').replace(/[\[\]*?:/\\]/g,' ').trim().slice(0,31)||'Nhân viên';
  let name=base, suffix=2;
  while(used.has(name.toLowerCase())){const tail=` (${suffix++})`;name=base.slice(0,31-tail.length)+tail;}
  used.add(name.toLowerCase());return name;
}
function excelSafeFilePart(value){
  return String(value||'tat-ca').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/[^A-Za-z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,55)||'tat-ca';
}
function callExportSheetRows(items){
  return items.map((x,i)=>({
    'STT':i+1,'Ngày gọi':dateKey(x.created_at),
    'Thời gian gọi':vnParts(x.created_at)?.time||'',
    'Team':x.team||'','Nhân viên':x.owner||'',
    'Khách hàng':x.customer_name||'','Số điện thoại':String(x.phone||''),
    'Nguồn Data':x.source||'','Mã trạng thái':x.status||'',
    'Kết quả cuộc gọi':STATUS_LABELS[x.status]||x.status||'',
    'Ghi chú':x.note||'','Hẹn gọi lại':x.follow_up_at||''
  }));
}
function callExportSheet(workbook, used, name, rows){
  const headers=['STT','Ngày gọi','Thời gian gọi','Team','Nhân viên','Khách hàng','Số điện thoại','Nguồn Data','Mã trạng thái','Kết quả cuộc gọi','Ghi chú','Hẹn gọi lại'];
  const ws=XLSX.utils.json_to_sheet(rows,{header:headers});
  ws['!cols']=headers.map(h=>({wch:h==='Ghi chú'?46:h==='Kết quả cuộc gọi'?30:h==='Khách hàng'||h==='Nhân viên'?27:h==='Số điện thoại'?17:17}));
  // Ép SĐT thành chuỗi Excel để không mất số 0 đầu.
  const phoneColumn=7;
  for(let r=2;r<=rows.length+1;r++){
    const addr=XLSX.utils.encode_cell({r:r-1,c:phoneColumn-1});
    if(ws[addr]){ws[addr].t='s';ws[addr].v=String(ws[addr].v??'');ws[addr].z='@';}
  }
  ws['!autofilter']={ref:`A1:L${Math.max(1,rows.length+1)}`};
  XLSX.utils.book_append_sheet(workbook,ws,safeExcelSheetName(name,used));
}
async function fetchCallExport(params,onProgress){
  let offset=0,all=[];
  const PAGE=1500,MAX=50000;
  while(true){
    const query=new URLSearchParams({...params,limit:String(PAGE),offset:String(offset)});
    const res=await API.request('/calls/export?'+query.toString());
    const items=res.items||[];
    all.push(...items);
    if(onProgress)onProgress(all.length);
    if(all.length>=MAX && items.length===PAGE) throw new Error('Quá 50.000 cuộc gọi. Hãy chọn khoảng ngày ngắn hơn để xuất đủ dữ liệu.');
    if(!res.has_more)break;
    if(!items.length)throw new Error('Không đọc được trang dữ liệu tiếp theo.');
    offset+=items.length;
  }
  return all;
}
function openCallExportModal({initialUserId='',initialTeamId='',initialStatus='',initialFrom='',initialTo=''}={}){
  if(!['admin','sup','teamlead'].includes(state.session?.user?.role)) return;
  const isLead=state.session.user.role==='teamlead';
  const teamId=isLead?String(state.session.user.team_id||''):String(initialTeamId??state.callDetailTeam??'');
  const saleUsers=state.users.filter(u=>u.role==='sale'&&(!teamId||String(u.team_id)===teamId)).sort((a,b)=>String(a.display_name).localeCompare(String(b.display_name),'vi'));
  const defaultFrom=initialFrom||state.callDetailFrom||todayISO(), defaultTo=initialTo||state.callDetailTo||todayISO();
  const selectedId=String(initialUserId||state.callDetailEmployee||'');
  const selectedStatus=initialStatus||state.callDetailStatus||'';
  openAdminModal('Xuất Excel lịch sử cuộc gọi',`<form id="call-export-form" class="form-grid">
    <div class="form-field"><label>Từ ngày</label><input id="call-export-from" type="date" value="${esc(defaultFrom)}" required></div>
    <div class="form-field"><label>Đến ngày</label><input id="call-export-to" type="date" value="${esc(defaultTo)}" required></div>
    <div class="form-field full"><label>Nhân viên</label><select id="call-export-user"><option value="">Tất cả nhân viên (${saleUsers.length} người, mỗi người một sheet)</option>${saleUsers.map(u=>`<option value="${u.id}" ${selectedId===String(u.id)?'selected':''}>${esc(u.display_name)} (${esc(u.team||'')})</option>`).join('')}</select></div>
    <div class="form-field full"><label>Trạng thái cuộc gọi</label><select id="call-export-status"><option value="">Tất cả trạng thái (mọi lượt gọi)</option>${Object.entries(STATUS_LABELS).filter(([k])=>k!=='NEW').map(([k,v])=>`<option value="${k}" ${selectedStatus===k?'selected':''}>${esc(v)}</option>`).join('')}</select></div>
    <div class="form-field full"><div class="notice">Xuất lịch sử <strong>từng lượt gọi</strong>, kể cả các lần gọi lại của cùng một KH. File Excel gồm sheet Tổng hợp và sheet riêng theo từng nhân viên. Bộ lọc Team: <strong>${esc(isLead?state.session.user.team:state.teamObjects.find(t=>String(t.id)===teamId)?.name||'Tất cả Team')}</strong>.</div></div>
    <div class="form-field full"><span class="muted" id="call-export-progress"></span></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="call-export-cancel">Hủy</button><button class="btn primary" id="call-export-submit" type="submit">⬇ Tải Excel (.xlsx)</button></div></div>
  </form>`);
  $('#call-export-cancel').onclick=closeAdminModal;
  $('#call-export-form').onsubmit=async e=>{
    e.preventDefault();
    if(state.mode!=='d1'){toast('Cần kết nối D1 Online để xuất đầy đủ dữ liệu.','bad');return;}
    if(!window.XLSX){toast('Không tải được thư viện Excel. Hãy kiểm tra Internet.','bad');return;}
    const from=$('#call-export-from').value,to=$('#call-export-to').value;
    const userId=$('#call-export-user').value, status=$('#call-export-status').value;
    if(!from||!to||from>to){toast('Khoảng ngày không hợp lệ.','bad');return;}
    const button=$('#call-export-submit'),progress=$('#call-export-progress');
    button.disabled=true;
    try{
      progress.textContent='Đang tải lịch sử cuộc gọi từ D1...';
      const data=await fetchCallExport({from,to,user_id:userId,team_id:teamId,status},n=>{progress.textContent=`Đã tải ${n.toLocaleString('vi-VN')} lượt gọi...`;});
      if(!data.length){toast('Không có cuộc gọi phù hợp với bộ lọc.','bad');return;}
      const users=userId?saleUsers.filter(u=>String(u.id)===userId):saleUsers;
      const byUser=new Map(users.map(u=>[String(u.id),{name:u.display_name,team:u.team,rows:[]}]));
      for(const x of data){
        const id=String(x.user_id);
        if(!byUser.has(id))byUser.set(id,{name:x.owner||'Nhân viên khác',team:x.team,rows:[]});
        byUser.get(id).rows.push(x);
      }
      const book=XLSX.utils.book_new(),used=new Set(['tổng hợp']);
      const summary=[];
      for(const [id,u] of byUser){
        const calls=u.rows;const connected=calls.filter(x=>String(x.status).startsWith('Y')).length;
        const row={'Nhân viên':u.name,'Team':u.team||'', 'Tổng cuộc gọi':calls.length,'Kết nối':connected,'Tỷ lệ kết nối (%)':calls.length?Math.round(connected*100/calls.length):0};
        for(const k of Object.keys(STATUS_LABELS).filter(k=>k!=='NEW'))row[k]=calls.filter(x=>x.status===k).length;
        summary.push(row);
      }
      const ws=XLSX.utils.json_to_sheet(summary);
      ws['!cols']=[{wch:29},{wch:20},...Array(16).fill({wch:16})];
      XLSX.utils.book_append_sheet(book,ws,'Tổng hợp');
      for(const [,u] of byUser){
        if(!u.rows.length)continue;
        callExportSheet(book,used,userId?'Lịch sử cuộc gọi':u.name,callExportSheetRows(u.rows));
      }
      const filename=`Cuoc_goi_${userId?excelSafeFilePart(users[0]?.display_name||data[0]?.owner):'Tat_ca_nhan_vien'}_${from}_${to}.xlsx`;
      XLSX.writeFile(book,filename);
      closeAdminModal();toast(`Đã xuất ${data.length} lượt gọi ra Excel.`);
    }catch(err){progress.textContent='Không xuất được file. '+err.message;toast(err.message,'bad');}
    finally{button.disabled=false;}
  };
}

function renderCallDetails(main){
  const role=state.session.user.role;
  const isLead=role==='teamlead';
  const today=todayISO();
  const from=state.callDetailFrom||today;
  const to=state.callDetailTo||today;
  if(!state.callDetailFrom)state.callDetailFrom=from;
  if(!state.callDetailTo)state.callDetailTo=to;
  const ownTeamId=String(state.session.user.team_id||'');
  let selectedTeam=isLead?ownTeamId:String(state.callDetailTeam||'');
  const teams=(state.teamObjects.length?state.teamObjects:state.teams.map((name,i)=>({id:i+1,name}))).filter(t=>!isLead||String(t.id)===ownTeamId);
  const statusKeys=Object.keys(STATUS_LABELS).filter(k=>k!=='NEW');

  let sales=state.users.filter(u=>u.role==='sale');
  if(isLead) sales=sales.filter(u=>String(u.team_id)===ownTeamId || u.team===state.session.user.team);
  else if(selectedTeam) sales=sales.filter(u=>String(u.team_id)===selectedTeam);
  sales=sales.sort((a,b)=>String(a.team||'').localeCompare(String(b.team||''))||String(a.display_name||'').localeCompare(String(b.display_name||''),'vi'));

  let calls=state.calls.filter(x=>{const d=dateKey(x.created_at);return d>=from&&d<=to;});
  if(selectedTeam) calls=calls.filter(x=>String(x.team_id)===selectedTeam);
  const saleIds=new Set(sales.map(u=>Number(u.id)));
  calls=calls.filter(x=>saleIds.has(Number(x.user_id)) || sales.some(u=>!x.user_id&&x.owner===u.display_name));

  const summaries=sales.map(u=>{
    const userCalls=calls.filter(x=>Number(x.user_id)===Number(u.id)||(!x.user_id&&x.owner===u.display_name));
    const latestUserCalls=latestCallsByCustomer(userCalls);
    const counts=Object.fromEntries(statusKeys.map(k=>[k,latestUserCalls.filter(x=>x.status===k).length]));
    const connected=userCalls.filter(x=>String(x.status).startsWith('Y')).length;
    return {u,total:userCalls.length,counts,connected,rate:userCalls.length?Math.round(connected/userCalls.length*100):0};
  }).sort((a,b)=>b.total-a.total||String(a.u.display_name).localeCompare(String(b.u.display_name),'vi'));

  const totalCalls=calls.length;
  const connected=calls.filter(x=>String(x.status).startsWith('Y')).length;
  const latestStatusCalls=latestCallsByCustomer(calls);
  const y01=latestStatusCalls.filter(x=>x.status==='Y01').length;
  const y02=latestStatusCalls.filter(x=>x.status==='Y02').length;
  const calledEmployees=summaries.filter(x=>x.total>0).length;

  if(state.callDetailEmployee && !sales.some(u=>String(u.id)===String(state.callDetailEmployee))){state.callDetailEmployee='';state.callDetailStatus='';}
  if(state.callDetailStatus && !statusKeys.includes(state.callDetailStatus)) state.callDetailStatus='';
  const employeeCalls=state.callDetailEmployee?calls.filter(x=>String(x.user_id)===String(state.callDetailEmployee)||(!x.user_id&&sales.find(u=>String(u.id)===String(state.callDetailEmployee))?.display_name===x.owner)):calls;
  // Theo khoảng ngày: mỗi KH chỉ tính trạng thái mới nhất trong chính khoảng đang chọn khi bấm một cột Y/N.
  const detailCalls=state.callDetailStatus?latestCallsByCustomer(employeeCalls).filter(x=>x.status===state.callDetailStatus):employeeCalls;
  const allRangeCalls=state.calls.filter(x=>{const d=dateKey(x.created_at);return d>=from&&d<=to;});
  const teamTabs=isLead
    ? `<div class="team-tabs"><button class="team-tab active">${esc(state.session.user.team||'Team của bạn')} <span>${totalCalls}</span></button></div>`
    : `<div class="team-tabs"><button class="team-tab ${!selectedTeam?'active':''}" data-call-detail-team="">Tất cả Team <span>${allRangeCalls.length}</span></button>${teams.map(t=>`<button class="team-tab ${String(selectedTeam)===String(t.id)?'active':''}" data-call-detail-team="${t.id}">${esc(t.name)} <span>${allRangeCalls.filter(x=>String(x.team_id)===String(t.id)).length}</span></button>`).join('')}</div>`;

  const summaryRows=summaries.map(r=>`<tr class="call-summary-row ${String(state.callDetailEmployee)===String(r.u.id)?'selected':''}" data-call-detail-user="${r.u.id}">
    <td><div class="call-employee-cell"><strong>${esc(r.u.display_name)}</strong><button type="button" class="btn small call-export-individual" data-call-export-user="${r.u.id}" title="Xuất lịch sử của ${esc(r.u.display_name)} trong khoảng đang chọn">⬇ Excel</button></div></td><td>${esc(r.u.team||'')}</td><td class="num"><strong>${r.total}</strong></td><td class="num"><strong>${r.rate}%</strong></td>
    ${statusKeys.map(k=>`<td class="num ${r.counts[k]?'has-value':''} ${String(state.callDetailEmployee)===String(r.u.id)&&state.callDetailStatus===k?'status-selected':''}">${r.counts[k]?`<button type="button" class="call-status-count" data-call-detail-status-user="${r.u.id}" data-call-detail-status="${k}" title="Xem ${r.counts[k]} KH có trạng thái mới nhất ${esc(STATUS_LABELS[k])} trong khoảng đã chọn">${r.counts[k]}</button>`:'<span class="call-status-zero">0</span>'}</td>`).join('')}
  </tr>`).join('')||`<tr><td colspan="${4+statusKeys.length}"><div class="empty">Chưa có nhân viên Sale trong phạm vi này.</div></td></tr>`;

  const selectedUser=sales.find(u=>String(u.id)===String(state.callDetailEmployee));
  const selectedStatusLabel=state.callDetailStatus?STATUS_LABELS[state.callDetailStatus]:'';
  const detailTitle=selectedUser?`Chi tiết cuộc gọi · ${esc(selectedUser.display_name)}${state.callDetailStatus?` · ${esc(state.callDetailStatus)}`:''}`:'Chi tiết từng cuộc gọi';
  const detailRows=[...detailCalls].sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))).map(x=>{
    const c=state.customers.find(c=>Number(c.id)===Number(x.customer_id));
    return `<tr><td>${fmtDate(x.created_at)}</td><td>${esc(x.team||c?.team||'')}</td><td><strong>${esc(x.owner||'')}</strong></td><td>${esc(c?.name||'')}</td><td class="phone">${esc(c?.phone||'')}</td><td>${statusPill(x.status)}</td><td>${esc(x.note||'')}</td></tr>`;
  }).join('')||'<tr><td colspan="7"><div class="empty">Không có cuộc gọi phù hợp.</div></td></tr>';

  const rangeText=from===to?shortDate(from):`${shortDate(from)} → ${shortDate(to)}`;
  main.innerHTML=`${pageHead('Chi tiết cuộc gọi',isLead?`Tổng hợp cuộc gọi của từng nhân viên trong ${esc(state.session.user.team||'Team của bạn')}.`:'Tổng hợp số cuộc gọi và trạng thái của từng nhân viên theo Team.',`<div class="date-actions call-detail-range"><label>Từ ngày <input type="date" id="call-detail-from" value="${esc(from)}"></label><span class="range-arrow">→</span><label>Đến ngày <input type="date" id="call-detail-to" value="${esc(to)}"></label><button class="btn" id="call-detail-today">Hôm nay</button><button class="btn" id="call-detail-7d">7 ngày</button><button class="btn" id="call-detail-30d">30 ngày</button><button class="btn primary" id="call-detail-export-main">⬇ Xuất Excel</button></div>`)}
  ${teamTabs}
  <div class="kpis dashboard-kpis monitor-kpis">${kpi('Tổng cuộc gọi',totalCalls,rangeText)}${kpi('Nhân viên đã gọi',`${calledEmployees}/${sales.length}`,'Sale có phát sinh cuộc gọi')}${kpi('Tỷ lệ kết nối',totalCalls?Math.round(connected/totalCalls*100)+'%':'0%','Y01–Y06 / tổng calls','positive')}${kpi('Y01',y01,'Trạng thái mới nhất trong khoảng','positive')}${kpi('Y02',y02,'Trạng thái mới nhất trong khoảng','attn')}</div>
  <div class="card call-detail-summary-card"><div class="card-head"><div><h3>Tổng hợp theo nhân viên</h3><span class="muted">Dữ liệu từ <strong>${shortDate(from)}</strong> đến <strong>${shortDate(to)}</strong>. Bấm tên nhân viên để xem từng lượt gọi; Y01, Y02, Y03… tính theo trạng thái mới nhất của mỗi KH trong khoảng đã chọn.</span></div></div><div class="table-wrap call-summary-wrap"><table class="data-table call-summary-table"><thead><tr><th>Nhân viên</th><th>Team</th><th>Tổng Calls</th><th>Kết nối</th>${statusKeys.map(k=>`<th title="${esc(STATUS_LABELS[k])}">${k}</th>`).join('')}</tr></thead><tbody>${summaryRows}</tbody></table></div></div>
  <div class="card call-detail-log-card" id="call-detail-log"><div class="card-head"><div><h3>${detailTitle}</h3><span class="muted">${detailCalls.length} cuộc gọi · ${rangeText}${selectedStatusLabel?` · ${esc(selectedStatusLabel)}`:''}</span></div><div class="actions"><button class="btn primary small" id="call-detail-export">⬇ Xuất Excel cuộc gọi</button>${state.callDetailStatus?'<button class="btn small" id="call-detail-clear-status">Bỏ lọc trạng thái</button>':''}${state.callDetailEmployee?'<button class="btn small" id="call-detail-clear-user">Xem tất cả nhân viên</button>':''}</div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Thời gian</th><th>Team</th><th>Nhân viên</th><th>Khách hàng</th><th>SĐT</th><th>Trạng thái</th><th>Ghi chú</th></tr></thead><tbody>${detailRows}</tbody></table></div></div>`;

  const exportArgs=()=>({initialUserId:state.callDetailEmployee,initialTeamId:selectedTeam,initialStatus:state.callDetailStatus,initialFrom:state.callDetailFrom,initialTo:state.callDetailTo});
  $('#call-detail-export-main').onclick=()=>openCallExportModal(exportArgs());
  $('#call-detail-export').onclick=()=>openCallExportModal(exportArgs());
  $$('[data-call-export-user]').forEach(b=>b.onclick=e=>{e.stopPropagation();openCallExportModal({initialUserId:b.dataset.callExportUser,initialTeamId:selectedTeam,initialStatus:'',initialFrom:state.callDetailFrom,initialTo:state.callDetailTo});});
  $$('[data-call-detail-team]').forEach(b=>b.onclick=()=>{state.callDetailTeam=b.dataset.callDetailTeam;state.callDetailEmployee='';state.callDetailStatus='';renderCallDetails(main)});
  $$('[data-call-detail-user]').forEach(row=>row.onclick=()=>{state.callDetailEmployee=String(row.dataset.callDetailUser);state.callDetailStatus='';renderCallDetails(main)});
  $$('[data-call-detail-status]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();state.callDetailEmployee=String(btn.dataset.callDetailStatusUser);state.callDetailStatus=String(btn.dataset.callDetailStatus);renderCallDetails(main);requestAnimationFrame(()=>$('#call-detail-log')?.scrollIntoView({behavior:'smooth',block:'start'}));});
  const setRange=async(nextFrom,nextTo)=>{
    if(nextFrom>nextTo){toast('Từ ngày không được lớn hơn Đến ngày.','bad');return;}
    const days=(Date.parse(nextTo+'T00:00:00Z')-Date.parse(nextFrom+'T00:00:00Z'))/86400000;
    if(days>366){toast('Mỗi lần xem tối đa 366 ngày để tránh đọc D1 quá nhiều.','bad');return;}
    state.callDetailFrom=nextFrom;state.callDetailTo=nextTo;state.callDetailEmployee='';state.callDetailStatus='';
    try{await ensureCallsRange(nextFrom,nextTo);renderCallDetails(main);}catch(err){toast(err.message,'bad');}
  };
  $('#call-detail-from').onchange=e=>setRange(e.target.value||today,state.callDetailTo||today);
  $('#call-detail-to').onchange=e=>setRange(state.callDetailFrom||today,e.target.value||today);
  $('#call-detail-today').onclick=()=>setRange(today,today);
  $('#call-detail-7d').onclick=()=>setRange(addDays(today,-6),today);
  $('#call-detail-30d').onclick=()=>setRange(addDays(today,-29),today);
  if($('#call-detail-clear-status')) $('#call-detail-clear-status').onclick=()=>{state.callDetailStatus='';renderCallDetails(main)};
  if($('#call-detail-clear-user')) $('#call-detail-clear-user').onclick=()=>{state.callDetailEmployee='';state.callDetailStatus='';renderCallDetails(main)};
}

function renderCRM(main){
  const role=state.session.user.role;
  if((role==='admin'||role==='sup')||role==='teamlead') return renderCallDetails(main);
  if((role!=='admin'&&role!=='sup')) state.filters.team='';
  if(role==='sale') state.filters.owner='';
  const c=filteredCustomers(), owners=[...new Set(visibleCustomers().map(x=>x.owner).filter(Boolean))].sort(), sources=[...new Set(visibleCustomers().map(x=>x.source).filter(Boolean))].sort();
  const isAdmin=(role==='admin'||role==='sup'), isLead=role==='teamlead', isSale=role==='sale';
  const title=isSale?'CRM / Data của tôi':(isLead?`CRM / ${esc(state.session.user.team||'Team của tôi')}`:'CRM / Khách hàng');
  const desc=isSale?'Chỉ hiển thị Data và lịch sử cuộc gọi của chính bạn.':(isLead?'Theo dõi Data và cuộc gọi của nhân viên trong Team của bạn.':'Quản lý toàn bộ khách hàng và phân Data.');
  const actions=isAdmin?`<button class="btn" id="export-btn">⬇ Xuất Excel</button><button class="btn primary" id="distribute-btn">Chia Data về Team</button>`:(isLead?`<button class="btn primary" id="team-distribute-btn">Chia Data Team</button>`:'');
  const teamFilter=isAdmin?`<select id="crm-team"><option value="">Tất cả Team</option>${state.teams.map(x=>`<option ${x===state.filters.team?'selected':''}>${esc(x)}</option>`).join('')}</select>`:'';
  const ownerFilter=isAdmin||isLead?`<select id="crm-owner"><option value="">Tất cả nhân viên</option>${owners.map(x=>`<option ${x===state.filters.owner?'selected':''}>${esc(x)}</option>`).join('')}</select>`:'';
  const viewToggle=isAdmin?`<div class="view-toggle"><button data-view="list" class="${state.crmView==='list'?'active':''}">☷ List</button><button data-view="kanban" class="${state.crmView==='kanban'?'active':''}">▦ Kanban</button></div>`:'';
  if(!isAdmin) state.crmView='list';
  main.innerHTML=`${pageHead(title,desc,actions)}
  <div class="toolbar"><input id="crm-q" class="search" placeholder="🔎 Tìm tên, SĐT..." value="${esc(state.filters.q)}">${teamFilter}${ownerFilter}<select id="crm-source"><option value="">Tất cả nguồn</option>${sources.map(x=>`<option ${x===state.filters.source?'selected':''}>${esc(x)}</option>`).join('')}</select><select id="crm-status"><option value="">Tất cả trạng thái</option>${Object.entries(STATUS_LABELS).map(([k,v])=>`<option value="${k}" ${k===state.filters.status?'selected':''}>${v}</option>`).join('')}</select>${viewToggle}</div>
  <div id="crm-content">${state.crmView==='list'?renderCustomerTable(c):renderKanban(c)}</div>`;
  // Ô tìm kiếm CRM không render lại toàn bộ trang ở mỗi phím bấm.
  // Trước đây việc render lại làm input bị thay node và mất focus sau ký tự đầu tiên.
  const crmSearch=$('#crm-q');
  if(crmSearch) crmSearch.oninput=()=>{
    state.filters.q=crmSearch.value;
    const content=$('#crm-content');
    if(content){content.innerHTML=state.crmView==='list'?renderCustomerTable(filteredCustomers()):renderKanban(filteredCustomers());bindCustomerLinks();if(isAdmin)bindKanbanDnD();}
  };
  ['team','owner','source','status'].forEach(k=>{const el=$('#crm-'+k); if(el) el.onchange=()=>{state.filters[k]=el.value;renderCRM(main);};});
  $$('[data-view]').forEach(b=>b.onclick=()=>{state.crmView=b.dataset.view;renderCRM(main)});
  bindCustomerLinks();
  if(isAdmin) bindKanbanDnD();
  if(isAdmin&&$('#export-btn')) $('#export-btn').onclick=exportCsv;
  if(isAdmin&&$('#distribute-btn')) $('#distribute-btn').onclick=()=>distributeData();
  if(isLead&&$('#team-distribute-btn')) $('#team-distribute-btn').onclick=()=>navigate('import');
}
function renderCustomerTable(c){
  const role=state.session.user.role;
  const showTeam=(role==='admin'||role==='sup'), showOwner=role!=='sale';
  const heads=['☐','Khách hàng','SĐT','Nguồn'];
  if(showTeam) heads.push('Team');
  if(showOwner) heads.push('Nhân viên');
  heads.push('Trạng thái','Hẹn gọi lại');
  const rows=c.map(x=>`<tr><td><input type="checkbox"></td><td><span class="name-link" data-customer="${x.id}">${esc(x.name)}</span></td><td class="phone">${esc(x.phone)}</td><td>${esc(x.source)}</td>${showTeam?`<td>${esc(x.team)}</td>`:''}${showOwner?`<td>${esc(x.owner)}</td>`:''}<td>${statusPill(x.status)}</td><td>${fmtDate(x.follow_up)}</td></tr>`).join('');
  return `<div class="table-wrap"><table class="data-table"><thead><tr>${heads.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows||`<tr><td colspan="${heads.length}"><div class="empty">Không có khách phù hợp bộ lọc.</div></td></tr>`}</tbody></table></div>`;
}
function renderKanban(c){
  const cols=[['NEW','Data mới'],['Y02','Đang chăm sóc'],['Y01','Quan tâm'],['FOLLOW','Hẹn lại']];
  return `<div class="kanban">${cols.map(([key,label])=>{const items=c.filter(x=>key==='FOLLOW'?!!x.follow_up:(!x.follow_up && (key==='Y02'?['Y02','Y05','N02'].includes(x.status):x.status===key)));return `<div class="kanban-col" data-drop-status="${key}"><div class="kanban-head"><span>${label}</span><span class="kanban-count">${items.length}</span></div>${items.map(x=>`<div class="kanban-card" draggable="true" data-drag-id="${x.id}"><h4 data-customer="${x.id}">${esc(x.name)}</h4><p>☎ ${esc(x.phone)}</p><p>${esc(x.owner)}</p><div class="meta">${statusPill(x.status)}<span class="muted">${x.source}</span></div></div>`).join('')}</div>`}).join('')}</div>`;
}
function statusPill(s){return `<span class="status ${String(s).toLowerCase()}">${esc(STATUS_LABELS[s]||s)}</span>`}
function bindCustomerLinks(){$$('[data-customer]').forEach(x=>x.onclick=e=>{e.stopPropagation();openCustomerModal(Number(x.dataset.customer));});}
function bindKanbanDnD(){
  $$('[data-drag-id]').forEach(card=>{card.ondragstart=()=>{card.classList.add('dragging');dataTransferId=Number(card.dataset.dragId)};card.ondragend=()=>card.classList.remove('dragging')});
  $$('[data-drop-status]').forEach(col=>{col.ondragover=e=>e.preventDefault();col.ondrop=async e=>{e.preventDefault();const id=dataTransferId;const target=col.dataset.dropStatus;if(target==='FOLLOW'){openCustomerModal(id);toast('Đặt lịch hẹn trong hồ sơ khách.');return;}await updateCustomer(id,{status:target});renderCRM($('#main'));};});
}
let dataTransferId=null;
function customerTimelineHtml(logs){
  return logs.map((l,i)=>`<div class="timeline-item"><div class="timeline-time">Lần ${logs.length-i}<br>${fmtDate(l.created_at)}<br>${esc(l.owner||'')}</div><div class="timeline-content"><strong>${esc(STATUS_LABELS[l.status]||l.status)}</strong><p>${esc(l.note||'')}</p></div></div>`).join('')||'<div class="empty">Chưa có lịch sử cuộc gọi.</div>';
}

function openCustomerModal(id){
  const c=state.customers.find(x=>x.id===id); if(!c)return; state.selectedCustomerId=id;
  $('#modal-code').textContent=c.source?`Nguồn: ${c.source}`:''; $('#modal-name').textContent=c.name;
  const logs=state.calls.filter(x=>Number(x.customer_id)===Number(id)).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at)));
  const canCall=state.session.user.role==='sale';
  $('#modal-body').innerHTML=`<div class="profile-grid">
    ${info('Số điện thoại',c.phone)}${info('Nguồn Data',c.source)}${info('Phân loại',c.data_category||'Chưa phân loại')}${info('Team',c.team)}${info('Nhân viên',c.owner)}${info('Trạng thái',STATUS_LABELS[c.status]||c.status)}${info('Vòng gọi',c.assignment_round||0)}${info('Deadline',c.assignment_deadline?shortDate(String(c.assignment_deadline).slice(0,10)):'Không giới hạn')}${info('Ngày nhận Data',c.received)}${info('Lịch hẹn gọi lại',fmtDate(c.follow_up))}${info('Ghi chú',c.note||'—')}
  </div>${canCall?'<div class="call-actions"><button class="btn" id="modal-call">☎ Ghi nhận cuộc gọi</button><button class="btn primary" id="modal-follow">📅 Đặt lịch hẹn</button></div>':'<div class="notice">Chế độ theo dõi: chỉ Sale được ghi nhận cuộc gọi hoặc thay đổi lịch hẹn.</div>'}
  <div class="timeline"><h3>Lịch sử chăm sóc / trạng thái</h3><div id="modal-call-history">${customerTimelineHtml(logs)}</div></div>`;
  $('#customer-modal').classList.remove('hidden'); $('#customer-modal').setAttribute('aria-hidden','false');
  if(state.mode==='d1'){
    API.request('/calls/customer/'+id).then(r=>{
      if(state.selectedCustomerId!==id||$('#customer-modal').classList.contains('hidden'))return;
      const items=r.items||[];const byId=new Map(state.calls.map(x=>[String(x.id),x]));for(const row of items)byId.set(String(row.id),row);state.calls=[...byId.values()].sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))||Number(b.id)-Number(a.id));state.v84CallMemo?.clear?.();
      const holder=$('#modal-call-history');if(holder)holder.innerHTML=customerTimelineHtml(items);
    }).catch(()=>{});
  }
  if(canCall){
    $('#modal-call').onclick=()=>{closeCustomerModal();navigate('telesale');setTimeout(()=>selectCallCustomer(id),0)};
    $('#modal-follow').onclick=()=>{const v=prompt('Nhập lịch hẹn dạng YYYY-MM-DD HH:MM','2026-10-06 09:00');if(v){updateCustomer(id,{follow_up:v.replace(' ','T')});openCustomerModal(id);}};
  }
}
function info(k,v){return `<div class="info-row"><label>${k}</label><div>${esc(v)}</div></div>`}
function closeCustomerModal(){$('#customer-modal').classList.add('hidden');$('#customer-modal').setAttribute('aria-hidden','true');}

function lastCallAt(customerId){
  const rows=state.calls.filter(x=>Number(x.customer_id)===Number(customerId));
  if(!rows.length) return '';
  return rows.reduce((m,x)=>String(x.created_at)>m?String(x.created_at):m,'');
}
function telesaleQueue(mode=state.callMode){
  const customers=visibleCustomers().filter(c=>String(c.source||'').toUpperCase()!=='LOGIN_APP');
  if(mode==='old'){
    return customers.filter(c=>(c.data_state||'ARCHIVED')==='ARCHIVED')
      .sort((a,b)=>String(lastCallAt(a.id)||'0000').localeCompare(String(lastCallAt(b.id)||'0000'))||String(a.name||'').localeCompare(String(b.name||'')));
  }
  return customers.filter(c=>(c.data_state||'ASSIGNED')==='ASSIGNED')
    .sort((a,b)=>(a.follow_up||'9999').localeCompare(b.follow_up||'9999')||String(a.name||'').localeCompare(String(b.name||'')));
}
function renderAdminCallMonitor(main){
  const role=state.session.user.role;
  const date=state.monitorDate||todayISO();
  const isLead=role==='teamlead';
  const ownTeamId=String(state.session.user.team_id||'');
  const selected=isLead?ownTeamId:(state.monitorTeam||'');
  let teams=state.teamObjects.length?state.teamObjects:state.teams.map((name,i)=>({id:i+1,name}));
  if(isLead) teams=teams.filter(t=>String(t.id)===ownTeamId);
  const dateRows=state.calls.filter(x=>dateKey(x.created_at)===date);
  const rows=dateRows.filter(x=>(!selected||String(x.team_id)===String(selected)));
  const connected=rows.filter(x=>String(x.status).startsWith('Y')).length, latestRows=latestCallsByCustomer(rows), y01=latestRows.filter(x=>x.status==='Y01').length, y02=latestRows.filter(x=>x.status==='Y02').length;
  const tabs=isLead?`<div class="team-tabs"><button class="team-tab active">${esc(state.session.user.team||'Team của bạn')} <span>${rows.length}</span></button></div>`:`<div class="team-tabs"><button class="team-tab ${!selected?'active':''}" data-monitor-team="">Tất cả Team</button>${teams.map(t=>`<button class="team-tab ${String(selected)===String(t.id)?'active':''}" data-monitor-team="${t.id}">${esc(t.name)} <span>${dateRows.filter(x=>String(x.team_id)===String(t.id)).length}</span></button>`).join('')}</div>`;
  main.innerHTML=`${pageHead(isLead?'Theo dõi cuộc gọi Team':'Theo dõi Bàn gọi',isLead?`Chỉ hiển thị cuộc gọi của ${esc(state.session.user.team||'Team của bạn')}.`:'Admin theo dõi cuộc gọi theo Team và ngày.',`<div class="date-actions"><button class="btn small" id="mon-prev">‹</button><input type="date" id="monitor-date" value="${esc(date)}"><button class="btn small" id="mon-next">›</button><button class="btn" id="mon-today">Hôm nay</button></div>`)}
  ${tabs}
  <div class="kpis dashboard-kpis monitor-kpis">${kpi('Calls',rows.length,'Số lượt gọi')}${kpi('Kết nối',rows.length?Math.round(connected/rows.length*100)+'%':'0%','Y01–Y06','positive')}${kpi('Y01',y01,'Có nhu cầu','positive')}${kpi('Y02',y02,'Suy nghĩ','attn')}</div>
  <div class="table-wrap"><table class="data-table"><thead><tr><th>Thời gian</th><th>Team</th><th>Nhân viên</th><th>Khách hàng</th><th>Trạng thái</th><th>Ghi chú</th></tr></thead><tbody>${rows.map(x=>{const c=state.customers.find(c=>Number(c.id)===Number(x.customer_id));return `<tr><td>${fmtDate(x.created_at)}</td><td>${esc(x.team||c?.team||'')}</td><td><strong>${esc(x.owner||'')}</strong></td><td>${esc(c?.name||'')}</td><td>${statusPill(x.status)}</td><td>${esc(x.note||'')}</td></tr>`}).join('')||'<tr><td colspan="6"><div class="empty">Không có cuộc gọi trong ngày/Team đã chọn.</div></td></tr>'}</tbody></table></div>`;
  $$('[data-monitor-team]').forEach(b=>b.onclick=()=>{state.monitorTeam=b.dataset.monitorTeam;renderAdminCallMonitor(main)});
  $('#monitor-date').onchange=async e=>{state.monitorDate=e.target.value||todayISO();await ensureCallsRange(state.monitorDate,state.monitorDate);renderAdminCallMonitor(main)};
  $('#mon-prev').onclick=async()=>{state.monitorDate=addDays(date,-1);await ensureCallsRange(state.monitorDate,state.monitorDate);renderAdminCallMonitor(main)};
  $('#mon-next').onclick=async()=>{state.monitorDate=addDays(date,1);await ensureCallsRange(state.monitorDate,state.monitorDate);renderAdminCallMonitor(main)};
  $('#mon-today').onclick=async()=>{state.monitorDate=todayISO();await ensureCallsRange(state.monitorDate,state.monitorDate);renderAdminCallMonitor(main)};
}
function legacyRenderTelesale(main){
  if(['admin','sup','teamlead'].includes(state.session.user.role)) return renderAdminCallMonitor(main);
  const normal=telesaleQueue('queue'), old=telesaleQueue('old');
  const queue=state.callMode==='old'?old:normal;
  let current=queue.find(x=>x.id===state.selectedCustomerId)||queue[0];
  if(current)state.selectedCustomerId=current.id;
  const actions=`<div class="call-mode-actions"><button class="btn ${state.callMode==='queue'?'primary':''}" id="call-mode-queue">Hàng đợi (${normal.length})</button><button class="btn ${state.callMode==='old'?'primary':''}" id="call-mode-old">↻ Gọi lại Data cũ (${old.length})</button></div>`;
  const queueTitle=state.callMode==='old'?'Data đã gọi / lưu trữ':'Hàng đợi gọi';
  const saleFinished=state.session.user.role==='sale'&&normal.length===0;
  const finishNotice=saleFinished?`<div class="data-finished-banner call-finished"><div><strong>✅ Đã gọi hết Data</strong><span>Không còn khách nào trong hàng đợi được giao cho bạn.${old.length?' Bạn vẫn có thể gọi lại Data cũ.':''}</span></div>${old.length?'<button class="btn" id="finished-old-data">↻ Gọi lại Data cũ</button>':''}</div>`:'';
  main.innerHTML=`${pageHead('Bàn gọi Telesale',state.callMode==='old'?'Gọi lại khách đã xử lý. Mỗi lần lưu sẽ tạo thêm một lịch sử cuộc gọi mới.':'Data đang được giao cho bạn.',actions)}
  ${finishNotice}
  <div class="call-layout"><div class="queue"><div class="queue-head">${queueTitle} (${queue.length})</div>${queue.map(c=>`<div class="queue-item ${current&&c.id===current.id?'active':''}" data-call-customer="${c.id}"><strong>${esc(c.name)}</strong><span>${esc(c.phone)} · ${STATUS_LABELS[c.status]||c.status}${state.callMode==='old'?` · Gần nhất: ${lastCallAt(c.id)?fmtDate(lastCallAt(c.id)):'Chưa có log'}`:''}</span></div>`).join('')||`<div class="empty">${state.callMode==='old'?'Chưa có Data lưu trữ để gọi lại.':saleFinished?'✅ Đã gọi hết Data được giao.':'Không còn khách trong hàng đợi.'}</div>`}</div>
  <div class="call-desk">${current?callDesk(current):'<div class="empty">Chọn khách để bắt đầu gọi.</div>'}</div></div>`;
  $('#call-mode-queue').onclick=()=>{state.callMode='queue';state.selectedCustomerId=null;renderTelesale(main)};
  $('#call-mode-old').onclick=()=>{state.callMode='old';state.selectedCustomerId=null;renderTelesale(main)};
  if($('#finished-old-data')) $('#finished-old-data').onclick=()=>{state.callMode='old';state.selectedCustomerId=null;renderTelesale(main)};
  $$$('[data-call-customer]').forEach(x=>x.onclick=()=>{state.selectedCustomerId=Number(x.dataset.callCustomer);renderTelesale(main);});
  if(current){
    const statusSelect=$('#call-status'), saveBtn=$('#save-call');
    const syncCallSaveState=()=>{
      if(!saveBtn||!statusSelect)return;
      const ready=Boolean(statusSelect.value);
      saveBtn.disabled=!ready;
      saveBtn.setAttribute('aria-disabled',ready?'false':'true');
      saveBtn.title=ready?'':'Hãy chọn trạng thái cuộc gọi trước khi lưu.';
      saveBtn.textContent=ready?'Lưu lượt gọi mới & chuyển khách tiếp theo':'Chọn trạng thái để lưu lượt gọi';
    };
    if(statusSelect){statusSelect.onchange=syncCallSaveState;syncCallSaveState();}
    if(saveBtn) saveBtn.onclick=()=>saveCall(current.id);
    $('#open-profile').onclick=()=>openCustomerModal(current.id);
  }
}
function callDesk(c){
  const history=state.calls.filter(x=>Number(x.customer_id)===Number(c.id)).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))).slice(0,12);
  const historyHtml=history.map((l,i)=>`<div class="call-history-row"><div class="call-history-no">Lần ${history.length-i}</div><div class="call-history-time">${fmtDate(l.created_at)}</div><div class="call-history-status">${statusPill(l.status)}</div><div class="call-history-note">${esc(l.note||'Không có ghi chú')}</div></div>`).join('')||'<div class="empty small-empty">Chưa có lịch sử cuộc gọi.</div>';
  return `<div class="call-customer"><div><div class="eyebrow">${esc(c.source||'Chưa đặt nguồn')} · ${esc(c.team)}</div><h2>${esc(c.name)}</h2><div class="call-phone">☎ ${esc(c.phone)}</div><div class="muted">Nhân viên: ${esc(c.owner)} · ${esc(c.data_category||'Chưa phân loại')}${c.assignment_deadline?` · Deadline ${shortDate(String(c.assignment_deadline).slice(0,10))}`:''}</div></div><button id="open-profile" class="btn">Mở hồ sơ</button></div>
  <div class="form-grid"><div class="form-field"><label>Kết quả cuộc gọi <span class="required-star">*</span></label><select id="call-status"><option value="" selected disabled>-- Chọn trạng thái cuộc gọi --</option>${Object.entries(STATUS_LABELS).filter(([k])=>k!=='NEW').map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select><span class="field-help">Bắt buộc chọn trạng thái cho mỗi lượt gọi mới.</span></div><div class="form-field"><label>Lịch hẹn gọi lại</label><input id="call-follow" type="datetime-local" value="${c.follow_up?String(c.follow_up).slice(0,16):''}"></div><div class="form-field full"><label>Ghi chú chi tiết</label><textarea id="call-note" placeholder="Nhập nội dung trao đổi với khách..."></textarea></div></div><div class="call-actions"><button class="btn teal" id="save-call" disabled>Chọn trạng thái để lưu lượt gọi</button></div>
  <div class="call-history-panel"><div class="call-history-head"><div><h3>Lịch sử chăm sóc / trạng thái</h3><span>Mỗi lần lưu đều tạo một lịch sử riêng, không ghi đè lần trước.</span></div><strong>${history.length} lượt gần nhất</strong></div>${historyHtml}</div>`;
}
function selectCallCustomer(id){
  state.selectedCustomerId=id;
  const inNormal=telesaleQueue('queue').some(x=>Number(x.id)===Number(id));
  if(!inNormal) state.callMode='old';
  if(state.page==='telesale')renderTelesale($('#main'));
}
async function saveCall(id){
  const listBefore=telesaleQueue(state.callMode), idx=listBefore.findIndex(x=>Number(x.id)===Number(id));
  const nextId=listBefore.length>1?listBefore[(idx+1+listBefore.length)%listBefore.length].id:null;
  const selectedStatus=$('#call-status')?.value||'';
  if(!selectedStatus){toast('Hãy chọn trạng thái cuộc gọi trước khi lưu.','bad');$('#call-status')?.focus();return;}
  const payload={status:selectedStatus,follow_up:$('#call-follow').value||null,note:$('#call-note').value.trim()};
  // V6.0: Mỗi lần Lưu là một lượt gọi độc lập. Không sửa/ghi đè lần gọi trước.
  if(state.mode==='d1'){
    try{
      const res=await API.request('/calls',{method:'POST',body:JSON.stringify({customer_id:id,...payload})});
      const saved=res.call;
      if(saved){
        const c=state.customers.find(x=>Number(x.id)===Number(id));
        if(c){c.status=saved.status;c.note=saved.note;c.follow_up=saved.follow_up_at;c.data_state=saved.data_state;c.archived_at=saved.archived_at;c.assignment_deadline=saved.assignment_deadline;}
        const item={id:saved.id||Date.now(),customer_id:Number(saved.customer_id),user_id:Number(saved.user_id),owner:state.session.user.display_name,
          team_id:c?.team_id,team:c?.team,status:saved.status,note:saved.note,follow_up_at:saved.follow_up_at,created_at:saved.created_at};
        state.calls.unshift(item);state.v84CallMemo?.clear?.();if(saved.status==='Y01'||saved.status==='Y02')state.leadLoadedAt=0;state.kpiAlerts=buildKpiAlerts();updateNotifications();
      }else await refreshCustomersOnly();
    }catch(e){toast(e.message,'bad');return;}
  }else{
    const c=state.customers.find(x=>x.id===id);Object.assign(c,payload);
    state.calls.push({id:Date.now(),customer_id:id,user_id:state.session.user.id,owner:state.session.user.display_name,status:payload.status,note:payload.note,follow_up_at:payload.follow_up,created_at:new Date().toISOString()});
    DemoStore.save();
  }
  toast(state.callMode==='old'?'Đã lưu thêm một lần gọi lại mới.':'Đã lưu một lượt gọi mới.');
  state.selectedCustomerId=nextId;
  renderTelesale($('#main'));
}
async function updateCustomer(id,patch){
  if(state.mode==='d1'){try{await API.request('/customers/'+id,{method:'PATCH',body:JSON.stringify(patch)});await syncFromApi({lightweight:true});}catch(e){toast(e.message,'bad')}}
  else{Object.assign(state.customers.find(x=>x.id===id),patch);DemoStore.save();toast('Đã cập nhật khách hàng.');}
}

function renderFollowup(main){
  const role=state.session.user.role;
  state.followupBucket=state.followupBucket||'today';
  state.followupKind=state.followupKind||'all';
  const today=todayISO();
  const nowTs=Date.now();
  const scopeUsers=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||(role==='teamlead'&&Number(u.team_id)===Number(state.session.user.team_id))||(role==='sale'&&Number(u.id)===Number(state.session.user.id))));
  const ownerFilter=role==='sale'?String(state.session.user.id):String(state.followupOwner||'');
  const ownerName=scopeUsers.find(u=>String(u.id)===ownerFilter)?.display_name||'';
  const matchOwner=c=>!ownerFilter||String(c.assigned_user_id||'')===ownerFilter||String(c.owner||'')===ownerName;
  const hasClock=c=>/\d{1,2}:\d{2}/.test(String(c.follow_up||''));
  const bucketOf=c=>{const d=dateKey(c.follow_up||'');if(!d)return '';if(d<today)return 'overdue';if(d>today)return 'upcoming';return 'today';};
  const statusMeta=c=>{
    const bucket=bucketOf(c),ts=parseCrmTime(c.follow_up)?.getTime()||0;
    if(bucket==='overdue')return {label:'Quá hạn',cls:'overdue'};
    if(bucket==='upcoming')return {label:'Sắp tới',cls:'upcoming'};
    if(!hasClock(c))return {label:'Đến hạn hôm nay',cls:'due'};
    if(ts&&ts<=nowTs)return {label:'Đến giờ gọi',cls:'due'};
    return {label:'Chưa đến giờ',cls:'waiting'};
  };
  const followupKind=c=>/^Đã từ chối hồ sơ ngày /i.test(String(c.note||'').trim())?'rejected':'callback';
  const baseRows=visibleCustomers().filter(c=>c.follow_up).filter(matchOwner).filter(c=>state.followupKind==='all'||followupKind(c)===state.followupKind).sort((a,b)=>String(a.follow_up).localeCompare(String(b.follow_up))||String(a.name||'').localeCompare(String(b.name||''),'vi'));
  const todayRows=baseRows.filter(c=>bucketOf(c)==='today'),overdueRows=baseRows.filter(c=>bucketOf(c)==='overdue'),upcomingRows=baseRows.filter(c=>bucketOf(c)==='upcoming');
  const dateOnlyToday=todayRows.filter(c=>!hasClock(c)).length;
  const timedToday=todayRows.filter(hasClock);
  const arrived=timedToday.filter(c=>(parseCrmTime(c.follow_up)?.getTime()||0)<=nowTs).length;
  const waiting=Math.max(0,timedToday.length-arrived);
  const todayCaption=[dateOnlyToday?`${dateOnlyToday} đến hạn trong ngày`:'',waiting?`${waiting} chưa đến giờ`:'',arrived?`${arrived} đã đến giờ`:''].filter(Boolean).join(' · ')||'Không có lịch hôm nay';
  const bucket=state.followupBucket,rows=bucket==='month'?baseRows:bucket==='overdue'?overdueRows:bucket==='upcoming'?upcomingRows:todayRows;
  const userOptions=role==='sale'?`<option value="${esc(state.session.user.id)}">${esc(state.session.user.display_name)}</option>`:`<option value="">Mọi nhân viên</option>${scopeUsers.map(u=>`<option value="${u.id}" ${String(u.id)===ownerFilter?'selected':''}>${esc(u.display_name)}</option>`).join('')}`;
  const kindOptions=`<select id="followup-kind"><option value="all" ${state.followupKind==='all'?'selected':''}>Tất cả loại</option><option value="rejected" ${state.followupKind==='rejected'?'selected':''}>KH bị từ chối hồ sơ</option><option value="callback" ${state.followupKind==='callback'?'selected':''}>KH hẹn gọi lại</option></select>`;
  const renderTimeCell=c=>{const d=shortDate(dateKey(c.follow_up));if(!hasClock(c))return `<div class="fu-time date-only"><strong>${esc(d)}</strong><span>Không đặt giờ</span></div>`;const p=vnParts(c.follow_up);return `<div class="fu-time"><strong>${esc((p?.time||'').slice(0,5)||'--:--')}</strong><span>${esc(d)}</span></div>`};
  const renderRejectNote=c=>{const note=String(c.note||'').trim();if(!/^Đã từ chối hồ sơ ngày /i.test(note))return '';const first=note.split(' · Lý do: ')[0];const reason=note.includes(' · Lý do: ')?note.split(' · Lý do: ').slice(1).join(' · Lý do: '):'';return `<small class="fu-reject-note" title="${esc(note)}">${esc(first)}${reason?`<span>Lý do: ${esc(reason)}</span>`:''}</small>`};
  const renderCustomerCell=c=>`<div class="fu-customer"><strong data-customer="${c.id}">${esc(c.name||'Khách hàng')}</strong><small class="fu-kind ${followupKind(c)}">${followupKind(c)==='rejected'?'KH bị từ chối hồ sơ cần chăm sóc':'Khách hàng hẹn gọi lại'}</small>${renderRejectNote(c)}</div>`;
  main.innerHTML=`<div class="premium-page followup-page followup-compact-v101"><div class="premium-page-head"><div class="premium-page-title"><h1>Follow-up</h1><p>Khách bị từ chối hồ sơ cần chăm sóc và khách hàng hẹn gọi lại.</p></div></div><section class="followup-summary-grid"><article class="followup-summary-card primary"><div class="followup-summary-icon blue">${uiIcon('calendar')}</div><div><span>Hôm nay</span><strong>${todayRows.length}</strong><small>${esc(todayCaption)}</small></div></article><article class="followup-summary-card warning"><div class="followup-summary-icon red">${uiIcon('alert')}</div><div><span>Quá hạn</span><strong>${overdueRows.length}</strong><small>Cần xử lý ngay</small></div></article><article class="followup-summary-card info"><div class="followup-summary-icon indigo">${uiIcon('clock')}</div><div><span>Sắp tới</span><strong>${upcomingRows.length}</strong><small>Từ ngày mai</small></div></article></section><section class="crm-panel followup-panel"><div class="followup-toolbar"><div class="followup-tabs"><button class="followup-tab ${bucket==='today'?'active':''}" data-followup-bucket="today">Hôm nay <span>${todayRows.length}</span></button><button class="followup-tab ${bucket==='overdue'?'active':''}" data-followup-bucket="overdue">Quá hạn <span>${overdueRows.length}</span></button><button class="followup-tab ${bucket==='upcoming'?'active':''}" data-followup-bucket="upcoming">Sắp tới <span>${upcomingRows.length}</span></button></div><div class="followup-filters">${kindOptions}<select id="followup-owner">${userOptions}</select></div></div><div class="table-wrap followup-table-wrap"><table class="data-table followup-table"><thead><tr><th>Lịch hẹn</th><th>Khách hàng</th><th>SĐT</th><th>Nhân viên</th><th>Team</th><th>Tình trạng</th><th></th></tr></thead><tbody>${rows.map(c=>{const st=statusMeta(c);return `<tr><td>${renderTimeCell(c)}</td><td>${renderCustomerCell(c)}</td><td class="phone">${esc(c.phone||'')}</td><td><strong>${esc(c.owner||'Chưa phân công')}</strong></td><td>${esc(c.team||'—')}</td><td><span class="fu-state-pill ${st.cls}">${esc(st.label)}</span></td><td class="followup-action-cell"><div class="followup-action-buttons"><button class="btn primary small followup-call-btn" data-followup-open="${c.id}">${uiIcon('call','ui-svg mini')}<span>Gọi</span></button>${(role==='admin'||role==='sup')?`<button class="btn danger small" data-followup-delete="${c.id}" data-followup-name="${esc(c.name||'Khách hàng')}">Xóa</button>`:''}</div></td></tr>`}).join('')||'<tr><td colspan="7"><div class="empty">Không có lịch hẹn trong nhóm đang chọn.</div></td></tr>'}</tbody></table></div></section></div>`;
  bindCustomerLinks();
  $$('#followup-owner').forEach(el=>el.onchange=e=>{state.followupOwner=e.target.value;renderFollowup(main)});
  if($('#followup-kind'))$('#followup-kind').onchange=e=>{state.followupKind=e.target.value;renderFollowup(main)};
  $$('[data-followup-bucket]').forEach(b=>b.onclick=()=>{state.followupBucket=b.dataset.followupBucket;renderFollowup(main)});
  $$('[data-followup-open]').forEach(b=>b.onclick=()=>openCustomerModal(Number(b.dataset.followupOpen)));
  $$('[data-followup-delete]').forEach(b=>b.onclick=async()=>{if(!['admin','sup'].includes(state.session.user.role))return;const name=b.dataset.followupName||'khách hàng này';if(!confirm(`Xóa ${name} khỏi Follow-up?`))return;try{await API.request(`/followups/${b.dataset.followupDelete}`,{method:'DELETE'});await refreshCustomersOnly();state.loginAppsLoadedAt=0;renderFollowup(main);toast('Đã xóa khách khỏi Follow-up.');}catch(e){toast(e.message,'bad')}});
}

function khtnCfg(){return state.khtnConfig||structuredClone(KHTN_DEFAULT_CONFIG);}
function khtnField(key){return khtnCfg().fields?.[key]||KHTN_DEFAULT_CONFIG.fields[key]||{label:'Trường thông tin',enabled:true,required:false,type:'text'};}
function khtnFieldOrder(){
  const cfg=khtnCfg();
  const base=Array.isArray(cfg.field_order)&&cfg.field_order.length?cfg.field_order:Object.keys(cfg.fields||{}).filter(k=>cfg.fields[k]?.enabled!==false);
  return [...new Set(base)].filter(k=>cfg.fields?.[k]&&cfg.fields[k].enabled!==false);
}
function khtnValue(data,key){return KHTN_BUILTIN_ORDER.includes(key)?(data?.[key]??''):(data?.custom_fields?.[key]??'');}
function khtnSourceOptions(selected=''){
  const opts=khtnCfg().source_options||[];
  return `<option value="">-- Chọn nguồn --</option>${opts.map(x=>`<option value="${esc(x)}" ${String(x)===String(selected)?'selected':''}>${esc(x)}</option>`).join('')}`;
}
function khtnGenericOptions(options=[],selected=''){
  return `<option value="">-- Chọn --</option>${(options||[]).map(x=>`<option value="${esc(x)}" ${String(x)===String(selected)?'selected':''}>${esc(x)}</option>`).join('')}`;
}
function khtnFieldInputHtml(key,f,value=''){
  const req=f.required?'required':''; const star=f.required?' <span class="required-star">*</span>':'';
  const full=f.type==='textarea'?' full':'';
  let control='';
  if(key==='source') control=`<select id="khtn-${key}" ${req}>${khtnSourceOptions(value)}</select>`;
  else if(f.type==='select') control=`<select id="khtn-${key}" ${req}>${khtnGenericOptions(f.options||[],value)}</select>`;
  else if(f.type==='textarea') control=`<textarea id="khtn-${key}" rows="3" ${req}>${esc(value)}</textarea>`;
  else if(f.type==='date') control=`<input id="khtn-${key}" type="date" value="${esc(value)}" ${req}>`;
  else if(key==='phone') control=`<input id="khtn-${key}" inputmode="tel" value="${esc(value)}" ${req}>`;
  else if(f.type==='number'||key==='birth_year') control=`<input id="khtn-${key}" inputmode="numeric" type="number" value="${esc(value)}" ${req}>`;
  else control=`<input id="khtn-${key}" value="${esc(value)}" ${req}>`;
  return `<div class="form-field${full}"><label>${esc(f.label)}${star}</label>${control}</div>`;
}
function khtnFormFieldsHtml(data={}){
  return khtnFieldOrder().map(key=>khtnFieldInputHtml(key,khtnField(key),khtnValue(data,key))).join('');
}
function readKhtnFormPayload(){
  const out={custom_fields:{}};
  for(const key of khtnFieldOrder()){
    const el=$(`#khtn-${key}`); if(!el) continue;
    const value=String(el.value??'').trim();
    if(KHTN_BUILTIN_ORDER.includes(key)) out[key]=value; else out.custom_fields[key]=value;
  }
  return out;
}
function renderKhtnEntryForm(main){
  const u=state.session.user;
  main.innerHTML=`${pageHead('Nhập KHTN','Nhập khách hàng tiềm năng trực tiếp trên CRM. Nhân viên và Team được ghi tự động theo tài khoản đăng nhập.')}
  <div class="card khtn-entry-card"><div class="card-head"><div><h3>Báo cáo KHTN mới</h3><span class="muted">Không cần chọn tên nhân viên — hệ thống tự ghi nhận người đang đăng nhập.</span></div></div><div class="card-body">
    <div class="khtn-user-strip"><div><span>Nhân viên</span><strong>${esc(u.display_name)}</strong></div><div><span>Team</span><strong>${esc(u.team||'Chưa có Team')}</strong></div></div>
    <form id="khtn-entry-form" class="form-grid khtn-form">${khtnFormFieldsHtml()}
      <div class="form-field full"><div class="call-actions"><button type="reset" class="btn">Nhập lại</button><button type="submit" class="btn primary" id="khtn-submit">Lưu KHTN</button></div></div>
    </form>
  </div></div>`;
  $('#khtn-entry-form').onsubmit=async e=>{
    e.preventDefault();
    if(state.mode!=='d1'){toast('KHTN cần D1 Online để lưu dữ liệu.','bad');return;}
    const btn=$('#khtn-submit');btn.disabled=true;
    try{
      const res=await API.request('/khtn',{method:'POST',body:JSON.stringify(readKhtnFormPayload())});
      e.target.reset();
      toast(res.duplicate_phone?'Đã lưu KHTN. Lưu ý: SĐT này đã có trong báo cáo trước đó.':'Đã lưu KHTN thành công.',res.duplicate_phone?'bad':'ok');
    }catch(err){toast(err.message,'bad')}finally{btn.disabled=false;}
  };
}
function filteredKhtnEntries(){
  const role=state.session.user.role; const q=(state.khtnSearch||'').trim().toLowerCase();
  return (state.khtnEntries||[]).filter(x=>{
    const d=dateKey(x.created_at);
    if(state.khtnDateFrom&&d<state.khtnDateFrom) return false;
    if(state.khtnDateTo&&d>state.khtnDateTo) return false;
    if((role==='admin'||role==='sup')&&state.khtnTeam&&String(x.team_id)!==String(state.khtnTeam)) return false;
    if(state.khtnEmployee&&String(x.user_id)!==String(state.khtnEmployee)) return false;
    if(state.khtnSource&&String(x.source)!==String(state.khtnSource)) return false;
    const customText=Object.values(x.custom_fields||{}).join(' ');
    if(q&&!`${x.customer_name||''} ${x.phone||''} ${x.employee||''} ${x.source||''} ${x.area||''} ${x.cccd||''} ${customText}`.toLowerCase().includes(q)) return false;
    return true;
  });
}
function exportKhtnExcel(rows){
  if(!rows.length){toast('Không có KHTN trong bộ lọc hiện tại.','bad');return;}
  if(typeof XLSX==='undefined'){toast('Không tải được thư viện Excel. Hãy kiểm tra Internet.','bad');return;}
  const fields=khtnFieldOrder();
  const data=rows.map((x,i)=>{
    const r={'STT':i+1,'Thời gian báo cáo':fmtDate(x.created_at),'Nhân viên':x.employee||'','Team':x.team||''};
    for(const key of fields) r[khtnField(key).label]=khtnValue(x,key)||'';
    r['Trùng SĐT']=Number(x.duplicate_phone_count||0)>1?'Có':'';
    return r;
  });
  const ws=XLSX.utils.json_to_sheet(data), wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,'KHTN');
  XLSX.writeFile(wb,`Bao_cao_KHTN_${state.khtnDateFrom||'all'}_${state.khtnDateTo||'all'}.xlsx`);
}
function openKhtnEdit(entry){
  const saleUsers=state.users.filter(u=>u.role==='sale');
  openAdminModal(`Sửa KHTN · ${entry.customer_name}`,`<form id="khtn-edit-form" class="form-grid khtn-form">
    <div class="form-field full"><label>Nhân viên báo cáo</label><select id="khtn-edit-user">${saleUsers.map(u=>`<option value="${u.id}" ${Number(u.id)===Number(entry.user_id)?'selected':''}>${esc(u.display_name)} · ${esc(u.team||'')}</option>`).join('')}</select></div>
    ${khtnFormFieldsHtml(entry)}
    <div class="form-field full"><div class="notice">Admin/Teamlead có thể chỉnh sửa nội dung KHTN. Teamlead chỉ thao tác dữ liệu trong Team của mình.</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="khtn-edit-cancel">Huỷ</button><button class="btn primary" type="submit">Lưu thay đổi</button></div></div>
  </form>`);
  $('#khtn-edit-cancel').onclick=closeAdminModal;
  $('#khtn-edit-form').onsubmit=async e=>{e.preventDefault();try{const payload=readKhtnFormPayload();payload.user_id=Number($('#khtn-edit-user').value);await API.request('/khtn/'+entry.id,{method:'PATCH',body:JSON.stringify(payload)});closeAdminModal();await syncFromApi();renderKHTN($('#main'));toast('Đã cập nhật KHTN.');}catch(err){toast(err.message,'bad')}};
}
function khtnConfigTypeOptions(selected){
  return [['text','Chữ ngắn'],['number','Số'],['date','Ngày'],['textarea','Nội dung dài'],['select','Danh sách chọn']].map(([v,l])=>`<option value="${v}" ${v===selected?'selected':''}>${l}</option>`).join('');
}
function khtnConfigRowHtml(key,f){
  const builtin=KHTN_BUILTIN_ORDER.includes(key), core=KHTN_CORE_FIELDS.has(key), type=f.type||KHTN_DEFAULT_CONFIG.fields[key]?.type||'text';
  const canDelete=!core;
  return `<div class="khtn-builder-row" data-khtn-config-row data-key="${esc(key)}">
    <div class="khtn-builder-main">
      <input class="khtn-builder-label" data-role="label" value="${esc(f.label||'Trường mới')}" placeholder="Tên trường">
      <select data-role="type" ${builtin?'disabled':''}>${khtnConfigTypeOptions(type)}</select>
      <label class="khtn-check"><input type="checkbox" data-role="required" ${f.required||core?'checked':''} ${core?'disabled':''}> Bắt buộc</label>
      ${canDelete?'<button type="button" class="btn small danger" data-role="delete">Xóa</button>':'<span class="khtn-core-badge">Cốt lõi</span>'}
    </div>
    <div class="khtn-builder-options ${type==='select'&&key!=='source'?'':'hidden'}" data-role="options-wrap">
      <label>Các lựa chọn <span class="muted">(ngăn cách bằng dấu |)</span></label>
      <input data-role="options" value="${esc((f.options||[]).join(' | '))}" placeholder="Ví dụ: Có | Không | Chưa rõ">
    </div>
  </div>`;
}
function bindKhtnBuilderRow(row){
  const type=row.querySelector('[data-role="type"]'), wrap=row.querySelector('[data-role="options-wrap"]');
  if(type&&!type.disabled) type.onchange=()=>wrap?.classList.toggle('hidden',type.value!=='select');
  const del=row.querySelector('[data-role="delete"]'); if(del) del.onclick=()=>row.remove();
}
function openKhtnConfig(){
  const cfg=khtnCfg(); const order=khtnFieldOrder();
  openAdminModal('Cấu hình biểu mẫu KHTN',`<form id="khtn-config-form" class="form-grid">
    <div class="form-field full"><div class="notice warning"><strong>Áp dụng cho toàn hệ thống.</strong> Bạn có thể đổi tên, thêm hoặc xóa trường nhập KHTN. Họ tên khách hàng, SĐT và Nguồn KHTN là 3 trường cốt lõi nên không thể xóa.</div></div>
    <div class="form-field full"><div class="khtn-builder-head"><strong>Các trường thông tin</strong><div><button type="button" class="btn small" id="khtn-restore-defaults">Khôi phục trường mặc định</button><button type="button" class="btn primary small" id="khtn-add-field">＋ Thêm trường</button></div></div><div class="khtn-config-list" id="khtn-config-list">${order.map(key=>khtnConfigRowHtml(key,cfg.fields?.[key]||KHTN_DEFAULT_CONFIG.fields[key])).join('')}</div></div>
    <div class="form-field full"><label>Danh sách Nguồn KHTN <span class="muted">(mỗi dòng một nguồn)</span></label><textarea id="khtn-source-options" rows="7">${esc((cfg.source_options||[]).join('\n'))}</textarea></div>
    <div class="form-field full"><div class="notice">Khi xóa một trường tự tạo, dữ liệu cũ của trường đó vẫn được giữ trong hệ thống để tránh mất dữ liệu; trường chỉ không còn xuất hiện trên form và báo cáo mới.</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="khtn-config-cancel">Huỷ</button><button class="btn primary" type="submit">Lưu cấu hình</button></div></div>
  </form>`);
  $('#khtn-config-cancel').onclick=closeAdminModal;
  $$('[data-khtn-config-row]').forEach(bindKhtnBuilderRow);
  $('#khtn-add-field').onclick=()=>{
    const key=`custom_${Date.now().toString(36)}_${Math.floor(Math.random()*1e5).toString(36)}`;
    $('#khtn-config-list').insertAdjacentHTML('beforeend',khtnConfigRowHtml(key,{label:'Trường mới',required:false,type:'text',options:[]}));
    bindKhtnBuilderRow($('#khtn-config-list').lastElementChild);
  };
  $('#khtn-restore-defaults').onclick=()=>{
    const existing=new Set($$('[data-khtn-config-row]').map(r=>r.dataset.key));
    let added=0;
    for(const key of KHTN_BUILTIN_ORDER){if(existing.has(key))continue;$('#khtn-config-list').insertAdjacentHTML('beforeend',khtnConfigRowHtml(key,cfg.fields?.[key]||KHTN_DEFAULT_CONFIG.fields[key]));bindKhtnBuilderRow($('#khtn-config-list').lastElementChild);added++;}
    toast(added?`Đã khôi phục ${added} trường mặc định.`:'Các trường mặc định đã đầy đủ.');
  };
  $('#khtn-config-form').onsubmit=async e=>{
    e.preventDefault();
    const next={fields:{},field_order:[],source_options:$('#khtn-source-options').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean)};
    for(const row of $$('[data-khtn-config-row]')){
      const key=row.dataset.key, old=cfg.fields?.[key]||KHTN_DEFAULT_CONFIG.fields[key]||{};
      const label=row.querySelector('[data-role="label"]').value.trim()||old.label||'Trường mới';
      const type=row.querySelector('[data-role="type"]').value||old.type||'text';
      const required=KHTN_CORE_FIELDS.has(key)?true:row.querySelector('[data-role="required"]').checked;
      const options=(row.querySelector('[data-role="options"]')?.value||'').split('|').map(x=>x.trim()).filter(Boolean);
      next.fields[key]={label,enabled:true,required,type,options}; next.field_order.push(key);
    }
    try{const res=await API.request('/khtn/config',{method:'PUT',body:JSON.stringify({config:next})});state.khtnConfig=res.config||next;closeAdminModal();await syncFromApi();renderKHTN($('#main'));toast('Đã cập nhật biểu mẫu KHTN.');}catch(err){toast(err.message,'bad')}
  };
}
function renderKhtnManager(main){
  const role=state.session.user.role, rows=filteredKhtnEntries();
  const activeSales=state.users.filter(u=>u.role==='sale');
  const employeesReported=new Set(rows.map(x=>String(x.user_id))).size;
  const duplicateCount=rows.filter(x=>Number(x.duplicate_phone_count||0)>1).length;
  const sources=new Set(rows.map(x=>x.source).filter(Boolean)).size;
  const byEmployee=new Map(); for(const x of rows){const key=String(x.user_id);if(!byEmployee.has(key))byEmployee.set(key,{user_id:x.user_id,employee:x.employee,team:x.team,count:0});byEmployee.get(key).count++;}
  const employeeSummary=[...byEmployee.values()].sort((a,b)=>b.count-a.count||String(a.employee).localeCompare(String(b.employee),'vi'));
  const fields=khtnFieldOrder();
  const actions=`<button class="btn" id="khtn-config-open">⚙ Cấu hình KHTN</button><button class="btn primary" id="khtn-export">⬇ Xuất Excel</button>`;
  const headers=fields.map(key=>`<th>${esc(khtnField(key).label)}</th>`).join('');
  const bodyRows=rows.map(x=>`<tr><td>${fmtDate(x.created_at)}</td><td><strong>${esc(x.employee)}</strong></td><td>${esc(x.team||'')}</td>${fields.map(key=>{const v=khtnValue(x,key);return `<td class="${key==='phone'?'phone':''}">${esc(v||'')}${key==='phone'&&Number(x.duplicate_phone_count||0)>1?'<span class="duplicate-badge">Trùng</span>':''}</td>`}).join('')}<td><div class="khtn-row-actions"><button class="btn small" data-khtn-edit="${x.id}">Sửa</button><button class="btn small danger" data-khtn-delete="${x.id}">Xóa</button></div></td></tr>`).join('');
  main.innerHTML=`${pageHead('Báo cáo KHTN',role==='teamlead'?`Theo dõi KHTN của ${esc(state.session.user.team||'Team của bạn')}.`:'Theo dõi KHTN toàn bộ nhân viên và xuất báo cáo Excel.',actions)}
    <div class="kpis dashboard-kpis khtn-kpis"><div class="kpi"><div class="label">Tổng KHTN</div><div class="value">${rows.length}</div><div class="sub">Theo bộ lọc hiện tại</div></div><div class="kpi positive"><div class="label">Nhân viên đã báo cáo</div><div class="value">${employeesReported}</div><div class="sub">Có phát sinh KHTN</div></div><div class="kpi"><div class="label">Nguồn KHTN</div><div class="value">${sources}</div><div class="sub">Nguồn khác nhau</div></div><div class="kpi ${duplicateCount?'attn':''}"><div class="label">Trùng SĐT</div><div class="value">${duplicateCount}</div><div class="sub">Dòng có SĐT trùng</div></div></div>
    <div class="toolbar khtn-toolbar"><input class="search" id="khtn-search" placeholder="Tìm KH, SĐT, nhân viên, CCCD..." value="${esc(state.khtnSearch||'')}"><label>Từ <input type="date" id="khtn-from" value="${esc(state.khtnDateFrom||'')}"></label><label>Đến <input type="date" id="khtn-to" value="${esc(state.khtnDateTo||'')}"></label>${(role==='admin'||role==='sup')?`<select id="khtn-team"><option value="">Tất cả Team</option>${state.teamObjects.map(t=>`<option value="${t.id}" ${String(state.khtnTeam)===String(t.id)?'selected':''}>${esc(t.name)}</option>`).join('')}</select>`:''}<select id="khtn-employee"><option value="">Tất cả nhân viên</option>${activeSales.map(u=>`<option value="${u.id}" ${String(state.khtnEmployee)===String(u.id)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select><select id="khtn-source"><option value="">Tất cả nguồn</option>${(khtnCfg().source_options||[]).map(x=>`<option value="${esc(x)}" ${String(state.khtnSource)===String(x)?'selected':''}>${esc(x)}</option>`).join('')}</select><button class="btn" id="khtn-today">Hôm nay</button><button class="btn" id="khtn-clear">Xóa lọc</button></div>
    <div class="card khtn-employee-summary"><div class="card-head"><div><h3>Tổng hợp theo nhân viên</h3><span class="muted">Bấm nhân viên để lọc danh sách KHTN phía dưới.</span></div></div><div class="khtn-employee-chips">${employeeSummary.map(x=>`<button class="khtn-employee-chip ${String(state.khtnEmployee)===String(x.user_id)?'active':''}" data-khtn-employee="${x.user_id}"><strong>${esc(x.employee)}</strong><span>${esc(x.team||'')} · ${x.count} KHTN</span></button>`).join('')||'<div class="empty small-empty">Chưa có KHTN trong khoảng đang chọn.</div>'}</div></div>
    <div class="table-wrap khtn-table-wrap"><table class="data-table khtn-table"><thead><tr><th>Thời gian</th><th>Nhân viên</th><th>Team</th>${headers}<th></th></tr></thead><tbody>${bodyRows||`<tr><td colspan="${fields.length+4}"><div class="empty">Chưa có báo cáo KHTN.</div></td></tr>`}</tbody></table></div>`;
  const rerender=()=>renderKHTN(main);
  $('#khtn-search').oninput=e=>{state.khtnSearch=e.target.value;clearTimeout(state._khtnSearchTimer);state._khtnSearchTimer=setTimeout(rerender,250)};
  $('#khtn-from').onchange=e=>{state.khtnDateFrom=e.target.value;rerender()}; $('#khtn-to').onchange=e=>{state.khtnDateTo=e.target.value;rerender()};
  if($('#khtn-team')) $('#khtn-team').onchange=e=>{state.khtnTeam=e.target.value;state.khtnEmployee='';rerender()};
  $('#khtn-employee').onchange=e=>{state.khtnEmployee=e.target.value;rerender()}; $('#khtn-source').onchange=e=>{state.khtnSource=e.target.value;rerender()};
  $('#khtn-today').onclick=()=>{state.khtnDateFrom=todayISO();state.khtnDateTo=todayISO();rerender()};
  $('#khtn-clear').onclick=()=>{state.khtnDateFrom='';state.khtnDateTo='';state.khtnTeam='';state.khtnEmployee='';state.khtnSource='';state.khtnSearch='';rerender()};
  $('#khtn-export').onclick=()=>exportKhtnExcel(rows); $('#khtn-config-open').onclick=openKhtnConfig;
  $$('[data-khtn-employee]').forEach(b=>b.onclick=()=>{state.khtnEmployee=String(state.khtnEmployee)===String(b.dataset.khtnEmployee)?'':b.dataset.khtnEmployee;rerender()});
  $$('[data-khtn-edit]').forEach(b=>b.onclick=()=>openKhtnEdit(state.khtnEntries.find(x=>Number(x.id)===Number(b.dataset.khtnEdit))));
  $$('[data-khtn-delete]').forEach(b=>b.onclick=()=>deleteKhtnEntry(Number(b.dataset.khtnDelete)));
}
async function deleteKhtnEntry(id){
  const entry=(state.khtnEntries||[]).find(x=>Number(x.id)===Number(id));
  if(!entry) return;
  if(!window.confirm(`Bạn có chắc muốn XÓA KHTN của khách "${entry.customer_name}" do ${entry.employee} báo cáo?\n\nThao tác này không thể hoàn tác.`)) return;
  try{
    await API.request('/khtn/'+id,{method:'DELETE'});
    state.khtnEntries=state.khtnEntries.filter(x=>Number(x.id)!==id);
    try{state.khtnEntries=(await API.request('/khtn')).items||state.khtnEntries;}catch{}
    renderKHTN($('#main')); toast('Đã xóa KHTN báo cáo sai.');
  }catch(err){toast(err.message,'bad')}
}
// V5.1: Báo cáo đầu ngày, lặp nhiều khách và phân quyền Admin / Teamlead / Sale.
const moneyVND=n=>new Intl.NumberFormat('vi-VN').format(Number(n)||0)+' đ';
function dailyLoginRow(x={}){
  return `<div class="daily-customer-row daily-login-row"><div class="daily-customer-fields">
    <div class="form-field"><label>Tên khách hàng</label><input data-daily="name" placeholder="Họ và tên KH" value="${esc(x.customer_name||'')}" required maxlength="150"></div>
    <div class="form-field"><label>CCCD / CMND</label><input data-daily="cccd" inputmode="numeric" placeholder="9 hoặc 12 chữ số" value="${esc(x.cccd||'')}" required maxlength="12" pattern="[0-9]{9}|[0-9]{12}"></div>
    <button type="button" class="btn small danger daily-remove">Xóa</button></div></div>`;
}
function dailySigningRow(x={}){
  return `<div class="daily-customer-row daily-sign-row"><div class="daily-customer-fields daily-sign-fields">
    <div class="form-field"><label>Tên khách hàng</label><input data-daily="name" placeholder="Họ và tên KH" value="${esc(x.customer_name||'')}" required maxlength="150"></div>
    <div class="form-field"><label>Giờ hẹn ký</label><input data-daily="time" type="time" value="${esc(x.sign_time||'')}" required></div>
    <div class="form-field"><label>Dự kiến ký (VNĐ)</label><input data-daily="amount" inputmode="numeric" type="number" step="1" min="1" max="100000000000000" value="${esc(x.expected_amount??'')}" placeholder="Ví dụ: 50000000" required></div>
    <button type="button" class="btn small danger daily-remove">Xóa</button></div></div>`;
}
function dailyRowControls(root){
  $$('button.daily-remove',root).forEach(b=>b.onclick=()=>{b.closest('.daily-customer-row').remove();updateDailyCounts()});
  updateDailyCounts();
}
function updateDailyCounts(){
  const a=$('#daily-login-count'),b=$('#daily-sign-count');
  if(a)a.textContent=$$('.daily-login-row').length;
  if(b)b.textContent=$$('.daily-sign-row').length;
  const empty=$('#daily-sign-empty');if(empty)empty.classList.toggle('hidden',$$('.daily-sign-row').length>0);
}
function renderDailyEntry(main){
  const u=state.session.user, today=todayVN();
  const current=(state.dailyReports||[]).find(x=>x.report_date===today);
  const loginList=Array.isArray(current?.login_apps)?current.login_apps:[], signList=Array.isArray(current?.signings)?current.signings:[];
  const dailyError=state.dailyReportsError?`<div class="notice warning">Chưa tải được báo cáo đầu ngày. Kiểm tra migration 0007: ${esc(state.dailyReportsError)}</div>`:'';
  main.innerHTML=`${pageHead('Báo cáo đầu ngày','Báo cáo khách dự kiến login app và hẹn ký trong hôm nay. Mỗi ngày lưu một báo cáo, có thể cập nhật lại trong ngày.')}
  ${dailyError}<div class="card daily-entry-card"><div class="card-head"><div><h3>Báo cáo ngày ${shortDate(today)}</h3><span class="muted">${esc(u.display_name)} · ${esc(u.team||'Chưa có Team')}</span></div><span class="daily-state">${current?'Đã gửi · Có thể cập nhật':'Chưa gửi báo cáo'}</span></div><div class="card-body">
  <form id="daily-report-form">
    <div class="daily-section-head"><div><h3>1. Khách dự kiến Login app <span id="daily-login-count" class="daily-counter">0</span></h3><span class="muted">Ghi tên KH và CCCD. Mỗi dòng tương ứng 1 app.</span></div><button type="button" class="btn primary" id="daily-add-login">＋ Thêm 1 khách</button></div>
    <div id="daily-login-list" class="daily-rows">${loginList.map(dailyLoginRow).join('')}</div>
    <div class="daily-section-head"><div><h3>2. Khách dự kiến ký hôm nay <span id="daily-sign-count" class="daily-counter">0</span></h3><span class="muted">Có khách hẹn ký thì thêm từng khách, giờ hẹn và số tiền dự kiến.</span></div><button type="button" class="btn primary" id="daily-add-sign">＋ Thêm 1 khách ký</button></div>
    <div id="daily-sign-list" class="daily-rows">${signList.map(dailySigningRow).join('')}</div>
    <div class="notice" id="daily-sign-empty">Hôm nay chưa có khách dự kiến ký.</div>
    <div class="daily-submit-row"><span class="muted">Số lượng app và khách ký sẽ tự đếm theo các dòng nhập.</span><button type="submit" class="btn primary" id="daily-save">${current?'Cập nhật báo cáo':'Gửi báo cáo đầu ngày'}</button></div>
  </form></div></div>`;
  $('#daily-add-login').onclick=()=>{if($$('.daily-login-row').length>=100){toast('Tối đa 100 khách login.','bad');return;}$('#daily-login-list').insertAdjacentHTML('beforeend',dailyLoginRow());dailyRowControls($('#daily-login-list'));};
  $('#daily-add-sign').onclick=()=>{if($$('.daily-sign-row').length>=100){toast('Tối đa 100 khách ký.','bad');return;}$('#daily-sign-list').insertAdjacentHTML('beforeend',dailySigningRow());dailyRowControls($('#daily-sign-list'));};
  dailyRowControls($('#daily-report-form'));
  $('#daily-report-form').onsubmit=async e=>{
    e.preventDefault();if(state.mode!=='d1'){toast('Cần D1 Online để gửi báo cáo.','bad');return;}
    const login_apps=$$('.daily-login-row').map(row=>({customer_name:$('[data-daily="name"]',row).value.trim(),cccd:$('[data-daily="cccd"]',row).value.trim()}));
    const signings=$$('.daily-sign-row').map(row=>({customer_name:$('[data-daily="name"]',row).value.trim(),sign_time:$('[data-daily="time"]',row).value,expected_amount:Number($('[data-daily="amount"]',row).value)}));
    const btn=$('#daily-save');btn.disabled=true;
    try{
      const res=await API.request('/daily-reports',{method:'POST',body:JSON.stringify({report_date:today,login_apps,signings})});
      const replacement={...current,...res,user_id:u.id,employee:u.display_name,team:u.team,team_id:u.team_id};
      state.dailyReports=[...(state.dailyReports||[]).filter(x=>x.report_date!==today),replacement];
      renderDailyEntry(main);toast('Đã lưu báo cáo đầu ngày thành công.');
    }catch(err){toast(err.message,'bad');btn.disabled=false;}
  };
}
function filteredDailyReports(){
  const q=(state.dailySearch||'').toLowerCase().trim();
  return (state.dailyReports||[]).filter(x=>{
    if(state.dailyDateFrom&&x.report_date<state.dailyDateFrom)return false;
    if(state.dailyDateTo&&x.report_date>state.dailyDateTo)return false;
    if(['admin','sup'].includes(state.session.user.role)&&state.dailyTeam&&String(x.team_id)!==String(state.dailyTeam))return false;
    if(state.dailyEmployee&&String(x.user_id)!==String(state.dailyEmployee))return false;
    if(q&&!`${x.employee} ${x.team} ${(x.login_apps||[]).map(y=>`${y.customer_name} ${y.cccd}`).join(' ')} ${(x.signings||[]).map(y=>y.customer_name).join(' ')}`.toLowerCase().includes(q))return false;
    return true;
  });
}
function dailyExport(rows){
  if(!rows.length){toast('Chưa có báo cáo trong bộ lọc hiện tại.','bad');return;}
  if(!window.XLSX){toast('Không tải được thư viện Excel.','bad');return;}
  const summary=[],apps=[],signs=[];
  rows.forEach((x,i)=>{
    summary.push({'STT':i+1,'Ngày':x.report_date,'Nhân viên':x.employee,'Team':x.team,'Số app login':x.login_apps.length,'Số khách hẹn ký':x.signings.length,'Tổng dự kiến ký (VNĐ)':x.signings.reduce((n,z)=>n+Number(z.expected_amount||0),0)});
    x.login_apps.forEach((z,j)=>apps.push({'Ngày':x.report_date,'Nhân viên':x.employee,'Team':x.team,'STT app':j+1,'Tên khách hàng':z.customer_name,'CCCD':String(z.cccd||'')}));
    x.signings.forEach((z,j)=>signs.push({'Ngày':x.report_date,'Nhân viên':x.employee,'Team':x.team,'STT lịch ký':j+1,'Tên khách hàng':z.customer_name,'Giờ hẹn ký':z.sign_time,'Số tiền dự kiến (VNĐ)':Number(z.expected_amount||0)}));
  });
  const wb=XLSX.utils.book_new();
  for(const [name,data,headers] of [
    ['Tổng hợp',summary,['Ngày','Nhân viên','Team','Số app login','Số khách hẹn ký','Tổng dự kiến ký (VNĐ)']],
    ['Khách login',apps,['Ngày','Nhân viên','Team','STT app','Tên khách hàng','CCCD']],
    ['Khách hẹn ký',signs,['Ngày','Nhân viên','Team','STT lịch ký','Tên khách hàng','Giờ hẹn ký','Số tiền dự kiến (VNĐ)']]
  ]){
    const ws=XLSX.utils.json_to_sheet(data,{header:headers});
    ws['!cols']=headers.map(h=>({wch:h.includes('Tên')?29:h.includes('CCCD')?19:19}));
    XLSX.utils.book_append_sheet(wb,ws,name);
  }
  XLSX.writeFile(wb,`Bao_cao_dau_ngay_${state.dailyDateFrom||'tat-ca'}_${state.dailyDateTo||'tat-ca'}.xlsx`);
}
function renderDailyManager(main){
  const rows=filteredDailyReports(),allLogins=rows.reduce((n,x)=>n+x.login_apps.length,0),allSigns=rows.reduce((n,x)=>n+x.signings.length,0),sum=rows.reduce((n,x)=>n+x.signings.reduce((a,b)=>a+Number(b.expected_amount||0),0),0);
  const users=state.users.filter(u=>u.role==='sale');
  const dailyError=state.dailyReportsError?`<div class="notice warning">Chưa tải được báo cáo đầu ngày. Kiểm tra migration 0007: ${esc(state.dailyReportsError)}</div>`:'';
  main.innerHTML=`${pageHead('Báo cáo đầu ngày',state.session.user.role==='teamlead'?'Theo dõi báo cáo của Sale trong Team bạn.':'Theo dõi kế hoạch login và lịch ký của các Team.',`<button class="btn primary" id="daily-export">⬇ Xuất Excel</button>`)}
    ${dailyError}<div class="kpis dashboard-kpis daily-kpis"><div class="kpi"><div class="label">Nhân viên đã báo cáo</div><div class="value">${new Set(rows.map(x=>x.user_id)).size}</div><div class="sub">${rows.length} báo cáo</div></div><div class="kpi"><div class="label">Dự kiến login app</div><div class="value">${allLogins}</div><div class="sub">Tổng số khách login</div></div><div class="kpi"><div class="label">Khách hẹn ký</div><div class="value">${allSigns}</div><div class="sub">Tổng số lịch ký</div></div><div class="kpi positive"><div class="label">Tổng dự kiến ký</div><div class="value daily-money">${moneyVND(sum)}</div><div class="sub">Theo bộ lọc đang xem</div></div></div>
    <div class="toolbar daily-toolbar"><label>Từ <input type="date" id="daily-from" value="${esc(state.dailyDateFrom||'')}"></label><label>Đến <input type="date" id="daily-to" value="${esc(state.dailyDateTo||'')}"></label>${['admin','sup'].includes(state.session.user.role)?`<select id="daily-team"><option value="">Tất cả Team</option>${state.teamObjects.map(t=>`<option value="${t.id}" ${String(state.dailyTeam)===String(t.id)?'selected':''}>${esc(t.name)}</option>`).join('')}</select>`:''}<select id="daily-employee"><option value="">Tất cả nhân viên</option>${users.map(u=>`<option value="${u.id}" ${String(state.dailyEmployee)===String(u.id)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select><input class="search" id="daily-search" placeholder="Tìm nhân viên, tên KH, CCCD..." value="${esc(state.dailySearch||'')}"><button type="button" class="btn" id="daily-today">Hôm nay</button><button type="button" class="btn" id="daily-clear">Xóa lọc</button></div>
    <div class="card daily-manager-card"><div class="card-head"><h3>Chi tiết theo nhân viên</h3></div><div class="table-wrap"><table class="data-table daily-table"><thead><tr><th>Ngày</th><th>Nhân viên</th><th>Team</th><th>Login app</th><th>Khách ký</th><th>Dự kiến ký</th><th>Chi tiết</th></tr></thead><tbody>${rows.map((x,i)=>`<tr><td>${esc(x.report_date)}</td><td><strong>${esc(x.employee)}</strong></td><td>${esc(x.team||'')}</td><td><strong>${x.login_apps.length}</strong></td><td><strong>${x.signings.length}</strong></td><td>${moneyVND(x.signings.reduce((a,z)=>a+Number(z.expected_amount||0),0))}</td><td><button type="button" class="btn small" data-daily-view="${i}">Xem khách</button></td></tr>`).join('')||'<tr><td colspan="7">Chưa có báo cáo trong khoảng đang chọn.</td></tr>'}</tbody></table></div></div>`;
  const rerender=()=>renderDailyManager(main);
  $('#daily-from').onchange=e=>{state.dailyDateFrom=e.target.value;rerender()};
  $('#daily-to').onchange=e=>{state.dailyDateTo=e.target.value;rerender()};
  if($('#daily-team'))$('#daily-team').onchange=e=>{state.dailyTeam=e.target.value;state.dailyEmployee='';rerender()};
  $('#daily-employee').onchange=e=>{state.dailyEmployee=e.target.value;rerender()};
  $('#daily-search').oninput=e=>{state.dailySearch=e.target.value};
  $('#daily-search').onchange=rerender;
  $('#daily-today').onclick=()=>{state.dailyDateFrom=todayVN();state.dailyDateTo=todayVN();rerender()};
  $('#daily-clear').onclick=()=>{state.dailyDateFrom='';state.dailyDateTo='';state.dailyTeam='';state.dailyEmployee='';state.dailySearch='';rerender()};
  $('#daily-export').onclick=()=>dailyExport(rows);
  $$('[data-daily-view]').forEach(b=>b.onclick=()=>{
    const x=rows[Number(b.dataset.dailyView)];if(!x)return;
    openAdminModal(`Báo cáo ${x.employee} · ${shortDate(x.report_date)}`,`<div class="daily-modal-list"><h3>Login app (${x.login_apps.length})</h3>
      ${x.login_apps.length?x.login_apps.map((z,i)=>`<div class="daily-detail-line"><strong>${i+1}. ${esc(z.customer_name)}</strong><span>CCCD: ${esc(z.cccd)}</span></div>`).join(''):'<p class="muted">Không có app dự kiến.</p>'}
      <h3>Hẹn ký (${x.signings.length})</h3>${x.signings.length?x.signings.map((z,i)=>`<div class="daily-detail-line"><strong>${i+1}. ${esc(z.customer_name)}</strong><span>${esc(z.sign_time)} · ${moneyVND(z.expected_amount)}</span></div>`).join(''):'<p class="muted">Không có lịch ký.</p>'}
      <div class="daily-detail-total">Tổng dự kiến ký: <strong>${moneyVND(x.signings.reduce((a,z)=>a+Number(z.expected_amount||0),0))}</strong></div></div>`);
  });
}
function renderDailyReports(main){
  if(state.session.user.role==='sale')return renderDailyEntry(main);
  return renderDailyManager(main);
}


function leadStagePill(status){
  if(!status) return '<span class="lead-stage new">Chưa xử lý</span>';
  const cls=status==='LOGIN_APP'?'login':status==='SIGNED'?'signed':LEAD_NEGATIVE_STATUSES.has(status)?'negative':'new';
  return `<span class="lead-stage ${cls}">${esc(LEAD_STATUS_LABELS[status]||status)}</span>`;
}
async function loadLeads(force=false){
  if(state.mode!=='d1'){
    state.leads=state.customers.filter(c=>['Y01','Y02'].includes(c.status)).map(c=>({customer_id:c.id,source_call_status:c.status,name:c.name,phone:c.phone,source:c.source,call_status:c.status,team:c.team,owner:c.owner,lead_status:null,lead_created_at:c.updated_at||c.received}));
    state.leadLoadedAt=Date.now();return;
  }
  if(state.leadLoading||(!force&&state.leadLoadedAt&&Date.now()-state.leadLoadedAt<60000))return;
  state.leadLoading=true;state.leadError='';
  try{const r=await API.request('/leads');state.leads=r.items||[];state.leadLoadedAt=Date.now();}
  catch(e){state.leadError=e.message||'Không tải được Lead.';}
  finally{state.leadLoading=false;}
}
function leadScopeRows(){
  const role=state.session.user.role,ownTeamId=String(state.session.user.team_id||''),ownUserId=String(state.session.user.id||'');
  return (state.leads||[]).filter(x=>{
    // Client-side guard mirrors server permissions; backend remains authoritative.
    if(role==='teamlead'&&String(x.team_id)!==ownTeamId)return false;
    if(role==='sale'&&String(x.assigned_user_id)!==ownUserId)return false;
    if((role==='admin'||role==='sup')&&state.leadTeamFilter&&String(x.team_id)!==String(state.leadTeamFilter))return false;
    return true;
  });
}
function leadDateScopeRows(){
  const rows=leadScopeRows();
  const from=String(state.leadDateFrom||'').trim(),to=String(state.leadDateTo||'').trim();
  if(!from&&!to)return rows;
  return rows.filter(x=>{const d=dateKey(x.lead_created_at);if(!d)return false;if(from&&d<from)return false;if(to&&d>to)return false;return true;});
}
function leadFilteredRows(){
  const q=(state.leadSearch||'').trim().toLowerCase(),role=state.session.user.role;
  return leadDateScopeRows().filter(x=>{
    if(state.leadStatusFilter==='UNPROCESSED'&&x.lead_status)return false;
    if(state.leadStatusFilter&&state.leadStatusFilter!=='UNPROCESSED'&&x.lead_status!==state.leadStatusFilter)return false;
    if(q&&!`${x.name||''} ${x.phone||''} ${x.owner||''} ${x.source||''}`.toLowerCase().includes(q))return false;
    return true;
  }).sort((a,b)=>String(b.lead_created_at||'').localeCompare(String(a.lead_created_at||''))||Number(b.customer_id)-Number(a.customer_id));
}
function leadEmployeeOptions(){
  const role=state.session.user.role;
  if(role==='sale')return [];
  const seen=new Map();
  for(const x of leadDateScopeRows()){if(x.assigned_user_id&&x.owner&&!seen.has(String(x.assigned_user_id)))seen.set(String(x.assigned_user_id),{id:x.assigned_user_id,name:x.owner});}
  return [...seen.values()].sort((a,b)=>String(a.name).localeCompare(String(b.name),'vi'));
}
function leadDateCaption(){
  const from=state.leadDateFrom,to=state.leadDateTo;
  if(!from&&!to)return 'Tất cả ngày phát sinh';
  if(from&&to)return `${shortDate(from)} → ${shortDate(to)}`;
  if(from)return `Từ ${shortDate(from)}`;
  return `Đến ${shortDate(to)}`;
}
function leadRowsHtml(){
  const role=state.session.user.role,rows=leadFilteredRows();
  const colCount=(role==='admin'||role==='sup')?9:role==='sale'?7:8;
  if(!rows.length)return `<tr><td colspan="${colCount}"><div class="empty">Không có Lead phù hợp.</div></td></tr>`;
  const grouped=new Map();
  for(const x of rows){const day=dateKey(x.lead_created_at)||'Không rõ ngày';if(!grouped.has(day))grouped.set(day,[]);grouped.get(day).push(x);}
  return [...grouped.entries()].map(([day,items])=>{
    const label=day==='Không rõ ngày'?day:shortDate(day);
    const groupHead=`<tr class="lead-date-group"><td colspan="${colCount}"><div><strong>📅 ${esc(label)}</strong><span>${items.length} Lead phát sinh</span></div></td></tr>`;
    const itemRows=items.map(x=>{
      const callChanged=String(x.call_status||'')!==String(x.source_call_status||'');
      const callNote=String(x.last_call_note||'').trim();
      const latestCall=`<div class="lead-latest-call">${x.call_status?statusPill(x.call_status):'<span class="muted">—</span>'}${callNote?`<small title="${esc(callNote)}">${esc(callNote)}</small>`:''}${x.last_call_at?`<small>${fmtDate(x.last_call_at)}${callChanged?' · đã gọi lại':''}</small>`:''}</div>`;
      const note=String(x.latest_lead_note||'').trim();
      const noteMeta=[x.latest_lead_note_by||'',x.latest_lead_note_at?fmtDate(x.latest_lead_note_at):''].filter(Boolean).join(' · ');
      const mainRow=`<tr class="lead-main-row">
      <td><div class="lead-customer"><strong>${esc(x.name)}</strong><small>${esc(x.phone||'')}</small></div></td>
      <td>${v1027ManualLeadOriginPill(x)}</td><td>${String(x.lead_origin||'').toUpperCase()==='MANUAL'&&!x.last_call_at?'<div class="lead-latest-call"><span class="muted">Chưa có cuộc gọi</span></div>':latestCall}</td><td>${esc(x.source||'—')}</td>
      ${(role==='admin'||role==='sup')?`<td>${esc(x.team||'—')}</td>`:''}${role!=='sale'?`<td>${esc(x.owner||'Chưa giao')}</td>`:''}
      <td><div class="lead-stage-with-reason">${leadStagePill(x.lead_status)}${x.lead_status==='NO_LOGIN'&&x.lead_reason?`<small>${esc(x.lead_reason)}</small>`:''}</div></td><td>${x.lead_updated_at?fmtDate(x.lead_updated_at):'<span class="muted">Chưa xử lý</span>'}</td>
      <td><div class="lead-actions">${role==='sale'
        ? `<button class="btn small primary" data-lead-update="${x.customer_id}">Cập nhật</button><button class="btn small" data-lead-note="${x.customer_id}">+ Ghi chú</button><button class="btn small" data-lead-history="${x.customer_id}">Lịch sử</button>`
        : `<button class="btn small primary" data-lead-row-remind="${Number(x.assigned_user_id||0)}" data-lead-row-name="${esc(x.name||'Khách hàng')}" ${x.assigned_user_id?'':'disabled'}>🔔 Nhắc cập nhật</button>`}${['admin','sup','teamlead'].includes(role)?`<button class="btn small danger" data-lead-delete="${x.customer_id}">Xóa</button>`:''}</div></td>
    </tr>`;
      const noteRow=note?`<tr class="lead-inline-note-row"><td colspan="${colCount}"><div class="lead-inline-note"><span class="lead-inline-note-icon">📝</span><div><p>${esc(note)}</p>${noteMeta?`<small>${esc(noteMeta)}</small>`:''}</div></div></td></tr>`:'';
      return mainRow+noteRow;
    }).join('');
    return groupHead+itemRows;
  }).join('');
}
function bindLeadRows(){
  $$('[data-lead-update]').forEach(b=>b.onclick=()=>openLeadUpdateModal(Number(b.dataset.leadUpdate)));
  $$('[data-lead-note]').forEach(b=>b.onclick=()=>openLeadNoteModal(Number(b.dataset.leadNote)));
  $$('[data-lead-history]').forEach(b=>b.onclick=()=>openLeadHistory(Number(b.dataset.leadHistory)));
  $$('[data-lead-row-remind]').forEach(b=>b.onclick=async()=>{
    const uid=Number(b.dataset.leadRowRemind||0);if(!uid)return;
    const old=b.textContent;b.disabled=true;b.textContent='Đang gửi…';
    await v109_remindEmployee(uid,b.dataset.leadRowName||'Khách hàng','Lead');
    b.textContent='✓ Đã nhắc';
    setTimeout(()=>{b.disabled=false;b.textContent=old;},1600);
  });
  $$('[data-lead-delete]').forEach(b=>b.onclick=()=>deleteLead(Number(b.dataset.leadDelete)));
}
async function deleteLead(customerId){
  if(!['admin','sup','teamlead'].includes(state.session.user.role)){toast('Chỉ Admin hoặc Team Leader được xóa Lead.','bad');return;}
  const x=(state.leads||[]).find(v=>Number(v.customer_id)===Number(customerId));if(!x)return;
  if(!confirm(`Xóa Lead của ${x.name}?\n\nKhách hàng và toàn bộ lịch sử cuộc gọi gốc vẫn được giữ lại. Tiến trình/Ghi chú Lead sẽ bị xóa.`))return;
  try{await API.request(`/leads/${customerId}`,{method:'DELETE'});state.leads=(state.leads||[]).filter(v=>Number(v.customer_id)!==Number(customerId));renderLeads($('#main'));toast('Đã xóa Lead. Lịch sử cuộc gọi của khách vẫn được giữ.');}catch(err){toast(err.message,'bad')}
}

function refreshLeadTableOnly(){const body=$('#lead-table-body');if(body){body.innerHTML=leadRowsHtml();bindLeadRows();}}
function leadTeamTabsHtml(){
  const role=state.session.user.role;
  if(role==='sale')return '';
  if(role==='teamlead'){
    return `<div class="lead-team-tabs"><button class="lead-team-tab active" type="button">${esc(state.session.user.team||'Team của bạn')}</button></div>`;
  }
  const dateRows=(state.leads||[]).filter(x=>{
    const d=dateKey(x.lead_created_at);if(!d)return false;
    const from=String(state.leadDateFrom||'').trim(),to=String(state.leadDateTo||'').trim();
    if(from&&d<from)return false;if(to&&d>to)return false;return true;
  });
  const teams=state.teamObjects||[];
  const allCount=dateRows.length;
  return `<div class="lead-team-tabs"><button class="lead-team-tab ${!state.leadTeamFilter?'active':''}" type="button" data-lead-team-tab="">Tất cả Team <span>${allCount}</span></button>${teams.map(t=>{const count=dateRows.filter(x=>String(x.team_id)===String(t.id)).length;return `<button class="lead-team-tab ${String(state.leadTeamFilter)===String(t.id)?'active':''}" type="button" data-lead-team-tab="${t.id}">${esc(t.name)} <span>${count}</span></button>`}).join('')}</div>`;
}
function leadReminderRows(){
  if(state.session.user.role==='sale')return [];
  const map=new Map();
  for(const x of leadDateScopeRows()){
    const id=String(x.assigned_user_id||'');
    if(!id||!x.owner)continue;
    if(!map.has(id))map.set(id,{id:Number(id),name:x.owner,team:x.team||'',total:0,unprocessed:0,updated:0});
    const r=map.get(id);r.total++;
    if(!x.lead_status)r.unprocessed++;
    const t=parseCrmTime(x.lead_updated_at)?.getTime()||0;if(t>r.updated)r.updated=t;
  }
  return [...map.values()].sort((a,b)=>b.unprocessed-a.unprocessed||b.total-a.total||String(a.name).localeCompare(String(b.name),'vi'));
}
function leadReminderPanelHtml(){
  const role=state.session.user.role;if(role==='sale')return '';
  const rows=leadReminderRows();if(!rows.length)return '';
  return `<div class="card lead-reminder-card"><div class="card-head"><div><h3>🔔 Nhắc cập nhật Lead theo nhân viên</h3><span class="muted">Gửi nhắc trực tiếp qua Chat nội bộ. Mỗi lần nhắc chỉ ghi 1 tin nhắn D1.</span></div></div><div class="lead-reminder-list">${rows.map(r=>{const sending=!!state.leadReminderSending?.[r.id],sent=!!state.leadReminderSent?.[r.id];const disabled=r.unprocessed===0||sending;return `<div class="lead-reminder-item"><div class="lead-reminder-person"><span class="chat-avatar small">${esc(initials(r.name))}</span><div><strong>${esc(r.name)}</strong><small>${(role==='admin'||role==='sup')&&r.team?esc(r.team):`${r.total} Lead trong khoảng đang xem`}</small></div></div><div class="lead-reminder-counts"><span><b>${r.total}</b> Lead</span><span class="${r.unprocessed?'needs-update':'done'}"><b>${r.unprocessed}</b> chưa xử lý</span></div><button type="button" class="btn small ${r.unprocessed?'primary':''}" data-lead-remind="${r.id}" ${disabled?'disabled':''}>${sending?'Đang gửi…':sent?'✓ Đã nhắc':r.unprocessed?'🔔 Nhắc cập nhật':'Đã xử lý'}</button></div>`}).join('')}</div></div>`;
}
async function sendLeadReminder(userId){
  const row=leadReminderRows().find(x=>Number(x.id)===Number(userId));if(!row||row.unprocessed<1)return;
  if(state.mode!=='d1'){toast('Nhắc cập nhật Lead chỉ hoạt động khi kết nối D1 Online.','bad');return;}
  state.leadReminderSending[row.id]=true;renderLeads($('#main'));
  const message=`🔔 Nhắc cập nhật Lead: Bạn đang có ${row.total} Lead phát sinh trong ${leadDateCaption()}, trong đó ${row.unprocessed} Lead chưa xử lý. Vui lòng cập nhật tiến trình hoặc ghi chú khi có kết quả mới.`;
  try{
    await API.request('/chat/messages',{method:'POST',body:JSON.stringify({recipient_user_id:Number(row.id),message})});
    state.leadReminderSent[row.id]=Date.now();toast(`Đã nhắc ${row.name} cập nhật Lead.`);
  }catch(err){toast(err.message||'Không gửi được nhắc cập nhật Lead.','bad');}
  finally{delete state.leadReminderSending[row.id];if(state.page==='lead')renderLeads($('#main'));}
}
function bindLeadReminderButtons(){
  $$('[data-lead-remind]').forEach(b=>b.onclick=()=>sendLeadReminder(Number(b.dataset.leadRemind)));
}
function leadExportRows(){
  return leadFilteredRows().map((x,i)=>({
    'STT':i+1,
    'Khách hàng':x.name||'',
    'Số điện thoại':String(x.phone||''),
    'Ngày phát sinh Lead':dateKey(x.lead_created_at)||'',
    'Giờ phát sinh':vnParts(x.lead_created_at)?.time?.slice(0,5)||'',
    'Mã cuộc gọi tạo Lead':x.source_call_status||'',
    'Kết quả tạo Lead':STATUS_LABELS[x.source_call_status]||x.source_call_status||'',
    'Cuộc gọi mới nhất':x.last_call_at?fmtDate(x.last_call_at):'',
    'Mã kết quả mới nhất':x.call_status||'',
    'Kết quả cuộc gọi mới nhất':STATUS_LABELS[x.call_status]||x.call_status||'',
    'Nguồn Data':x.source||'',
    'Team':x.team||'',
    'Nhân viên':x.owner||'',
    'Tiến trình Lead':x.lead_status?(LEAD_STATUS_LABELS[x.lead_status]||x.lead_status):'Chưa xử lý',
    'Ghi chú mới nhất':x.latest_lead_note||'',
    'Cập nhật Lead lúc':x.lead_updated_at?fmtDate(x.lead_updated_at):'',
    'Người cập nhật':x.changed_by||''
  }));
}
function exportLeadsExcel(){
  const rows=leadExportRows();
  if(!rows.length){toast('Không có Lead phù hợp để xuất Excel.','bad');return;}
  if(!window.XLSX){toast('Không tải được thư viện Excel. Hãy kiểm tra Internet.','bad');return;}
  const headers=['STT','Khách hàng','Số điện thoại','Ngày phát sinh Lead','Giờ phát sinh','Mã cuộc gọi tạo Lead','Kết quả tạo Lead','Cuộc gọi mới nhất','Mã kết quả mới nhất','Kết quả cuộc gọi mới nhất','Nguồn Data','Team','Nhân viên','Tiến trình Lead','Ghi chú mới nhất','Cập nhật Lead lúc','Người cập nhật'];
  const ws=XLSX.utils.json_to_sheet(rows,{header:headers});
  ws['!cols']=headers.map(h=>({wch:h==='Ghi chú mới nhất'?48:h.includes('Kết quả')||h==='Tiến trình Lead'?30:h==='Khách hàng'||h==='Nhân viên'||h==='Người cập nhật'?25:h==='Số điện thoại'?17:18}));
  for(let r=2;r<=rows.length+1;r++){
    const addr=XLSX.utils.encode_cell({r:r-1,c:2});
    if(ws[addr]){ws[addr].t='s';ws[addr].v=String(ws[addr].v??'');ws[addr].z='@';}
  }
  ws['!autofilter']={ref:`A1:Q${Math.max(1,rows.length+1)}`};
  const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,ws,'Lead');
  const from=state.leadDateFrom||'tat-ca',to=state.leadDateTo||'tat-ca';
  const team=state.session.user.role==='teamlead'?state.session.user.team:(state.leadTeamFilter?state.teamObjects.find(t=>String(t.id)===String(state.leadTeamFilter))?.name:'Tat_ca_Team');
  XLSX.writeFile(book,`Lead_${excelSafeFilePart(team||'Tat_ca_Team')}_${from}_${to}.xlsx`);
  toast(`Đã xuất ${rows.length} Lead ra Excel.`);
}

function renderLeads(main){
  const role=state.session.user.role;
  // V7.3: bỏ lọc nhân viên trong Lead; tránh bộ lọc cũ còn lưu từ phiên bản trước.
  state.leadEmployeeFilter='';
  // V7.0: Lead mặc định xem hôm nay; người dùng có thể nới rộng khoảng ngày sau.
  if(!state.leadDateFrom && !state.leadDateTo){const d=todayISO();state.leadDateFrom=d;state.leadDateTo=d;}
  if(state.mode==='d1'&&(!state.leadLoadedAt||Date.now()-state.leadLoadedAt>60000)&&!state.leadLoading){
    main.innerHTML=`${pageHead('Lead','Khách phát sinh từ cuộc gọi Y01 hoặc Y02. Lead được phân quyền theo Team ở phía server.')}<div class="card"><div class="lead-loading">Đang tải Lead…</div></div>`;
    loadLeads().then(()=>{if(state.page==='lead')renderLeads(main)});return;
  }
  const scope=leadDateScopeRows(),visible=leadFilteredRows();
  const unprocessed=scope.filter(x=>!x.lead_status).length,login=scope.filter(x=>x.lead_status==='LOGIN_APP').length,signed=scope.filter(x=>x.lead_status==='SIGNED').length,negative=scope.filter(x=>LEAD_NEGATIVE_STATUSES.has(x.lead_status)).length;
  const scopeText=role==='sale'?'Chỉ Lead Y01/Y02 của chính bạn.':role==='teamlead'?`Chỉ Lead của nhân viên thuộc ${esc(state.session.user.team||'Team của bạn')}. Teamlead khác không thể xem.`:'Admin xem toàn bộ Lead và có thể lọc theo Team.';
  main.innerHTML=`${pageHead('Lead',scopeText)}
  ${state.leadError?`<div class="notice warning">${esc(state.leadError)}</div>`:''}
  <div class="lead-summary"><div class="lead-total-card"><span>Tổng Lead phát sinh</span><strong>${scope.length}</strong><small>${esc(leadDateCaption())}</small></div><div><span>Đang hiển thị</span><strong>${visible.length}</strong><small>Sau các bộ lọc</small></div><div><span>Chưa xử lý</span><strong>${unprocessed}</strong><small>${esc(leadDateCaption())}</small></div><div><span>Đã login app</span><strong>${login}</strong><small>${esc(leadDateCaption())}</small></div><div><span>Đã ký / giải ngân</span><strong>${signed}</strong><small>${esc(leadDateCaption())}</small></div><div><span>Không login / vướng điều kiện</span><strong>${negative}</strong><small>${esc(leadDateCaption())}</small></div></div>
  ${leadReminderPanelHtml()}
  <div class="card lead-card"><div class="card-head"><div><h3>Danh sách Lead theo khoảng ngày</h3><span class="muted">Chọn Từ ngày → Đến ngày. Danh sách bên dưới vẫn chia nhóm theo từng ngày phát sinh để dễ theo dõi.</span></div><div class="actions"><button class="btn" id="lead-export-excel">⬇ Xuất Excel</button><button class="btn" id="lead-refresh">↻ Làm mới</button></div></div><div class="card-body">
    <div class="lead-day-controls lead-range-controls"><label class="lead-day-picker"><span>Từ ngày</span><input type="date" id="lead-date-from" value="${esc(state.leadDateFrom||todayISO())}"></label><span class="range-arrow">→</span><label class="lead-day-picker"><span>Đến ngày</span><input type="date" id="lead-date-to" value="${esc(state.leadDateTo||todayISO())}"></label><div class="lead-day-current">Đang xem: <strong>${esc(leadDateCaption())}</strong></div></div>
    ${leadTeamTabsHtml()}
    <div class="toolbar lead-toolbar lead-toolbar-simple"><input id="lead-search" class="search" placeholder="Tìm tên, SĐT, nhân viên, nguồn…" value="${esc(state.leadSearch)}"><select id="lead-status-filter"><option value="">Tất cả tiến trình</option><option value="UNPROCESSED" ${state.leadStatusFilter==='UNPROCESSED'?'selected':''}>Chưa xử lý</option>${LEAD_SELECTABLE_STATUSES.map(k=>`<option value="${k}" ${state.leadStatusFilter===k?'selected':''}>${esc(LEAD_STATUS_LABELS[k])}</option>`).join('')}</select></div>
  </div><div class="table-wrap"><table class="data-table lead-table"><thead><tr><th>Khách hàng</th><th>Lead phát sinh</th><th>Cuộc gọi mới nhất</th><th>Nguồn Data</th>${(role==='admin'||role==='sup')?'<th>Team</th>':''}${role!=='sale'?'<th>Nhân viên</th>':''}<th>Tiến trình Lead</th><th>Cập nhật lúc</th><th>Thao tác</th></tr></thead><tbody id="lead-table-body">${leadRowsHtml()}</tbody></table></div></div>`;
  $('#lead-refresh').onclick=async()=>{state.leadLoadedAt=0;await loadLeads(true);renderLeads(main)};
  $('#lead-export-excel').onclick=exportLeadsExcel;
  $('#lead-date-from').onchange=e=>{state.leadDateFrom=e.target.value||'';if(state.leadDateTo&&state.leadDateFrom>state.leadDateTo)state.leadDateTo=state.leadDateFrom;state.leadEmployeeFilter='';renderLeads(main)};
  $('#lead-date-to').onchange=e=>{state.leadDateTo=e.target.value||'';if(state.leadDateFrom&&state.leadDateTo<state.leadDateFrom)state.leadDateFrom=state.leadDateTo;state.leadEmployeeFilter='';renderLeads(main)};
  $('#lead-search').oninput=e=>{state.leadSearch=e.target.value;refreshLeadTableOnly()};
  $('#lead-status-filter').onchange=e=>{state.leadStatusFilter=e.target.value;renderLeads(main)};
  $$('[data-lead-team-tab]').forEach(b=>b.onclick=()=>{state.leadTeamFilter=b.dataset.leadTeamTab||'';renderLeads(main)});
  bindLeadRows();
  bindLeadReminderButtons();
}
function openLeadUpdateModal(customerId){
  const x=(state.leads||[]).find(v=>Number(v.customer_id)===Number(customerId));if(!x)return;
  const canSign=x.lead_status==='LOGIN_APP';
  openAdminModal(`Cập nhật Lead · ${x.name}`,`<form id="lead-update-form" class="form-grid">
    <div class="form-field full"><label>Trạng thái hiện tại</label><div>${leadStagePill(x.lead_status)}</div></div>
    <div class="form-field full"><label>Chuyển sang</label><select id="lead-next-status" required><option value="">Chọn trạng thái…</option><option value="LOGIN_APP">Khách hàng đã login app</option><option value="SIGNED" ${canSign?'':'disabled'}>KH ký hồ sơ / giải ngân${canSign?'':' — cần Login app trước'}</option><option value="HIGH_DEBT">KH dư nợ cao</option><option value="BAD_DEBT">KH nợ xấu</option><option value="NEW_DEBT">KH mới phát sinh dư nợ</option></select></div>
    <div class="form-field full"><div class="notice">Mỗi lần thay đổi được lưu thành lịch sử riêng. Ghi chú khách hàng dùng nút <strong>Ghi chú</strong> ngoài danh sách và không yêu cầu đổi trạng thái.</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="lead-update-cancel">Hủy</button><button class="btn primary" type="submit">Lưu trạng thái</button></div></div>
  </form>`);
  $('#lead-update-cancel').onclick=closeAdminModal;
  $('#lead-update-form').onsubmit=async e=>{e.preventDefault();const status=$('#lead-next-status').value;if(!status)return;try{await API.request(`/leads/${customerId}/status`,{method:'POST',body:JSON.stringify({status})});closeAdminModal();state.leadLoadedAt=0;await loadLeads(true);renderLeads($('#main'));toast('Đã cập nhật Lead và lưu lịch sử.');}catch(err){toast(err.message,'bad')}};
}
async function openLeadNoteModal(customerId){
  const x=(state.leads||[]).find(v=>Number(v.customer_id)===Number(customerId));if(!x)return;
  openAdminModal(`Ghi chú Lead · ${x.name}`,`<form id="lead-note-form" class="form-grid"><div class="form-field full"><label>Ghi chú mới</label><textarea id="lead-note-text" maxlength="1000" rows="4" placeholder="Nhập ghi chú chăm sóc khách hàng…" required></textarea><small class="muted">Ghi chú được lưu độc lập, không thay đổi tiến trình Lead.</small></div><div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="lead-note-cancel">Đóng</button><button class="btn primary" type="submit">Lưu ghi chú</button></div></div></form><div class="lead-note-list" id="lead-note-list"><div class="lead-loading">Đang tải ghi chú gần nhất…</div></div>`);
  $('#lead-note-cancel').onclick=closeAdminModal;
  const renderNotes=events=>{const notes=(events||[]).filter(e=>e.event_type==='NOTE');const el=$('#lead-note-list');if(!el)return;el.innerHTML=notes.length?`<h4>Ghi chú gần nhất</h4>${notes.slice(0,5).map(n=>`<div class="lead-note-item"><div><strong>${esc(n.actor||'')}</strong><span>${fmtDate(n.event_at)}</span></div><p>${esc(n.detail||'')}</p></div>`).join('')}<small class="muted">Xem toàn bộ tại nút Lịch sử.</small>`:'<div class="empty small-empty">Chưa có ghi chú Lead.</div>';};
  const noteEvents=x.latest_lead_note?[{event_type:'NOTE',detail:x.latest_lead_note,event_at:x.latest_lead_note_at,actor:x.latest_lead_note_by}]:[];
  renderNotes(noteEvents);
  $('#lead-note-form').onsubmit=async e=>{e.preventDefault();const note=$('#lead-note-text').value.trim();if(!note)return;try{const saved=await API.request(`/leads/${customerId}/notes`,{method:'POST',body:JSON.stringify({note})});$('#lead-note-text').value='';const at=saved?.item?.created_at||new Date().toISOString(),actor=saved?.item?.created_by||state.session.user.display_name||'';const row=(state.leads||[]).find(v=>Number(v.customer_id)===Number(customerId));if(row){row.latest_lead_note=note;row.latest_lead_note_at=at;row.latest_lead_note_by=actor;refreshLeadTableOnly();}noteEvents.unshift({event_type:'NOTE',detail:note,event_at:at,actor});renderNotes(noteEvents);toast('Đã lưu ghi chú Lead.');}catch(err){toast(err.message,'bad')}};
}
async function openLeadHistory(customerId){
  const x=(state.leads||[]).find(v=>Number(v.customer_id)===Number(customerId));if(!x)return;
  openAdminModal(`Lịch sử Lead · ${x.name}`,'<div class="lead-loading">Đang tải lịch sử…</div>');
  try{
    const r=state.mode==='d1'?await API.request(`/leads/${customerId}/history`):{events:[]},events=r.events||[];
    const html=events.map(ev=>{
      if(ev.event_type==='CALL') return `<div class="lead-history-item lead-history-call"><div class="lead-history-index">☎ Cuộc gọi</div><div><div class="lead-history-top">${ev.code?statusPill(ev.code):''}<span>${fmtDate(ev.event_at)}</span></div><strong>${esc(ev.actor||'')}</strong><p>${esc(ev.detail||'Không có ghi chú cuộc gọi.')}</p></div></div>`;
      if(ev.event_type==='NOTE') return `<div class="lead-history-item lead-history-note"><div class="lead-history-index">📝 Ghi chú</div><div><div class="lead-history-top"><strong>${esc(ev.actor||'')}</strong><span>${fmtDate(ev.event_at)}</span></div><p>${esc(ev.detail||'')}</p></div></div>`;
      return `<div class="lead-history-item"><div class="lead-history-index">Tiến trình Lead</div><div><div class="lead-history-top">${leadStagePill(ev.code)}<span>${fmtDate(ev.event_at)}</span></div><strong>${esc(ev.actor||'')}</strong>${ev.detail?`<p>${esc(ev.detail)}</p>`:''}</div></div>`;
    }).join('');
    $('#admin-modal-body').innerHTML=html?`<div class="notice lead-history-help">Cuộc gọi sau khi Lead phát sinh được lấy trực tiếp từ lịch sử cuộc gọi. Vì vậy Y03/N02… và ghi chú của nhân viên tự xuất hiện ở đây mà không tạo thêm Rows written.</div><div class="lead-history">${html}</div>`:'<div class="empty">Lead chưa có lịch sử.</div>';
  }catch(e){$('#admin-modal-body').innerHTML=`<div class="notice warning">${esc(e.message)}</div>`;}
}

function renderKHTN(main){
  if(state.session.user.role==='sale') return renderKhtnEntryForm(main);
  return renderKhtnManager(main);
}

function userKpiTarget(userId){return state.kpiTargets.find(x=>Number(x.user_id)===Number(userId))||{calls_daily:50,connect_rate_target:50,y01_daily:5};}
function openKpiForm(user,date){
  const t=userKpiTarget(user.id);
  openAdminModal(`KPI · ${user.display_name}`,`<form id="kpi-form" class="form-grid">
    <div class="form-field"><label>Calls / ngày</label><input id="kpi-calls" type="number" min="0" value="${t.calls_daily}"></div>
    <div class="form-field"><label>Y01 / ngày</label><input id="kpi-y01" type="number" min="0" value="${t.y01_daily}"></div>
    <div class="form-field full"><div class="notice">KPI gồm 2 mục tiêu: Calls và Y01. KPI áp dụng cố định cho nhân viên cho đến khi bạn thay đổi. Bảng KPI sẽ so với kết quả của ngày đang chọn (${shortDate(date)}).</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="kpi-cancel">Huỷ</button><button class="btn primary" type="submit">Lưu KPI</button></div></div>
  </form>`);
  $('#kpi-cancel').onclick=closeAdminModal;
  $('#kpi-form').onsubmit=async e=>{e.preventDefault();try{await API.request('/kpi-targets/'+user.id,{method:'PUT',body:JSON.stringify({calls_daily:Number($('#kpi-calls').value),y01_daily:Number($('#kpi-y01').value)})});closeAdminModal();await syncFromApi();renderKPI($('#main'));toast('Đã cập nhật KPI.');}catch(err){toast(err.message,'bad')}};
}
function openBulkKpiForm(date){
  const saleUsers=state.users.filter(u=>u.role==='sale');
  if(!saleUsers.length){toast('Chưa có nhân viên Sale.','bad');return;}
  const first=userKpiTarget(saleUsers[0].id);
  openAdminModal('Đặt KPI hàng loạt',`<form id="kpi-bulk-form" class="form-grid">
    <div class="form-field"><label>Calls / ngày</label><input id="kpi-bulk-calls" type="number" min="0" value="${first.calls_daily}"></div>
    <div class="form-field"><label>Y01 / ngày</label><input id="kpi-bulk-y01" type="number" min="0" value="${first.y01_daily}"></div>
    <div class="form-field full"><div class="kpi-bulk-head"><strong>Chọn nhân viên áp KPI</strong><div><button type="button" class="btn small" id="kpi-select-all">Chọn tất cả</button><button type="button" class="btn small" id="kpi-select-none">Bỏ chọn</button></div></div><div class="kpi-bulk-list">${saleUsers.map(u=>`<label class="kpi-bulk-user"><input type="checkbox" data-kpi-user value="${u.id}"><span><strong>${esc(u.display_name)}</strong><small>${esc(u.team||'Chưa có Team')}</small></span></label>`).join('')}</div></div>
    <div class="form-field full"><div class="notice">Chỉ những nhân viên được chọn mới nhận bộ KPI mới. Teamlead chỉ thấy và áp KPI cho Sale thuộc Team của mình.</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="kpi-bulk-cancel">Huỷ</button><button class="btn primary" type="submit" id="kpi-bulk-save">Lưu KPI hàng loạt</button></div></div>
  </form>`);
  $('#kpi-bulk-cancel').onclick=closeAdminModal;
  $('#kpi-select-all').onclick=()=>$$('[data-kpi-user]').forEach(x=>x.checked=true);
  $('#kpi-select-none').onclick=()=>$$('[data-kpi-user]').forEach(x=>x.checked=false);
  $('#kpi-bulk-form').onsubmit=async e=>{
    e.preventDefault();
    const userIds=$$('[data-kpi-user]:checked').map(x=>Number(x.value));
    if(!userIds.length){toast('Hãy chọn ít nhất 1 nhân viên.','bad');return;}
    try{
      await API.request('/kpi-targets/bulk',{method:'POST',body:JSON.stringify({user_ids:userIds,calls_daily:Number($('#kpi-bulk-calls').value),y01_daily:Number($('#kpi-bulk-y01').value)})});
      closeAdminModal();await syncFromApi();renderKPI($('#main'));toast(`Đã áp KPI cho ${userIds.length} nhân viên.`);
    }catch(err){toast(err.message,'bad')}
  };
}
function legacyRenderKPI(main){
  const date=state.dashboardDate||todayISO(); const role=state.session.user.role;
  const saleUsers=state.users.filter(u=>u.role==='sale');
  const rows=saleUsers.map(u=>{
    const calls=state.calls.filter(x=>dateKey(x.created_at)===date && (Number(x.user_id)===Number(u.id)||(!x.user_id&&x.owner===u.display_name)));
    const y01=latestCallsByCustomer(calls).filter(x=>x.status==='Y01').length, target=userKpiTarget(u.id);
    const checks=[calls.length>=target.calls_daily,y01>=target.y01_daily];
    const met=checks.filter(Boolean).length;
    return {u,calls:calls.length,y01,target,met,checks};
  });
  const canSet=(role==='admin'||role==='sup')||role==='teamlead';
  const selfRow=role==='sale'?rows.find(r=>Number(r.u.id)===Number(state.session.user.id)):null;
  const finishedDay=date<todayISO();
  const missList=selfRow&&finishedDay&&selfRow.met<2?[selfRow.calls<selfRow.target.calls_daily?`Calls ${selfRow.calls}/${selfRow.target.calls_daily}`:'',selfRow.y01<selfRow.target.y01_daily?`Y01 ${selfRow.y01}/${selfRow.target.y01_daily}`:''].filter(Boolean):[];
  const warning=missList.length?`<div class="kpi-warning-banner"><strong>⚠ KPI ngày ${shortDate(date)} chưa đạt</strong><span>${esc(missList.join(' · '))}</span></div>`:'';
  const actions=`<input type="date" id="kpi-date" value="${esc(date)}">${canSet?'<button class="btn primary" id="kpi-bulk-open">Đặt KPI hàng loạt</button>':''}`;
  main.innerHTML=`${pageHead('KPI Telesale','Theo dõi 2 mục tiêu: Calls và Y01 theo ngày.',actions)}${warning}
  <div class="table-wrap"><table class="data-table"><thead><tr><th>Nhân viên</th><th>Team</th><th>Calls</th><th>Y01</th><th>Kết quả</th>${canSet?'<th>KPI</th>':''}</tr></thead><tbody>${rows.map(r=>`<tr><td><strong>${esc(r.u.display_name)}</strong></td><td>${esc(r.u.team||'')}</td><td>${r.calls} / ${r.target.calls_daily}</td><td>${r.y01} / ${r.target.y01_daily}</td><td><span class="status ${r.met===2?'y01':r.met===1?'y02':'danger'}">${r.met}/2 mục tiêu</span></td>${canSet?`<td><button class="btn small" data-set-kpi="${r.u.id}">Đặt KPI</button></td>`:''}</tr>`).join('')||'<tr><td colspan="6"><div class="empty">Chưa có nhân viên Sale.</div></td></tr>'}</tbody></table></div>`;
  $('#kpi-date').onchange=e=>{state.dashboardDate=e.target.value||todayISO();renderKPI(main)};
  if($('#kpi-bulk-open')) $('#kpi-bulk-open').onclick=()=>openBulkKpiForm(date);
  $$('[data-set-kpi]').forEach(b=>b.onclick=()=>openKpiForm(state.users.find(u=>u.id===Number(b.dataset.setKpi)),date));
}
function teamOptions(selected=''){
  const rows=state.teamObjects.length?state.teamObjects:state.teams.map((name,i)=>({id:[1,3,5,6][i]||i+1,name}));
  return rows.map(t=>`<option value="${t.id}" ${String(t.id)===String(selected)?'selected':''}>${esc(t.name)}</option>`).join('');
}
function closeAdminModal(){$('#admin-modal').classList.add('hidden');$('#admin-modal').setAttribute('aria-hidden','true');}
function openAdminModal(title,body){const box=$('#admin-modal .admin-modal');if(box)box.classList.remove('loan-care-admin-modal','loginapp-create-admin-modal','loginapp-import-admin-modal','loginapp-update-admin-modal');$('#admin-modal-title').textContent=title;$('#admin-modal-body').innerHTML=body;$('#admin-modal').classList.remove('hidden');$('#admin-modal').setAttribute('aria-hidden','false');}
function openChangePasswordForm(){
  const u=state.session?.user;
  if(!u)return;
  openAdminModal('Đổi mật khẩu',`<form id="change-password-form" class="form-grid password-change-form">
    <div class="form-field full"><div class="notice">Tài khoản: <strong>${esc(u.display_name)}</strong> · ${esc(u.username)}${u.team?` · ${esc(u.team)}`:''}. Bạn chỉ có thể đổi mật khẩu của chính mình.</div></div>
    <div class="form-field full"><label>Mật khẩu hiện tại</label><input id="cp-current" type="password" autocomplete="current-password" required></div>
    <div class="form-field"><label>Mật khẩu mới</label><input id="cp-new" type="password" autocomplete="new-password" minlength="6" required></div>
    <div class="form-field"><label>Nhập lại mật khẩu mới</label><input id="cp-confirm" type="password" autocomplete="new-password" minlength="6" required></div>
    <div class="form-field full"><div class="password-hint">Mật khẩu tối thiểu 6 ký tự. Sau khi đổi, các phiên đăng nhập khác của tài khoản sẽ tự động hết hiệu lực.</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="cp-cancel">Huỷ</button><button type="submit" class="btn primary">Lưu mật khẩu mới</button></div></div>
  </form>`);
  $('#cp-cancel').onclick=closeAdminModal;
  $('#change-password-form').onsubmit=async e=>{
    e.preventDefault();
    if(state.mode!=='d1'){toast('Đổi mật khẩu cần D1 Online.','bad');return;}
    const current_password=$('#cp-current').value, new_password=$('#cp-new').value, confirm_password=$('#cp-confirm').value;
    if(new_password.length<6){toast('Mật khẩu mới tối thiểu 6 ký tự.','bad');return;}
    if(new_password!==confirm_password){toast('Hai lần nhập mật khẩu mới chưa khớp.','bad');return;}
    if(new_password===current_password){toast('Mật khẩu mới phải khác mật khẩu hiện tại.','bad');return;}
    const submit=e.submitter; if(submit){submit.disabled=true;submit.textContent='Đang lưu…';}
    try{
      await API.request('/me/password',{method:'POST',body:JSON.stringify({current_password,new_password})});
      closeAdminModal();toast('Đã đổi mật khẩu. Các phiên đăng nhập khác đã được đăng xuất.');
    }catch(err){toast(err.message,'bad');if(submit){submit.disabled=false;submit.textContent='Lưu mật khẩu mới';}}
  };
}
function employeeForm(u=null){
  const role=state.session.user.role;
  const isLead=role==='teamlead';
  const isEdit=!!u;
  if(isLead&&isEdit){toast('Team Leader chỉ được thêm hoặc xoá Sales/Freelancer trong Team, không sửa tài khoản.','bad');return;}
  const fixedTeamId=isLead?state.session.user.team_id:(u?.team_id||'');
  const currentRoleKey=staffRoleKey(u);
  openAdminModal(isEdit?'Sửa nhân viên':(isLead?'Thêm thành viên vào Team':'Thêm nhân viên'),`<form id="employee-form" class="form-grid">
    <div class="form-field"><label>Họ tên nhân viên</label><input id="emp-name" value="${esc(u?.display_name||'')}" required></div>
    <div class="form-field"><label>Tên đăng nhập</label><input id="emp-username" value="${esc(u?.username||'')}" autocomplete="off" required></div>
    ${isLead?`<div class="form-field"><label>Vai trò</label><select id="emp-role"><option value="sale" ${currentRoleKey!=='freelancer'?'selected':''}>Sales</option><option value="freelancer" ${currentRoleKey==='freelancer'?'selected':''}>Freelancer</option></select></div><input type="hidden" id="emp-team" value="${esc(fixedTeamId)}"><div class="form-field"><label>Team</label><input value="${esc(state.session.user.team||'Team của bạn')}" disabled></div>`:`<div class="form-field"><label>Vai trò</label><select id="emp-role"><option value="sale" ${currentRoleKey==='sales'?'selected':''}>Sales</option><option value="freelancer" ${currentRoleKey==='freelancer'?'selected':''}>Freelancer</option><option value="teamlead" ${currentRoleKey==='teamlead'?'selected':''}>Team Leader</option>${role==='admin'?`<option value="sup" ${currentRoleKey==='sup'?'selected':''}>Sup</option><option value="admin" ${currentRoleKey==='admin'?'selected':''}>Admin</option>`:''}</select></div><div class="form-field"><label>Team</label><select id="emp-team"><option value="">Không áp dụng</option>${teamOptions(fixedTeamId)}</select></div>`}
    <div class="form-field"><label>Email (không bắt buộc)</label><input id="emp-email" type="email" value="${esc(u?.email||'')}"></div>
    <div class="form-field"><label>${isEdit?'Mật khẩu mới (để trống nếu giữ nguyên)':'Mật khẩu'}</label><input id="emp-password" type="password" autocomplete="new-password" ${isEdit?'':'required'}></div>
    <div class="form-field full"><div class="notice">${isLead?'Thành viên mới tự động thuộc Team của bạn. Bạn có thể chọn Sales hoặc Freelancer; hai vai trò có cùng quyền thao tác CRM.':'Admin và Sup có phạm vi toàn hệ thống. Team Leader, Sales và Freelancer phải thuộc một Team. Chỉ Admin được cấp vai trò quản trị.'}</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="emp-cancel">Huỷ</button><button class="btn primary" type="submit">${isEdit?'Lưu thay đổi':'Thêm nhân viên'}</button></div></div>
  </form>`);
  $('#emp-cancel').onclick=closeAdminModal;
  if(!isLead){$('#emp-role').onchange=()=>{$('#emp-team').disabled=['admin','sup'].includes($('#emp-role').value);}; $('#emp-role').onchange();}
  $('#employee-form').onsubmit=async e=>{
    e.preventDefault(); if(state.mode!=='d1'){toast('Chức năng này cần D1 Online.','bad');return;}
    const payload={display_name:$('#emp-name').value.trim(),username:$('#emp-username').value.trim(),role:$('#emp-role').value,team_id:$('#emp-team').value?Number($('#emp-team').value):null,email:$('#emp-email').value.trim(),password:$('#emp-password').value};
    if(isEdit&&!payload.password) delete payload.password;
    try{await API.request(isEdit?'/users/'+u.id:'/users',{method:isEdit?'PATCH':'POST',body:JSON.stringify(payload)});closeAdminModal();await syncFromApi();renderEmployees($('#main'));toast(isEdit?'Đã cập nhật nhân viên.':'Đã thêm nhân viên.');}catch(err){toast(err.message,'bad');}
  };
}
async function deleteEmployee(u){
  if(u.role==='admin'){toast('Không xoá tài khoản Admin từ giao diện này.','bad');return;}
  if(!confirm(`Xoá nhân viên ${u.display_name}? Data đang giao cho nhân viên sẽ được trả về trạng thái chưa gán Sales/Freelancer.`))return;
  try{await API.request('/users/'+u.id,{method:'DELETE'});await syncFromApi();renderEmployees($('#main'));toast('Đã xoá nhân viên.');}catch(err){toast(err.message,'bad');}
}
function adminUserForm(){
  if(state.session.user.role!=='admin'){toast('Chỉ Admin được tạo tài khoản Admin.','bad');return;}
  openAdminModal('Tạo tài khoản Admin',`<form id="admin-user-form" class="form-grid">
    <div class="form-field"><label>Họ tên / Tên hiển thị</label><input id="admin-user-name" placeholder="Ví dụ: Nguyễn Văn A" required></div>
    <div class="form-field"><label>Tên đăng nhập</label><input id="admin-user-username" autocomplete="off" required></div>
    <div class="form-field"><label>Email (không bắt buộc)</label><input id="admin-user-email" type="email"></div>
    <div class="form-field"><label>Mật khẩu</label><input id="admin-user-password" type="password" autocomplete="new-password" minlength="6" required></div>
    <div class="form-field full"><div class="notice"><strong>Quyền Admin:</strong> tài khoản này có thể xem toàn bộ Team, Kho Data, nhân sự và cấu hình hệ thống. Không gắn Admin vào một Team cụ thể.</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="admin-user-cancel">Huỷ</button><button class="btn primary" type="submit">Tạo Admin</button></div></div>
  </form>`);
  $('#admin-user-cancel').onclick=closeAdminModal;
  $('#admin-user-form').onsubmit=async e=>{
    e.preventDefault();
    if(state.mode!=='d1'){toast('Chức năng này cần D1 Online.','bad');return;}
    const payload={display_name:$('#admin-user-name').value.trim(),username:$('#admin-user-username').value.trim(),email:$('#admin-user-email').value.trim(),password:$('#admin-user-password').value,role:'admin',team_id:null};
    try{await API.request('/users',{method:'POST',body:JSON.stringify(payload)});closeAdminModal();await syncFromApi();renderEmployees($('#main'));toast('Đã tạo tài khoản Admin.');}catch(err){toast(err.message,'bad')}
  };
}

function openTeamForm(){
  openAdminModal('Tạo Team mới',`<form id="team-form" class="form-grid"><div class="form-field full"><label>Tên Team</label><input id="team-name" placeholder="Ví dụ: Mobility 7" required></div><div class="form-field full"><div class="notice">Team mới sẽ xuất hiện ngay trong Nhân sự, Kho Data, phân Data và bộ lọc.</div></div><div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="team-cancel">Huỷ</button><button class="btn primary" type="submit">Tạo Team</button></div></div></form>`);
  $('#team-cancel').onclick=closeAdminModal;
  $('#team-form').onsubmit=async e=>{e.preventDefault();try{await API.request('/teams',{method:'POST',body:JSON.stringify({name:$('#team-name').value.trim()})});closeAdminModal();await syncFromApi();state.employeeTeamFilter='';renderEmployees($('#main'));toast('Đã tạo Team mới.');}catch(err){toast(err.message,'bad')}};
}
async function deleteTeam(team){
  if(!team)return;
  if(!confirm(`Xoá Team ${team.name}? Chỉ Team không còn nhân viên hoạt động và không còn Data mới được xoá.`))return;
  try{await API.request('/teams/'+team.id,{method:'DELETE'});await syncFromApi();state.employeeTeamFilter='';renderEmployees($('#main'));toast('Đã xoá Team.');}catch(err){toast(err.message,'bad')}
}
function legacyRenderEmployees(main){
  const role=state.session.user.role;
  if(role==='sale'){main.innerHTML='<div class="empty">Bạn không có quyền truy cập Nhân sự.</div>';return;}
  const isAdmin=(role==='admin'||role==='sup'), isLead=role==='teamlead';
  if(isLead) state.employeeTeamFilter=String(state.session.user.team_id||'');
  const teamId=state.employeeTeamFilter;
  const selectedTeam=state.teamObjects.find(t=>String(t.id)===String(teamId));
  const adminUsers=state.users.filter(u=>u.role==='admin').sort((a,b)=>a.display_name.localeCompare(b.display_name));
  const base=state.users.filter(u=>u.role!=='admin').sort((a,b)=>String(a.team||'').localeCompare(String(b.team||''))||a.display_name.localeCompare(b.display_name));
  const grouped=teamId?base.filter(u=>String(u.team_id)===String(teamId)):base;
  const actions=isAdmin?`<button class="btn" id="add-admin">+ Tạo Admin</button><button class="btn" id="add-team">+ Tạo Team</button>${selectedTeam?'<button class="btn danger" id="delete-team">− Xoá Team</button>':''}<button class="btn primary" id="add-employee">+ Thêm nhân viên</button>`:`<button class="btn primary" id="add-employee">+ Thêm thành viên</button>`;
  const subtitle=isLead?`Chỉ quản lý nhân sự của ${esc(state.session.user.team||'Team của bạn')}. Bạn có thể thêm hoặc xoá Sale trong Team.`:'Admin có thể tạo thêm Admin, Team Leader, Sales và Freelancer. Mỗi Team Leader chỉ quản lý Team của mình.';
  const teamSummary=isLead?`<div class="team-summary"><button class="team-chip team-filter active"><strong>${esc((state.session.user.team||'Team').replace('Mobility ','M'))}</strong> ${grouped.length} người</button></div>`:`<div class="team-summary"><button class="team-chip team-filter ${!teamId?'active':''}" data-team-filter=""><strong>Tất cả</strong> ${base.length} người</button>${state.teamObjects.map(t=>`<button class="team-chip team-filter ${String(teamId)===String(t.id)?'active':''}" data-team-filter="${t.id}"><strong>${esc(t.name.replace('Mobility ','M'))}</strong> ${base.filter(u=>Number(u.team_id)===Number(t.id)).length} người</button>`).join('')}</div>`;
  const adminSection=isAdmin?`<div class="card admin-account-card"><div class="card-head"><div><h3>🔐 Tài khoản Admin</h3><span class="muted">Chỉ Admin mới nhìn thấy và tạo được tài khoản quản trị.</span></div><span class="team-chip">${adminUsers.length} Admin</span></div><div class="card-body"><div class="employee-grid">${adminUsers.map(u=>`<div class="employee admin-account"><div class="employee-avatar">${initials(u.display_name)}</div><div class="employee-info"><h4>${esc(u.display_name)}</h4><p>Quản trị toàn hệ thống</p><p>@${esc(u.username)}</p></div><div class="employee-actions"><button class="btn small" data-edit-user="${u.id}">Sửa</button></div></div>`).join('')||'<div class="empty">Chưa có tài khoản Admin.</div>'}</div></div></div>`:'';
  main.innerHTML=`${pageHead('Nhân sự & phân quyền',subtitle,actions)}
  ${adminSection}
  ${teamSummary}
  <div class="employee-grid">${grouped.map(u=>`<div class="employee"><div class="employee-avatar">${initials(u.display_name)}</div><div class="employee-info"><h4>${esc(u.display_name)}</h4><p>${esc(u.team||'Chưa có Team')} · ${esc(u.role)}</p><p>@${esc(u.username)}</p></div>${isAdmin?`<div class="employee-actions"><button class="btn small" data-edit-user="${u.id}">Sửa</button><button class="btn small danger" data-delete-user="${u.id}">Xoá</button></div>`:(isLead&&u.role==='sale'?`<div class="employee-actions"><button class="btn small danger" data-delete-user="${u.id}">Xoá</button></div>`:'')}</div>`).join('')||'<div class="empty">Team này chưa có nhân viên.</div>'}</div>`;
  if(isAdmin) $$('[data-team-filter]').forEach(b=>b.onclick=()=>{state.employeeTeamFilter=b.dataset.teamFilter;renderEmployees(main)});
  if(isAdmin){$('#add-admin').onclick=adminUserForm;$('#add-team').onclick=openTeamForm;if(selectedTeam)$('#delete-team').onclick=()=>deleteTeam(selectedTeam);$('#add-employee').onclick=()=>employeeForm();$$('[data-edit-user]').forEach(b=>b.onclick=()=>employeeForm(state.users.find(u=>u.id===Number(b.dataset.editUser))));}
  if(isLead) $('#add-employee').onclick=()=>employeeForm();
  $$('[data-delete-user]').forEach(b=>b.onclick=()=>deleteEmployee(state.users.find(u=>u.id===Number(b.dataset.deleteUser))));
}
function normalizeHeader(s){return String(s||'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/[^a-z0-9]+/g,' ').trim();}
function cell(row,names){const entries=Object.entries(row);for(const n of names){const hit=entries.find(([k])=>normalizeHeader(k)===n);if(hit&&hit[1]!==''&&hit[1]!=null)return hit[1];}return '';}
function normalizeImportPhone(v){let s=String(v??'').trim().replace(/\.0$/,'').replace(/\D/g,'');if(s.startsWith('84')&&s.length>=11)s='0'+s.slice(2);if(s.length===9&&/^[35789]/.test(s))s='0'+s;return s;}
function isoCell(v){
  if(!v)return ''; if(v instanceof Date&&!isNaN(v))return v.toISOString().slice(0,16);
  if(typeof v==='number'&&window.XLSX){const d=XLSX.SSF.parse_date_code(v);if(d)return `${d.y}-${String(d.m).padStart(2,'0')}-${String(d.d).padStart(2,'0')}T${String(d.H||0).padStart(2,'0')}:${String(d.M||0).padStart(2,'0')}`;}
  const s=String(v).trim(); const m=s.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})(?:\s+(\d{1,2}):(\d{2}))?/); if(m)return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}T${(m[4]||'00').padStart(2,'0')}:${m[5]||'00'}`; return s;
}
function mapImportRow(row){
  const allocation=String(cell(row,['phan bo cho'])||'').trim(); const explicitTeam=String(cell(row,['team'])||'').trim();
  const allocationIsTeam=/^(mobility\s*)?[1356]$/i.test(allocation)||/^m[1356]$/i.test(allocation);
  let team=explicitTeam||(allocationIsTeam?allocation:''); let owner=String(cell(row,['ten nv','nhan vien','sale','nhan vien phu trach'])||'').trim(); if(!owner&&!allocationIsTeam)owner=allocation;
  const status=String(cell(row,['trang thai cuoc goi','trang thai','ket qua cuoc goi'])||'').trim();
  return {name:String(cell(row,['ho ten kh','ho ten khach hang','ten khach hang','khach hang','ten','ho ten','ho va ten','ten kh','fullname','full name','customer name'])||'').trim(),phone:normalizeImportPhone(cell(row,['so dien thoai','sdt','dien thoai','so dt','sdt kh','so dien thoai kh','dien thoai kh','phone','phone number','mobile'])),source:String(cell(row,['nguon data','nguon'])||'').trim(),team,owner,status:status||'NEW',received:isoCell(cell(row,['ngay nhan data','ngay goi','ngay nhan'])),follow_up:isoCell(cell(row,['lich hen goi lai','hen goi lai'])),note:String(cell(row,['ghi chu chi tiet','ghi chu'])||'').trim()};
}
let importPreview=[];
async function bulkApiRetry(path,opts={},retries=4){
  let last;
  for(let attempt=0;attempt<retries;attempt++){
    try{return await API.request(path,{...opts,timeoutMs:opts.timeoutMs||30000});}
    catch(err){last=err;if(attempt===retries-1)break;await sleep(500*(attempt+1));}
  }
  throw last||new Error('Không thể kết nối máy chủ.');
}

let importRaw=[];
let warehouseImportSource='';
async function readImportFile(file){
  if(!window.XLSX)throw new Error('Không tải được thư viện đọc Excel. Hãy kiểm tra Internet rồi tải lại trang.');
  const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true}); const rows=[];
  for(const sheetName of wb.SheetNames){const sheetRows=XLSX.utils.sheet_to_json(wb.Sheets[sheetName],{defval:'',raw:true});for(const r of sheetRows){const x=mapImportRow(r);if(x.name||x.phone)rows.push(x);}}
  return rows;
}
function salesForTeam(teamId){return state.users.filter(u=>u.role==='sale'&&Number(u.team_id)===Number(teamId));}
function teamById(teamId){return state.teamObjects.find(t=>Number(t.id)===Number(teamId));}
function importAssignmentOptions(teamId){
  const sales=salesForTeam(teamId);
  return `<option value="round_robin">Chia đều các thành viên trong Team</option><option value="unassigned">Chưa gán nhân viên (chia sau)</option><option value="keep_file">Giữ tên nhân viên trong file Excel</option>${sales.map(u=>`<option value="user:${u.id}">Gán toàn bộ cho ${esc(u.display_name)}</option>`).join('')}`;
}
function applyImportAssignment(rows,teamId,mode){
  const team=teamById(teamId); const sales=salesForTeam(teamId); let rr=0;
  if(mode!=='keep_file'&&!team) throw new Error('Hãy chọn Team trước khi phân nhân viên.');
  if(mode==='round_robin'&&!sales.length) throw new Error('Team đã chọn chưa có nhân viên Sale. Hãy thêm nhân viên trước.');
  if(mode.startsWith('user:')&&!sales.some(u=>u.id===Number(mode.split(':')[1]))) throw new Error('Nhân viên được chọn không thuộc Team này.');
  return rows.map(x=>{
    const y={...x};
    if(!y.received) y.received=todayISO();
    if(team){y.team=team.name;y.team_id=team.id;y.force_team=true;}
    if(mode==='round_robin'){const u=sales[rr%sales.length];rr++;y.owner=u.display_name;y.owner_username=u.username;y.assigned_user_id=u.id;y.force_owner=true;}
    else if(mode==='unassigned'){y.owner='';y.owner_username='';y.assigned_user_id=null;y.force_owner=true;}
    else if(mode.startsWith('user:')){const u=sales.find(z=>z.id===Number(mode.split(':')[1]));y.owner=u.display_name;y.owner_username=u.username;y.assigned_user_id=u.id;y.force_owner=true;}
    return y;
  });
}
async function checkImportDuplicates(rows,targetTeamId=null){
  const existing=new Set(), phones=[...new Set(rows.map(x=>normalizeImportPhone(x.phone)).filter(Boolean))];
  if(state.mode==='d1'){
    for(let i=0;i<phones.length;i+=250){
      const res=await bulkApiRetry('/customers/import/check',{method:'POST',body:JSON.stringify({phones:phones.slice(i,i+250),target_team_id:targetTeamId?Number(targetTeamId):null})});
      (res.existing_phones||[]).forEach(p=>existing.add(normalizeImportPhone(p)));
    }
  }else{
    state.customers.filter(c=>!targetTeamId||Number(c.team_id)===Number(targetTeamId)).forEach(c=>existing.add(normalizeImportPhone(c.phone)));
  }
  const seen=new Set();
  return rows.map(row=>{
    const phone=normalizeImportPhone(row.phone);
    let importDuplicate='';
    if(!phone) importDuplicate='Thiếu SĐT';
    else if(existing.has(phone)) importDuplicate='Trùng trong Kho Team / phạm vi đang nhập';
    else if(seen.has(phone)) importDuplicate='Trùng trong file';
    seen.add(phone);
    return {...row,importDuplicate};
  });
}
function importPreviewStats(){
  const valid=importPreview.filter(x=>!x.importDuplicate).length;
  const old=importPreview.filter(x=>x.importDuplicate==='Trùng trong Kho Team / phạm vi đang nhập').length;
  const file=importPreview.filter(x=>x.importDuplicate==='Trùng trong file').length;
  const missing=importPreview.length-valid-old-file;
  return {valid,old,file,missing};
}
function renderImportPreview(){
  const sample=importPreview.slice(0,15),stats=importPreviewStats();
  $('#import-preview').innerHTML=`<div class="import-check-summary"><strong>Kiểm tra trước khi đẩy Kho:</strong> ${importPreview.length} dòng · <span class="good">${stats.valid} Data mới</span> · <span class="duplicate">${stats.old} trùng Data cũ</span> · ${stats.file} trùng trong file · ${stats.missing} thiếu SĐT. <br><small>Chỉ nhập Data mới. Data trùng được bỏ qua và không làm thay đổi khách đang giao, nguồn hoặc lịch sử cuộc gọi.</small></div>
    <div class="table-wrap import-preview"><table class="data-table"><thead><tr><th>Khách hàng</th><th>SĐT</th><th>Nguồn</th><th>Trạng thái lọc trùng</th></tr></thead><tbody>${sample.map(x=>`<tr class="${x.importDuplicate?'import-duplicate':''}"><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${esc(x.source)}</td><td>${esc(x.importDuplicate||'✓ Data mới')}</td></tr>`).join('')}</tbody></table>${importPreview.length>sample.length?`<div class="muted preview-note">Hiển thị ${sample.length}/${importPreview.length} dòng.</div>`:''}</div>`;
  const button=$('#upload-import');if(button)button.disabled=!stats.valid;
  if(stats.old+stats.file+stats.missing){
    const exportButton=document.createElement('button');exportButton.type='button';exportButton.className='btn small';
    exportButton.textContent='⬇ Xuất Excel danh sách bị lọc';
    exportButton.onclick=()=>{
      if(typeof XLSX==='undefined'){toast('Thư viện Excel chưa được tải.','bad');return;}
      const skipped=importPreview.filter(x=>x.importDuplicate).map((x,i)=>({'STT':i+1,'Tên khách hàng':x.name||'','Số điện thoại':String(x.phone||''),'Nguồn':x.source||'','Lý do loại':x.importDuplicate}));
      const wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(skipped);
      for(const address of Object.keys(ws)){if(/^C\d+$/.test(address)){ws[address].t='s';ws[address].v=String(ws[address].v);}}
      ws['!cols']=[{wch:7},{wch:32},{wch:18},{wch:24},{wch:32}];XLSX.utils.book_append_sheet(wb,ws,'Data bi loc');
      XLSX.writeFile(wb,`data-trung-${todayVN()}.xlsx`);
    };
    $('#import-preview').prepend(exportButton);
  }
}
async function uploadImportRows(rows){
  let inserted=0,updated=0,skipped=0; const total=rows.length;
  for(let i=0;i<rows.length;i+=250){const batch=rows.slice(i,i+250);const r=await bulkApiRetry('/customers/import',{method:'POST',body:JSON.stringify({items:batch})});inserted+=r.inserted||0;updated+=r.updated||0;skipped+=r.skipped||0;$('#import-progress').textContent=`Đang tải ${Math.min(i+batch.length,total)}/${total} dòng...`; }
  return {inserted,updated,skipped,total};
}
function warehouseState(c){return c.data_state||((c.owner||c.assigned_user_id)?'ASSIGNED':'POOL');}
function warehouseRowsBase(kind=state.warehouseView){return visibleCustomers().filter(c=>warehouseState(c)===kind);}
function warehouseRows(kind=state.warehouseView){
  let rows=warehouseRowsBase(kind);
  if(kind==='ARCHIVED'){
    if(state.warehouseTeamFilter) rows=rows.filter(c=>String(c.team_id)===String(state.warehouseTeamFilter));
    if(state.warehouseStatusFilter) rows=rows.filter(c=>c.status===state.warehouseStatusFilter);
  }
  return rows;
}
function applyWarehouseImport(rows,sourceName){const source=String(sourceName||'').trim();return rows.map(x=>({...x,source,team:'',owner:'',team_id:null,assigned_user_id:null,force_team:true,force_owner:true,to_warehouse:true,status:'NEW',received:x.received||todayISO(),follow_up:'',note:x.note||''}));}
function renderWarehouseTable(rows){
  const sample=rows.slice(0,100);
  return `<div class="table-wrap"><table class="data-table"><thead><tr><th>Khách hàng</th><th>SĐT</th><th>Nguồn</th><th>Team</th><th>Nhân viên</th><th>Kho</th><th>Trạng thái cuộc gọi</th></tr></thead><tbody>${sample.map(x=>`<tr><td><strong>${esc(x.name)}</strong></td><td>${esc(x.phone)}</td><td>${esc(x.source)}</td><td>${esc(x.team||'—')}</td><td>${esc(x.owner||'—')}</td><td><span class="status ${warehouseState(x).toLowerCase()}">${warehouseState(x)==='POOL'?'Kho chờ phân':warehouseState(x)==='ASSIGNED'?'Đang giao':'Đã gọi / lưu trữ'}</span></td><td>${x.status&&x.status!=='NEW'?statusPill(x.status):'<span class="muted">Chưa gọi</span>'}</td></tr>`).join('')||'<tr><td colspan="7"><div class="empty">Không có Data ở trạng thái này.</div></td></tr>'}</tbody></table>${rows.length>sample.length?`<div class="muted preview-note">Hiển thị 100/${rows.length} khách.</div>`:''}</div>`;
}
// V5.6: giao trực tiếp Data theo nhân viên + trạng thái. Không thay đổi lịch sử cuộc gọi.
function transferSaleUsers(){
  const role=state.session.user.role,team=Number(state.session.user.team_id);
  return state.users.filter(u=>u.role==='sale'&&u.active!==0&&((role==='admin'||role==='sup')||Number(u.team_id)===team));
}
function transferCandidateBase(fromId){
  return state.customers.filter(c=>Number(c.assigned_user_id)===Number(fromId)&&['ASSIGNED','ARCHIVED'].includes(c.data_state));
}
function transferCandidates(fromId,status='ALL'){
  const rows=transferCandidateBase(fromId);return status==='ALL'?rows:rows.filter(c=>String(c.status||'NEW').toUpperCase()===status);
}
function transferStatusCounts(fromId){
  const rows=transferCandidateBase(fromId),counts={ALL:rows.length};Object.keys(STATUS_LABELS).forEach(k=>counts[k]=0);
  rows.forEach(c=>{const k=String(c.status||'NEW').toUpperCase();if(counts[k]!==undefined)counts[k]++;});return counts;
}

// V8.6: cập nhật state tại client ngay sau khi phân/chuyển Data để không phải tải lại toàn bộ /customers.
function patchDistributedCustomers(assignments=[]){
  if(!Array.isArray(assignments)||!assignments.length)return;
  const userMap=new Map((state.users||[]).map(u=>[Number(u.id),u]));
  const teamMap=new Map((state.teamObjects||[]).map(t=>[Number(t.id),t]));
  const customerMap=new Map((state.customers||[]).map(c=>[Number(c.id),c]));
  for(const a of assignments){
    const c=customerMap.get(Number(a.customer_id));if(!c)continue;
    const u=userMap.get(Number(a.user_id)),t=teamMap.get(Number(a.team_id));
    c.team_id=Number(a.team_id)||c.team_id;c.team=t?.name||u?.team||c.team||'';
    c.assigned_user_id=Number(a.user_id)||null;c.owner=u?.display_name||c.owner||'';
    c.data_state='ASSIGNED';c.status='NEW';c.archived_at=null;c.follow_up='';c.follow_up_at=null;
    c.assignment_deadline=a.deadline||null;c.assignment_round=Number(a.round||c.assignment_round||0);
  }
}
function patchTransferredCustomers(ids,targetId,targetTeamId,deadline){
  const idSet=new Set((ids||[]).map(Number));if(!idSet.size)return;
  const u=(state.users||[]).find(x=>Number(x.id)===Number(targetId));
  const t=(state.teamObjects||[]).find(x=>Number(x.id)===Number(targetTeamId));
  for(const c of state.customers||[]){
    if(!idSet.has(Number(c.id)))continue;
    c.last_assigned_user_id=c.assigned_user_id;c.assigned_user_id=Number(targetId);c.owner=u?.display_name||c.owner||'';
    c.team_id=Number(targetTeamId)||c.team_id;c.team=t?.name||u?.team||c.team||'';c.data_state='ASSIGNED';
    c.archived_at=null;c.follow_up='';c.follow_up_at=null;c.assignment_deadline=deadline||null;
    c.assignment_round=Number(c.assignment_round||0)+1;
  }
}
async function bulkJobProgressMarkup(job){
  if(!job)return '';
  const total=Number(job.total_count||0),done=Number(job.processed_count||0),pct=total?Math.min(100,Math.round(done/total*100)):100;
  const status=job.status==='COMPLETED'?'Hoàn tất':job.status==='CANCELLED'?'Đã hủy':'Đang xử lý';
  return `<div class="bulk-job-card ${String(job.status||'').toLowerCase()}"><div><strong>${status} · Chia Data</strong><span>${done.toLocaleString('vi-VN')} / ${total.toLocaleString('vi-VN')} Data</span></div><div class="bulk-job-track"><i style="width:${pct}%"></i></div><b>${pct}%</b></div>`;
}
function renderBulkJobIndicator(job){
  state.bulkDistributionJob=job||null;
  let el=document.getElementById('bulk-job-indicator');
  if(!job){el?.remove();return;}
  if(!el){el=document.createElement('div');el.id='bulk-job-indicator';document.body.appendChild(el);}
  el.innerHTML=bulkJobProgressMarkup(job);
  el.classList.toggle('done',job.status==='COMPLETED'||job.status==='CANCELLED');
  if(job.status==='COMPLETED'||job.status==='CANCELLED') setTimeout(()=>{if(document.getElementById('bulk-job-indicator')===el)el.remove();},6000);
}
async function loadActiveBulkDistributionJob(){
  if(state.mode!=='d1'||!['admin','sup','teamlead'].includes(state.session?.user?.role||''))return null;
  try{
    const r=await API.request('/bulk-jobs/active?type=WAREHOUSE_DISTRIBUTE',{timeoutMs:10000});
    const job=(r.items||[])[0]||null;
    if(job){state.bulkDistributionJob=job;renderBulkJobIndicator(job);localStorage.setItem('a4_bulk_job_id',String(job.id));}
    return job;
  }catch{return null;}
}
async function driveBulkDistributionJob(jobId,button=null,{silent=false}={}){
  jobId=Number(jobId||0);if(!jobId)return {updated:0,recipients:0};
  if(state.bulkJobRunnerId===jobId&&state.bulkJobRunnerPromise)return state.bulkJobRunnerPromise;
  state.bulkJobRunnerId=jobId;
  state.bulkJobRunnerPromise=(async()=>{
    const original=button?.textContent||'';
    try{
      let job=state.bulkDistributionJob&&Number(state.bulkDistributionJob.id)===jobId?state.bulkDistributionJob:null;
      if(!job){const g=await API.request(`/bulk-jobs/${jobId}`,{timeoutMs:10000});job=g.job;}
      if(!job)return {updated:0,recipients:0};
      renderBulkJobIndicator(job);localStorage.setItem('a4_bulk_job_id',String(job.id));
      while(job.status==='RUNNING'){
        if(button){button.disabled=true;button.textContent=`Đang phân ${Number(job.processed_count||0).toLocaleString('vi-VN')}/${Number(job.total_count||0).toLocaleString('vi-VN')}...`;}
        let r;
        try{r=await API.request(`/bulk-jobs/${jobId}/process`,{method:'POST',timeoutMs:35000,body:JSON.stringify({max_items:300})});}
        catch(err){
          renderBulkJobIndicator(job);
          if(!silent)toast(`Job đã lưu tiến độ ${Number(job.processed_count||0).toLocaleString('vi-VN')}/${Number(job.total_count||0).toLocaleString('vi-VN')}. Cloudflare sẽ tiếp tục chạy nền.`, 'bad');
          return {updated:Number(job.processed_count||0),recipients:Number(job.recipients_count||0),job,pending:true};
        }
        job=r.job||job;patchDistributedCustomers(r.assignments||[]);renderBulkJobIndicator(job);
        if(r.locked){await sleep(900);continue;}
        if(job.status!=='RUNNING')break;
        await sleep(80);
      }
      if(job.status==='COMPLETED'){
        localStorage.removeItem('a4_bulk_job_id');invalidateWarehousePending();
        if(!silent)toast(`Đã phân xong ${Number(job.processed_count||0).toLocaleString('vi-VN')} Data.`);
      }
      return {updated:Number(job.processed_count||0),recipients:Number(job.recipients_count||0),job,pending:job.status==='RUNNING'};
    }finally{
      if(button){button.disabled=false;button.textContent=original;}
      state.bulkJobRunnerId=null;state.bulkJobRunnerPromise=null;
    }
  })();
  return state.bulkJobRunnerPromise;
}
async function resumePersistentBulkJob(){
  if(state.mode!=='d1'||!['admin','sup','teamlead'].includes(state.session?.user?.role||''))return;
  const stored=Number(localStorage.getItem('a4_bulk_job_id')||0);
  let job=null;
  if(stored){try{job=(await API.request(`/bulk-jobs/${stored}`,{timeoutMs:8000})).job;if(job&&job.status!=='RUNNING'){localStorage.removeItem('a4_bulk_job_id');renderBulkJobIndicator(job);}}catch{localStorage.removeItem('a4_bulk_job_id');}}
  if(!job||job.status!=='RUNNING')job=await loadActiveBulkDistributionJob();
  if(job?.status==='RUNNING')driveBulkDistributionJob(job.id,null,{silent:true});
}
async function distributeWarehouseBatched(baseBody,requestedLimit,button){
  if(state.mode!=='d1')throw new Error('Cần D1 Online để chia Data.');
  const created=await API.request('/bulk-jobs/distribute',{method:'POST',timeoutMs:20000,body:JSON.stringify({...baseBody,limit:Math.max(0,Number(requestedLimit)||0)})});
  if(!created.job)return {updated:0,recipients:Number(created.recipients||0)};
  state.bulkDistributionJob={...created.job,recipients_count:Number(created.recipients||created.job.recipients_count||0)};
  renderBulkJobIndicator(state.bulkDistributionJob);localStorage.setItem('a4_bulk_job_id',String(created.job.id));
  return driveBulkDistributionJob(created.job.id,button);
}

function recallSaleUsers(){
  const role=state.session.user.role,team=Number(state.session.user.team_id||0);
  return state.users.filter(u=>u.role==='sale'&&Number(u.active)!==0&&((role==='admin'||role==='sup')||Number(u.team_id)===team));
}
function recallCandidateBase(userId){
  return state.customers.filter(c=>Number(c.assigned_user_id)===Number(userId)&&['ASSIGNED','ARCHIVED'].includes(String(c.data_state||'')));
}
function recallCandidates(userId,status='ALL'){
  const rows=recallCandidateBase(userId);return status==='ALL'?rows:rows.filter(c=>String(c.status||'NEW').toUpperCase()===String(status).toUpperCase());
}
function recallStatusCounts(userId){
  const rows=recallCandidateBase(userId),counts={ALL:rows.length};Object.keys(STATUS_LABELS).forEach(k=>counts[k]=0);
  rows.forEach(c=>{const k=String(c.status||'NEW').toUpperCase();if(counts[k]!==undefined)counts[k]++;});return counts;
}
function recallDataCard(){
  const staff=recallSaleUsers();
  const fromId=staff.some(u=>Number(u.id)===Number(state.recallFrom))?Number(state.recallFrom):Number(staff[0]?.id||0);
  const source=staff.find(u=>Number(u.id)===fromId);
  const counts=recallStatusCounts(fromId),wanted=state.recallStatus&&['ALL',...Object.keys(STATUS_LABELS)].includes(state.recallStatus)?state.recallStatus:'ALL';
  const statusOptions=`<option value="ALL">Tất cả trạng thái (${counts.ALL||0})</option>${Object.keys(STATUS_LABELS).map(k=>`<option value="${k}" ${wanted===k?'selected':''}>${esc(STATUS_LABELS[k])} (${counts[k]||0})</option>`).join('')}`;
  const chips=['ALL','NEW','Y01','Y02','Y03','Y04','Y05','Y06','N01','N02','N03','N04'].filter(k=>k==='ALL'||Number(counts[k]||0)>0).map(k=>`<button type="button" class="transfer-count-chip ${wanted===k?'active':''}" data-recall-chip="${k}">${k==='ALL'?'Tất cả':k} <strong>${counts[k]||0}</strong></button>`).join('');
  return `<div class="card transfer-card recall-card" id="recall-card"><div class="card-head"><div><h3>↩ Thu hồi Data của nhân viên về Kho</h3><span class="muted">Gỡ người phụ trách của Data đã chọn và đưa trở lại Kho của Team. Lịch sử cuộc gọi, Lead và phân loại được giữ nguyên.</span></div></div>
    <div class="form-grid">
      <div class="form-field"><label>Nhân viên đang giữ Data</label><select id="recall-from">${staff.map(u=>`<option value="${u.id}" ${Number(u.id)===fromId?'selected':''}>${esc(u.display_name)} · ${esc(u.team||'')}</option>`).join('')}</select></div>
      <div class="form-field"><label>Trạng thái cần thu hồi</label><select id="recall-status">${statusOptions}</select></div>
      <div class="form-field"><label>Số lượng</label><input id="recall-limit" type="number" min="0" max="10000" value="0" placeholder="0 = toàn bộ phù hợp"></div>
      <div class="form-field"><label>Kho nhận</label><input value="${esc(source?.team||'Kho Team')}" disabled></div>
      <div class="form-field full"><div class="transfer-status-counts" id="recall-status-counts">${chips}</div></div>
      <div class="form-field full"><div class="notice" id="recall-preview" aria-live="polite"></div></div>
    </div>
    <div class="call-actions"><button class="btn danger" id="recall-submit" ${!staff.length?'disabled':''}>↩ Thu hồi Data về Kho</button></div>
    <p class="muted transfer-help">Sau khi thu hồi: Data trở về Kho của Team hiện tại, người phụ trách được gỡ, deadline và lịch gọi lại hiện tại được xoá. Lịch sử cuộc gọi cũ không bị xoá. Khi chia lại, hệ thống sẽ mở vòng phân công mới.</p></div>`;
}
function patchRecalledCustomers(ids){
  const set=new Set((ids||[]).map(Number));if(!set.size)return;
  for(const c of state.customers||[]){if(!set.has(Number(c.id)))continue;c.last_assigned_user_id=c.assigned_user_id;c.assigned_user_id=null;c.owner='';c.data_state='POOL';c.status='NEW';c.assignment_deadline=null;c.archived_at=null;c.follow_up='';c.follow_up_at=null;}
}
function bindRecallDataCard(main,renderPage){
  const from=$('#recall-from'),status=$('#recall-status'),limit=$('#recall-limit'),submit=$('#recall-submit');if(!from||!status||!submit)return;
  const update=()=>{
    const source=Number(from.value||0);state.recallFrom=String(source);state.recallStatus=status.value||'ALL';
    const counts=recallStatusCounts(source),matches=recallCandidates(source,state.recallStatus),requested=Math.max(0,Number(limit?.value)||0),take=requested?Math.min(requested,matches.length):matches.length;
    const u=recallSaleUsers().find(x=>Number(x.id)===source),preview=$('#recall-preview');
    if(preview)preview.innerHTML=`<strong>${take.toLocaleString('vi-VN')} Data</strong> sẽ được thu hồi từ <strong>${esc(u?.display_name||'nhân viên')}</strong> về <strong>Kho ${esc(u?.team||'Team')}</strong>. ${requested>matches.length?`Chỉ có ${matches.length.toLocaleString('vi-VN')} Data phù hợp.`:''}`;
    const chips=$('#recall-status-counts');if(chips)chips.innerHTML=['ALL','NEW','Y01','Y02','Y03','Y04','Y05','Y06','N01','N02','N03','N04'].filter(k=>k==='ALL'||Number(counts[k]||0)>0).map(k=>`<button type="button" class="transfer-count-chip ${state.recallStatus===k?'active':''}" data-recall-chip="${k}">${k==='ALL'?'Tất cả':k} <strong>${counts[k]||0}</strong></button>`).join('');
    $$('[data-recall-chip]',chips).forEach(b=>b.onclick=()=>{status.value=b.dataset.recallChip;state.recallStatus=status.value;update()});
    submit.disabled=!source||take===0;
  };
  from.onchange=()=>{state.recallStatus='ALL';status.value='ALL';update()};status.onchange=update;if(limit)limit.oninput=update;update();
  submit.onclick=async()=>{
    const source=Number(from.value||0),st=status.value||'ALL',requested=Math.max(0,Number(limit?.value)||0),u=recallSaleUsers().find(x=>Number(x.id)===source),available=recallCandidates(source,st).length,total=requested?Math.min(requested,available):available;
    if(!source||!total){toast('Không có Data phù hợp để thu hồi.','bad');return;}
    if(!confirm(`Thu hồi ${total.toLocaleString('vi-VN')} Data của ${u?.display_name||'nhân viên'} về Kho ${u?.team||'Team'}?\n\nLịch sử cuộc gọi và phân loại vẫn được giữ nguyên.`))return;
    const old=submit.textContent;submit.disabled=true;let done=0;
    try{
      while(done<total){
        const batch=Math.min(500,total-done);submit.textContent=`Đang thu hồi ${done.toLocaleString('vi-VN')}/${total.toLocaleString('vi-VN')}...`;
        const r=await API.request('/warehouse/recall-user',{method:'POST',timeoutMs:35000,body:JSON.stringify({user_id:source,status:st,limit:batch})});
        const moved=Number(r.updated||0);patchRecalledCustomers(r.customer_ids||[]);done+=moved;if(!moved)break;
      }
      invalidateWarehousePending();toast(`Đã thu hồi ${done.toLocaleString('vi-VN')} Data về Kho.`);renderPage(main);
    }catch(err){toast(`Đã thu hồi ${done.toLocaleString('vi-VN')}/${total.toLocaleString('vi-VN')}. ${err.message}`,'bad');renderPage(main);}
    finally{submit.disabled=false;submit.textContent=old;}
  };
}

function transferDataCard(){
  const staff=transferSaleUsers(), fromId=staff.some(u=>Number(u.id)===Number(state.transferFrom))?Number(state.transferFrom):Number(staff[0]?.id||0);
  const staffOpts=staff.map(u=>`<option value="${u.id}" ${Number(u.id)===fromId?'selected':''}>${esc(u.display_name)} · ${esc(u.team||'')}</option>`).join('');
  return `<div class="card transfer-card" id="transfer-card"><div class="card-head"><div><h3>↪ Chuyển Data giữa nhân viên</h3><span class="muted">Chuyển theo một trạng thái cụ thể hoặc toàn bộ Data đang do nhân viên nguồn giữ.</span></div></div>
    <div class="card-body"><div class="form-grid">
      <div class="form-field"><label>Nhân viên đang giữ Data</label><select id="transfer-from">${staffOpts}</select></div>
      <div class="form-field"><label>Trạng thái cần chuyển</label><select id="transfer-status"></select></div>
      <div class="form-field"><label>Nhân viên nhận Data</label><select id="transfer-to"></select></div>
      <div class="form-field"><label>Số lượng</label><input id="transfer-limit" type="number" min="0" max="500" value="0" placeholder="0 = tất cả, tối đa 500"></div>
      <div class="form-field"><label>Thời hạn gọi lại (ngày)</label><input id="transfer-days" type="number" min="0" max="365" value="7"></div>
      <div class="form-field full"><div class="transfer-status-counts" id="transfer-status-counts"></div></div>
      <div class="form-field full"><div class="notice" id="transfer-preview" aria-live="polite"></div></div>
    </div><div class="call-actions"><button class="btn primary" id="transfer-submit" ${staff.length<2?'disabled':''}>↪ Chuyển Data cho nhân viên khác</button></div>
    <p class="muted transfer-help">Giữ nguyên khách, phân loại và toàn bộ lịch sử cuộc gọi. Admin có thể chuyển giữa mọi Team; Team Leader chỉ chuyển trong Team mình. Người nhận được mở vòng phân công mới; tối đa 500 khách/lần.</p></div></div>`;
}
function bindTransferDataCard(main,renderPage){
  const from=$('#transfer-from'),to=$('#transfer-to'),status=$('#transfer-status'),submit=$('#transfer-submit');
  if(!from||!to||!status||!submit)return;
  const staff=transferSaleUsers();
  const refresh=()=>{
    const source=Number(from.value),sourceUser=staff.find(u=>Number(u.id)===source);
    const targets=staff.filter(u=>Number(u.id)!==source && (['admin','sup'].includes(state.session.user.role)||Number(u.team_id)===Number(sourceUser?.team_id)));
    const preferred=Number(state.transferTo), selected=targets.some(u=>Number(u.id)===preferred)?preferred:targets[0]?.id;
    to.innerHTML=targets.map(u=>`<option value="${u.id}" ${Number(u.id)===Number(selected)?'selected':''}>${esc(u.display_name)} · ${esc(u.team||'')}</option>`).join('');
    state.transferFrom=String(source);state.transferTo=String(selected||'');
    const counts=transferStatusCounts(source),wanted=state.transferStatus&&['ALL',...Object.keys(STATUS_LABELS)].includes(state.transferStatus)?state.transferStatus:'ALL';
    status.innerHTML=`<option value="ALL">Tất cả trạng thái (${counts.ALL||0})</option>${Object.entries(STATUS_LABELS).map(([k,label])=>`<option value="${k}">${esc(label)} (${counts[k]||0})</option>`).join('')}`;
    status.value=wanted; if(!status.value)status.value='ALL';state.transferStatus=status.value;
    const matches=transferCandidates(source,status.value),requested=Number($('#transfer-limit').value)||0;
    const chipKeys=['NEW','Y01','Y02','Y03','Y04','Y05','Y06','N01','N02','N03','N04'].filter(k=>counts[k]>0);
    const chips=$('#transfer-status-counts');if(chips)chips.innerHTML=`<button type="button" class="transfer-count-chip ${status.value==='ALL'?'active':''}" data-transfer-chip="ALL">Tất cả <strong>${counts.ALL||0}</strong></button>${chipKeys.map(k=>`<button type="button" class="transfer-count-chip ${status.value===k?'active':''}" data-transfer-chip="${k}" title="${esc(STATUS_LABELS[k])}">${k} <strong>${counts[k]}</strong></button>`).join('')}`;
    $$('[data-transfer-chip]').forEach(b=>b.onclick=()=>{state.transferStatus=b.dataset.transferChip;status.value=state.transferStatus;refresh();});
    const display=matches.slice(0,5).map(c=>esc(c.name||c.phone)).join(', '),label=status.value==='ALL'?'tất cả trạng thái':status.value;
    $('#transfer-preview').innerHTML=`<strong>${matches.length} khách · ${esc(label)}</strong> đang do nhân viên này phụ trách. ${display?`Ví dụ: ${display}${matches.length>5?'…':''}.`:''} ${matches.length>500&&!requested?'<strong>Hãy nhập số lượng từ 1 đến 500.</strong>':''}`;
    submit.disabled=!targets.length||!matches.length;
  };
  from.onchange=refresh;
  status.onchange=()=>{state.transferStatus=status.value;refresh()};
  to.onchange=()=>{state.transferTo=to.value};
  $('#transfer-limit').oninput=refresh;
  refresh();
  submit.onclick=async()=>{
    if(state.mode!=='d1'){toast('Cần D1 Online để chuyển Data.','bad');return;}
    const source=Number(from.value),target=Number(to.value),st=status.value;
    const available=transferCandidates(source,st),limit=Number($('#transfer-limit').value),days=Number($('#transfer-days').value);
    if(!Number.isSafeInteger(limit)||limit<0||limit>500){toast('Số lượng phải từ 0 đến 500.','bad');return;}
    if(!Number.isSafeInteger(days)||days<0||days>365){toast('Thời hạn phải từ 0 đến 365 ngày.','bad');return;}
    if(!available.length||(!limit&&available.length>500)){toast('Không có Data phù hợp hoặc vượt 500 khách. Hãy giới hạn số lượng.','bad');return;}
    const sourceName=staff.find(u=>Number(u.id)===source)?.display_name||'nguồn',targetName=staff.find(u=>Number(u.id)===target)?.display_name||'người nhận';
    const count=limit?Math.min(limit,available.length):available.length,label=st==='ALL'?'tất cả trạng thái':st;
    if(!confirm(`Chuyển ${count} khách (${label}) từ ${sourceName} sang ${targetName}?\n\nLịch sử gọi và trạng thái hiện tại được giữ nguyên.`))return;
    submit.disabled=true;
    const originalText=submit.textContent;
    let moved=0;
    try{
      const targetTotal=count,chunkSize=100;
      while(moved<targetTotal){
        const ask=Math.min(chunkSize,targetTotal-moved);
        submit.textContent=`Đang chuyển ${moved}/${targetTotal}...`;
        const result=await API.request('/warehouse/transfer',{method:'POST',timeoutMs:30000,body:JSON.stringify({from_user_id:source,to_user_id:target,status:st,limit:ask,deadline_days:days,mode:'filtered'})});
        const n=Number(result.updated||0);if(!n)break;
        patchTransferredCustomers(result.customer_ids||[],result.target_user_id||target,result.target_team_id,result.deadline);
        moved+=n;if(n<ask)break;await sleep(40);
      }
      invalidateWarehousePending();renderPage(main);
      toast(`Đã chuyển ${moved} khách cho ${targetName}.`);
    }catch(err){
      if(moved){invalidateWarehousePending();renderPage(main);toast(`Đã chuyển ${moved} khách trước khi kết nối bị gián đoạn. Bạn có thể tiếp tục phần còn lại.`,'bad');}
      else toast(err.message,'bad');
    }finally{submit.disabled=false;submit.textContent=originalText;}
  };
}

function warehouseEmployeeTotals(rows, users){
  const byUser=new Map();
  for(const c of rows||[]){
    const uid=Number(c.assigned_user_id||0);if(!uid)continue;
    if(!byUser.has(uid))byUser.set(uid,{total:0,uncalled:0,called:0});
    const g=byUser.get(uid);g.total++;
    if(warehouseState(c)==='ARCHIVED')g.called++;else g.uncalled++;
  }
  return (users||[]).filter(u=>u.role==='sale'&&Number(u.active)!==0).map(u=>{
    const g=byUser.get(Number(u.id))||{total:0,uncalled:0,called:0};
    return {...u,...g,doneRate:g.total?Math.round(g.called/g.total*100):0};
  }).sort((a,b)=>String(a.team||'').localeCompare(String(b.team||''),'vi')||String(a.display_name||'').localeCompare(String(b.display_name||''),'vi'));
}
function warehouseEmployeeTotalsMarkup(rows, users, title='Tổng Data theo nhân viên', subtitle='Bao gồm Data chưa gọi và Data đã gọi hiện đang thuộc từng nhân viên.'){
  const items=warehouseEmployeeTotals(rows,users);
  const body=items.map(u=>`<tr><td><strong>${esc(u.display_name||u.username||'Nhân viên')}</strong></td><td>${esc(u.team||'—')}</td><td class="num"><strong>${Number(u.total||0)}</strong></td><td class="num">${Number(u.uncalled||0)}</td><td class="num">${Number(u.called||0)}</td><td><div class="warehouse-staff-progress"><span style="width:${Math.max(0,Math.min(100,Number(u.doneRate||0)))}%"></span></div><small>${Number(u.doneRate||0)}% đã gọi</small></td></tr>`).join('')||'<tr><td colspan="6"><div class="empty small-empty">Chưa có nhân viên.</div></td></tr>';
  const grand=items.reduce((n,u)=>n+Number(u.total||0),0),uncalled=items.reduce((n,u)=>n+Number(u.uncalled||0),0),called=items.reduce((n,u)=>n+Number(u.called||0),0);
  return `<div class="card warehouse-staff-total-card"><div class="card-head"><div><h3>👥 ${esc(title)}</h3><span class="muted">${esc(subtitle)}</span></div><div class="warehouse-staff-total-summary"><span>Tổng <strong>${grand}</strong></span><span>Chưa gọi <strong>${uncalled}</strong></span><span>Đã gọi <strong>${called}</strong></span></div></div><div class="table-wrap"><table class="data-table warehouse-staff-total-table"><thead><tr><th>Nhân viên</th><th>Team</th><th class="num">Tổng Data</th><th class="num">Chưa gọi</th><th class="num">Đã gọi</th><th>Tiến độ</th></tr></thead><tbody>${body}</tbody></table></div></div>`;
}

function renderTeamleadData(main){
  const teamId=Number(state.session.user.team_id||0), teamName=state.session.user.team||'Team của bạn';
  const sales=state.users.filter(u=>u.role==='sale'&&Number(u.team_id)===teamId&&Number(u.active)!==0);
  const teamRows=visibleCustomers().filter(c=>Number(c.team_id)===teamId);
  const pool=teamRows.filter(c=>warehouseState(c)==='POOL');
  const assigned=teamRows.filter(c=>warehouseState(c)==='ASSIGNED');
  const archived=teamRows.filter(c=>warehouseState(c)==='ARCHIVED');
  // Nhóm tại client từ dữ liệu Team đã tải sẵn: không phát sinh thêm Rows read.
  const categoryMap=new Map();
  for(const c of teamRows){
    const categoryId=Number(c.data_category_id||0),name=c.data_category||c.source||'Chưa phân loại';
    const key=categoryId?`id:${categoryId}`:`name:${name}`;
    if(!categoryMap.has(key))categoryMap.set(key,{id:categoryId||'',name,total:0,pool:0,assigned:0,archived:0,uncalled:0});
    const g=categoryMap.get(key),ws=warehouseState(c);g.total++;
    if(ws==='POOL')g.pool++; else if(ws==='ASSIGNED'){g.assigned++;if(c.status==='NEW')g.uncalled++;} else if(ws==='ARCHIVED')g.archived++;
  }
  const categoryGroups=[...categoryMap.values()].sort((a,b)=>b.pool-a.pool||b.total-a.total||String(a.name).localeCompare(String(b.name),'vi'));
  const categoryOptions=categoryGroups.filter(g=>g.id&&g.pool>0).map(g=>`<option value="${g.id}">${esc(g.name)} · còn ${g.pool}</option>`).join('');
  const finishedGroups=categoryGroups.filter(g=>g.id&&g.archived>0&&g.pool===0&&g.assigned===0);
  const finishedOptions=finishedGroups.map(g=>`<option value="${g.id}">${esc(g.name)} · ${g.archived} Data đã gọi</option>`).join('');
  const categoryTable=categoryGroups.map(g=>{
    const finished=g.id&&g.total>0&&g.pool===0&&g.assigned===0&&g.archived===g.total;
    const action=g.id&&g.pool>0?`<button class="btn small" data-team-category-pick="${g.id}">Chia loại này</button>`:finished?`<button class="btn small" data-team-called-jump="${g.id}">Xem Data đã gọi</button>`:'<span class="muted">—</span>';
    return `<tr><td><strong>${esc(g.name)}</strong>${finished?'<small class="category-ready">Đã gọi xong</small>':''}</td><td class="num">${g.total}</td><td class="num"><strong>${g.pool}</strong></td><td class="num">${g.assigned}</td><td class="num">${g.uncalled}</td><td class="num">${g.archived}</td><td>${action}</td></tr>`
  }).join('')||'<tr><td colspan="7"><div class="empty">Chưa có phân loại Data.</div></td></tr>';
  const called=[...archived].sort((a,b)=>String(b.archived_at||b.updated_at||'').localeCompare(String(a.archived_at||a.updated_at||''))||Number(b.id)-Number(a.id));
  const calledRows=called.slice(0,300).map(c=>`<tr data-called-cat="${Number(c.data_category_id||0)}"><td><strong>${esc(c.name||'Chưa rõ')}</strong><div class="muted">${esc(c.phone||'')}</div></td><td>${esc(c.data_category||c.source||'Chưa phân loại')}</td><td>${esc(c.owner||'—')}</td><td>${c.status&&c.status!=='NEW'?statusPill(c.status):'<span class="muted">—</span>'}</td><td>${c.archived_at?fmtDate(c.archived_at):'—'}</td></tr>`).join('')||'<tr><td colspan="5"><div class="empty">Chưa có Data đã gọi.</div></td></tr>';
  const teamStaffTotals=warehouseEmployeeTotalsMarkup(teamRows,sales,'Tổng Data theo nhân viên',`Tất cả Data đang thuộc Sale của ${teamName}, gồm cả chưa gọi và đã gọi.`);
  const teamSection=['staff','recall'].includes(state.warehouseSection)?state.warehouseSection:'categories';
  const teamTabs=`<nav class="warehouse-section-tabs" aria-label="Chức năng Kho Team"><button type="button" class="warehouse-section-tab ${teamSection==='categories'?'active':''}" data-team-wh-section="categories">📦 Kho Data Team</button><button type="button" class="warehouse-section-tab ${teamSection==='staff'?'active':''}" data-team-wh-section="staff">👥 Data nhân viên</button><button type="button" class="warehouse-section-tab ${teamSection==='recall'?'active':''}" data-team-wh-section="recall">↩ Thu hồi Data</button></nav>`;
  const teamPageHead=pageHead('Kho Data Team',`Kho riêng của ${esc(teamName)}. Data và thao tác chỉ thuộc Team của bạn.`);
  const teamNote=`<div class="teamlead-data-note"><strong>🔒 Kho riêng theo Team:</strong> mọi thao tác chỉ áp dụng cho <strong>${esc(teamName)}</strong>. Teamlead khác không thể xem hoặc sử dụng Data của Team này.</div>`;
  if(teamSection==='staff'){
    main.innerHTML=`${teamPageHead}${teamNote}${teamTabs}<div class="warehouse-section-intro"><h3>Data theo nhân viên</h3><p>Xem nhanh tổng Data, Data chưa gọi, Data đã gọi và tiến độ của từng Sale trong ${esc(teamName)}.</p></div>${teamStaffTotals}`;
    $$('[data-team-wh-section]').forEach(b=>b.onclick=()=>{state.warehouseSection=b.dataset.teamWhSection;renderTeamleadData(main)});
    return;
  }
  if(teamSection==='recall'){
    main.innerHTML=`${teamPageHead}${teamNote}${teamTabs}<div class="warehouse-section-intro"><h3>Thu hồi Data về Kho Team</h3><p>Chọn một nhân viên trong ${esc(teamName)}, lọc trạng thái và thu hồi Data về Kho riêng của Team.</p></div>${recallDataCard()}`;
    $$('[data-team-wh-section]').forEach(b=>b.onclick=()=>{state.warehouseSection=b.dataset.teamWhSection;renderTeamleadData(main)});
    bindRecallDataCard(main,renderTeamleadData);
    return;
  }

  main.innerHTML=`${teamPageHead}${teamNote}${teamTabs}
  <div class="team-warehouse-flow"><span class="active">1 · Đẩy Data</span><span>2 · Phân cho Sale</span><span>3 · Data đã gọi</span><span>4 · Chia lại</span><span>5 · Chuyển nhân viên</span></div>

  <div class="card team-data-upload-card"><div class="card-head"><div><h3>📥 Đẩy Data vào Team</h3><span class="muted">Tên nguồn bạn nhập sẽ tự động trở thành Phân loại Data. Không cần phân loại lại sau khi tải.</span></div><span class="team-chip">${esc(teamName)}</span></div>
    <div class="team-data-upload-grid"><div class="team-upload-side"><div class="form-field"><label>Tên nguồn / Phân loại Data</label><input id="warehouse-source" list="team-category-suggestions" value="${esc(warehouseImportSource)}" placeholder="Ví dụ: LNL T10, CTV Facebook, Data cũ tháng 9…" autocomplete="off"><datalist id="team-category-suggestions">${categoryGroups.map(g=>`<option value="${esc(g.name)}"></option>`).join('')}</datalist><small class="muted">Bắt buộc nhập trước khi tải. <strong>Tên nguồn = Phân loại Data</strong>.</small></div>
      <div class="team-file-drop"><input type="file" accept=".xlsx,.xls,.csv" id="file-input"><span>Hỗ trợ .xlsx, .xls, .csv</span></div>
      <div class="import-actions"><button class="btn" id="preview-import">Đọc & kiểm tra</button><button class="btn primary" id="upload-import" disabled>Đẩy vào Team</button></div><div id="import-progress" class="import-progress"></div>
      <p class="muted team-import-help">Hệ thống chỉ kiểm tra SĐT trùng trong <strong>${esc(teamName)}</strong>. SĐT đang có ở Team khác vẫn được phép nhập vào Team này.</p>
    </div>
    <div class="team-distribute-side"><h3>Phân Data đang nằm trong Kho</h3><p class="muted">Chọn đúng phân loại vừa tải hoặc một phân loại còn Data trong Kho.</p><div class="form-grid">
      <div class="form-field"><label>Phân loại Data</label><select id="lead-wh-category"><option value="">Tất cả phân loại còn trong Kho (${pool.length})</option>${categoryOptions}</select></div>
      <div class="form-field"><label>Cách chia</label><select id="lead-wh-mode"><option value="all">Chia đều toàn bộ thành viên</option><option value="user">Gán cho 1 thành viên</option></select></div>
      <div class="form-field"><label>Số lượng</label><input id="lead-wh-limit" type="number" min="0" value="0" placeholder="0 = tất cả"></div>
      <div class="form-field"><label>Thời hạn gọi (ngày)</label><input id="lead-wh-days" type="number" min="0" max="365" value="7"></div>
      <div class="form-field full" id="lead-wh-target-wrap"></div></div>
      <div class="call-actions"><button class="btn primary" id="lead-wh-distribute" ${!sales.length?'disabled':''}>Phân Data cho Team</button></div><div id="team-bulk-job-status">${bulkJobProgressMarkup(state.bulkDistributionJob)}</div>
      <div class="notice">Chỉ ${sales.length} Sale đang hoạt động của <strong>${esc(teamName)}</strong> có thể nhận Data. Job lớn được lưu tiến độ và tự tiếp tục nếu bạn refresh hoặc đóng trình duyệt.</div>
    </div></div>
  </div>
  <div id="import-preview"></div>

  <div class="team-data-summary"><div><span>Tổng Data Team</span><strong>${teamRows.length}</strong></div><div><span>Trong Kho</span><strong>${pool.length}</strong></div><div><span>Đang giao</span><strong>${assigned.length}</strong></div><div><span>Data đã gọi</span><strong>${archived.length}</strong></div></div>


  <div class="card team-category-card"><div class="card-head"><div><h3>Data theo nguồn / phân loại</h3><span class="muted">Theo dõi mỗi nguồn đã tải: còn trong Kho, đang giao và đã gọi bao nhiêu.</span></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Phân loại</th><th class="num">Tổng</th><th class="num">Trong Kho</th><th class="num">Đang giao</th><th class="num">Chưa gọi</th><th class="num">Đã gọi</th><th>Thao tác</th></tr></thead><tbody>${categoryTable}</tbody></table></div></div>

  <div class="card team-called-card" id="team-called-section"><div class="card-head"><div><h3>☎ Data đã gọi</h3><span class="muted">Data hoàn tất nằm riêng tại đây. Khi cả phân loại đã gọi xong, có thể mở vòng mới và chia lại trong chính Team.</span></div></div><div class="card-body">
    <div class="team-called-toolbar"><label>Hiển thị phân loại<select id="team-called-filter"><option value="">Tất cả Data đã gọi (${archived.length})</option>${categoryGroups.filter(g=>g.id&&g.archived>0).map(g=>`<option value="${g.id}">${esc(g.name)} (${g.archived})</option>`).join('')}</select></label><label>Phân loại chia lại<select id="team-called-recycle-category"><option value="">Chọn phân loại đã gọi xong…</option>${finishedOptions}</select></label><label>Số lượng<input id="team-called-recycle-limit" type="number" min="0" value="0" placeholder="0 = tất cả"></label><label>Hạn gọi (ngày)<input id="team-called-recycle-days" type="number" min="1" max="365" value="7"></label><button class="btn primary" id="team-called-recycle" ${finishedGroups.length?'':'disabled'}>🎲 Chia lại Data đã gọi</button></div>
    ${finishedGroups.length?'':'<div class="notice">Chưa có phân loại nào hoàn tất toàn bộ. Hệ thống chỉ cho chia lại khi cả phân loại đã gọi xong để không trộn vòng gọi.</div>'}
  </div><div class="table-wrap"><table class="data-table team-called-table"><thead><tr><th>Khách hàng</th><th>Phân loại</th><th>Nhân viên lần trước</th><th>Kết quả cuối</th><th>Hoàn tất lúc</th></tr></thead><tbody id="team-called-body">${calledRows}</tbody></table></div></div>

  <div class="team-transfer-last"><div class="warehouse-section-intro"><h3>↔ Chuyển Data giữa nhân viên</h3><p>Đặt ở cuối luồng. Chọn nhân viên nguồn, trạng thái (hoặc tất cả) và người nhận. Trạng thái cùng toàn bộ lịch sử gọi được giữ nguyên.</p></div>${transferDataCard()}</div>`;

  $$('[data-team-wh-section]').forEach(b=>b.onclick=()=>{state.warehouseSection=b.dataset.teamWhSection;renderTeamleadData(main)});
  const renderTarget=()=>{
    const mode=$('#lead-wh-mode').value,wrap=$('#lead-wh-target-wrap');
    if(mode==='user') wrap.innerHTML=`<label>Thành viên nhận Data</label><select id="lead-wh-target">${sales.map(u=>`<option value="${u.id}">${esc(u.display_name)}</option>`).join('')}</select>`;
    else wrap.innerHTML=`<div class="notice">Sẽ chia vòng tròn cho toàn bộ ${sales.length} Sale trong Team.</div>`;
  };
  $('#lead-wh-mode').onchange=renderTarget;renderTarget();
  $$('[data-team-category-pick]').forEach(b=>b.onclick=()=>{const sel=$('#lead-wh-category');if(sel){sel.value=b.dataset.teamCategoryPick;sel.scrollIntoView({behavior:'smooth',block:'center'});toast('Đã chọn phân loại để chia Data.');}});
  $$('[data-team-called-jump]').forEach(b=>b.onclick=()=>{const sel=$('#team-called-filter');if(sel){sel.value=b.dataset.teamCalledJump;sel.dispatchEvent(new Event('change'));$('#team-called-section')?.scrollIntoView({behavior:'smooth',block:'start'});}});
  bindTransferDataCard(main,renderTeamleadData);
  $('#warehouse-source').oninput=e=>{warehouseImportSource=e.target.value;if(importPreview.length){importPreview=importPreview.map(x=>({...x,source:warehouseImportSource}));renderImportPreview();}};
  if($('#warehouse-target-team')) $('#warehouse-target-team').onchange=()=>{importPreview=[];importRaw=[];$('#import-preview').innerHTML='';$('#import-progress').textContent='Đã đổi Kho nhận Data. Hãy bấm Đọc & kiểm tra lại để lọc trùng đúng phạm vi Team.';$('#upload-import').disabled=true;};
  $('#file-input').onchange=()=>{importPreview=[];importRaw=[];$('#import-preview').innerHTML='';$('#import-progress').textContent='';$('#upload-import').disabled=true;};
  $('#preview-import').onclick=async()=>{
    const sourceName=$('#warehouse-source').value.trim();warehouseImportSource=sourceName;
    if(!sourceName){toast('Nhập tên nguồn / phân loại Data trước.','bad');$('#warehouse-source').focus();return;}
    const f=$('#file-input').files[0];if(!f){toast('Chọn file trước.','bad');return;}
    try{
      $('#upload-import').disabled=true;$('#import-progress').textContent=`Đang kiểm tra SĐT trùng chỉ trong ${teamName}...`;
      importRaw=await readImportFile(f);importPreview=await checkImportDuplicates(applyWarehouseImport(importRaw,sourceName),teamId);
      const stats=importPreviewStats();$('#import-progress').textContent=`${stats.valid} Data mới · ${stats.old} trùng Data cũ · ${stats.file} trùng trong file · ${stats.missing} thiếu SĐT.`;renderImportPreview();
    }catch(err){toast(err.message,'bad');$('#import-progress').textContent='Kiểm tra thất bại.';importPreview=[];$('#upload-import').disabled=true;}
  };
  $('#upload-import').onclick=async()=>{
    if(state.mode!=='d1'){toast('Cần D1 Online để import.','bad');return;}
    const sourceName=$('#warehouse-source').value.trim(),stats=importPreviewStats();
    const clean=importPreview.filter(x=>!x.importDuplicate).map(x=>({...x,source:sourceName}));
    if(!sourceName||!clean.length){toast(!sourceName?'Nhập tên nguồn Data trước.':'Không có Data mới để nhập.','bad');return;}
    if(!confirm(`Đưa ${clean.length} Data mới vào ${teamName} với phân loại “${sourceName}”? Data trùng sẽ bỏ qua.`))return;
    try{
      $('#upload-import').disabled=true;let inserted=0,skipped=0;
      for(let i=0;i<clean.length;i+=250){const batch=clean.slice(i,i+250);const r=await bulkApiRetry('/customers/import',{method:'POST',body:JSON.stringify({items:batch,to_warehouse:true,source_name:sourceName})});inserted+=r.inserted||0;skipped+=r.skipped||0;$('#import-progress').textContent=`Đang tải ${Math.min(i+batch.length,clean.length)}/${clean.length}...`;}
      await refreshCustomersOnly();importRaw=[];importPreview=[];warehouseImportSource='';renderTeamleadData(main);toast(`Đã đẩy ${inserted} Data vào Kho ${teamName}; tự phân loại “${sourceName}”. Bỏ qua ${stats.old+stats.file+stats.missing+skipped} dòng trùng/không hợp lệ.`);
    }catch(err){toast(err.message,'bad');$('#upload-import').disabled=false;}
  };
  $('#lead-wh-distribute').onclick=async()=>{
    if(state.mode!=='d1'){toast('Cần D1 Online để chia Data.','bad');return;}
    const mode=$('#lead-wh-mode').value,limit=Math.max(0,Number($('#lead-wh-limit').value)||0),deadline_days=Math.max(0,Number($('#lead-wh-days').value)||0),category_id=Number($('#lead-wh-category').value||0)||null;const body={mode,deadline_days,category_id};
    if(mode==='user') body.user_id=Number($('#lead-wh-target').value);
    const btn=$('#lead-wh-distribute');
    try{const r=await distributeWarehouseBatched(body,limit,btn);invalidateWarehousePending();renderTeamleadData(main);toast(r.pending?`Job đang tiếp tục chạy nền: ${r.updated}/${r.job?.total_count||0} Data.`:`Đã phân ${r.updated} khách cho ${r.recipients} nhân viên trong Team.`,r.pending?'bad':'ok');}catch(err){renderTeamleadData(main);toast(err.message,'bad')}
  };
  const applyCalledFilter=()=>{const v=$('#team-called-filter')?.value||'';$$('[data-called-cat]').forEach(tr=>tr.classList.toggle('hidden',!!v&&tr.dataset.calledCat!==v));};
  if($('#team-called-filter'))$('#team-called-filter').onchange=applyCalledFilter;
  if($('#team-called-recycle'))$('#team-called-recycle').onclick=async()=>{
    if(state.mode!=='d1'){toast('Cần D1 Online để chia lại Data.','bad');return;}
    const category_id=Number($('#team-called-recycle-category').value||0),limit=Math.max(0,Number($('#team-called-recycle-limit').value)||0),deadline_days=Math.max(1,Number($('#team-called-recycle-days').value)||7);
    if(!category_id){toast('Chọn một phân loại đã gọi xong.','bad');return;}
    const name=$('#team-called-recycle-category').selectedOptions[0]?.textContent||'phân loại';
    if(!confirm(`Chia lại Data đã gọi của ${name}?\n\nKhách Lead đã ký / giải ngân sẽ tự động bị loại.`))return;
    try{const r=await API.request('/warehouse/recycle',{method:'POST',body:JSON.stringify({category_id,limit,deadline_days})});await refreshCustomersOnly();renderTeamleadData(main);toast(`Đã mở vòng mới và chia lại ${r.updated} Data. Lead đã ký được tự loại.`);}catch(err){toast(err.message,'bad')}
  };
}

function renderImport(main){
  if(state.session.user.role==='teamlead'){renderTeamleadData(main);return;}
  if(!['admin','sup'].includes(state.session.user.role)){main.innerHTML='<div class="empty">Bạn không có quyền truy cập Dữ liệu / Kho Data.</div>';return;}
  const role=state.session.user.role, pool=warehouseRowsBase('POOL'), assigned=warehouseRowsBase('ASSIGNED'), archivedAll=warehouseRowsBase('ARCHIVED'), archived=warehouseRows('ARCHIVED');
  const allowedSales=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||Number(u.team_id)===Number(state.session.user.team_id)));
  const allowedTeams=state.teamObjects.filter(t=>(role==='admin'||role==='sup')||Number(t.id)===Number(state.session.user.team_id));
  main.innerHTML=`${pageHead('Kho dữ liệu','Admin xem tổng toàn hệ thống. Mỗi Teamlead chỉ nhìn thấy Kho Data của Team mình.')}
  <div class="warehouse-kpis"><button class="warehouse-kpi ${state.warehouseView==='POOL'?'active':''}" data-wh-view="POOL"><strong>${pool.length}</strong><span>Kho chờ phân</span></button><button class="warehouse-kpi ${state.warehouseView==='ASSIGNED'?'active':''}" data-wh-view="ASSIGNED"><strong>${assigned.length}</strong><span>Đang giao</span></button><button class="warehouse-kpi ${state.warehouseView==='ARCHIVED'?'active':''}" data-wh-view="ARCHIVED"><strong>${archivedAll.length}</strong><span>Đã gọi / lưu trữ</span></button></div>
  <div class="grid-2 warehouse-panels"><div class="card"><div class="card-head"><h3>1. Nhập Data vào Kho</h3></div><div class="card-body"><p class="muted">Tên nguồn sẽ tự trở thành <strong>Phân loại Data</strong>. Chọn Kho chung Admin hoặc đẩy thẳng vào Kho riêng của một Team. Hệ thống lọc trùng SĐT trước khi nhập.</p><div class="form-grid import-source-grid"><div class="form-field"><label>Tên nguồn / Phân loại Data</label><input id="warehouse-source" list="admin-category-suggestions" value="${esc(warehouseImportSource)}" placeholder="Chọn phân loại cũ hoặc nhập phân loại mới…" autocomplete="off"><datalist id="admin-category-suggestions">${(state.dataCategories||[]).map(c=>`<option value="${esc(c.name)}"></option>`).join('')}</datalist></div><div class="form-field"><label>Kho nhận Data</label><select id="warehouse-target-team"><option value="">Kho chung Admin</option>${state.teamObjects.map(t=>`<option value="${t.id}">Kho ${esc(t.name)}</option>`).join('')}</select></div></div><input type="file" accept=".xlsx,.xls,.csv" id="file-input"><div class="import-actions"><button class="btn" id="preview-import">Đọc & kiểm tra</button><button class="btn primary" id="upload-import" disabled>Đẩy vào Kho</button><button class="btn" id="import-export">⬇ Xuất Excel</button></div><div id="import-progress" class="import-progress"></div></div></div>
  <div class="card"><div class="card-head"><h3>2. Chia Data từ Kho</h3></div><div class="card-body"><div class="form-grid"><div class="form-field"><label>Cách chia</label><select id="wh-mode"><option value="all">Chia đều toàn bộ nhân viên</option><option value="team">Chia đều 1 Team</option><option value="user">Gán cho 1 nhân viên</option></select></div><div class="form-field"><label>Số lượng</label><input id="wh-limit" type="number" min="0" value="0" placeholder="0 = tất cả"></div><div class="form-field"><label>Thời hạn gọi (ngày)</label><input id="wh-deadline-days" type="number" min="0" max="365" value="7" placeholder="0 = không giới hạn"></div><div class="form-field"><label>Chỉ chia phân loại</label><select id="wh-category"><option value="">Tất cả Data trong Kho</option>${(state.dataCategories||[]).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></div><div class="form-field full" id="wh-target-wrap"></div></div><div class="call-actions"><button class="btn primary" id="wh-distribute">Chia Data trong Kho</button></div><div id="admin-bulk-job-status">${bulkJobProgressMarkup(state.bulkDistributionJob)}</div><div class="notice"><strong>Deadline:</strong> hết thời hạn, Data chưa gọi sẽ tự trả về Kho. <strong>Job lớn:</strong> tiến độ được lưu trong D1 và Cloudflare tiếp tục xử lý nền nếu trình duyệt đóng.</div></div></div></div>
  <div id="import-preview"></div>
  <div class="card daily-card"><div class="card-head"><h3>${state.warehouseView==='ARCHIVED'?'Đã gọi / lưu trữ':'Kho dữ liệu hiện tại'}</h3><span class="muted">${state.warehouseView==='ARCHIVED'?`${archived.length}/${archivedAll.length} khách theo bộ lọc`:'Bấm 3 ô phía trên để đổi trạng thái'}</span></div>${state.warehouseView==='ARCHIVED'?`<div class="archive-filters"><div class="team-tabs"><button class="team-tab ${!state.warehouseTeamFilter?'active':''}" data-archive-team="">Tất cả Team <span>${archivedAll.length}</span></button>${allowedTeams.map(t=>{const n=archivedAll.filter(c=>Number(c.team_id)===Number(t.id)).length;return `<button class="team-tab ${String(state.warehouseTeamFilter)===String(t.id)?'active':''}" data-archive-team="${t.id}">${esc(t.name)} <span>${n}</span></button>`}).join('')}</div><div class="archive-status-row"><label>Trạng thái cuộc gọi <select id="archive-status"><option value="">Tất cả trạng thái</option>${Object.entries(STATUS_LABELS).filter(([k])=>k!=='NEW').map(([k,v])=>`<option value="${k}" ${state.warehouseStatusFilter===k?'selected':''}>${esc(v)}</option>`).join('')}</select></label></div></div>`:''}<div id="warehouse-table">${renderWarehouseTable(warehouseRows())}</div></div>
  <div class="danger-zone"><div><h3>↩ Thu hồi Data đã chia về Kho</h3><p>Chỉ thu hồi Data đang giao / đã gọi khỏi danh sách nhân viên. <strong>Không xóa khách hàng trong Kho, không xóa lịch sử cuộc gọi, không ảnh hưởng Team và KPI.</strong> Data thu hồi có thể chia lại.</p></div><div class="reset-controls">${(role==='admin'||role==='sup')?`<select id="reset-team"><option value="">Toàn bộ hệ thống</option>${state.teamObjects.map(t=>`<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select>`:`<input type="hidden" id="reset-team" value="${state.session.user.team_id}"><span class="team-chip">${esc(state.session.user.team||'Team của bạn')}</span>`}<input id="reset-confirm" placeholder="Nhập THU HOI DATA"><button class="btn danger" id="reset-data">Thu hồi về Kho</button></div></div>`;
  const renderTarget=()=>{const mode=$('#wh-mode').value;const wrap=$('#wh-target-wrap');if(mode==='team')wrap.innerHTML=`<label>Team nhận Data</label><select id="wh-target">${allowedTeams.map(t=>`<option value="${t.id}">${esc(t.name)} (${allowedSales.filter(u=>Number(u.team_id)===Number(t.id)).length} Sale)</option>`).join('')}</select>`;else if(mode==='user')wrap.innerHTML=`<label>Nhân viên nhận Data</label><select id="wh-target">${allowedTeams.map(t=>`<optgroup label="${esc(t.name)}">${allowedSales.filter(u=>Number(u.team_id)===Number(t.id)).map(u=>`<option value="${u.id}">${esc(u.display_name)}</option>`).join('')}</optgroup>`).join('')}</select>`;else wrap.innerHTML='<div class="notice">Sẽ chia vòng tròn cho toàn bộ Sale đang hoạt động.</div>';};
  $('#wh-mode').onchange=renderTarget;renderTarget();
  $$('[data-wh-view]').forEach(b=>b.onclick=()=>{state.warehouseView=b.dataset.whView;renderImport(main)});
  $$('[data-archive-team]').forEach(b=>b.onclick=()=>{state.warehouseTeamFilter=b.dataset.archiveTeam;renderImport(main)});
  if($('#archive-status')) $('#archive-status').onchange=e=>{state.warehouseStatusFilter=e.target.value;renderImport(main)};
  $('#warehouse-source').oninput=e=>{warehouseImportSource=e.target.value;if(importPreview.length){importPreview=importPreview.map(x=>({...x,source:warehouseImportSource}));renderImportPreview();}};
  if($('#warehouse-target-team')) $('#warehouse-target-team').onchange=()=>{importPreview=[];importRaw=[];$('#import-preview').innerHTML='';$('#import-progress').textContent='Đã đổi Kho nhận Data. Hãy bấm Đọc & kiểm tra lại để lọc trùng đúng phạm vi Team.';$('#upload-import').disabled=true;};
  $('#file-input').onchange=()=>{importPreview=[];importRaw=[];$('#import-preview').innerHTML='';$('#import-progress').textContent='';$('#upload-import').disabled=true;};
  $('#preview-import').onclick=async()=>{
    const sourceName=$('#warehouse-source').value.trim();warehouseImportSource=sourceName;
    if(!sourceName){toast('Nhập tên nguồn / phân loại Data trước.','bad');$('#warehouse-source').focus();return;}
    const f=$('#file-input').files[0];if(!f){toast('Chọn file trước.','bad');return;}
    try{
      const targetTeam=$('#warehouse-target-team')?.value?Number($('#warehouse-target-team').value):null;
      $('#upload-import').disabled=true;$('#import-progress').textContent=targetTeam?'Đang đối chiếu SĐT trong đúng Kho Team đã chọn...':'Đang đối chiếu SĐT với Kho chung / toàn CRM...';
      importRaw=await readImportFile(f);importPreview=await checkImportDuplicates(applyWarehouseImport(importRaw,sourceName),targetTeam);
      const stats=importPreviewStats();$('#import-progress').textContent=`Đã kiểm tra ${importPreview.length} dòng · ${stats.valid} mới · ${stats.old} trùng dữ liệu cũ · ${stats.file} trùng trong file · ${stats.missing} thiếu SĐT.`;
      renderImportPreview();
    }catch(err){toast(err.message,'bad');$('#import-progress').textContent='Kiểm tra thất bại, chưa thể nhập Data.';importPreview=[];$('#upload-import').disabled=true;}
  };
  $('#upload-import').onclick=async()=>{
    if(state.mode!=='d1'){toast('Cần D1 Online để import.','bad');return;}
    const sourceName=$('#warehouse-source').value.trim();warehouseImportSource=sourceName;
    if(!sourceName){toast('Nhập tên nguồn / phân loại Data trước.','bad');$('#warehouse-source').focus();return;}
    const stats=importPreviewStats(), clean=importPreview.filter(x=>!x.importDuplicate).map(x=>({...x,source:sourceName}));
    if(!clean.length){toast('Không có Data mới để nhập.','bad');return;}
    if(!confirm(`Đã lọc trùng: ${stats.valid} Data mới, ${stats.old} trùng Kho/Data cũ, ${stats.file} trùng trong file, ${stats.missing} thiếu SĐT. Chỉ đưa ${clean.length} Data mới vào Kho?`))return;
    try{
      $('#upload-import').disabled=true;let inserted=0,skipped=0,newCategory=null;
      const targetTeam=$('#warehouse-target-team')?.value?Number($('#warehouse-target-team').value):null;
      for(let i=0;i<clean.length;i+=250){
        const batch=clean.slice(i,i+250);const r=await bulkApiRetry('/customers/import',{method:'POST',body:JSON.stringify({items:batch,to_warehouse:true,source_name:sourceName,target_team_id:targetTeam})});
        inserted+=r.inserted||0;skipped+=r.skipped||0;if(r.category)newCategory=r.category;$('#import-progress').textContent=`Đang tải ${Math.min(i+batch.length,clean.length)}/${clean.length}...`;
      }
      if(newCategory&&!state.dataCategories.some(c=>Number(c.id)===Number(newCategory.id)))state.dataCategories.push({...newCategory,active:1});
      await refreshCustomersOnly();importRaw=[];importPreview=[];warehouseImportSource='';state.warehouseView='POOL';renderImport(main);
      const targetName=targetTeam?(state.teamObjects.find(t=>Number(t.id)===targetTeam)?.name||'Team'):'Kho chung Admin';
      toast(`Đã thêm ${inserted} Data vào ${targetName} · phân loại “${sourceName}”; bỏ qua ${stats.old+stats.file+stats.missing+skipped} Data trùng/không hợp lệ.`);
    }catch(err){toast(err.message,'bad');$('#upload-import').disabled=false;}
  };
  $('#wh-distribute').onclick=async()=>{if(state.mode!=='d1'){toast('Cần D1 Online.','bad');return;}const mode=$('#wh-mode').value,limit=Math.max(0,Number($('#wh-limit').value)||0),deadline_days=Math.max(0,Number($('#wh-deadline-days').value)||0),category_id=$('#wh-category').value?Number($('#wh-category').value):null;const body={mode,deadline_days,category_id};if(mode==='team')body.team_id=Number($('#wh-target').value);if(mode==='user')body.user_id=Number($('#wh-target').value);const btn=$('#wh-distribute');try{const r=await distributeWarehouseBatched(body,limit,btn);state.warehouseView='ASSIGNED';invalidateWarehousePending();renderImport(main);toast(r.pending?`Job đang tiếp tục chạy nền: ${r.updated}/${r.job?.total_count||0} Data.`:`Đã chia ${r.updated} khách cho ${r.recipients} nhân viên.`,r.pending?'bad':'ok');}catch(err){renderImport(main);toast(err.message,'bad')}};
  $('#import-export').onclick=exportCsv;
  $('#reset-data').onclick=async()=>{
    const confirmText=$('#reset-confirm').value.trim();
    if(confirmText!=='THU HOI DATA'){toast('Nhập đúng THU HOI DATA để xác nhận.','bad');return;}
    const teamId=$('#reset-team').value?Number($('#reset-team').value):null;
    if(!confirm('Xác nhận THU HỒI Data đã giao về Kho? Không xóa khách hoặc lịch sử cuộc gọi. Nhân viên sẽ mất quyền truy cập những khách đã thu hồi.'))return;
    try{
      const r=await API.request('/data/reset',{method:'POST',body:JSON.stringify({confirm:'THU HOI DATA',team_id:teamId})});
      await refreshCustomersOnly();state.warehouseView='POOL';renderImport(main);toast(`Đã thu hồi ${r.recalled} khách về Kho; giữ nguyên khách và lịch sử gọi.`);
    }catch(err){toast(err.message,'bad');}
  };
}
// V5.7: lightweight per-employee pending data, fetched only for overview.
function invalidateWarehousePending(){
  state.staffPending=null;state.staffPendingAt=0;state.staffDetail=null;state.staffSelected='';state.staffOffset=0;
}
function maybeLoadWarehousePending(renderPage){
  if(state.mode!=='d1'||state.staffPendingLoading) return;
  if((state.staffPending || state.staffPendingError) && Date.now()-state.staffPendingAt<120000) return;
  state.staffPendingLoading=true;state.staffPendingError='';
  const requestUser=state.session?.user?.id;
  API.request('/warehouse/staff-pending').then(r=>{
    if(state.session?.user?.id!==requestUser)return;
    state.staffPending=r.items||[];state.staffPendingAt=Date.now();
  }).catch(e=>{if(state.session?.user?.id===requestUser){state.staffPendingError=e.message||'Không tải được số liệu';state.staffPendingAt=Date.now();}}).finally(()=>{
    state.staffPendingLoading=false;
    if(!state.session?.user || state.session.user.id!==requestUser)return;
    if(state.page==='warehouseAdmin'&&state.warehouseSection==='overview') renderWarehouseAdmin($('#main'));
    if(state.page==='import'&&state.session.user.role==='teamlead') renderTeamleadData($('#main'));
  });
}
async function loadWarehousePendingDetails(employeeId,kind='all',offset=0){
  if(state.staffDetailLoading||state.mode!=='d1') return;
  state.staffSelected=String(employeeId);state.staffKind=kind;state.staffOffset=offset;
  state.staffDetailLoading=true;state.staffDetail=null;
  const el=$('#staff-pending-detail');if(el)el.innerHTML='<div class="warehouse-pending-loading">Đang tải danh sách khách chưa gọi…</div>';
  try{
    const r=await API.request(`/warehouse/staff-pending/${encodeURIComponent(employeeId)}?kind=${encodeURIComponent(kind)}&offset=${offset}`);
    // Discard an obsolete response after switching the selected employee.
    if(state.staffSelected===String(employeeId)&&state.staffKind===kind&&state.staffOffset===offset)state.staffDetail=r;
  }catch(e){state.staffDetail={items:[],error:e.message||'Không thể tải danh sách'};}
  finally{state.staffDetailLoading=false;renderWarehousePendingDetail();}
}
function renderWarehousePendingDetail(){
  const el=$('#staff-pending-detail');if(!el)return;
  if(!state.staffSelected){el.innerHTML='';return;}
  if(state.staffDetailLoading){el.innerHTML='<div class="warehouse-pending-loading">Đang tải danh sách khách chưa gọi…</div>';return;}
  const d=state.staffDetail||{}, selected=(state.staffPending||[]).find(x=>String(x.user_id)===String(state.staffSelected));
  const rows=(d.items||[]).map(c=>`<tr><td><strong>${esc(c.name||'Chưa rõ')}</strong><div class="muted">${esc(c.phone||'')}</div></td><td>${c.status==='NEW'?'<span class="status new">Data mới</span>':statusPill(c.status)}</td><td>${esc(c.source||'—')}</td><td>${c.assignment_deadline?shortDate(String(c.assignment_deadline).slice(0,10)):'Không giới hạn'}</td><td>${Number(c.assignment_round||0)}</td></tr>`).join('')||'<tr><td colspan="5"><div class="empty small-empty">Không có khách phù hợp.</div></td></tr>';
  const kinds=[['all','Tất cả'],['new','Data mới (NEW)'],['recall','Chờ gọi lại']];
  el.innerHTML=`<div class="staff-detail-title"><div><strong>Data còn phải gọi — ${esc(selected?.display_name||d.employee||'Nhân viên')}</strong><p class="muted">Đây là những khách đang được giao để gọi; lượt gọi cũ vẫn được giữ nguyên.</p></div><button class="btn small" id="staff-pending-close">Đóng ✕</button></div>
  <div class="staff-detail-filters">${kinds.map(([k,label])=>`<button class="btn small ${state.staffKind===k?'primary':''}" data-staff-kind="${k}">${label}</button>`).join('')}</div>
  ${d.error?`<p class="warehouse-error">${esc(d.error)}</p>`:`<div class="table-wrap"><table class="data-table staff-detail-table"><thead><tr><th>Khách hàng / SĐT</th><th>Trạng thái trước đó</th><th>Nguồn</th><th>Hạn gọi</th><th>Vòng</th></tr></thead><tbody>${rows}</tbody></table></div>`}
  <div class="staff-pagination"><span class="muted">Hiển thị ${state.staffOffset+1}–${state.staffOffset+(d.items||[]).length} ${d.has_more?'(còn dữ liệu tiếp)':''}</span><div class="actions"><button class="btn small" id="staff-prev" ${state.staffOffset<=0?'disabled':''}>← Trước</button><button class="btn small" id="staff-next" ${!d.has_more?'disabled':''}>Sau →</button></div></div>`;
  $('#staff-pending-close').onclick=()=>{state.staffSelected='';state.staffDetail=null;renderWarehousePendingDetail()};
  $$('[data-staff-kind]',el).forEach(b=>b.onclick=()=>loadWarehousePendingDetails(state.staffSelected,b.dataset.staffKind,0));
  $('#staff-prev').onclick=()=>loadWarehousePendingDetails(state.staffSelected,state.staffKind,Math.max(0,state.staffOffset-100));
  $('#staff-next').onclick=()=>loadWarehousePendingDetails(state.staffSelected,state.staffKind,state.staffOffset+100);
}
function warehousePendingMarkup(){
  const staff=state.staffPending||[], total=staff.reduce((n,u)=>n+Number(u.pending_count||0),0), fresh=staff.reduce((n,u)=>n+Number(u.new_count||0),0), recall=staff.reduce((n,u)=>n+Number(u.recall_count||0),0), active=staff.filter(u=>Number(u.pending_count||0)>0).length;
  const opts=[...new Map(staff.filter(u=>u.team_id).map(u=>[String(u.team_id),u.team])).entries()];
  const q=String(state.staffSearch||'').trim().toLocaleLowerCase('vi');
  const filtered=staff.filter(u=>(!state.staffTeamFilter||String(u.team_id)===state.staffTeamFilter)&&(!q||String(u.display_name).toLocaleLowerCase('vi').includes(q)||String(u.team||'').toLocaleLowerCase('vi').includes(q)));
  const body=filtered.map(u=>`<tr class="staff-pending-row ${state.staffSelected===String(u.user_id)?'highlighted':''}"><td><strong>${esc(u.display_name)}</strong></td><td>${esc(u.team||'—')}</td><td class="num">${Number(u.new_count||0)}</td><td class="num">${Number(u.recall_count||0)}</td><td class="num"><strong class="pending-number">${Number(u.pending_count||0)}</strong></td><td><button class="btn small" data-staff-open="${Number(u.user_id)}" ${Number(u.pending_count||0)===0?'disabled':''}>Xem khách →</button></td></tr>`).join('')||'<tr><td colspan="6"><div class="empty small-empty">Không có nhân viên phù hợp.</div></td></tr>';
  return `<div class="warehouse-mini-stats"><div class="warehouse-mini-stat"><span>Data còn cần gọi</span><strong>${total}</strong></div><div class="warehouse-mini-stat"><span>Data mới (NEW)</span><strong>${fresh}</strong></div><div class="warehouse-mini-stat"><span>Được giao gọi lại</span><strong>${recall}</strong></div><div class="warehouse-mini-stat"><span>Nhân viên còn Data</span><strong>${active}/${staff.length}</strong></div></div>
  <div class="card staff-pending-card"><div class="card-head"><div><h3>Data chưa gọi theo nhân viên</h3><span class="muted">Theo lượt phân công hiện tại · Đang giao = còn phải gọi, kể cả khách N02/Y03 chuyển sang nhân viên khác</span></div><button class="btn small" id="staff-pending-refresh" ${state.staffPendingLoading?'disabled':''}>↻ Làm mới</button></div>
  <div class="card-body"><div class="staff-filter-bar"><label>Tìm nhân viên<input id="staff-pending-search" placeholder="Nhập tên nhân viên…" value="${esc(state.staffSearch)}"></label>${['admin','sup'].includes(state.session.user.role)?`<label>Team<select id="staff-pending-team"><option value="">Tất cả Team</option>${opts.map(([id,name])=>`<option value="${esc(id)}" ${state.staffTeamFilter===id?'selected':''}>${esc(name)}</option>`).join('')}</select></label>`:''}</div>
  ${state.staffPendingError?`<p class="warehouse-error">${esc(state.staffPendingError)}</p>`:''}
  ${!state.staffPending?(state.staffPendingError?'<div class="warehouse-pending-loading">Hãy bấm Làm mới để thử lại.</div>':'<div class="warehouse-pending-loading">Đang tổng hợp Data nhân viên từ D1…</div>'):`<div class="table-wrap"><table class="data-table staff-pending-table"><thead><tr><th>Nhân viên</th><th>Team</th><th>Data mới</th><th>Gọi lại</th><th>Còn phải gọi</th><th>Chi tiết</th></tr></thead><tbody>${body}</tbody></table></div>`}
  <div id="staff-pending-detail"></div></div></div>`;
}
function bindWarehousePendingOverview(main,rerender){
  maybeLoadWarehousePending(rerender);
  const sr=$('#staff-pending-search'); if(sr) sr.oninput=e=>{state.staffSearch=e.target.value;const caret=e.target.selectionStart;rerender(main);const next=$('#staff-pending-search');next?.focus();try{next?.setSelectionRange(caret,caret)}catch{}};
  const team=$('#staff-pending-team');if(team)team.onchange=e=>{state.staffTeamFilter=e.target.value;rerender(main)};
  const refresh=$('#staff-pending-refresh');if(refresh)refresh.onclick=()=>{state.staffPendingAt=0;maybeLoadWarehousePending(rerender)};
  $$('[data-staff-open]').forEach(b=>b.onclick=()=>loadWarehousePendingDetails(b.dataset.staffOpen,state.staffSelected===b.dataset.staffOpen?state.staffKind:'all',0));
  if(state.staffSelected && state.staffDetail)renderWarehousePendingDetail();
}
function warehouseCategoryRows(ignoreCallStatus=false){
  let rows=state.session.user.role==='teamlead'?[...visibleCustomers()]:[...state.customers];
  if(state.categoryTab==='uncategorized') rows=rows.filter(c=>!c.data_category_id);
  else if(state.categoryTab) rows=rows.filter(c=>String(c.data_category_id)===String(state.categoryTab));
  if(state.categoryStateFilter==='UNCALLED') rows=rows.filter(c=>(c.data_state||'POOL')!=='ARCHIVED');
  else if(state.categoryStateFilter) rows=rows.filter(c=>(c.data_state||'POOL')===state.categoryStateFilter);
  if(!ignoreCallStatus && state.categoryCallStatusFilter) rows=rows.filter(c=>String(c.status||'NEW').toUpperCase()===state.categoryCallStatusFilter);
  const q=String(state.categorySearch||'').trim().toLowerCase();
  if(q) rows=rows.filter(c=>[c.name,c.phone,c.owner,c.team,c.data_category,c.source].some(v=>String(v||'').toLowerCase().includes(q)));
  return rows;
}
function daysLeft(deadline){
  if(!deadline) return '';
  const a=new Date(todayISO()+'T12:00:00'), b=new Date(String(deadline).slice(0,10)+'T12:00:00');
  return Math.ceil((b-a)/86400000);
}
function renderWarehouseAdmin(main){
  const role=state.session.user.role,isLead=role==='teamlead';
  if(!['admin','sup','teamlead'].includes(role)){main.innerHTML='<div class="empty">Không có quyền truy cập Kho.</div>';return;}
  // V7.2: Data & phân loại bổ sung tổng Data theo từng nhân viên (đã gọi + chưa gọi), tính tại client từ dữ liệu Kho đã tải.
  if(isLead){renderTeamleadData(main);return;}
  const section=['categories','staff','recall','recycle','transfer'].includes(state.warehouseSection)?state.warehouseSection:'categories';
  const whAll=isLead?[...visibleCustomers()]:[...state.customers];
  const teamCategoryIds=new Set(whAll.map(c=>Number(c.data_category_id||0)).filter(Boolean));
  const cats=(state.dataCategories||[]).filter(c=>!isLead||teamCategoryIds.has(Number(c.id))), rows=section==='categories'?warehouseCategoryRows():[], analytics=(state.warehouseAnalytics||[]).filter(a=>!isLead||teamCategoryIds.has(Number(a.id)));
  const statusUniverse=section==='categories'?warehouseCategoryRows(true):[];
  const statusCount=Object.fromEntries(Object.keys(STATUS_LABELS).map(key=>[key,statusUniverse.filter(c=>String(c.status||'NEW').toUpperCase()===key).length]));
  // Never bulk-categorize clients hidden by an active filter.
  const eligibleIds=new Set(rows.map(c=>Number(c.id)));
  const selected=new Set((state.categorySelectedIds||[]).map(Number).filter(id=>eligibleIds.has(id)));
  state.categorySelectedIds=[...selected];
  const visibleRows=rows.slice(0,500);
  const allSelected=visibleRows.length>0&&visibleRows.every(c=>selected.has(Number(c.id)));
  const statusOptions=Object.keys(STATUS_LABELS).map(k=>`<option value="${k}" ${state.categoryCallStatusFilter===k?'selected':''}>${esc(STATUS_LABELS[k])} (${statusCount[k]||0})</option>`).join('');
  const statusQuickFilters=['Y01','Y02','Y03','Y04','Y05','Y06','N01','N02','N03','N04'].filter(k=>statusCount[k]>0);
  const statusChips=`<div class="warehouse-callstatus-chips"><span class="muted">Lọc nhanh:</span><button type="button" class="warehouse-status-chip ${!state.categoryCallStatusFilter?'active':''}" data-cat-call-chip="">Tất cả (${statusUniverse.length})</button>${statusQuickFilters.map(k=>`<button type="button" class="warehouse-status-chip ${state.categoryCallStatusFilter===k?'active':''}" data-cat-call-chip="${k}" title="${esc(STATUS_LABELS[k])}">${k} <strong>${statusCount[k]}</strong></button>`).join('')}</div>`;
  const categoryTabs=`<div class="team-tabs category-tabs"><button class="team-tab ${!state.categoryTab?'active':''}" data-cat-tab="">Tất cả <span>${whAll.length}</span></button><button class="team-tab ${state.categoryTab==='uncategorized'?'active':''}" data-cat-tab="uncategorized">Chưa phân loại <span>${whAll.filter(c=>!c.data_category_id).length}</span></button>${cats.map(c=>`<button class="team-tab ${String(state.categoryTab)===String(c.id)?'active':''}" data-cat-tab="${c.id}">${esc(c.name)} <span>${whAll.filter(x=>Number(x.data_category_id)===Number(c.id)).length}</span></button>`).join('')}</div>`;
  const analyticsRows=analytics.map(a=>`<tr><td><strong>${esc(a.name)}</strong></td><td class="num">${a.total_data||0}</td><td class="num">${a.pool_count||0}</td><td class="num">${a.assigned_count||0}</td><td class="num">${a.archived_count||0}</td><td class="num">${a.lead_count||0}</td><td class="num signed-excluded">${a.signed_leads||0}</td><td class="num"><strong>${a.recyclable_count||0}</strong></td><td class="num">${a.calls||0}</td><td class="num"><strong>${a.connect_rate||0}%</strong></td><td>Vòng ${a.max_round||0}</td></tr>`).join('')||'<tr><td colspan="11"><div class="empty small-empty">Chưa có phân loại Data.</div></td></tr>';
  const roundList=[...(state.warehouseRoundAnalytics||[])].sort((a,b)=>String(a.category_name||'').localeCompare(String(b.category_name||''),'vi')||Number(a.round_no)-Number(b.round_no));
  const previousRate=new Map();
  const roundRows=roundList.map(a=>{const key=String(a.category_id||a.category_name||'none'),prev=previousRate.get(key),rate=Number(a.connect_rate||0),delta=prev===undefined?null:rate-prev;previousRate.set(key,rate);return `<tr><td><strong>${esc(a.category_name||'Chưa phân loại')}</strong></td><td>Vòng ${a.round_no||0}</td><td class="num">${a.assigned_data||0}</td><td class="num">${a.calls||0}</td><td class="num"><strong>${rate}%</strong></td><td class="num">${a.y01||0}</td><td class="num">${a.y02||0}</td><td>${delta===null?'<span class="muted">Vòng đầu</span>':`<span class="round-delta ${delta>0?'up':delta<0?'down':'flat'}">${delta>0?'▲ +':delta<0?'▼ ':''}${delta}%</span>`}</td><td class="num">${a.expired_returns||0}</td></tr>`}).join('')||'<tr><td colspan="9"><div class="empty small-empty">Chưa có vòng phân Data để đo lường.</div></td></tr>';
  const bodyRows=visibleRows.map(c=>{const left=daysLeft(c.assignment_deadline);return `<tr><td><input type="checkbox" data-cat-select="${c.id}" ${selected.has(Number(c.id))?'checked':''}></td><td><strong>${esc(c.name)}</strong><div class="muted">${esc(c.phone||'')}</div></td><td>${esc(c.data_category||'Chưa phân loại')}</td><td>${esc(c.team||'—')}</td><td>${esc(c.owner||'—')}</td><td>${c.status&&c.status!=='NEW'?statusPill(c.status):'<span class="muted">Chưa gọi</span>'}</td><td>${c.data_state==='ARCHIVED'?'Đã gọi':c.data_state==='ASSIGNED'?'Đang giao':'Trong kho'}</td><td>${c.assignment_deadline?`${shortDate(String(c.assignment_deadline).slice(0,10))}${left>=0?` <span class="muted">(${left} ngày)</span>`:''}`:'—'}</td><td>${Number(c.assignment_round||0)}</td></tr>`}).join('')||'<tr><td colspan="9"><div class="empty">Không có Data phù hợp.</div></td></tr>';
  const sections=[['categories','🏷 Data & phân loại'],['staff','👥 Data nhân viên'],['recall','↩ Thu hồi Data'],['recycle','🎲 Random & chất lượng'],['transfer','↔ Chuyển Data']];
  const allDataCount=whAll.length, uncalledDataCount=whAll.filter(c=>warehouseState(c)!=='ARCHIVED').length, calledDataCount=whAll.filter(c=>warehouseState(c)==='ARCHIVED').length;
  const warehouseStaff=state.users.filter(u=>u.role==='sale'&&Number(u.active)!==0);
  const employeeTotalsCard=warehouseEmployeeTotalsMarkup(whAll,warehouseStaff,'Tổng Data theo nhân viên','Tổng Data hiện thuộc từng Sale, gồm cả Data chưa gọi và Data đã gọi. Tính trực tiếp từ dữ liệu Kho đã tải, không phát sinh thêm truy vấn D1.');
  main.innerHTML=`${pageHead(isLead?'Kho Data Team': 'Kho dữ liệu toàn hệ thống',isLead?`Kho riêng của ${esc(state.session.user.team||'Team bạn')}: tổng quan, chuyển Data, phân loại, random và thống kê đều chỉ tính trong Team.`:'Admin quản lý Kho tổng toàn hệ thống, xem và phân bổ Data theo từng Team, phân loại và vòng gọi.',`<button class="btn" id="expire-now">↩ Thu hồi Data hết hạn</button>${section==='categories'?'<button class="btn primary" id="warehouse-go-import">📥 Đẩy Data mới</button>':''}${section==='categories'&&!isLead?'<button class="btn primary" id="new-category">+ Phân loại mới</button>':''}`)}
  <nav class="warehouse-section-tabs" aria-label="Chức năng Kho">${sections.map(([id,label])=>`<button type="button" class="warehouse-section-tab ${section===id?'active':''}" data-wh-section="${id}" aria-current="${section===id?'page':'false'}">${label}</button>`).join('')}</nav>
  ${section==='transfer'?`<div class="warehouse-section-intro"><h3>Chuyển Data giữa nhân viên</h3><p>Chọn nhân viên nguồn, trạng thái và người nhận. Lịch sử gọi vẫn được giữ nguyên.</p></div>`:''}
  ${section==='recall'?`<div class="warehouse-section-intro"><h3>Thu hồi Data về Kho</h3><p>Chọn một nhân viên cụ thể, lọc theo trạng thái hoặc thu hồi toàn bộ Data người đó đang giữ.</p></div>`:''}
  ${section==='staff'?`<div class="warehouse-section-intro"><h3>Data theo nhân viên</h3><p>Tổng hợp Data đang thuộc từng Sale: tổng, chưa gọi, đã gọi và tiến độ. Tính từ dữ liệu Kho đã tải, không phát sinh query D1 riêng.</p></div>`:''}
  ${section==='categories'?`  <div class="card category-manager"><div class="card-head"><div><h3>Phân loại Data</h3><span class="muted">${isLead?'Chỉ hiển thị và quản lý Data thuộc Team của bạn.':'Data loại 1, Data loại 2… có thể đổi tên bất kỳ lúc nào.'}</span></div>${!isLead&&state.categoryTab&&state.categoryTab!=='uncategorized'?`<div class="actions"><button class="btn" id="rename-category">Đổi tên</button><button class="btn danger" id="delete-category">Xoá phân loại</button></div>`:''}</div><div class="card-body">${categoryTabs}</div></div>`: ''}
  ${section==='transfer'?`  ${transferDataCard()}`: ''}
  ${section==='recall'?`  ${recallDataCard()}`: ''}
  ${section==='recycle'?`  <div class="grid-2 warehouse-admin-panels" id="warehouse-recycle-section"><div class="card"><div class="card-head"><div><h3>🎲 Random lại Data theo phân loại</h3><span class="muted">Chỉ lấy Data đã gọi. Lead đã ký hồ sơ / giải ngân được tự động loại khỏi random.</span></div></div><div class="card-body"><div class="form-grid"><div class="form-field"><label>Phân loại muốn random</label><select id="recycle-category"><option value="">Chọn phân loại đã gọi xong…</option>${cats.map(c=>{const a=analytics.find(x=>Number(x.id)===Number(c.id));const pending=a?Number(a.pool_count||0)+Number(a.assigned_count||0):null,ready=!!a&&pending===0&&Number(a.archived_count||0)>0;const suffix=!a?' · đang tải số liệu':ready?` · sẵn sàng ${a.recyclable_count||0}`:` · còn ${pending||0} chưa xong`;return `<option value="${c.id}" ${ready?'':'disabled'}>${esc(c.name)}${suffix}</option>`}).join('')}</select></div><div class="form-field"><label>Phạm vi nhân viên</label>${isLead?`<select id="recycle-team" disabled><option value="${Number(state.session.user.team_id||0)}">${esc(state.session.user.team||'Team của bạn')}</option></select>`:`<select id="recycle-team"><option value="">Toàn bộ Sale</option>${state.teamObjects.map(t=>`<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select>`}</div><div class="form-field"><label>Số lượng</label><input id="recycle-limit" type="number" min="0" value="0" placeholder="0 = tất cả đủ điều kiện"></div><div class="form-field"><label>Được gọi trong (ngày)</label><input id="recycle-days" type="number" min="1" max="365" value="7"></div><div class="form-field full"><div class="recycle-preview" id="recycle-preview"></div></div></div><div class="call-actions"><button class="btn primary" id="recycle-data">🎲 Random Data đủ điều kiện</button></div><div class="notice"><strong>Tự loại khách đã ký:</strong> bất kỳ Lead nào từng đạt trạng thái “KH ký hồ sơ / giải ngân” sẽ không được đưa vào vòng random tiếp theo.</div></div></div>
  <div class="card"><div class="card-head"><div><h3>Chất lượng theo phân loại</h3><span class="muted">Biết Lead nào đã ký và số Data thực tế còn có thể random.</span></div></div><div class="card-body"><div class="table-wrap"><table class="data-table analytics-table warehouse-quality-table"><thead><tr><th>Phân loại</th><th>Tổng</th><th>Trong kho</th><th>Đang giao</th><th>Đã gọi</th><th>Lead</th><th>Đã ký / loại</th><th>Có thể random</th><th>Calls</th><th>Kết nối</th><th>Vòng</th></tr></thead><tbody>${analyticsRows}</tbody></table></div></div></div></div>`: ''}
  ${section==='staff'?employeeTotalsCard:''}
  ${section==='categories'?`  <div class="card warehouse-control-card"><div class="card-head"><div><h3>Phân loại Data đã chọn</h3><span class="muted">Tích chọn từng khách ở bảng bên dưới để đổi phân loại, không phân loại toàn bộ Kho.</span></div></div><div class="card-body"><div class="toolbar compact"><input id="cat-search" class="search" placeholder="Tìm tên, SĐT, nguồn, nhân viên…" value="${esc(state.categorySearch)}"><select id="cat-state"><option value="">Tất cả Data</option><option value="UNCALLED" ${state.categoryStateFilter==='UNCALLED'?'selected':''}>Chưa gọi (Trong kho + Đang giao)</option><option value="ARCHIVED" ${state.categoryStateFilter==='ARCHIVED'?'selected':''}>Đã gọi</option><option value="POOL" ${state.categoryStateFilter==='POOL'?'selected':''}>Chỉ trong kho</option><option value="ASSIGNED" ${state.categoryStateFilter==='ASSIGNED'?'selected':''}>Chỉ đang giao</option></select><select id="cat-call-status" aria-label="Lọc trạng thái cuộc gọi"><option value="">Tất cả trạng thái gọi (${statusUniverse.length})</option>${statusOptions}</select><select id="bulk-category"><option value="">Chọn phân loại…</option>${cats.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select><button class="btn primary" id="assign-category">Phân loại Data đã chọn</button><button class="btn" id="remove-category-data">Bỏ phân loại Data đã chọn</button></div>${statusChips}<p class="muted warehouse-status-help"><strong>Data chưa gọi</strong> gồm Data trong kho và Data đang giao chưa hoàn tất lượt gọi. <strong>Data đã gọi</strong> là Data đã hoàn tất lượt gọi hiện tại. Đổi phân loại không làm mất người phụ trách, trạng thái hay lịch sử gọi.</p></div></div>`: ''}
  ${section==='categories'?`  <div class="card daily-card"><div class="card-head"><h3>Danh sách Data</h3><span class="muted">Hiển thị ${Math.min(rows.length,500)}/${rows.length} Data · Checkbox đầu bảng chỉ chọn các Data đang hiển thị để xử lý từng nhóm đã chọn</span></div><div class="table-wrap"><table class="data-table warehouse-admin-table"><thead><tr><th><input type="checkbox" id="cat-select-all" ${allSelected?'checked':''}></th><th>Khách hàng</th><th>Phân loại</th><th>Team</th><th>Nhân viên</th><th>Trạng thái gọi</th><th>Kho</th><th>Deadline</th><th>Vòng gọi</th></tr></thead><tbody>${bodyRows}</tbody></table></div></div>`: ''}
  ${section==='recycle'?`  <div class="card daily-card"><div class="card-head"><h3>Hiệu quả theo vòng gọi</h3><span class="muted">So sánh sau mỗi lần random/tái phân Data</span></div><div class="table-wrap"><table class="data-table analytics-table"><thead><tr><th>Phân loại</th><th>Vòng</th><th>Data giao</th><th>Calls</th><th>Kết nối</th><th>Y01</th><th>Y02</th><th>So với vòng trước</th><th>Hết hạn trả kho</th></tr></thead><tbody>${roundRows}</tbody></table></div></div>`: ''}`;
  $$('[data-wh-section]').forEach(b=>b.onclick=()=>{state.warehouseSection=b.dataset.whSection;state.categorySelectedIds=[];renderWarehouseAdmin(main)});
  if($('#warehouse-go-import'))$('#warehouse-go-import').onclick=()=>navigate('import');

  if(section==='recycle' && state.mode==='d1' && !state.whAnalyticsLoading && (!state.lastWarehouseAnalyticsRefresh || Date.now()-state.lastWarehouseAnalyticsRefresh>120000)){
    state.whAnalyticsLoading=true;
    Promise.all([API.request('/warehouse/analytics'),API.request('/warehouse/round-analytics')])
      .then(([a,b])=>{state.warehouseAnalytics=a.items||[];state.warehouseRoundAnalytics=b.items||[];state.lastWarehouseAnalyticsRefresh=Date.now()})
      .catch(e=>{state.lastWarehouseAnalyticsRefresh=Date.now();toast('Không tải được thống kê Kho: '+e.message,'bad')})
      .finally(()=>{state.whAnalyticsLoading=false;if(state.page==='warehouseAdmin'&&state.warehouseSection==='recycle')renderWarehouseAdmin($('#main'))});
  }
  bindTransferDataCard(main,renderWarehouseAdmin);
  bindRecallDataCard(main,renderWarehouseAdmin);
  $$('[data-cat-tab]').forEach(b=>b.onclick=()=>{state.categoryTab=b.dataset.catTab;state.categorySelectedIds=[];renderWarehouseAdmin(main)});
  if($('#cat-search')) $('#cat-search').onchange=e=>{state.categorySearch=e.target.value;state.categorySelectedIds=[];renderWarehouseAdmin(main)};
  if($('#cat-state')) $('#cat-state').onchange=e=>{state.categoryStateFilter=e.target.value;state.categorySelectedIds=[];renderWarehouseAdmin(main)};
  if($('#cat-call-status')) $('#cat-call-status').onchange=e=>{state.categoryCallStatusFilter=e.target.value;state.categorySelectedIds=[];renderWarehouseAdmin(main)};
  $$('[data-cat-call-chip]').forEach(b=>b.onclick=()=>{state.categoryCallStatusFilter=b.dataset.catCallChip;state.categorySelectedIds=[];renderWarehouseAdmin(main)});
  $$('[data-cat-select]').forEach(cb=>cb.onchange=()=>{const id=Number(cb.dataset.catSelect),set=new Set((state.categorySelectedIds||[]).map(Number));cb.checked?set.add(id):set.delete(id);state.categorySelectedIds=[...set];renderWarehouseAdmin(main)});
  if($('#cat-select-all')) $('#cat-select-all').onchange=e=>{const set=new Set((state.categorySelectedIds||[]).map(Number));visibleRows.forEach(c=>e.target.checked?set.add(Number(c.id)):set.delete(Number(c.id)));state.categorySelectedIds=[...set];renderWarehouseAdmin(main)};
  $$('[data-bulk-scope]').forEach(b=>b.onclick=()=>{const hidden=$('#bulk-scope-value');if(!hidden)return;hidden.value=b.dataset.bulkScope;$$('[data-bulk-scope]').forEach(x=>x.classList.toggle('active',x===b));const count=b.dataset.bulkScope==='called'?calledDataCount:b.dataset.bulkScope==='uncalled'?uncalledDataCount:allDataCount;const a=$('#assign-scope'),c=$('#clear-scope');if(a){a.disabled=count===0;a.textContent=`Phân loại ${count} Data`;}if(c){c.disabled=count===0;c.textContent=`Bỏ phân loại ${count} Data`;}});
  if($('#assign-scope')) $('#assign-scope').onclick=async()=>{const scope=$('#bulk-scope-value')?.value||'',category_id=Number($('#bulk-scope-category')?.value||0);if(!scope){toast('Hãy chọn Tất cả Data, Data chưa gọi hoặc Data đã gọi.','bad');return;}if(!category_id){toast('Hãy chọn phân loại đích.','bad');return;}const count=scope==='called'?calledDataCount:scope==='uncalled'?uncalledDataCount:allDataCount;if(!count)return;if(!confirm(`Phân loại toàn bộ ${count} Data trong phạm vi đã chọn vào “${$('#bulk-scope-category').selectedOptions[0]?.textContent||''}”?

Người phụ trách, trạng thái và lịch sử gọi vẫn được giữ nguyên.`))return;try{const r=await API.request('/warehouse/categories/assign-scope',{method:'POST',body:JSON.stringify({scope,category_id})});state.categorySelectedIds=[];await refreshCustomersOnly();renderWarehouseAdmin(main);toast(`Đã phân loại ${r.updated||0} Data.`)}catch(err){toast(err.message,'bad')}};
  if($('#clear-scope')) $('#clear-scope').onclick=async()=>{const scope=$('#bulk-scope-value')?.value||'';if(!scope){toast('Hãy chọn phạm vi Data trước.','bad');return;}const count=scope==='called'?calledDataCount:scope==='uncalled'?uncalledDataCount:allDataCount;if(!count)return;if(!confirm(`Bỏ phân loại của toàn bộ ${count} Data trong phạm vi đã chọn?`))return;try{const r=await API.request('/warehouse/categories/assign-scope',{method:'POST',body:JSON.stringify({scope,category_id:null})});state.categorySelectedIds=[];await refreshCustomersOnly();renderWarehouseAdmin(main);toast(`Đã bỏ phân loại ${r.updated||0} Data.`)}catch(err){toast(err.message,'bad')}};
  if($('#new-category')) $('#new-category').onclick=()=>{openAdminModal('Tạo phân loại Data',`<form id="cat-create-form" class="form-grid"><div class="form-field full"><label>Tên phân loại</label><input id="cat-create-name" placeholder="Ví dụ: Data tiềm năng" required></div><div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="cat-create-cancel">Huỷ</button><button class="btn primary">Tạo phân loại</button></div></div></form>`); $('#cat-create-cancel').onclick=closeAdminModal; $('#cat-create-form').onsubmit=async e=>{e.preventDefault();try{await API.request('/data-categories',{method:'POST',body:JSON.stringify({name:$('#cat-create-name').value})});closeAdminModal();await syncFromApi();invalidateWarehousePending();renderWarehouseAdmin(main);toast('Đã tạo phân loại.')}catch(err){toast(err.message,'bad')}};};
  if($('#rename-category')) $('#rename-category').onclick=async()=>{const c=cats.find(x=>String(x.id)===String(state.categoryTab));if(!c)return;const name=prompt('Tên mới cho phân loại',c.name);if(!name||name.trim()===c.name)return;try{await API.request(`/data-categories/${c.id}`,{method:'PATCH',body:JSON.stringify({name:name.trim()})});await syncFromApi();invalidateWarehousePending();renderWarehouseAdmin(main);toast('Đã đổi tên phân loại.')}catch(err){toast(err.message,'bad')}};
  if($('#delete-category')) $('#delete-category').onclick=async()=>{const c=cats.find(x=>String(x.id)===String(state.categoryTab));if(!c||!confirm(`Xoá phân loại “${c.name}”? Data bên trong sẽ chuyển thành Chưa phân loại.`))return;try{await API.request(`/data-categories/${c.id}`,{method:'DELETE'});state.categoryTab='';await syncFromApi();invalidateWarehousePending();renderWarehouseAdmin(main);toast('Đã xoá phân loại.')}catch(err){toast(err.message,'bad')}};
  if($('#assign-category')) $('#assign-category').onclick=async()=>{const ids=state.categorySelectedIds||[],category_id=$('#bulk-category').value;if(!ids.length){toast('Hãy chọn Data trước.','bad');return;}if(!category_id){toast('Hãy chọn phân loại.','bad');return;}if(!confirm(`Chuyển ${ids.length} Data đã chọn vào phân loại “${$('#bulk-category').selectedOptions[0]?.textContent||''}”? Trạng thái và lịch sử cuộc gọi sẽ được giữ nguyên.`))return;try{await API.request('/warehouse/categories/assign',{method:'POST',body:JSON.stringify({customer_ids:ids,category_id:Number(category_id)})});state.categorySelectedIds=[];await syncFromApi();invalidateWarehousePending();renderWarehouseAdmin(main);toast(`Đã phân loại ${ids.length} Data.`)}catch(err){toast(err.message,'bad')}};
  if($('#remove-category-data')) $('#remove-category-data').onclick=async()=>{const ids=state.categorySelectedIds||[];if(!ids.length){toast('Hãy chọn Data trước.','bad');return;}try{await API.request('/warehouse/categories/assign',{method:'POST',body:JSON.stringify({customer_ids:ids,category_id:null})});state.categorySelectedIds=[];await syncFromApi();invalidateWarehousePending();renderWarehouseAdmin(main);toast(`Đã bỏ ${ids.length} Data khỏi phân loại.`)}catch(err){toast(err.message,'bad')}};
  $('#expire-now').onclick=async()=>{try{const r=await API.request('/warehouse/expire-now',{method:'POST',body:'{}'});await syncFromApi();invalidateWarehousePending();renderWarehouseAdmin(main);toast(r.returned?`Đã thu hồi ${r.returned} Data hết hạn.`:'Không có Data hết hạn.')}catch(err){toast(err.message,'bad')}};
  const refreshRecyclePreview=()=>{const el=$('#recycle-preview');if(!el)return;const id=Number($('#recycle-category')?.value||0);if(!id){el.innerHTML='<span class="muted">Chọn một phân loại đã gọi xong để xem số Data đủ điều kiện random.</span>';return;}const rows=analytics.filter(a=>Number(a.id)===id),sum=k=>rows.reduce((n,a)=>n+Number(a[k]||0),0);el.innerHTML=analytics.length?`<div><span>Đã gọi</span><strong>${sum('archived_count')}</strong></div><div><span>Lead Y01/Y02</span><strong>${sum('lead_count')}</strong></div><div class="exclude"><span>Đã ký · loại khỏi random</span><strong>${sum('signed_leads')}</strong></div><div class="eligible"><span>Có thể random</span><strong>${sum('recyclable_count')}</strong></div>`:'<span class="muted">Đang tải số liệu phân loại…</span>';};
  if($('#recycle-category')){$('#recycle-category').onchange=refreshRecyclePreview;refreshRecyclePreview();}
  if($('#recycle-data')) $('#recycle-data').onclick=async()=>{const categoryId=Number($('#recycle-category').value||0);if(!categoryId){toast('Hãy chọn một phân loại đã gọi xong để random.','bad');return;}const body={category_id:categoryId,team_id:$('#recycle-team').value?Number($('#recycle-team').value):null,limit:Math.max(0,Number($('#recycle-limit').value)||0),deadline_days:Math.max(1,Number($('#recycle-days').value)||7)};if(!confirm('Random Data đã gọi đủ điều kiện cho nhân viên khác và mở vòng gọi mới?\n\nKhách Lead đã ký hồ sơ/giải ngân sẽ tự động bị loại.'))return;try{const r=await API.request('/warehouse/recycle',{method:'POST',body:JSON.stringify(body)});await refreshCustomersOnly();state.lastWarehouseAnalyticsRefresh=0;invalidateWarehousePending();renderWarehouseAdmin(main);toast(`Đã random lại ${r.updated} Data; khách đã ký được loại tự động.`)}catch(err){toast(err.message,'bad')}};
}

function stopChatPolling(){
  if(state.chatPollTimer) clearInterval(state.chatPollTimer);
  state.chatPollTimer=null;
}
function chatRoleLabel(role,staffType){return staffRoleLabel({role,staff_type:staffType});}
async function loadChatContacts(force=false){
  if(state.mode!=='d1'){
    state.chatContacts=[];state.chatError='Chat nội bộ chỉ hoạt động khi kết nối D1 Online.';state.chatContactsAt=Date.now();return;
  }
  if(state.chatContactsLoading)return;
  if(!force&&state.chatContactsAt&&Date.now()-state.chatContactsAt<120000)return;
  state.chatContactsLoading=true;state.chatError='';
  try{
    const r=await API.request('/chat/contacts');state.chatContacts=r.items||[];state.chatContactsAt=Date.now();
    if(state.chatSelectedUserId&&!state.chatContacts.some(u=>String(u.id)===String(state.chatSelectedUserId))){state.chatSelectedUserId='';state.chatMessages=[];}
  }catch(e){state.chatError=e.message||'Không tải được danh sách chat.';}
  finally{state.chatContactsLoading=false;}
}
async function loadChatMessages(mode='initial'){
  if(state.mode!=='d1'||!state.chatSelectedUserId||state.chatLoading)return;
  state.chatLoading=true;
  try{
    const p=new URLSearchParams({user_id:String(state.chatSelectedUserId),limit:'60'});
    if(mode==='older'&&state.chatOldestId)p.set('before_id',String(state.chatOldestId));
    if(mode==='newer'&&state.chatNewestId)p.set('after_id',String(state.chatNewestId));
    const r=await API.request('/chat/messages?'+p.toString()),items=r.items||[];
    if(mode==='initial') state.chatMessages=items;
    else if(mode==='older') state.chatMessages=[...items,...state.chatMessages];
    else if(mode==='newer'){
      const seen=new Set(state.chatMessages.map(x=>Number(x.id)));
      state.chatMessages.push(...items.filter(x=>!seen.has(Number(x.id))));
    }
    state.chatMessages.sort((a,b)=>Number(a.id)-Number(b.id));
    state.chatOldestId=state.chatMessages.length?Number(state.chatMessages[0].id):0;
    state.chatNewestId=state.chatMessages.length?Number(state.chatMessages[state.chatMessages.length-1].id):0;
    if(mode==='initial'||mode==='older') state.chatHasOlder=!!r.has_more;
    return items.length;
  }catch(e){toast(e.message,'bad');return 0;}
  finally{state.chatLoading=false;}
}
async function openChatConversation(userId){
  stopChatPolling();state.chatSelectedUserId=String(userId);state.chatMessages=[];state.chatOldestId=0;state.chatNewestId=0;state.chatHasOlder=false;
  await loadChatMessages('initial');
  if(state.page==='chat')renderChat($('#main'),true);
  startChatPolling();
}
function startChatPolling(){
  stopChatPolling();
  if(state.mode!=='d1'||state.page!=='chat'||!state.chatSelectedUserId)return;
  state.chatPollTimer=setInterval(async()=>{
    if(document.hidden||state.page!=='chat'||!state.chatSelectedUserId)return;
    const n=await loadChatMessages('newer');
    if(n&&state.page==='chat')renderChat($('#main'),true);
  },30000);
}
function renderChat(main,scrollBottom=false){
  if(!state.chatContactsAt&&!state.chatContactsLoading){
    loadChatContacts().then(()=>{if(state.page==='chat')renderChat($('#main'))});
  }
  const q=String(state.chatContactSearch||'').trim().toLocaleLowerCase('vi');
  const contacts=(state.chatContacts||[]);
  const selected=contacts.find(u=>String(u.id)===String(state.chatSelectedUserId));
  const contactRows=contacts.map(u=>{const hay=`${u.display_name||''} ${u.team||''} ${u.username||''}`.toLocaleLowerCase('vi'),match=!q||hay.includes(q);return `<button type="button" class="chat-contact ${String(u.id)===String(state.chatSelectedUserId)?'active':''}" data-chat-user="${u.id}" data-chat-search="${esc(hay)}" ${match?'':'hidden'}><span class="chat-avatar">${esc(initials(u.display_name))}</span><span class="chat-contact-copy"><strong>${esc(u.display_name)}</strong><small>${esc(chatRoleLabel(u.role,u.staff_type))}${u.team?` · ${esc(u.team)}`:''}</small></span></button>`}).join('')||`<div class="empty small-empty">${state.chatContactsLoading?'Đang tải danh sách…':'Không có tài khoản phù hợp.'}</div>`;
  const messages=state.chatMessages.map(m=>{const mine=Number(m.sender_user_id)===Number(state.session.user.id);return `<div class="chat-message-row ${mine?'mine':'theirs'}"><div class="chat-bubble"><div class="chat-message-text">${esc(m.message).replace(/\n/g,'<br>')}</div><small>${esc(mine?'Bạn':m.sender_name||selected?.display_name||'')} · ${fmtDate(m.created_at)}</small></div></div>`}).join('')||'<div class="chat-empty-thread">Chưa có tin nhắn. Bạn có thể bắt đầu cuộc trò chuyện.</div>';
  main.innerHTML=`${pageHead('Chat nội bộ','Trao đổi đúng phạm vi: Teamlead ↔ nhân viên trong Team; Admin ↔ tất cả tài khoản.')}
  <div class="chat-layout">
    <aside class="chat-contacts-panel"><div class="chat-panel-head"><div><h3>Người có thể chat</h3><span class="muted">${state.chatContacts.length} liên hệ</span></div><button class="btn small" id="chat-refresh-contacts" title="Làm mới danh sách">↻</button></div><div class="chat-search"><input id="chat-contact-search" placeholder="Tìm tên hoặc Team…" value="${esc(state.chatContactSearch)}"></div><div class="empty small-empty chat-search-empty" id="chat-search-empty" ${contacts.some(u=>!q||`${u.display_name||''} ${u.team||''} ${u.username||''}`.toLocaleLowerCase('vi').includes(q))?'hidden':''}>Không có tài khoản phù hợp.</div>${state.chatError?`<div class="warehouse-error">${esc(state.chatError)}</div>`:''}<div class="chat-contact-list">${contactRows}</div></aside>
    <section class="chat-thread-panel">${selected?`<div class="chat-thread-head"><div class="chat-thread-person"><span class="chat-avatar large">${esc(initials(selected.display_name))}</span><div><h3>${esc(selected.display_name)}</h3><span>${esc(chatRoleLabel(selected.role,selected.staff_type))}${selected.team?` · ${esc(selected.team)}`:''}</span></div></div><button class="btn small" id="chat-refresh-thread">↻ Làm mới</button></div>
      <div class="chat-history-tools">${state.chatHasOlder?'<button class="btn small" id="chat-load-older">↑ Tải tin cũ hơn</button>':'<span class="muted">Đang hiển thị lịch sử gần nhất</span>'}</div>
      <div class="chat-messages" id="chat-messages">${state.chatLoading&& !state.chatMessages.length?'<div class="chat-empty-thread">Đang tải tin nhắn…</div>':messages}</div>
      <form class="chat-compose" id="chat-compose"><textarea id="chat-message-input" rows="2" maxlength="2000" placeholder="Nhập tin nhắn… (Enter để gửi, Shift+Enter xuống dòng)"></textarea><button class="btn primary" type="submit">Gửi</button></form>
      <div class="chat-write-note">Tin nhắn chỉ được ghi khi bấm Gửi. Không có read-receipt để tránh Rows written không cần thiết.</div>`:`<div class="chat-no-selection"><div class="chat-no-selection-icon">💬</div><h3>Chọn một người để chat</h3><p>${['admin','sup'].includes(state.session.user.role)?'Admin có thể chat với mọi tài khoản đang hoạt động.':state.session.user.role==='teamlead'?'Bạn có thể chat với nhân viên trong Team và Admin.':'Bạn có thể chat với Teamlead của Team và Admin.'}</p></div>`}</section>
  </div>`;
  $('#chat-refresh-contacts').onclick=async()=>{state.chatContactsAt=0;await loadChatContacts(true);if(state.page==='chat')renderChat(main)};
  $('#chat-contact-search').oninput=e=>{state.chatContactSearch=e.target.value;const query=String(e.target.value||'').trim().toLocaleLowerCase('vi');let shown=0;$$('[data-chat-user]',main).forEach(b=>{const match=!query||String(b.dataset.chatSearch||'').includes(query);b.hidden=!match;if(match)shown++;});const empty=$('#chat-search-empty',main);if(empty)empty.hidden=shown>0;};
  $$('[data-chat-user]').forEach(b=>b.onclick=()=>openChatConversation(b.dataset.chatUser));
  if(selected){
    $('#chat-refresh-thread').onclick=async()=>{await loadChatMessages('newer');renderChat(main,true)};
    if($('#chat-load-older'))$('#chat-load-older').onclick=async()=>{await loadChatMessages('older');renderChat(main,false)};
    $('#chat-compose').onsubmit=async e=>{e.preventDefault();const input=$('#chat-message-input'),message=input.value.trim();if(!message)return;const btn=$('#chat-compose button');btn.disabled=true;try{const r=await API.request('/chat/messages',{method:'POST',body:JSON.stringify({recipient_user_id:Number(state.chatSelectedUserId),message})});if(r.item){state.chatMessages.push(r.item);state.chatMessages.sort((a,b)=>Number(a.id)-Number(b.id));state.chatNewestId=Number(r.item.id)||state.chatNewestId;state.chatOldestId=state.chatOldestId||Number(r.item.id)||0;}renderChat(main,true);}catch(err){btn.disabled=false;toast(err.message,'bad')}};
    const input=$('#chat-message-input');if(input)input.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('#chat-compose').requestSubmit();}};
    requestAnimationFrame(()=>{const box=$('#chat-messages');if(box&&scrollBottom)box.scrollTop=box.scrollHeight;});
    startChatPolling();
  }else stopChatPolling();
}


const AUDIT_ACTION_LABELS={
  TEAM_CREATE:'Tạo Team',TEAM_DELETE:'Xóa Team',USER_CREATE:'Tạo tài khoản',USER_UPDATE:'Cập nhật tài khoản',USER_DELETE:'Xóa tài khoản',
  CUSTOMER_IMPORT:'Import dữ liệu',CUSTOMER_UPDATE:'Cập nhật khách hàng',WAREHOUSE_DISTRIBUTE:'Phân bổ Data',WAREHOUSE_TRANSFER:'Chuyển Data',WAREHOUSE_RECYCLE:'Tái phân Data',DATA_RECALL:'Thu hồi Data',DATA_DISTRIBUTE:'Chia Data',
  KPI_SET:'Cập nhật KPI',KPI_BULK_SET:'Đặt KPI hàng loạt',CATEGORY_CREATE:'Tạo phân loại',CATEGORY_RENAME:'Đổi tên phân loại',CATEGORY_DELETE:'Xóa phân loại',CATEGORY_ASSIGN:'Gán phân loại',CATEGORY_ASSIGN_SCOPE:'Gán phân loại theo phạm vi',
  KHTN_CREATE:'Tạo KHTN',KHTN_UPDATE:'Cập nhật KHTN',KHTN_DELETE:'Xóa KHTN',KHTN_CONFIG_UPDATE:'Cập nhật cấu hình KHTN',DAILY_REPORT_SAVE:'Lưu báo cáo đầu ngày',DEADLINE_SWEEP:'Thu hồi Data quá hạn'
};
async function loadAuditLogs(force=false){
  if(!['admin','sup'].includes(state.session?.user?.role))return;
  if(state.mode!=='d1'){state.auditLogs=[];state.auditLoadedAt=Date.now();return;}
  if(state.auditLoading||(!force&&state.auditLoadedAt&&Date.now()-state.auditLoadedAt<30000))return;
  state.auditLoading=true;
  try{const r=await API.request('/audit-logs?limit=350');state.auditLogs=r.items||[];state.auditLoadedAt=Date.now();}
  catch(err){toast(err.message,'bad');}
  finally{state.auditLoading=false;}
}
function auditDetailText(raw){
  if(!raw)return '—';
  try{
    const obj=typeof raw==='string'?JSON.parse(raw):raw;
    const text=Object.entries(obj||{}).slice(0,8).map(([k,v])=>`${k}: ${typeof v==='object'?JSON.stringify(v):v}`).join(' · ');
    return text.length>260?text.slice(0,257)+'…':text||'—';
  }catch{return String(raw).slice(0,260);}
}
function renderAuditLogs(main){
  if(!['admin','sup'].includes(state.session.user.role)){main.innerHTML='<div class="empty">Chỉ Admin được xem nhật ký thao tác.</div>';return;}
  if(!state.auditLoadedAt&&!state.auditLoading){loadAuditLogs().then(()=>{if(state.page==='audit')renderAuditLogs(main)});}
  const q=normalizeGlobalSearch(state.auditSearch),action=state.auditActionFilter;
  const source=state.auditLogs||[];
  const actions=[...new Set(source.map(x=>x.action).filter(Boolean))].sort();
  const rows=source.filter(x=>(!action||x.action===action)&&(!q||normalizeGlobalSearch(`${x.display_name} ${x.username} ${x.action} ${x.entity_type} ${x.entity_id} ${x.detail}`).includes(q)));
  const body=rows.map(x=>`<tr><td>${esc(fmtDate(x.created_at))}</td><td><strong>${esc(x.display_name||'—')}</strong><div class="muted">${esc(x.username||'')}</div></td><td><span class="status new">${esc(AUDIT_ACTION_LABELS[x.action]||x.action||'—')}</span></td><td>${esc(x.entity_type||'—')}${x.entity_id?` #${esc(x.entity_id)}`:''}</td><td class="audit-detail">${esc(auditDetailText(x.detail))}</td></tr>`).join('');
  main.innerHTML=`${pageHead('Nhật ký thao tác','Lịch sử các thay đổi quan trọng đã được backend ghi vào audit_logs.',`<button class="btn" id="audit-refresh">↻ Làm mới</button>`)}
    <div class="toolbar audit-toolbar"><input class="search" id="audit-search" placeholder="Tìm người thao tác, hành động, đối tượng…" value="${esc(state.auditSearch)}"><select id="audit-action"><option value="">Tất cả hành động</option>${actions.map(a=>`<option value="${esc(a)}" ${a===action?'selected':''}>${esc(AUDIT_ACTION_LABELS[a]||a)}</option>`).join('')}</select><span class="muted">${rows.length}/${source.length} bản ghi gần nhất</span></div>
    ${state.mode!=='d1'?'<div class="notice warning">Nhật ký thao tác chỉ có dữ liệu khi hệ thống kết nối backend D1. Chế độ Demo Local không tạo audit log giả.</div>':''}
    <div class="table-wrap"><table class="data-table audit-table"><thead><tr><th>Thời gian</th><th>Người thao tác</th><th>Hành động</th><th>Đối tượng</th><th>Chi tiết thay đổi</th></tr></thead><tbody>${body||`<tr><td colspan="5"><div class="empty">${state.auditLoading?'Đang tải nhật ký…':'Chưa có bản ghi phù hợp.'}</div></td></tr>`}</tbody></table></div>`;
  const search=$('#audit-search');if(search)search.oninput=e=>{state.auditSearch=e.target.value;renderAuditLogs(main)};
  const filter=$('#audit-action');if(filter)filter.onchange=e=>{state.auditActionFilter=e.target.value;renderAuditLogs(main)};
  const refresh=$('#audit-refresh');if(refresh)refresh.onclick=async()=>{state.auditLoadedAt=0;await loadAuditLogs(true);renderAuditLogs(main)};
}

function renderSettings(main){
  if(state.session.user.role!=='admin'){main.innerHTML='<div class="empty">Chỉ Admin được truy cập Cài đặt.</div>';return;}
  main.innerHTML=`${pageHead('Cài đặt','Cấu hình trạng thái, Team và hệ thống.')}
  <div class="grid-2"><div class="card"><div class="card-head"><h3>Trạng thái cuộc gọi</h3></div><div class="card-body">${Object.entries(STATUS_LABELS).map(([k,v])=>`<div style="padding:7px 0;border-bottom:1px solid #eee"><strong>${k}</strong> · ${esc(v)}</div>`).join('')}</div></div><div class="card"><div class="card-head"><h3>Team</h3></div><div class="card-body">${state.teams.map(t=>`<div style="padding:9px 0;border-bottom:1px solid #eee">${esc(t)}</div>`).join('')}<div class="notice">Phân quyền backend hiện có: <strong>Admin / Team Leader / Sales / Freelancer</strong>. Không hiển thị role chưa được backend hỗ trợ.</div></div></div></div>`;
}

async function distributeData(){
  if(!['admin','sup'].includes(state.session.user.role)){toast('Chỉ Admin được chia Data.','bad');return;}
  const unassigned=state.customers.filter(c=>!c.team||!c.owner);if(!unassigned.length){toast('Không có Data chưa phân trong bản demo.');return;}
  if(state.mode==='d1'){try{const r=await API.request('/distribute',{method:'POST',body:JSON.stringify({})});toast(`Đã chia ${r.updated} khách.`);await syncFromApi();renderCRM($('#main'));}catch(e){toast(e.message,'bad')}}
}
function exportCsv(){
  const items=visibleCustomers();
  const rows=items.map((c,i)=>({
    'STT':i+1,
    'Mã khách hàng':c.code||'',
    'Họ tên khách hàng':c.name||'',
    'Số điện thoại':String(c.phone||''),
    'Nguồn Data':c.source||'',
    'Team':c.team||'',
    'Nhân viên phụ trách':c.owner||'',
    'Trạng thái':STATUS_LABELS[c.status]||c.status||'',
    'Lịch hẹn gọi lại':c.follow_up||'',
    'Ghi chú':c.note||''
  }));
  if(typeof XLSX==='undefined'){toast('Thư viện Excel chưa sẵn sàng.','bad');return;}
  const headers=['STT','Mã khách hàng','Họ tên khách hàng','Số điện thoại','Nguồn Data','Team','Nhân viên phụ trách','Trạng thái','Lịch hẹn gọi lại','Ghi chú'];
  const wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(rows,{header:headers});
  ws['!cols']=[{wch:7},{wch:16},{wch:28},{wch:17},{wch:16},{wch:18},{wch:25},{wch:28},{wch:21},{wch:42}];
  for(let r=2;r<=rows.length+1;r++){const a=XLSX.utils.encode_cell({r:r-1,c:3});if(ws[a]){ws[a].t='s';ws[a].v=String(ws[a].v??'');ws[a].z='@';}}
  ws['!autofilter']={ref:`A1:J${Math.max(1,rows.length+1)}`};
  XLSX.utils.book_append_sheet(wb,ws,'Data khách hàng');
  XLSX.writeFile(wb,`call-center-crm-data-${todayISO()}.xlsx`);
  toast(`Đã xuất ${items.length} khách hàng ra Excel.`);
}



/* =====================================================================
   V8.0 PREMIUM CALL CENTER CRM — UI layer
   Giữ nguyên API/D1/logic dữ liệu của V7.14, thay shell và các màn hình lõi.
   ===================================================================== */
function premiumRoleLabel(role,staffType){return staffRoleLabel({role,staff_type:staffType});}
function premiumPageTitle(page,role){
  const titles={dashboard:'Bảng điều khiển',callcenter:'Call Center',customerdb:'Cơ sở dữ liệu khách hàng',lead:'Quản lý Lead',callhistory:'Lịch sử cuộc gọi',followup:'Follow-up',teamManagement:'Quản lý nhóm',employeeManagement:'Quản lý nhân viên',kpi:'KPI & Hiệu suất',reports:'Báo cáo & Phân tích',io:'Nhập / Xuất dữ liệu',settings:'Cài đặt',chat:'Trao đổi nội bộ',warehouseAdmin:'Kho & Phân bổ',import:'Nhập dữ liệu',crm:'Lịch sử cuộc gọi',telesale:'Call Center',employees:'Quản lý nhân viên',audit:'Nhật ký thao tác',apps:'Tất cả chức năng'};
  return titles[page]||pageTitleForRole(page,role);
}
function allowedPagesForRole(role){
  const common=['apps','dashboard','callcenter','customerdb','lead','callhistory','followup','kpi','reports','crm','telesale','chat'];
  if((role==='admin'||role==='sup'))return new Set([...common,'teamManagement','employeeManagement','io','settings','warehouseAdmin','import','employees','audit']);
  if(role==='teamlead')return new Set([...common,'teamManagement','employeeManagement','io','warehouseAdmin','import','employees']);
  return new Set([...common]);
}
function premiumDateLabel(){
  const end=state.dashboardViewDate||todayISO(),start=addDays(end,-6);
  return `${shortDate(start)} - ${shortDate(end)}`;
}
function navigate(page){
  closeMobileSidebar();if(page!=='chat')stopChatPolling();
  const role=state.session?.user?.role||'sale';
  if(!allowedPagesForRole(role).has(page))page='dashboard';
  state.page=page;state.app=page==='apps'?null:page;
  $('#sidebar').classList.remove('hidden');
  const t=premiumPageTitle(page,role);$('#current-app-title').textContent=t;$('#breadcrumb').textContent='Trang chủ';
  const dl=$('#global-date-label');if(dl)dl.textContent=premiumDateLabel();
  renderSidebar(page);renderMobileBottomNav(page);render();
}
function premiumSidebarItems(role){
  if(role==='sale')return [
    ['dashboard','dashboard','Bảng điều khiển'],['callcenter','call','Call Center'],['customerdb','customers','Cơ sở dữ liệu khách hàng'],['lead','lead','Quản lý Lead'],['callhistory','call','Lịch sử cuộc gọi'],['followup','calendar','Follow-up'],['kpi','kpi','KPI & Hiệu suất'],['chat','chat','Trao đổi nội bộ']
  ];
  if(role==='teamlead')return [
    ['dashboard','dashboard','Bảng điều khiển'],['callcenter','call','Call Center'],['customerdb','customers','Cơ sở dữ liệu khách hàng'],['lead','lead','Quản lý Lead'],['callhistory','call','Lịch sử cuộc gọi'],['followup','calendar','Follow-up'],['teamManagement','users','Quản lý nhóm'],['employeeManagement','users','Quản lý nhân viên'],['kpi','kpi','KPI & Hiệu suất'],['reports','kpi','Báo cáo & Phân tích'],['io','import','Nhập / Xuất dữ liệu'],['warehouseAdmin','warehouse','Kho Data Team'],['chat','chat','Trao đổi nội bộ']
  ];
  return [
    ['dashboard','dashboard','Bảng điều khiển'],['callcenter','call','Call Center'],['customerdb','customers','Cơ sở dữ liệu khách hàng'],['lead','lead','Quản lý Lead'],['callhistory','call','Lịch sử cuộc gọi'],['followup','calendar','Follow-up'],['teamManagement','users','Quản lý nhóm'],['employeeManagement','users','Quản lý nhân viên'],['kpi','kpi','KPI & Hiệu suất'],['reports','kpi','Báo cáo & Phân tích'],['io','import','Nhập / Xuất dữ liệu'],['settings','settings','Cài đặt']
  ];
}
function renderSidebar(active){
  const u=state.session.user,role=u.role,items=premiumSidebarItems(role),splitIndex=6;
  const team=u.team&&u.team!=='Tất cả'?u.team:((role==='admin'||role==='sup')?'Toàn hệ thống':'Chưa gán Team');
  const rows=items.map((x,i)=>`${i===splitIndex?'<div class="sidebar-divider"></div><div class="sidebar-caption">Quản trị & Báo cáo</div>':''}<button class="menu-item ${x[0]===active?'active':''}" data-nav="${x[0]}"><span class="menu-item-icon">${uiIcon(x[1])}</span><span class="menu-item-label">${x[2]}</span></button>`).join('');
  $('#sidebar-menu').innerHTML=`<div class="sidebar-brand"><div class="sidebar-brand-mark">CC</div><div><strong>CALL CENTER <b>CRM</b></strong><span>${esc(team)}</span></div></div><div class="sidebar-nav-scroll">${rows}</div><div class="sidebar-profile"><div class="sidebar-profile-avatar">${esc(initials(u.display_name))}</div><div class="sidebar-profile-copy"><strong>${esc(u.display_name)}</strong><small>${esc(premiumRoleLabel(role,u.staff_type))}</small></div><span class="sidebar-profile-status"></span></div>`;
  $$('[data-nav]',$('#sidebar-menu')).forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
}
function render(){
  const main=$('#main');$('#app')?.classList.remove('dashboard-redesign');
  const role=state.session?.user?.role||'sale';
  const map={apps:renderApps,dashboard:renderDashboard,callcenter:renderTelesale,customerdb:renderCustomerDatabase,lead:renderLeads,callhistory:renderPremiumCallHistory,followup:renderFollowup,teamManagement:renderEmployees,employeeManagement:renderEmployees,kpi:renderKPI,reports:renderKPI,io:(role==='admin'||role==='sup')?renderImport:renderWarehouseAdmin,settings:renderSettings,chat:renderChat,warehouseAdmin:renderWarehouseAdmin,import:renderImport,crm:renderCRM,telesale:renderTelesale,employees:renderEmployees,audit:renderAuditLogs};
  (map[state.page]||renderDashboard)(main);
}
function premiumCustomer(id){return state.customers.find(c=>Number(c.id)===Number(id));}
function premiumScopeUsers(){
  const role=state.session.user.role,tid=state.session.user.team_id;
  return state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||(role==='teamlead'&&Number(u.team_id)===Number(tid))||(role==='sale'&&Number(u.id)===Number(state.session.user.id))));
}
function premiumScopeCalls(from,to){
  const users=premiumScopeUsers(),ids=new Set(users.map(u=>Number(u.id))),names=new Set(users.map(u=>u.display_name));
  return state.calls.filter(x=>{const d=dateKey(x.created_at);return d>=from&&d<=to&&(ids.has(Number(x.user_id))||(!x.user_id&&names.has(x.owner)));});
}
function premiumLineChart(rows){
  const w=720,h=205,p={l:42,r:12,t:16,b:31},iw=w-p.l-p.r,ih=h-p.t-p.b;
  const max=Math.max(1,...rows.flatMap(r=>[r.calls,r.connected]));const ceil=Math.max(10,Math.ceil(max/10)*10);
  const pt=(v,i)=>[p.l+(rows.length===1?iw/2:i*iw/(rows.length-1)),p.t+ih-(v/ceil)*ih];
  const poly=k=>rows.map((r,i)=>pt(r[k],i).map(n=>n.toFixed(1)).join(',')).join(' ');
  const grids=[0,.25,.5,.75,1].map((q,i)=>{const y=p.t+ih*q,val=Math.round(ceil*(1-q));return `<line class="crm-chart-grid" x1="${p.l}" y1="${y}" x2="${w-p.r}" y2="${y}"/><text class="crm-chart-axis" x="${p.l-8}" y="${y+3}" text-anchor="end">${val}</text>`}).join('');
  const labels=rows.map((r,i)=>{const [x]=pt(0,i);return `<text class="crm-chart-axis" x="${x}" y="${h-9}" text-anchor="middle">${esc(r.label)}</text>`}).join('');
  const dots=k=>rows.map((r,i)=>{const [x,y]=pt(r[k],i);return `<circle class="crm-dot-${k==='calls'?'total':'connect'}" cx="${x}" cy="${y}" r="3"/>`}).join('');
  return `<svg class="crm-line-chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">${grids}<polyline class="crm-line-total" points="${poly('calls')}"/><polyline class="crm-line-connect" points="${poly('connected')}"/>${dots('calls')}${dots('connected')}${labels}</svg><div class="crm-chart-legend"><span><i class="total"></i>Tổng cuộc gọi</span><span><i class="connect"></i>Cuộc gọi kết nối</span></div>`;
}
function premiumDonut(total,parts){
  const r=51,c=2*Math.PI*r;let offset=0;const palette=['#1677ff','#f2a51a','#1caf74','#e34b4b','#7f91a5'];
  const circles=parts.map((p,i)=>{const len=total?c*(p.value/total):0;const s=`<circle cx="70" cy="70" r="${r}" fill="none" stroke="${palette[i]}" stroke-width="18" stroke-dasharray="${len} ${c-len}" stroke-dashoffset="${-offset}" transform="rotate(-90 70 70)"/>`;offset+=len;return s}).join('');
  return `<svg class="crm-donut" viewBox="0 0 140 140"><circle cx="70" cy="70" r="51" fill="none" stroke="#eef2f6" stroke-width="18"/>${circles}<text class="total" x="70" y="68" text-anchor="middle">${total.toLocaleString('vi-VN')}</text><text class="caption" x="70" y="83" text-anchor="middle">Tổng cuộc gọi</text></svg>`;
}
function premiumStatusGroup(status){
  if(['Y02','Y05'].includes(status))return 'Gọi lại';if(status==='Y03')return 'Không quan tâm';if(status==='N02')return 'Không nghe máy';if(['N01','N03','N04'].includes(status))return 'Sai số';if(String(status).startsWith('Y'))return 'Kết nối';return 'Sai số';
}
function premiumRecentCalls(rows,limit=6){return [...rows].sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))||Number(b.id)-Number(a.id)).slice(0,limit);}
function renderDashboard(main){
  const date=state.dashboardViewDate||todayISO();state.dashboardViewDate=date;const from=addDays(date,-6);
  if(state.mode==='d1'&&!isCallsRangeLoaded(from,date)&&!state.dashboardRangeLoading){state.dashboardRangeLoading=true;main.innerHTML='<div class="empty">Đang tải dữ liệu Dashboard…</div>';ensureCallsRange(from,date).then(()=>{state.dashboardRangeLoading=false;if(state.page==='dashboard')renderDashboard(main)}).catch(e=>{state.dashboardRangeLoading=false;toast(e.message,'bad')});return;}
  const customers=visibleCustomers(),dayCalls=premiumScopeCalls(date,date),rangeCalls=premiumScopeCalls(from,date),latest=latestCallsByCustomer(dayCalls),connected=latest.filter(x=>String(x.status).startsWith('Y')).length;
  const followups=customers.filter(c=>dateKey(c.follow_up||'')===date).sort((a,b)=>String(a.follow_up).localeCompare(String(b.follow_up)));
  const trend=dateRange(from,date,7).map(d=>{const rows=premiumScopeCalls(d,d),l=latestCallsByCustomer(rows);return {date:d,label:shortDate(d),calls:rows.length,connected:l.filter(x=>String(x.status).startsWith('Y')).length}});
  const groups={Kết_nối:0,Không_nghe_máy:0,Gọi_lại:0,Không_quan_tâm:0,Sai_số:0};latest.forEach(x=>{const g=premiumStatusGroup(x.status).replaceAll(' ','_');groups[g]=(groups[g]||0)+1});
  const outcomeParts=[['Kết nối',groups.Kết_nối||0,'#1677ff'],['Không nghe máy',groups.Không_nghe_máy||0,'#f2a51a'],['Gọi lại',groups.Gọi_lại||0,'#1caf74'],['Không quan tâm',groups.Không_quan_tâm||0,'#e34b4b'],['Sai số',groups.Sai_số||0,'#7f91a5']].map(([name,value,color])=>({name,value,color}));
  const users=premiumScopeUsers();const perf=users.map(u=>{const calls=rangeCalls.filter(x=>Number(x.user_id)===Number(u.id)||(!x.user_id&&x.owner===u.display_name)),l=latestCallsByCustomer(calls),conn=l.filter(x=>String(x.status).startsWith('Y')).length,y01=l.filter(x=>x.status==='Y01').length,t=userKpiTarget(u.id),progress=Math.min(160,Math.round(calls.length/Math.max(1,Number(t.calls_daily||50)*7)*100));return {u,calls:calls.length,conn,conv:l.length?Math.round(y01/l.length*100):0,progress}}).sort((a,b)=>b.calls-a.calls).slice(0,6);
  const recent=premiumRecentCalls(rangeCalls,7);
  const prevFrom=addDays(from,-7),prevTo=addDays(date,-7),prevCalls=premiumScopeCalls(prevFrom,prevTo);const delta=prevCalls.length?Math.round((rangeCalls.length-prevCalls.length)/prevCalls.length*100):0;
  main.innerHTML=`<div class="crm-dashboard premium-page">
    <div class="premium-page-head"><div class="premium-page-title"><h1>Bảng điều khiển CRM</h1><p>Tổng quan hoạt động của An Đông 4</p></div><div class="premium-page-actions"><input class="crm-panel-tool" id="premium-dashboard-date" type="date" value="${esc(date)}"><button class="btn" id="premium-dashboard-today">Hôm nay</button></div></div>
    <section class="crm-kpi-grid">
      <article class="crm-kpi-card"><div class="crm-kpi-icon blue">${uiIcon('customers')}</div><div class="crm-kpi-copy"><span>Tổng khách hàng</span><div class="crm-kpi-line"><strong>${customers.length.toLocaleString('vi-VN')}</strong><b class="crm-kpi-delta up">+${Math.min(999,Math.max(0,customers.filter(c=>{const d=dateKey(c.received||'');return d>=from&&d<=date;}).length))} mới</b></div><small>Trong phạm vi tài khoản đang truy cập</small></div></article>
      <article class="crm-kpi-card"><div class="crm-kpi-icon green">${uiIcon('call')}</div><div class="crm-kpi-copy"><span>Tổng cuộc gọi hôm nay</span><div class="crm-kpi-line"><strong>${dayCalls.length.toLocaleString('vi-VN')}</strong><b class="crm-kpi-delta ${delta>=0?'up':'down'}">${delta>=0?'↑':'↓'} ${Math.abs(delta)}%</b></div><small>So với trung bình giai đoạn trước</small></div></article>
      <article class="crm-kpi-card"><div class="crm-kpi-icon purple">${uiIcon('call')}</div><div class="crm-kpi-copy"><span>Cuộc gọi kết nối</span><div class="crm-kpi-line"><strong>${connected.toLocaleString('vi-VN')}</strong><b class="crm-kpi-delta up">${latest.length?Math.round(connected/latest.length*100):0}%</b></div><small>Tỷ lệ kết nối theo khách đã gọi</small></div></article>
      <article class="crm-kpi-card"><div class="crm-kpi-icon amber">${uiIcon('calendar')}</div><div class="crm-kpi-copy"><span>Follow-up đến hạn</span><div class="crm-kpi-line"><strong>${followups.length.toLocaleString('vi-VN')}</strong><b class="crm-kpi-delta ${followups.length?'down':'up'}">${followups.length?'Cần xử lý':'Đã sạch'}</b></div><small>Follow-up ngày ${shortDate(date)}</small></div></article>
    </section>
    <section class="crm-analytics-grid">
      <article class="crm-panel"><div class="crm-panel-head"><h2>Cuộc gọi theo ngày</h2><span>7 ngày gần nhất</span></div><div class="crm-chart-body">${premiumLineChart(trend)}</div></article>
      <article class="crm-panel"><div class="crm-panel-head"><h2>Kết quả cuộc gọi</h2><span>Ngày ${shortDate(date)}</span></div><div class="crm-outcome-wrap">${premiumDonut(latest.length,outcomeParts)}<div class="crm-outcome-list">${outcomeParts.map(p=>`<div class="crm-outcome-item"><span class="crm-outcome-name"><i class="crm-outcome-dot" style="background:${p.color}"></i>${p.name}</span><strong>${p.value}</strong><small>${latest.length?Math.round(p.value/latest.length*100):0}%</small></div>`).join('')}</div></div></article>
    </section>
    <section class="crm-middle-grid">
      <article class="crm-panel"><div class="crm-panel-head"><h2>Hiệu suất đội ngũ</h2><button class="crm-panel-tool" data-nav-kpi="1">Xem KPI</button></div><div class="table-wrap" style="border:0;border-radius:0;box-shadow:none"><table class="crm-compact-table"><thead><tr><th>Nhân viên</th><th>Nhóm</th><th>Tổng gọi</th><th>Kết nối</th><th>Chuyển đổi</th><th>Hoàn thành KPI</th></tr></thead><tbody>${perf.map(r=>`<tr><td><span class="crm-person"><i class="crm-avatar-mini">${esc(initials(r.u.display_name))}</i>${esc(r.u.display_name)}</span></td><td>${esc(r.u.team||'')}</td><td>${r.calls}</td><td>${r.conn}</td><td>${r.conv}%</td><td><div class="crm-kpi-cell"><div class="crm-progress"><i style="width:${Math.min(100,r.progress)}%"></i></div><b>${r.progress}%</b></div></td></tr>`).join('')||'<tr><td colspan="6">Chưa có dữ liệu.</td></tr>'}</tbody></table></div></article>
      <article class="crm-panel"><div class="crm-panel-head"><h2>Follow-up hôm nay</h2><button class="crm-panel-tool" data-nav-follow="1">Xem tất cả</button></div><div class="crm-follow-list"><div class="crm-follow-row header"><span>Khách hàng</span><span>Số điện thoại</span><span>Giờ</span><span>Nhân viên</span><span>Trạng thái</span></div>${followups.slice(0,6).map(c=>`<div class="crm-follow-row"><span class="crm-follow-name">${esc(c.name)}</span><span>${esc(c.phone)}</span><span>${esc(vnParts(c.follow_up)?.time||'--:--')}</span><span>${esc(c.owner||'')}</span><span><i class="crm-status-badge due">Đến hạn</i></span></div>`).join('')||'<div class="empty small-empty">Không có Follow-up đến hạn.</div>'}</div></article>
    </section>
    <section class="crm-panel"><div class="crm-panel-head"><h2>Hoạt động cuộc gọi gần đây</h2><button class="crm-panel-tool" data-nav-history="1">Xem tất cả</button></div><div class="table-wrap" style="border:0;border-radius:0;box-shadow:none"><table class="data-table crm-recent-table"><thead><tr><th>Khách hàng</th><th>Số điện thoại</th><th>Nhân viên</th><th>Thời gian gọi</th><th>Kết quả</th><th>Lịch hẹn tiếp theo</th><th>Thao tác</th></tr></thead><tbody>${recent.map(x=>{const c=premiumCustomer(x.customer_id)||{};return `<tr><td><strong>${esc(c.name||x.customer_name||'')}</strong></td><td>${esc(c.phone||x.phone||'')}</td><td>${esc(x.owner||'')}</td><td>${esc(fmtDate(x.created_at))}</td><td>${statusPill(x.status)}</td><td>${esc(fmtDate(x.follow_up_at||c.follow_up||''))}</td><td><div class="crm-action-buttons"><button class="crm-icon-action" data-customer="${c.id||x.customer_id}" title="Mở hồ sơ">›</button><button class="crm-icon-action" data-nav-history="1" title="Lịch sử">⋯</button></div></td></tr>`}).join('')||'<tr><td colspan="7">Chưa có cuộc gọi trong khoảng đang xem.</td></tr>'}</tbody></table></div></section>
  </div>`;
  $('#premium-dashboard-date').onchange=async e=>{state.dashboardViewDate=e.target.value||todayISO();const d=state.dashboardViewDate,f=addDays(d,-6);if(state.mode==='d1')await ensureCallsRange(f,d);const dl=$('#global-date-label');if(dl)dl.textContent=premiumDateLabel();renderDashboard(main)};
  $('#premium-dashboard-today').onclick=()=>{state.dashboardViewDate=todayISO();const dl=$('#global-date-label');if(dl)dl.textContent=premiumDateLabel();renderDashboard(main)};
  $$('[data-nav-kpi]').forEach(b=>b.onclick=()=>navigate('kpi'));$$('[data-nav-follow]').forEach(b=>b.onclick=()=>navigate('followup'));$$('[data-nav-history]').forEach(b=>b.onclick=()=>navigate('callhistory'));bindCustomerLinks();
}
function premiumDbRows(){
  const q=(state.filters.q||'').toLowerCase(),team=state.filters.team||'',owner=state.filters.owner||'',status=state.filters.status||'',source=state.filters.source||'',date=state.customerDbDate||'';
  return visibleCustomers().filter(c=>(!q||[c.code,c.name,c.phone,c.owner,c.team].some(v=>String(v||'').toLowerCase().includes(q)))&&(!team||c.team===team)&&(!owner||c.owner===owner)&&(!status||c.status===status)&&(!source||c.source===source)&&(!date||dateKey(c.received||'')===date));
}
function premiumDbTable(rows){
  const page=Math.max(1,Number(state.customerDbPage||1)),size=15,pages=Math.max(1,Math.ceil(rows.length/size)),cur=Math.min(page,pages);state.customerDbPage=cur;const slice=rows.slice((cur-1)*size,cur*size);
  return `<div class="table-wrap"><table class="data-table crm-data-table"><thead><tr><th><input class="crm-checkbox" id="db-check-all" type="checkbox"></th><th>Mã KH ↕</th><th>Tên khách hàng ↕</th><th>Số điện thoại</th><th>Nguồn data</th><th>Nhân viên phụ trách</th><th>Nhóm</th><th>Trạng thái lead</th><th>Cuộc gọi gần nhất</th><th>Follow-up tiếp theo</th><th>Thao tác</th></tr></thead><tbody>${slice.map(c=>{const lc=lastCallAt(c.id);return `<tr><td><input class="crm-checkbox db-row-check" type="checkbox" value="${c.id}"></td><td>${esc(c.code||('KH'+String(c.id).padStart(6,'0')))}</td><td><span class="customer-main"><i class="crm-avatar-mini">${esc(initials(c.name))}</i><span class="name-link" data-customer="${c.id}">${esc(c.name)}</span></span></td><td class="phone">${esc(c.phone)}</td><td>${esc(c.source||'')}</td><td>${esc(c.owner||'')}</td><td>${esc(c.team||'')}</td><td>${statusPill(c.status)}</td><td>${lc?esc(fmtDate(lc)):'—'}</td><td>${c.follow_up?esc(fmtDate(c.follow_up)):'—'}</td><td><div class="crm-action-buttons"><button class="crm-icon-action" data-customer="${c.id}" title="Mở hồ sơ">›</button><button class="crm-icon-action" title="Thêm thao tác">⋯</button></div></td></tr>`}).join('')||'<tr><td colspan="11"><div class="empty">Không có khách hàng phù hợp bộ lọc.</div></td></tr>'}</tbody></table><div class="crm-data-footer"><span>Hiển thị ${slice.length} / ${rows.length.toLocaleString('vi-VN')} khách hàng</span><div class="crm-pagination"><button data-db-page="${Math.max(1,cur-1)}">‹</button>${Array.from({length:Math.min(5,pages)},(_,i)=>Math.max(1,Math.min(pages,cur-2+i))).filter((v,i,a)=>a.indexOf(v)===i).map(n=>`<button class="${n===cur?'active':''}" data-db-page="${n}">${n}</button>`).join('')}<button data-db-page="${Math.min(pages,cur+1)}">›</button></div></div></div>`;
}
function bindPremiumDbTable(main){
  bindCustomerLinks();$$('[data-db-page]').forEach(b=>b.onclick=()=>{state.customerDbPage=Number(b.dataset.dbPage);renderCustomerDatabase(main)});
  const checks=$$('.db-row-check'),all=$('#db-check-all'),count=$('#db-selected-count');const sync=()=>{const n=checks.filter(x=>x.checked).length;if(count)count.textContent=`Đã chọn ${n} khách hàng`;};checks.forEach(x=>x.onchange=sync);if(all)all.onchange=()=>{checks.forEach(x=>x.checked=all.checked);sync();};
}
function renderCustomerDatabase(main){
  const rows=premiumDbRows(),owners=[...new Set(visibleCustomers().map(c=>c.owner).filter(Boolean))].sort(),sources=[...new Set(visibleCustomers().map(c=>c.source).filter(Boolean))].sort();const canManage=state.session.user.role!=='sale';
  main.innerHTML=`<div class="premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Cơ sở dữ liệu khách hàng <span class="premium-count-badge">${rows.length.toLocaleString('vi-VN')} khách hàng</span></h1><p>Quản lý danh sách khách hàng, nguồn data, người phụ trách và trạng thái chăm sóc</p></div><div class="premium-page-actions">${canManage?'<button class="btn" id="db-import">⇧ Nhập Excel</button>':''}<button class="btn" id="db-export">⇩ Xuất Excel</button>${canManage?'<button class="btn primary" id="db-add">＋ Thêm khách hàng</button>':''}</div></div>
  <div class="crm-data-toolbar"><input id="db-q" placeholder="Tìm kiếm theo tên, SĐT, mã KH..." value="${esc(state.filters.q||'')}"><select id="db-team"><option value="">Tất cả nhóm</option>${state.teams.map(x=>`<option ${x===state.filters.team?'selected':''}>${esc(x)}</option>`).join('')}</select><select id="db-owner"><option value="">Tất cả nhân viên</option>${owners.map(x=>`<option ${x===state.filters.owner?'selected':''}>${esc(x)}</option>`).join('')}</select><select id="db-status"><option value="">Tất cả trạng thái</option>${Object.entries(STATUS_LABELS).map(([k,v])=>`<option value="${k}" ${k===state.filters.status?'selected':''}>${esc(v)}</option>`).join('')}</select><select id="db-source"><option value="">Tất cả nguồn</option>${sources.map(x=>`<option ${x===state.filters.source?'selected':''}>${esc(x)}</option>`).join('')}</select><input id="db-date" type="date" value="${esc(state.customerDbDate||'')}"></div>
  <div class="crm-bulkbar"><div class="crm-bulk-left"><span id="db-selected-count">Đã chọn 0 khách hàng</span>${['admin','sup'].includes(state.session.user.role)?'<button class="btn" id="db-bulk">Phân bổ hàng loạt</button>':''}</div><small class="muted">Dữ liệu hiển thị theo đúng phạm vi phân quyền backend của tài khoản.</small></div><div id="db-table">${premiumDbTable(rows)}</div></div>`;
  const rerender=()=>{state.customerDbPage=1;renderCustomerDatabase(main)};$('#db-q').oninput=e=>{state.filters.q=e.target.value;const table=$('#db-table');if(table){table.innerHTML=premiumDbTable(premiumDbRows());bindPremiumDbTable(main)}};$('#db-team').onchange=e=>{state.filters.team=e.target.value;rerender()};$('#db-owner').onchange=e=>{state.filters.owner=e.target.value;rerender()};$('#db-status').onchange=e=>{state.filters.status=e.target.value;rerender()};$('#db-source').onchange=e=>{state.filters.source=e.target.value;rerender()};$('#db-date').onchange=e=>{state.customerDbDate=e.target.value;rerender()};
  if($('#db-import'))$('#db-import').onclick=()=>navigate('io');$('#db-export').onclick=exportCsv;if($('#db-add'))$('#db-add').onclick=()=>toast('Backend hiện tại chưa có tạo từng khách thủ công. Hãy dùng Nhập Excel để bảo toàn luồng dữ liệu.','bad');if($('#db-bulk'))$('#db-bulk').onclick=()=>distributeData();bindPremiumDbTable(main);
}
function renderPremiumCallHistory(main){
  if(['admin','sup','teamlead'].includes(state.session.user.role))return renderCallDetails(main);
  const u=state.session.user,rows=state.calls.filter(x=>Number(x.user_id)===Number(u.id)||(!x.user_id&&x.owner===u.display_name)).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))).slice(0,300);
  main.innerHTML=`<div class="premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Lịch sử cuộc gọi</h1><p>Các lượt gọi đã được ghi nhận bởi tài khoản của bạn</p></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Thời gian</th><th>Khách hàng</th><th>Số điện thoại</th><th>Kết quả</th><th>Ghi chú</th><th>Follow-up</th></tr></thead><tbody>${rows.map(x=>{const c=premiumCustomer(x.customer_id)||{};return `<tr><td>${esc(fmtDate(x.created_at))}</td><td><span class="name-link" data-customer="${c.id||x.customer_id}">${esc(c.name||'')}</span></td><td>${esc(c.phone||'')}</td><td>${statusPill(x.status)}</td><td>${esc(x.note||'')}</td><td>${esc(fmtDate(x.follow_up_at||c.follow_up||''))}</td></tr>`}).join('')||'<tr><td colspan="6">Chưa có cuộc gọi.</td></tr>'}</tbody></table></div></div>`;bindCustomerLinks();
}
function renderTelesale(main){
  if(['admin','sup','teamlead'].includes(state.session.user.role))return renderAdminCallMonitor(main);
  const normal=telesaleQueue('queue'),old=telesaleQueue('old'),baseQueue=state.callMode==='old'?old:normal,queue=state.callStatusFilter?baseQueue.filter(c=>String(c.status||'NEW')===String(state.callStatusFilter)):baseQueue;let current=queue.find(x=>x.id===state.selectedCustomerId)||queue[0];if(current)state.selectedCustomerId=current.id;
  const callsToday=state.calls.filter(x=>dateKey(x.created_at)===todayISO()&&(Number(x.user_id)===Number(state.session.user.id)||(!x.user_id&&x.owner===state.session.user.display_name))).length,done=normal.filter(c=>c.status!=='NEW').length;
  const history=current?state.calls.filter(x=>Number(x.customer_id)===Number(current.id)).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))).slice(0,5):[];
  main.innerHTML=`<div class="cc-page premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Chi tiết cuộc gọi</h1><p>Danh sách khách được giao và khu vực cập nhật kết quả cuộc gọi</p></div><div class="cc-summary-strip"><div class="cc-summary-item"><div class="cc-summary-icon blue">${uiIcon('customers')}</div><div class="cc-summary-copy"><span>Tổng cần gọi hôm nay</span><strong>${normal.length}</strong></div></div><div class="cc-summary-item"><div class="cc-summary-icon green">${uiIcon('call')}</div><div class="cc-summary-copy"><span>Đã ghi nhận cuộc gọi</span><strong>${callsToday}</strong></div></div><div class="cc-summary-item"><div class="cc-summary-icon amber">${uiIcon('calendar')}</div><div class="cc-summary-copy"><span>Data cũ có thể gọi lại</span><strong>${old.length}</strong></div></div></div></div>
  <div class="cc-grid">
    <section class="cc-panel"><div class="cc-panel-head"><h2>Danh sách khách hàng cần gọi</h2><span>${queue.length} khách hàng</span></div><div class="cc-queue-tools"><input class="wide" id="cc-search" placeholder="Tìm theo tên, số điện thoại..."><select id="cc-mode"><option value="queue" ${state.callMode==='queue'?'selected':''}>Hàng đợi đang giao</option><option value="old" ${state.callMode==='old'?'selected':''}>Data cũ / đã gọi</option></select><select id="cc-status-filter" class="wide"><option value="">Tất cả trạng thái cuộc gọi</option>${Object.entries(STATUS_LABELS).map(([k,v])=>`<option value="${k}" ${state.callStatusFilter===k?'selected':''}>${esc(v)}</option>`).join('')}</select></div><div class="cc-queue-list">${queue.map(c=>`<div class="cc-queue-item ${current&&c.id===current.id?'active':''}" data-call-customer="${c.id}" data-search-text="${esc((c.name+' '+c.phone).toLowerCase())}"><div class="cc-queue-avatar">${esc(initials(c.name))}</div><div class="cc-queue-copy"><strong>${esc(c.name)}</strong><span>${esc(c.phone)} · ${esc(c.source||'')}</span></div><div class="cc-queue-meta">${statusPill(c.status)}<small>${c.follow_up?esc(fmtDate(c.follow_up)):'Chưa hẹn'}</small></div></div>`).join('')||'<div class="empty">Không có khách hàng trong hàng đợi.</div>'}</div></section>
    <section class="cc-panel">${current?`<div class="cc-panel-head"><h2>Thông tin khách hàng</h2><button id="open-profile" class="btn small">Sửa / xem hồ sơ</button></div><div class="cc-customer"><div class="cc-customer-hero"><div class="cc-customer-title"><div class="cc-queue-avatar">${esc(initials(current.name))}</div><div><h2>${esc(current.name)}</h2><p>${esc(current.data_category||'Khách hàng cá nhân')} · ${esc(current.source||'Chưa có nguồn')}</p></div></div>${statusPill(current.status)}</div><div class="cc-detail-grid"><div class="cc-detail-cell"><label>Mã khách hàng</label><strong>${esc(current.code||('KH'+String(current.id).padStart(6,'0')))}</strong></div><div class="cc-detail-cell"><label>Số điện thoại</label><strong>${esc(current.phone)}</strong></div><div class="cc-detail-cell"><label>Nguồn khách hàng</label><strong>${esc(current.source||'')}</strong></div><div class="cc-detail-cell"><label>Ngày nhận Data</label><strong>${current.received?esc(shortDate(String(current.received).slice(0,10))):'—'}</strong></div><div class="cc-detail-cell"><label>Nhân viên phụ trách</label><strong>${esc(current.owner||'')}</strong></div><div class="cc-detail-cell"><label>Kết quả gần nhất</label><strong>${esc(STATUS_LABELS[current.status]||current.status)}</strong></div></div><div class="cc-note-box"><strong>Ghi chú nhanh</strong><br>${esc(current.note||'Chưa có ghi chú cho khách hàng này.')}</div><div class="cc-section"><div class="cc-section-title"><span>Lịch sử xử lý nhanh</span><small>${history.length} lượt gần nhất</small></div><div class="cc-history">${history.map(x=>`<div class="cc-history-row"><time>${esc(fmtDate(x.created_at))}</time><strong>${esc(STATUS_LABELS[x.status]||x.status)}</strong><span>${esc(x.note||'Không có ghi chú')}</span></div>`).join('')||'<div class="empty small-empty">Chưa có lịch sử cuộc gọi.</div>'}</div></div></div>`:'<div class="empty">Chọn khách hàng để xem chi tiết.</div>'}</section>
    <aside class="cc-panel"><div class="cc-panel-head"><h2>Cập nhật kết quả cuộc gọi</h2></div>${current?`<div class="cc-form"><div class="form-field"><label>Kết quả cuộc gọi *</label><select id="call-status"><option value="" selected disabled>-- Chọn kết quả --</option>${Object.entries(STATUS_LABELS).filter(([k])=>k!=='NEW').map(([k,v])=>`<option value="${k}">${esc(v)}</option>`).join('')}</select><div class="cc-result-hints"><span><i style="background:#18a56b"></i>Kết nối / có nhu cầu</span><span><i style="background:#e34b4b"></i>Không nghe máy / sai số</span><span><i style="background:#f0a11b"></i>Gọi lại / đang cân nhắc</span></div></div><div class="form-field notes"><label>Ghi chú cuộc gọi</label><textarea id="call-note" placeholder="Nhập nội dung trao đổi với khách hàng..."></textarea></div><div class="form-field"><label>Ngày gọi lại</label><input id="call-follow" type="datetime-local" value="${current.follow_up?String(current.follow_up).slice(0,16):''}"></div><div class="cc-form-actions"><button class="btn primary" id="save-call" disabled>Lưu kết quả</button><button class="btn" id="cc-profile-bottom">Mở hồ sơ khách hàng</button></div></div>`:'<div class="empty">Chưa chọn khách hàng.</div>'}</aside>
  </div></div>`;
  $('#cc-mode').onchange=e=>{state.callMode=e.target.value;state.callStatusFilter='';state.selectedCustomerId=null;renderTelesale(main)};$('#cc-status-filter').onchange=e=>{state.callStatusFilter=e.target.value||'';state.selectedCustomerId=null;renderTelesale(main)};$('#cc-search').oninput=e=>{const q=e.target.value.toLowerCase();$$('.cc-queue-item').forEach(el=>el.style.display=el.dataset.searchText.includes(q)?'':'none')};$$('[data-call-customer]').forEach(x=>x.onclick=()=>{state.selectedCustomerId=Number(x.dataset.callCustomer);renderTelesale(main)});
  if(current){const status=$('#call-status'),save=$('#save-call');status.onchange=()=>{save.disabled=!status.value;save.textContent=status.value?'Lưu kết quả':'Chọn kết quả để lưu'};save.onclick=()=>saveCall(current.id);$('#open-profile').onclick=()=>openCustomerModal(current.id);$('#cc-profile-bottom').onclick=()=>openCustomerModal(current.id)}
}
function renderEmployees(main){
  const role=state.session.user.role;if(role==='sale'){main.innerHTML='<div class="empty">Bạn không có quyền truy cập Nhân sự.</div>';return;}const isAdmin=(role==='admin'||role==='sup'),isLead=role==='teamlead';
  if(isLead)state.employeeTeamFilter=String(state.session.user.team_id||'');const q=(state.premiumEmployeeSearch||'').toLowerCase(),team=String(state.employeeTeamFilter||''),rf=state.premiumEmployeeRole||'';
  let users=state.users.filter(u=>isAdmin||Number(u.team_id)===Number(state.session.user.team_id));users=users.filter(u=>(!q||[u.display_name,u.username,u.team].some(v=>String(v||'').toLowerCase().includes(q)))&&(!team||String(u.team_id)===team)&&(!rf||u.role===rf));
  const allScope=state.users.filter(u=>isAdmin||Number(u.team_id)===Number(state.session.user.team_id)),leaders=allScope.filter(u=>u.role==='teamlead'),agents=allScope.filter(u=>u.role==='sale'),activeTeams=new Set(allScope.map(u=>u.team_id).filter(Boolean)).size,today=todayISO();
  const leaderFor=u=>state.users.find(x=>x.role==='teamlead'&&Number(x.team_id)===Number(u.team_id));
  main.innerHTML=`<div class="premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Quản lý nhóm & nhân viên</h1><p>Quản lý nhóm, tài khoản và hiệu suất nhân viên</p></div></div>
  <section class="staff-summary-grid"><article class="staff-summary"><div class="staff-summary-icon blue">${uiIcon('users')}</div><div class="staff-summary-copy"><span>Tổng nhân viên</span><strong>${allScope.length}</strong><small>tài khoản</small></div></article><article class="staff-summary"><div class="staff-summary-icon green">${uiIcon('users')}</div><div class="staff-summary-copy"><span>Team Leader</span><strong>${leaders.length}</strong><small>người</small></div></article><article class="staff-summary"><div class="staff-summary-icon purple">${uiIcon('customers')}</div><div class="staff-summary-copy"><span>Sales / Freelancer</span><strong>${agents.length}</strong><small>người</small></div></article><article class="staff-summary"><div class="staff-summary-icon amber">${uiIcon('warehouse')}</div><div class="staff-summary-copy"><span>Team đang hoạt động</span><strong>${activeTeams}</strong><small>nhóm</small></div></article></section>
  <div class="staff-toolbar"><input id="staff-q" placeholder="Tìm kiếm theo tên nhân viên, tài khoản..." value="${esc(state.premiumEmployeeSearch||'')}"><select id="staff-team"><option value="">Tất cả nhóm</option>${state.teamObjects.map(t=>`<option value="${t.id}" ${String(t.id)===team?'selected':''}>${esc(t.name)}</option>`).join('')}</select><select id="staff-role"><option value="">Tất cả vai trò</option><option value="admin" ${rf==='admin'?'selected':''}>Admin</option><option value="teamlead" ${rf==='teamlead'?'selected':''}>Team Leader</option><option value="sale" ${rf==='sale'?'selected':''}>Sales</option><option value="freelancer" ${rf==='freelancer'?'selected':''}>Freelancer</option></select><select id="staff-status"><option>Đang hoạt động</option></select><div class="staff-actions">${isAdmin?'<button class="btn" id="add-admin">＋ Admin</button><button class="btn" id="add-team">＋ Tạo nhóm</button>':''}<button class="btn primary" id="add-employee">＋ Thêm nhân viên</button></div></div>
  <div class="table-wrap"><table class="data-table staff-table"><thead><tr><th>Nhân viên</th><th>User (Tên đăng nhập)</th><th>Nhóm</th><th>Team Leader</th><th>Vai trò</th><th>Số khách được giao</th><th>Cuộc gọi hôm nay</th><th>Tiến độ KPI</th><th>Trạng thái tài khoản</th><th>Thao tác</th></tr></thead><tbody>${users.map(u=>{const assigned=state.customers.filter(c=>Number(c.assigned_user_id)===Number(u.id)||(!c.assigned_user_id&&c.owner===u.display_name)).length,calls=state.calls.filter(x=>dateKey(x.created_at)===today&&(Number(x.user_id)===Number(u.id)||(!x.user_id&&x.owner===u.display_name))).length,target=userKpiTarget(u.id),prog=u.role==='sale'?Math.min(100,Math.round(calls/Math.max(1,Number(target.calls_daily||50))*100)):100,lead=leaderFor(u);return `<tr><td><span class="crm-person"><i class="crm-avatar-mini">${esc(initials(u.display_name))}</i>${esc(u.display_name)}</span></td><td><strong class="staff-username">@${esc(u.username||'—')}</strong></td><td>${esc(u.team||'—')}</td><td>${u.role==='admin'?'—':esc(lead?.display_name||'—')}</td><td><span class="staff-role ${staffRoleKey(u)}">${esc(staffRoleLabel(u))}</span></td><td>${assigned}</td><td>${calls}</td><td><div class="crm-kpi-cell"><div class="crm-progress"><i style="width:${prog}%"></i></div><b>${prog}%</b></div></td><td><span class="staff-status ${u.active===0?'locked':'active'}">${u.active===0?'Tạm khóa':'Hoạt động'}</span></td><td><div class="crm-action-buttons"><button class="crm-icon-action" data-edit-user="${u.id}" title="Sửa">✎</button>${u.role!=='admin'?`<button class="crm-icon-action" data-delete-user="${u.id}" title="Xóa">⋯</button>`:''}</div></td></tr>`}).join('')||'<tr><td colspan="10">Không có nhân viên phù hợp.</td></tr>'}</tbody></table></div></div>`;
  $('#staff-q').oninput=e=>{state.premiumEmployeeSearch=e.target.value;renderEmployees(main);requestAnimationFrame(()=>{const q=$('#staff-q');if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length);}})};$('#staff-team').onchange=e=>{state.employeeTeamFilter=e.target.value;renderEmployees(main)};$('#staff-role').onchange=e=>{state.premiumEmployeeRole=e.target.value;renderEmployees(main)};if($('#add-admin'))$('#add-admin').onclick=adminUserForm;if($('#add-team'))$('#add-team').onclick=openTeamForm;$('#add-employee').onclick=()=>employeeForm();$$('[data-edit-user]').forEach(b=>b.onclick=()=>employeeForm(state.users.find(u=>u.id===Number(b.dataset.editUser))));$$('[data-delete-user]').forEach(b=>b.onclick=()=>deleteEmployee(state.users.find(u=>u.id===Number(b.dataset.deleteUser))));
}
function renderKPI(main){
  const date=state.dashboardDate||todayISO(),from=addDays(date,-6),role=state.session.user.role;if(state.mode==='d1'&&!isCallsRangeLoaded(from,date)){main.innerHTML='<div class="empty">Đang tải dữ liệu KPI…</div>';ensureCallsRange(from,date).then(()=>{if(state.page==='kpi'||state.page==='reports')renderKPI(main)}).catch(e=>toast(e.message,'bad'));return;}
  const teamFilter=state.premiumKpiTeam||'',userFilter=state.premiumKpiUser||'';let users=premiumScopeUsers();if(teamFilter)users=users.filter(u=>String(u.team_id)===String(teamFilter));if(userFilter)users=users.filter(u=>String(u.id)===String(userFilter));const userIds=new Set(users.map(u=>Number(u.id))),names=new Set(users.map(u=>u.display_name));const calls=premiumScopeCalls(from,date).filter(x=>userIds.has(Number(x.user_id))||(!x.user_id&&names.has(x.owner))),latest=latestCallsByCustomer(calls),connected=latest.filter(x=>String(x.status).startsWith('Y')).length,y01=latest.filter(x=>x.status==='Y01').length,targetCalls=users.reduce((n,u)=>n+Number(userKpiTarget(u.id).calls_daily||50)*7,0),connRate=latest.length?Math.round(connected/latest.length*1000)/10:0,conv=latest.length?Math.round(y01/latest.length*1000)/10:0;
  const due=visibleCustomers().filter(c=>{const d=dateKey(c.follow_up||'');return d>=from&&d<=date&&(users.some(u=>Number(c.assigned_user_id)===Number(u.id)||c.owner===u.display_name))}),done=due.filter(c=>{const f=String(c.follow_up||'');return state.calls.some(x=>Number(x.customer_id)===Number(c.id)&&String(x.created_at)>=f)}).length,followRate=due.length?Math.round(done/due.length*1000)/10:100;
  const dayRows=dateRange(from,date,7).map(d=>{const a=calls.filter(x=>dateKey(x.created_at)===d);return {d,label:shortDate(d),actual:a.length,target:users.reduce((n,u)=>n+Number(userKpiTarget(u.id).calls_daily||50),0)}}),maxDay=Math.max(1,...dayRows.flatMap(x=>[x.actual,x.target]));
  const teamRows=state.teamObjects.map(t=>{const us=users.filter(u=>Number(u.team_id)===Number(t.id));if(!us.length)return null;const ids=new Set(us.map(u=>Number(u.id))),ns=new Set(us.map(u=>u.display_name)),cs=calls.filter(x=>ids.has(Number(x.user_id))||(!x.user_id&&ns.has(x.owner))),target=us.reduce((n,u)=>n+Number(userKpiTarget(u.id).calls_daily||50)*7,0);return {t,calls:cs.length,target,pct:target?Math.round(cs.length/target*100):0}}).filter(Boolean).sort((a,b)=>b.calls-a.calls);
  const ranks=users.map(u=>{const cs=calls.filter(x=>Number(x.user_id)===Number(u.id)||(!x.user_id&&x.owner===u.display_name)),l=latestCallsByCustomer(cs),con=l.filter(x=>String(x.status).startsWith('Y')).length,yy=l.filter(x=>x.status==='Y01').length,t=userKpiTarget(u.id),tar=Number(t.calls_daily||50)*7,pct=tar?Math.round(cs.length/tar*100):0;return {u,calls:cs.length,conn:l.length?Math.round(con/l.length*1000)/10:0,conv:l.length?Math.round(yy/l.length*1000)/10:0,pct}}).sort((a,b)=>b.pct-a.pct);
  const canSet=(role==='admin'||role==='sup')||role==='teamlead';
  main.innerHTML=`<div class="kpi-page premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>KPI & Hiệu suất</h1><p>Theo dõi KPI và hiệu suất theo khoảng thời gian</p></div><div class="premium-page-actions">${canSet?'<button class="btn primary" id="kpi-bulk-open">Đặt KPI hàng loạt</button>':''}</div></div>
  <section class="kpi-filter-grid"><div class="kpi-filter-card"><div class="kpi-filter-icon">${uiIcon('calendar')}</div><div><label>Ngày kết thúc kỳ 7 ngày</label><input id="kpi-date" type="date" value="${esc(date)}"></div></div><div class="kpi-filter-card"><div class="kpi-filter-icon">${uiIcon('users')}</div><div><label>Nhóm</label><select id="kpi-team"><option value="">Tất cả nhóm</option>${state.teamObjects.map(t=>`<option value="${t.id}" ${String(t.id)===String(teamFilter)?'selected':''}>${esc(t.name)}</option>`).join('')}</select></div></div><div class="kpi-filter-card"><div class="kpi-filter-icon">${uiIcon('customers')}</div><div><label>Nhân viên</label><select id="kpi-user"><option value="">Tất cả nhân viên</option>${premiumScopeUsers().filter(u=>!teamFilter||String(u.team_id)===String(teamFilter)).map(u=>`<option value="${u.id}" ${String(u.id)===String(userFilter)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select></div></div></section>
  <section class="kpi-metric-grid"><article class="kpi-metric-card"><div class="kpi-metric-icon blue">${uiIcon('target')}</div><div class="kpi-metric-copy"><span>Mục tiêu cuộc gọi</span><strong>${targetCalls.toLocaleString('vi-VN')}</strong><small>Kỳ 7 ngày</small></div></article><article class="kpi-metric-card"><div class="kpi-metric-icon green">${uiIcon('call')}</div><div class="kpi-metric-copy"><span>Thực đạt cuộc gọi</span><strong>${calls.length.toLocaleString('vi-VN')}</strong><small>${targetCalls?Math.round(calls.length/targetCalls*100):0}% mục tiêu</small></div></article><article class="kpi-metric-card"><div class="kpi-metric-icon purple">${uiIcon('call')}</div><div class="kpi-metric-copy"><span>Tỷ lệ kết nối</span><strong>${connRate}%</strong><small>${connected}/${latest.length} khách đã gọi</small></div></article><article class="kpi-metric-card"><div class="kpi-metric-icon amber">${uiIcon('users')}</div><div class="kpi-metric-copy"><span>Tỷ lệ chuyển đổi Y01</span><strong>${conv}%</strong><small>${y01} khách có nhu cầu</small></div></article><article class="kpi-metric-card"><div class="kpi-metric-icon red">${uiIcon('calendar')}</div><div class="kpi-metric-copy"><span>Follow-up hoàn thành</span><strong>${followRate}%</strong><small>${done}/${due.length} lịch trong kỳ</small></div></article></section>
  <section class="kpi-charts"><article class="crm-panel"><div class="crm-panel-head"><h2>KPI mục tiêu vs Thực đạt theo ngày</h2><span>7 ngày</span></div><div class="kpi-chart"><div class="kpi-bars">${dayRows.map(r=>`<div class="kpi-bar-group"><i class="kpi-bar target" style="height:${Math.max(3,r.target/maxDay*100)}%"></i><i class="kpi-bar actual" style="height:${Math.max(3,r.actual/maxDay*100)}%"></i><span class="kpi-bar-label">${esc(r.label)}</span></div>`).join('')}</div><div class="crm-chart-legend" style="margin-top:28px"><span><i style="background:#9bc9ff"></i>Mục tiêu</span><span><i class="total"></i>Thực đạt</span></div></div></article><article class="crm-panel"><div class="crm-panel-head"><h2>So sánh các nhóm</h2><span>Theo tổng cuộc gọi</span></div><div class="kpi-chart"><div class="kpi-team-bars">${teamRows.map(r=>`<div class="kpi-team-row"><strong>${esc(r.t.name.replace('Mobility ','M'))}</strong><div class="kpi-team-track"><i style="width:${Math.min(100,r.pct)}%"></i></div><span>${r.calls}/${r.target}</span></div>`).join('')||'<div class="empty">Không có dữ liệu Team.</div>'}</div></div></article></section>
  <section class="crm-panel"><div class="crm-panel-head"><h2>Bảng xếp hạng hiệu suất nhân viên</h2><span>${shortDate(from)} - ${shortDate(date)}</span></div><div class="table-wrap" style="border:0;border-radius:0;box-shadow:none"><table class="data-table"><thead><tr><th>Xếp hạng</th><th>Nhân viên</th><th>Nhóm</th><th>Tổng gọi</th><th>Tỷ lệ kết nối</th><th>Tỷ lệ chuyển đổi</th><th>Hoàn thành KPI</th>${canSet?'<th>Thiết lập</th>':''}</tr></thead><tbody>${ranks.map((r,i)=>`<tr><td><span class="ranking-medal ${i===0?'top1':i===1?'top2':i===2?'top3':''}">${i+1}</span></td><td><span class="crm-person"><i class="crm-avatar-mini">${esc(initials(r.u.display_name))}</i>${esc(r.u.display_name)}</span></td><td>${esc(r.u.team||'')}</td><td>${r.calls}</td><td>${r.conn}%</td><td>${r.conv}%</td><td><div class="crm-kpi-cell"><div class="crm-progress"><i style="width:${Math.min(100,r.pct)}%"></i></div><b>${r.pct}%</b></div></td>${canSet?`<td><button class="btn small" data-set-kpi="${r.u.id}">Đặt KPI</button></td>`:''}</tr>`).join('')||'<tr><td colspan="8">Không có dữ liệu.</td></tr>'}</tbody></table></div></section></div>`;
  $('#kpi-date').onchange=async e=>{state.dashboardDate=e.target.value||todayISO();if(state.mode==='d1')await ensureCallsRange(addDays(state.dashboardDate,-6),state.dashboardDate);renderKPI(main)};$('#kpi-team').onchange=e=>{state.premiumKpiTeam=e.target.value;state.premiumKpiUser='';renderKPI(main)};$('#kpi-user').onchange=e=>{state.premiumKpiUser=e.target.value;renderKPI(main)};if($('#kpi-bulk-open'))$('#kpi-bulk-open').onclick=()=>openBulkKpiForm(date);$$('[data-set-kpi]').forEach(b=>b.onclick=()=>openKpiForm(state.users.find(u=>u.id===Number(b.dataset.setKpi)),date));
}

// Topbar date control is intentionally a navigation shortcut; reporting date filters remain page-specific.
const premiumDateControl=$('#global-date-range');if(premiumDateControl)premiumDateControl.addEventListener('click',()=>navigate('dashboard'));


/* =====================================================================
   V8.1 OPERATIONS REDESIGN
   - Dashboard theo khoảng ngày + drill-down Team / Nhân viên
   - Lead pipeline tồn đọng: Lead -> Login App -> Giải ngân / Không giải ngân
   - Gộp Quản lý nhóm & nhân viên theo tab Team
   - KPI chọn Từ ngày / Đến ngày
   - Bỏ menu Báo cáo, Call Center, Chat; Chat chuyển thành bong bóng nổi
   - Admin có Kho tổng; Teamlead có Kho Team
   ===================================================================== */
function v81_override_premiumPageTitle(page,role){
  const titles={dashboard:'Bảng điều khiển',customerdb:'Chi tiết cuộc gọi',callhistory:'Lịch sử cuộc gọi',lead:'Quản lý Lead',followup:'Follow-up',teamManagement:'Quản lý nhóm và nhân viên',kpi:'KPI & Hiệu suất',io:'Nhập / Xuất dữ liệu',warehouseAdmin:role==='teamlead'?'Kho Data Team':'Kho dữ liệu',settings:'Cài đặt',audit:'Nhật ký thao tác',apps:'Tất cả chức năng'};
  return titles[page]||'An Đông 4';
}
function v81_override_allowedPagesForRole(role){
  const common=['dashboard','customerdb','callhistory','lead','followup','kpi'];
  if((role==='admin'||role==='sup'))return new Set([...common,'teamManagement','warehouseAdmin','io','settings','audit']);
  if(role==='teamlead')return new Set([...common,'teamManagement','warehouseAdmin']);
  return new Set(common);
}
function v81_override_premiumDateLabel(){
  const to=state.dashboardTo||todayISO(),from=state.dashboardFrom||addDays(to,-6);
  return `${shortDate(from)} - ${shortDate(to)}`;
}
function v81_override_premiumSidebarItems(role){
  const core=[
    ['dashboard','dashboard','Bảng điều khiển'],
    ['customerdb','customers','Chi tiết cuộc gọi'],
    ['callhistory','call','Lịch sử cuộc gọi'],
    ['lead','lead','Quản lý Lead'],
    ['followup','calendar','Follow-up']
  ];
  if(role==='sale')return [...core,['kpi','kpi','KPI & Hiệu suất']];
  const manage=[['teamManagement','users','Quản lý nhóm và nhân viên'],['kpi','kpi','KPI & Hiệu suất'],['warehouseAdmin','warehouse',role==='teamlead'?'Kho Data Team':'Kho dữ liệu']];
  if((role==='admin'||role==='sup'))manage.push(['io','import','Nhập / Xuất dữ liệu'],['settings','settings','Cài đặt']);
  return [...core,...manage];
}
function v81_override_renderSidebar(active){
  const u=state.session.user,role=u.role,items=premiumSidebarItems(role);
  const team=u.team&&u.team!=='Tất cả'?u.team:((role==='admin'||role==='sup')?'Toàn hệ thống':'Chưa gán Team');
  const rows=items.map((x,i)=>`${i===5&&role!=='sale'?'<div class="sidebar-divider"></div><div class="sidebar-caption">Quản trị & vận hành</div>':''}<button class="menu-item ${x[0]===active?'active':''}" data-nav="${x[0]}"><span class="menu-item-icon">${uiIcon(x[1])}</span><span class="menu-item-label">${x[2]}</span></button>`).join('');
  $('#sidebar-menu').innerHTML=`<div class="sidebar-brand"><div class="sidebar-brand-mark">CC</div><div><strong>CALL CENTER <b>CRM</b></strong><span>${esc(team)}</span></div></div><div class="sidebar-nav-scroll">${rows}</div><div class="sidebar-profile"><div class="sidebar-profile-avatar">${esc(initials(u.display_name))}</div><div class="sidebar-profile-copy"><strong>${esc(u.display_name)}</strong><small>${esc(premiumRoleLabel(role,u.staff_type))}</small></div><span class="sidebar-profile-status"></span></div>`;
  $$('[data-nav]',$('#sidebar-menu')).forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
}
function v81_override_mobileNavItems(){
  const role=state.session?.user?.role||'sale';
  if(role==='sale')return [['dashboard',uiIcon('dashboard'),'Tổng quan'],['customerdb',uiIcon('customers'),'Cuộc gọi'],['lead',uiIcon('lead'),'Lead'],['followup',uiIcon('calendar'),'Gọi lại']];
  return [['dashboard',uiIcon('dashboard'),'Tổng quan'],['customerdb',uiIcon('customers'),'Cuộc gọi'],['teamManagement',uiIcon('users'),'Nhân sự'],['warehouseAdmin',uiIcon('warehouse'),'Kho']];
}
function v81_override_navigate(page){
  closeMobileSidebar();stopChatPolling();
  const role=state.session?.user?.role||'sale';
  if(!allowedPagesForRole(role).has(page))page='dashboard';
  state.page=page;state.app=page;
  $('#sidebar').classList.remove('hidden');
  $('#current-app-title').textContent=premiumPageTitle(page,role);$('#breadcrumb').textContent='Trang chủ';
  const dl=$('#global-date-label');if(dl)dl.textContent=premiumDateLabel();
  renderSidebar(page);renderMobileBottomNav(page);render();
}
function v81_override_render(){
  const main=$('#main');const role=state.session?.user?.role||'sale';
  $('#app')?.classList.remove('dashboard-redesign');
  const map={dashboard:renderDashboard,customerdb:role==='sale'?renderTelesale:renderCallDetails,callhistory:renderPremiumCallHistory,lead:renderLeads,followup:renderFollowup,teamManagement:renderEmployees,kpi:renderKPI,warehouseAdmin:renderWarehouseAdmin,io:renderImport,settings:renderSettings,audit:renderAuditLogs};
  (map[state.page]||renderDashboard)(main);ensureFloatingChat();
}

function v81DateSpan(from,to){return Math.max(1,dateRange(from,to,366).length);}
function v81MatchUser(call,user){return Number(call.user_id)===Number(user.id)||(!call.user_id&&call.owner===user.display_name);}
function v81DashboardContext(){
  const role=state.session.user.role,me=state.session.user;
  const allSales=state.users.filter(u=>u.role==='sale');
  if(role==='sale'){
    const user=allSales.find(u=>Number(u.id)===Number(me.id))||me;
    return {view:'user',user,team:state.teamObjects.find(t=>Number(t.id)===Number(me.team_id)),users:[user],title:`Dashboard · ${user.display_name}`,subtitle:'Hiệu suất cá nhân trong khoảng thời gian đã chọn'};
  }
  if(role==='teamlead'){
    const team=state.teamObjects.find(t=>Number(t.id)===Number(me.team_id))||{id:me.team_id,name:me.team||'Team của bạn'};
    const teamUsers=allSales.filter(u=>Number(u.team_id)===Number(team.id));
    const user=state.dashboardDrillUserId?teamUsers.find(u=>String(u.id)===String(state.dashboardDrillUserId)):null;
    if(user)return {view:'user',user,team,users:[user],title:`Dashboard · ${user.display_name}`,subtitle:`Nhân viên ${team.name}`};
    return {view:'team',team,users:teamUsers,title:`Dashboard · ${team.name}`,subtitle:'Hiệu suất đội ngũ và khả năng chuyển đổi Lead'};
  }
  const team=state.dashboardDrillTeamId?state.teamObjects.find(t=>String(t.id)===String(state.dashboardDrillTeamId)):null;
  if(team){
    const teamUsers=allSales.filter(u=>Number(u.team_id)===Number(team.id));
    const user=state.dashboardDrillUserId?teamUsers.find(u=>String(u.id)===String(state.dashboardDrillUserId)):null;
    if(user)return {view:'user',user,team,users:[user],title:`Dashboard · ${user.display_name}`,subtitle:`Nhân viên ${team.name}`};
    return {view:'team',team,users:teamUsers,title:`Dashboard · ${team.name}`,subtitle:'Bấm nhân viên để xem Dashboard cá nhân'};
  }
  return {view:'all',team:null,user:null,users:allSales,title:'Bảng điều khiển CRM',subtitle:'Tổng quan hoạt động theo khoảng thời gian đã chọn'};
}
function v81CallsForUsers(from,to,users){
  const ids=users.map(u=>Number(u.id)).sort((a,b)=>a-b),names=users.map(u=>u.display_name).sort();
  const stamp=`${state.calls.length}:${state.calls[0]?.id||0}:${state.calls[state.calls.length-1]?.id||0}`;
  const key=`${from}|${to}|${ids.join(',')}|${names.join('~')}|${stamp}`;
  state.v84CallMemo=state.v84CallMemo||new Map();
  if(state.v84CallMemo.has(key))return state.v84CallMemo.get(key);
  // Index once per call-list version. KPI and Dashboard no longer scan every call
  // once for each employee and once for each team.
  if(state._v1031CallIndex?.source!==state.calls||state._v1031CallIndex?.stamp!==stamp){
   const byId=new Map(),byName=new Map();
   state.calls.forEach((x,index)=>{
    const d=dateKey(x.created_at),item={row:x,order:index,date:d};
    const uid=Number(x.user_id||0);
    if(uid){if(!byId.has(uid))byId.set(uid,[]);byId.get(uid).push(item)}
    else{const name=String(x.owner||'');if(!byName.has(name))byName.set(name,[]);byName.get(name).push(item)}
   });
   state._v1031CallIndex={source:state.calls,stamp,byId,byName};
  }
  const idx=state._v1031CallIndex,found=[];
  for(const id of ids)for(const x of(idx.byId.get(id)||[]))if(x.date>=from&&x.date<=to)found.push(x);
  for(const name of names)for(const x of(idx.byName.get(name)||[]))if(x.date>=from&&x.date<=to)found.push(x);
  found.sort((a,b)=>a.order-b.order);
  const out=found.map(x=>x.row);
  if(state.v84CallMemo.size>120)state.v84CallMemo.clear();
  state.v84CallMemo.set(key,out);return out;
}
function v81CustomersForContext(ctx){
  const role=state.session.user.role;
  if(ctx.view==='user')return state.customers.filter(c=>Number(c.assigned_user_id)===Number(ctx.user.id)||c.owner===ctx.user.display_name);
  if(ctx.view==='team')return state.customers.filter(c=>Number(c.team_id)===Number(ctx.team.id)||c.team===ctx.team.name);
  if((role==='admin'||role==='sup'))return state.customers;
  return visibleCustomers();
}
function v81LeadsForContext(ctx){
  let rows=state.leads||[];
  if(ctx.view==='user')rows=rows.filter(x=>Number(x.assigned_user_id)===Number(ctx.user.id));
  else if(ctx.view==='team')rows=rows.filter(x=>Number(x.team_id)===Number(ctx.team.id));
  else if(state.session.user.role==='teamlead')rows=rows.filter(x=>Number(x.team_id)===Number(state.session.user.team_id));
  else if(state.session.user.role==='sale')rows=rows.filter(x=>Number(x.assigned_user_id)===Number(state.session.user.id));
  return rows;
}
function v81Stats(calls){
  const latest=latestCallsByCustomer(calls),connected=latest.filter(x=>String(x.status).startsWith('Y')).length;
  return {calls:calls.length,customers:latest.length,connected,rate:latest.length?Math.round(connected/latest.length*1000)/10:0,y01:latest.filter(x=>x.status==='Y01').length,y02:latest.filter(x=>x.status==='Y02').length,y03:latest.filter(x=>x.status==='Y03').length};
}
function v81TrendRows(from,to,calls){
  const days=dateRange(from,to,366);const chunks=[];const chunkSize=Math.max(1,Math.ceil(days.length/14));
  for(let i=0;i<days.length;i+=chunkSize){const ds=days.slice(i,i+chunkSize);const set=new Set(ds);const rows=calls.filter(x=>set.has(dateKey(x.created_at))),st=v81Stats(rows);chunks.push({label:ds.length===1?shortDate(ds[0]):`${shortDate(ds[0])}`,calls:st.calls,connected:st.connected});}
  return chunks;
}
function v81LeadIsOpen(x){return !x.lead_status||x.lead_status==='LOGIN_APP';}
function v81LeadOutcomeText(x){
  if(!x.lead_status)return 'Chờ xác định có chuyển App hay không';
  if(x.lead_status==='LOGIN_APP')return 'Đã Login App · chờ kết quả giải ngân';
  if(x.lead_status==='SIGNED')return 'Đã giải ngân';
  if(x.lead_status==='OTHER')return Number(x.ever_login_app)?'Login App nhưng không giải ngân':'Không chuyển App · lý do khác';
  if(LEAD_NEGATIVE_STATUSES.has(x.lead_status))return 'Không chuyển App';
  return LEAD_STATUS_LABELS[x.lead_status]||x.lead_status;
}
function v81LeadPill(x){
  const s=x?.lead_status;if(!s)return '<span class="lead-stage new">Chờ xử lý</span>';
  const cls=s==='LOGIN_APP'?'login':s==='SIGNED'?'signed':LEAD_NEGATIVE_STATUSES.has(s)||s==='OTHER'?'negative':'new';
  const label=s==='OTHER'?(Number(x.ever_login_app)?'Không giải ngân':'Không chuyển App'):(LEAD_STATUS_LABELS[s]||s);
  return `<span class="lead-stage ${cls}">${esc(label)}</span>`;
}
function v81LeadAge(x){const d=dateKey(x.lead_created_at);if(!d)return 0;return Math.max(0,Math.floor((Date.parse(todayISO()+'T00:00:00Z')-Date.parse(d+'T00:00:00Z'))/86400000));}
function v81_override_renderDashboard(main){
  const to=state.dashboardTo||todayISO(),from=state.dashboardFrom||addDays(to,-6);state.dashboardFrom=from;state.dashboardTo=to;
  if(state.mode==='d1'&&!isCallsRangeLoaded(from,to)&&!state.dashboardRangeLoading){state.dashboardRangeLoading=true;main.innerHTML='<div class="empty">Đang tải dữ liệu Dashboard…</div>';ensureCallsRange(from,to).then(()=>{state.dashboardRangeLoading=false;if(state.page==='dashboard')renderDashboard(main)}).catch(e=>{state.dashboardRangeLoading=false;toast(e.message,'bad')});return;}
  if(state.mode==='d1'&&!(state.leads||[]).length&&!state.leadLoading){loadLeads(true).then(()=>{if(state.page==='dashboard')renderDashboard(main)}).catch(()=>{});}
  const ctx=v81DashboardContext(),calls=v81CallsForUsers(from,to,ctx.users),stats=v81Stats(calls),customers=v81CustomersForContext(ctx),allLeads=v81LeadsForContext(ctx),periodLeads=allLeads.filter(x=>{const d=dateKey(x.lead_created_at);return d>=from&&d<=to;}),trend=v81TrendRows(from,to,calls);
  const groups=['Kết nối','Không nghe máy','Gọi lại','Không quan tâm','Sai số'];const latest=latestCallsByCustomer(calls);const parts=groups.map(name=>({name,value:latest.filter(x=>premiumStatusGroup(x.status)===name).length}));const recent=premiumRecentCalls(calls,7);
  let performanceRows='';
  if(ctx.view==='all'){
    performanceRows=state.teamObjects.map(t=>{const us=state.users.filter(u=>u.role==='sale'&&Number(u.team_id)===Number(t.id)),cs=v81CallsForUsers(from,to,us),st=v81Stats(cs),ls=(state.leads||[]).filter(x=>Number(x.team_id)===Number(t.id)&&dateKey(x.lead_created_at)>=from&&dateKey(x.lead_created_at)<=to);return `<tr class="v81-click-row" data-dashboard-team="${t.id}"><td><span class="crm-person"><i class="crm-avatar-mini">${esc(initials(t.name))}</i><strong>${esc(t.name)}</strong></span></td><td>${us.length}</td><td>${st.calls}</td><td>${st.y01}</td><td>${st.y02}</td><td>${st.rate}%</td><td><span class="premium-count-badge">${ls.length}</span></td><td><button class="btn small">Xem Team ›</button></td></tr>`}).join('');
  }else if(ctx.view==='team'){
    performanceRows=ctx.users.map(u=>{const cs=v81CallsForUsers(from,to,[u]),st=v81Stats(cs),ls=(state.leads||[]).filter(x=>Number(x.assigned_user_id)===Number(u.id)&&dateKey(x.lead_created_at)>=from&&dateKey(x.lead_created_at)<=to);return `<tr class="v81-click-row" data-dashboard-user="${u.id}"><td><span class="crm-person"><i class="crm-avatar-mini">${esc(initials(u.display_name))}</i><strong>${esc(u.display_name)}</strong></span></td><td>${esc(u.team||ctx.team?.name||'')}</td><td>${st.calls}</td><td>${st.y01}</td><td>${st.y02}</td><td>${st.rate}%</td><td><span class="premium-count-badge">${ls.length}</span></td><td><button class="btn small">Xem Dashboard ›</button></td></tr>`}).join('');
  }else{
    performanceRows=dateRange(from,to,366).slice().reverse().map(d=>{const st=v81Stats(calls.filter(x=>dateKey(x.created_at)===d)),ls=periodLeads.filter(x=>dateKey(x.lead_created_at)===d);return `<tr><td><strong>${shortDate(d)}</strong></td><td>${st.calls}</td><td>${st.y01}</td><td>${st.y02}</td><td>${st.y03}</td><td>${st.rate}%</td><td>${ls.length}</td></tr>`}).join('');
  }
  const openLeads=allLeads.filter(v81LeadIsOpen).sort((a,b)=>v81LeadAge(b)-v81LeadAge(a)||String(a.lead_created_at).localeCompare(String(b.lead_created_at))).slice(0,6);
  const back=ctx.view==='team'&&['admin','sup'].includes(state.session.user.role)?'<button class="btn" id="dash-back-all">← Toàn hệ thống</button>':ctx.view==='user'&&state.session.user.role!=='sale'?`<button class="btn" id="dash-back-scope">← ${esc(ctx.team?.name||'Đội ngũ')}</button>`:'';
  const perfHead=ctx.view==='all'?'<th>Team</th><th>Nhân viên</th><th>Tổng gọi</th><th>Y01</th><th>Y02</th><th>Tỷ lệ kết nối</th><th>Lead</th><th></th>':ctx.view==='team'?'<th>Nhân viên</th><th>Team</th><th>Tổng gọi</th><th>Y01</th><th>Y02</th><th>Tỷ lệ kết nối</th><th>Lead</th><th></th>':'<th>Ngày</th><th>Tổng gọi</th><th>Y01</th><th>Y02</th><th>Y03</th><th>Tỷ lệ kết nối</th><th>Lead</th>';
  main.innerHTML=`<div class="premium-page v81-dashboard">
    <div class="premium-page-head"><div class="premium-page-title">${back}<h1>${esc(ctx.title)}</h1><p>${esc(ctx.subtitle)}</p></div><div class="v81-range-filter"><label><span>Từ ngày</span><input id="dash-from" type="date" value="${esc(from)}"></label><span class="range-arrow">→</span><label><span>Đến ngày</span><input id="dash-to" type="date" value="${esc(to)}"></label><button class="btn" id="dash-7d">7 ngày</button><button class="btn" id="dash-30d">30 ngày</button><button class="btn primary" id="dash-today">Hôm nay</button></div></div>
    <section class="crm-kpi-grid"><article class="crm-kpi-card"><div class="crm-kpi-icon blue">${uiIcon('customers')}</div><div><span>Tổng khách hàng</span><strong>${customers.length.toLocaleString('vi-VN')}</strong><small>Trong phạm vi đang xem</small></div></article><article class="crm-kpi-card crm-kpi-card-clickable" id="dash-open-call-details" role="button" tabindex="0" title="Xem Chi tiết cuộc gọi"><div class="crm-kpi-icon green">${uiIcon('call')}</div><div><span>Tổng cuộc gọi</span><strong>${stats.calls.toLocaleString('vi-VN')}</strong><small>${shortDate(from)} → ${shortDate(to)} · Bấm để xem chi tiết</small></div><span class="crm-kpi-card-arrow">→</span></article><article class="crm-kpi-card"><div class="crm-kpi-icon purple">${uiIcon('call')}</div><div><span>Tỷ lệ kết nối</span><strong>${stats.rate}%</strong><small>${stats.connected}/${stats.customers} khách đã gọi</small></div></article><article class="crm-kpi-card"><div class="crm-kpi-icon amber">${uiIcon('lead')}</div><div><span>Lead phát sinh</span><strong>${periodLeads.length}</strong><small>${allLeads.filter(v81LeadIsOpen).length} Lead còn cần xử lý</small></div></article></section>
    <section class="crm-analytics-grid"><article class="crm-panel"><div class="crm-panel-head"><h2>Cuộc gọi theo thời gian</h2><span>${shortDate(from)} - ${shortDate(to)}</span></div><div class="crm-chart-body">${premiumLineChart(trend)}</div></article><article class="crm-panel"><div class="crm-panel-head"><h2>Kết quả cuộc gọi</h2><span>${latest.length} khách đã gọi</span></div><div class="crm-donut-layout">${premiumDonut(latest.length,parts)}<div class="crm-donut-legend">${parts.map((p,i)=>`<div><span><i class="c${i}"></i>${esc(p.name)}</span><strong>${p.value}</strong><small>${latest.length?Math.round(p.value/latest.length*100):0}%</small></div>`).join('')}</div></div></article></section>
    <section class="crm-middle-grid"><article class="crm-panel"><div class="crm-panel-head"><h2>Hiệu suất đội ngũ</h2><span>${ctx.view==='all'?'Bấm Team để xem chi tiết':ctx.view==='team'?'Bấm nhân viên để xem Dashboard cá nhân':'Chi tiết theo ngày'}</span></div><div class="table-wrap" style="border:0;border-radius:0;box-shadow:none"><table class="crm-compact-table"><thead><tr>${perfHead}</tr></thead><tbody>${performanceRows||'<tr><td colspan="8">Chưa có dữ liệu.</td></tr>'}</tbody></table></div></article>
    <article class="crm-panel"><div class="crm-panel-head"><h2>Lead cần theo dõi</h2><button class="crm-panel-tool" id="dash-open-lead">Xem Quản lý Lead</button></div><div class="v81-lead-watch">${openLeads.map(x=>`<div class="v81-lead-watch-row"><div><strong>${esc(x.name||'Khách hàng')}</strong><small>${esc(x.owner||'')} · ${v81LeadAge(x)} ngày tồn</small></div><div>${v81LeadPill(x)}<small>${esc(v81LeadOutcomeText(x))}</small></div></div>`).join('')||'<div class="empty small-empty">Không có Lead tồn cần xử lý.</div>'}</div></article></section>
    <section class="crm-panel"><div class="crm-panel-head"><h2>Hoạt động cuộc gọi gần đây</h2><button class="crm-panel-tool" id="dash-open-history">Xem lịch sử</button></div><div class="table-wrap" style="border:0;border-radius:0;box-shadow:none"><table class="data-table crm-recent-table"><thead><tr><th>Khách hàng</th><th>Số điện thoại</th><th>Nhân viên</th><th>Thời gian gọi</th><th>Kết quả</th><th>Ghi chú</th></tr></thead><tbody>${recent.map(x=>{const c=premiumCustomer(x.customer_id)||{};return `<tr><td><strong>${esc(c.name||'')}</strong></td><td>${esc(c.phone||'')}</td><td>${esc(x.owner||'')}</td><td>${esc(fmtDate(x.created_at))}</td><td>${statusPill(x.status)}</td><td>${esc(x.note||'')}</td></tr>`}).join('')||'<tr><td colspan="6">Chưa có cuộc gọi trong khoảng đang xem.</td></tr>'}</tbody></table></div></section>
  </div>`;
  const setRange=async(a,b)=>{if(!a||!b||a>b){toast('Khoảng ngày không hợp lệ.','bad');return;}if(v81DateSpan(a,b)>366){toast('Mỗi lần xem tối đa 366 ngày.','bad');return;}state.dashboardFrom=a;state.dashboardTo=b;try{await ensureCallsRange(a,b);const dl=$('#global-date-label');if(dl)dl.textContent=premiumDateLabel();renderDashboard(main);}catch(e){toast(e.message,'bad')}};
  $('#dash-from').onchange=e=>setRange(e.target.value,state.dashboardTo);$('#dash-to').onchange=e=>setRange(state.dashboardFrom,e.target.value);$('#dash-today').onclick=()=>setRange(todayISO(),todayISO());$('#dash-7d').onclick=()=>setRange(addDays(todayISO(),-6),todayISO());$('#dash-30d').onclick=()=>setRange(addDays(todayISO(),-29),todayISO());
  if($('#dash-back-all'))$('#dash-back-all').onclick=()=>{state.dashboardDrillTeamId='';state.dashboardDrillUserId='';renderDashboard(main)};if($('#dash-back-scope'))$('#dash-back-scope').onclick=()=>{state.dashboardDrillUserId='';renderDashboard(main)};
  $$('[data-dashboard-team]').forEach(r=>r.onclick=()=>{state.dashboardDrillTeamId=r.dataset.dashboardTeam;state.dashboardDrillUserId='';renderDashboard(main)});$$('[data-dashboard-user]').forEach(r=>r.onclick=()=>{state.dashboardDrillUserId=r.dataset.dashboardUser;renderDashboard(main)});
  const openDashboardCallDetails=()=>{
    state.callDetailFrom=from;
    state.callDetailTo=to;
    state.callDetailStatus='';
    if(['admin','sup'].includes(state.session.user.role)||state.session.user.role==='teamlead'){
      state.callDetailTeam=ctx.view==='all'?'':String(ctx.team?.id||state.session.user.team_id||'');
      state.callDetailEmployee=ctx.view==='user'?String(ctx.user?.id||''):'';
    }
    navigate('customerdb');
  };
  const callCard=$('#dash-open-call-details');
  if(callCard){
    callCard.onclick=openDashboardCallDetails;
    callCard.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openDashboardCallDetails();}};
  }
  $('#dash-open-lead').onclick=()=>navigate('lead');$('#dash-open-history').onclick=()=>navigate('callhistory');
}


function v81_override_leadStagePill(status,row=null){
  if(row)return v81LeadPill(row);
  if(!status)return '<span class="lead-stage new">Chờ xử lý</span>';
  const cls=status==='LOGIN_APP'?'login':status==='SIGNED'?'signed':LEAD_NEGATIVE_STATUSES.has(status)||status==='OTHER'?'negative':'new';
  return `<span class="lead-stage ${cls}">${esc(LEAD_STATUS_LABELS[status]||status)}</span>`;
}
function v81LeadPeriodRows(){
  const rows=leadScopeRows(),from=state.leadDateFrom||'',to=state.leadDateTo||'';
  return rows.filter(x=>{const d=dateKey(x.lead_created_at);return d&&(!from||d>=from)&&(!to||d<=to);});
}
function v81_override_leadDateScopeRows(){
  const period=v81LeadPeriodRows(),open=leadScopeRows().filter(v81LeadIsOpen),map=new Map();[...period,...open].forEach(x=>map.set(String(x.customer_id),x));return [...map.values()];
}
function v81_override_leadFilteredRows(){
  const q=(state.leadSearch||'').trim().toLowerCase();
  return leadDateScopeRows().filter(x=>{
    const s=state.leadStatusFilter;
    if(s==='UNPROCESSED'&&x.lead_status)return false;
    if(s==='OPEN'&&!v81LeadIsOpen(x))return false;
    if(s==='NO_APP'&&!(LEAD_NEGATIVE_STATUSES.has(x.lead_status)||(x.lead_status==='OTHER'&&!Number(x.ever_login_app))))return false;
    if(s==='APP_FAILED'&&!(x.lead_status==='OTHER'&&Number(x.ever_login_app)))return false;
    if(s&& !['UNPROCESSED','OPEN','NO_APP','APP_FAILED'].includes(s)&&x.lead_status!==s)return false;
    if(q&&!`${x.name||''} ${x.phone||''} ${x.owner||''} ${x.source||''} ${x.team||''} ${x.lead_reason||''}`.toLowerCase().includes(q))return false;
    return true;
  }).sort((a,b)=>Number(v81LeadIsOpen(b))-Number(v81LeadIsOpen(a))||(v81LeadIsOpen(a)?String(a.lead_created_at).localeCompare(String(b.lead_created_at)):String(b.lead_created_at).localeCompare(String(a.lead_created_at))));
}
function v81_override_leadTeamTabsHtml(){
  const role=state.session.user.role;if(role==='sale')return '';
  if(role==='teamlead')return `<div class="lead-team-tabs"><button class="lead-team-tab active" type="button">${esc(state.session.user.team||'Team của bạn')} <span>${leadDateScopeRows().length}</span></button></div>`;
  const rows=leadDateScopeRows();return `<div class="lead-team-tabs"><button class="lead-team-tab ${!state.leadTeamFilter?'active':''}" data-lead-team-tab="">Tất cả Team <span>${rows.length}</span></button>${state.teamObjects.map(t=>`<button class="lead-team-tab ${String(state.leadTeamFilter)===String(t.id)?'active':''}" data-lead-team-tab="${t.id}">${esc(t.name)} <span>${rows.filter(x=>String(x.team_id)===String(t.id)).length}</span></button>`).join('')}</div>`;
}
function v81_override_leadRowsHtml(){
  const role=state.session.user.role,rows=leadFilteredRows(),colCount=(role==='admin'||role==='sup')?9:role==='sale'?7:8;
  if(!rows.length)return `<tr><td colspan="${colCount}"><div class="empty">Không có Lead phù hợp.</div></td></tr>`;
  return rows.map(x=>{const age=v81LeadAge(x),open=v81LeadIsOpen(x),latestNote=x.latest_lead_note||x.lead_reason||'';return `<tr class="${open?'v81-lead-open':''}"><td><div class="lead-customer"><strong>${esc(x.name)}</strong><small>${esc(x.phone||'')} · ${statusPill(x.source_call_status)}</small></div></td><td><strong>${shortDate(dateKey(x.lead_created_at))}</strong><small class="v81-age ${age>=3&&open?'overdue':''}">${age} ngày tồn</small></td>${(role==='admin'||role==='sup')?`<td>${esc(x.team||'—')}</td>`:''}${role!=='sale'?`<td>${esc(x.owner||'Chưa giao')}</td>`:''}<td>${v81LeadPill(x)}<small>${esc(v81LeadOutcomeText(x))}</small></td><td>${x.lead_status==='SIGNED'?'<span class="status y01">Hoàn tất</span>':open?'<span class="status y02">Cần theo dõi</span>':'<span class="status new">Đã kết luận</span>'}</td><td><div class="v81-lead-note">${esc(latestNote||'—')}</div></td><td>${x.lead_updated_at?fmtDate(x.lead_updated_at):'<span class="muted">Chưa cập nhật</span>'}</td><td><div class="lead-actions">${x.lead_status==='SIGNED'?'<span class="muted">Đã giải ngân</span>':`<button class="btn small primary" data-lead-update="${x.customer_id}">Cập nhật</button>`}<button class="btn small" data-lead-note="${x.customer_id}">Ghi chú</button><button class="btn small" data-lead-history="${x.customer_id}">Lịch sử</button>${['admin','sup','teamlead'].includes(role)?`<button class="btn small danger" data-lead-delete="${x.customer_id}">Xóa</button>`:''}</div></td></tr>`}).join('');
}
function v81_override_leadExportRows(){return leadFilteredRows().map((x,i)=>({'STT':i+1,'Khách hàng':x.name||'','Số điện thoại':String(x.phone||''),'Ngày phát sinh Lead':dateKey(x.lead_created_at)||'','Số ngày tồn':v81LeadAge(x),'Nguồn Data':x.source||'','Team':x.team||'','Nhân viên':x.owner||'','Giai đoạn':v81LeadOutcomeText(x),'Trạng thái hệ thống':x.lead_status||'CHUA_XU_LY','Lý do':x.lead_reason||'','Ghi chú mới nhất':x.latest_lead_note||'','Cập nhật Lead lúc':x.lead_updated_at?fmtDate(x.lead_updated_at):'','Người cập nhật':x.changed_by||''}));}
function v81_override_renderLeads(main){
  const role=state.session.user.role;if(!state.leadDateTo)state.leadDateTo=todayISO();if(!state.leadDateFrom)state.leadDateFrom=addDays(state.leadDateTo,-29);
  if(state.mode==='d1'&&(!state.leadLoadedAt||Date.now()-state.leadLoadedAt>60000)&&!state.leadLoading){main.innerHTML='<div class="empty">Đang tải Lead…</div>';loadLeads(true).then(()=>{if(state.page==='lead')renderLeads(main)});return;}
  const period=v81LeadPeriodRows(),scope=leadScopeRows(),visible=leadFilteredRows(),open=scope.filter(v81LeadIsOpen),unprocessed=scope.filter(x=>!x.lead_status).length,loginPending=scope.filter(x=>x.lead_status==='LOGIN_APP').length,signed=period.filter(x=>x.lead_status==='SIGNED').length,noApp=period.filter(x=>LEAD_NEGATIVE_STATUSES.has(x.lead_status)||(x.lead_status==='OTHER'&&!Number(x.ever_login_app))).length,appFailed=period.filter(x=>x.lead_status==='OTHER'&&Number(x.ever_login_app)).length;
  main.innerHTML=`<div class="premium-page v81-leads"><div class="premium-page-head"><div class="premium-page-title"><h1>Quản lý Lead</h1><p>Theo dõi xuyên suốt Lead → Login App → Giải ngân. Lead chưa hoàn tất không biến mất khi qua ngày.</p></div><div class="v81-range-filter"><label><span>Từ ngày phát sinh</span><input id="lead-date-from" type="date" value="${esc(state.leadDateFrom)}"></label><span class="range-arrow">→</span><label><span>Đến ngày</span><input id="lead-date-to" type="date" value="${esc(state.leadDateTo)}"></label><button class="btn" id="lead-30d">30 ngày</button><button class="btn" id="lead-refresh">↻ Làm mới</button><button class="btn" id="lead-export-excel">⬇ Excel</button></div></div>
  ${state.leadError?`<div class="notice warning">${esc(state.leadError)}</div>`:''}<div class="notice v81-lead-notice"><strong>Không bỏ sót Lead:</strong> khoảng ngày dùng để xem Lead phát sinh trong kỳ; mọi Lead còn <strong>Chưa xử lý</strong> hoặc <strong>Đã Login App nhưng chưa có kết quả giải ngân</strong> vẫn được giữ trong danh sách xử lý.</div>
  <section class="v81-lead-summary"><article><span>Lead phát sinh trong kỳ</span><strong>${period.length}</strong><small>${shortDate(state.leadDateFrom)} → ${shortDate(state.leadDateTo)}</small></article><article class="warn"><span>Lead tồn cần xử lý</span><strong>${open.length}</strong><small>${unprocessed} chưa xác định chuyển App</small></article><article><span>Chờ chuyển App</span><strong>${unprocessed}</strong><small>Cần cập nhật kết quả</small></article><article class="login"><span>Đã Login App</span><strong>${loginPending}</strong><small>Đang chờ giải ngân</small></article><article class="success"><span>Đã giải ngân</span><strong>${signed}</strong><small>Trong khoảng ngày</small></article><article class="negative"><span>Không chuyển / không giải ngân</span><strong>${noApp+appFailed}</strong><small>${noApp} không App · ${appFailed} App không giải ngân</small></article></section>
  ${leadTeamTabsHtml()}<section class="crm-panel"><div class="v81-lead-toolbar"><input id="lead-search" class="search" placeholder="Tìm tên, SĐT, nhân viên, Team, lý do…" value="${esc(state.leadSearch)}"><select id="lead-status-filter"><option value="">Tất cả trạng thái</option><option value="OPEN" ${state.leadStatusFilter==='OPEN'?'selected':''}>Lead tồn cần xử lý</option><option value="UNPROCESSED" ${state.leadStatusFilter==='UNPROCESSED'?'selected':''}>Chưa xác định chuyển App</option><option value="LOGIN_APP" ${state.leadStatusFilter==='LOGIN_APP'?'selected':''}>Đã Login App · chờ giải ngân</option><option value="SIGNED" ${state.leadStatusFilter==='SIGNED'?'selected':''}>Đã giải ngân</option><option value="NO_APP" ${state.leadStatusFilter==='NO_APP'?'selected':''}>Không chuyển App</option><option value="APP_FAILED" ${state.leadStatusFilter==='APP_FAILED'?'selected':''}>Login App nhưng không giải ngân</option></select><span>${visible.length} Lead đang hiển thị</span></div><div class="table-wrap"><table class="data-table v81-lead-table"><thead><tr><th>Khách hàng</th><th>Phát sinh / Tồn</th>${(role==='admin'||role==='sup')?'<th>Team</th>':''}${role!=='sale'?'<th>Nhân viên</th>':''}<th>Giai đoạn Lead</th><th>Kiểm soát</th><th>Lý do / Ghi chú</th><th>Cập nhật cuối</th><th>Thao tác</th></tr></thead><tbody id="lead-table-body">${leadRowsHtml()}</tbody></table></div></section></div>`;
  const setRange=(a,b)=>{if(!a||!b||a>b){toast('Khoảng ngày không hợp lệ.','bad');return;}state.leadDateFrom=a;state.leadDateTo=b;renderLeads(main)};$('#lead-date-from').onchange=e=>setRange(e.target.value,state.leadDateTo);$('#lead-date-to').onchange=e=>setRange(state.leadDateFrom,e.target.value);$('#lead-30d').onclick=()=>{state.leadDateTo=todayISO();state.leadDateFrom=addDays(state.leadDateTo,-29);renderLeads(main)};$('#lead-refresh').onclick=async()=>{state.leadLoadedAt=0;await loadLeads(true);renderLeads(main)};$('#lead-export-excel').onclick=exportLeadsExcel;$('#lead-add-manual')?.addEventListener('click',v1027OpenManualLeadModal);$('#lead-search').oninput=e=>{state.leadSearch=e.target.value;refreshLeadTableOnly()};$('#lead-status-filter').onchange=e=>{state.leadStatusFilter=e.target.value;renderLeads(main)};$$('[data-lead-team-tab]').forEach(b=>b.onclick=()=>{state.leadTeamFilter=b.dataset.leadTeamTab||'';renderLeads(main)});bindLeadRows();
}
function v81_override_openLeadUpdateModal(customerId){
  const x=(state.leads||[]).find(v=>Number(v.customer_id)===Number(customerId));if(!x)return;const everLogin=Number(x.ever_login_app)>0||x.lead_status==='LOGIN_APP'||x.lead_status==='SIGNED';
  if(x.lead_status==='SIGNED'){openAdminModal(`Lead đã hoàn tất · ${x.name}`,`<div class="notice"><strong>Khách hàng đã giải ngân.</strong> Tiến trình được giữ lại để báo cáo. Nếu cần bổ sung thông tin, hãy dùng chức năng Ghi chú.</div><div class="call-actions"><button class="btn" id="lead-done-close">Đóng</button></div>`);$('#lead-done-close').onclick=closeAdminModal;return;}
  const options=everLogin?`<option value="SIGNED">Đã giải ngân</option><option value="OTHER">Login App nhưng không giải ngân / lý do khác</option>`:`<option value="LOGIN_APP">Đã chuyển thành Login App</option><option value="HIGH_DEBT">Không chuyển App · dư nợ cao</option><option value="BAD_DEBT">Không chuyển App · nợ xấu</option><option value="NEW_DEBT">Không chuyển App · mới phát sinh dư nợ</option><option value="OTHER">Không chuyển App · lý do khác</option>`;
  openAdminModal(`Cập nhật Lead · ${x.name}`,`<form id="lead-update-form" class="form-grid"><div class="form-field full"><label>Giai đoạn hiện tại</label><div>${v81LeadPill(x)} <span class="muted">${esc(v81LeadOutcomeText(x))}</span></div></div><div class="form-field full"><label>Kết quả tiếp theo</label><select id="lead-next-status" required><option value="">-- Chọn kết quả --</option>${options}</select></div><div class="form-field full" id="lead-reason-wrap"><label>Lý do / ghi chú trạng thái</label><textarea id="lead-status-reason" rows="3" maxlength="500" placeholder="Nhập lý do khi không chuyển App hoặc không giải ngân..."></textarea><small class="muted">Bắt buộc khi chọn “Lý do khác”. Lịch sử thay đổi được lưu riêng.</small></div><div class="form-field full"><div class="notice">Luồng kiểm soát: <strong>Lead → Login App → Giải ngân</strong>. Lead chưa kết luận luôn nằm trong danh sách tồn để tiếp tục theo dõi.</div></div><div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="lead-update-cancel">Hủy</button><button class="btn primary" type="submit">Lưu kết quả Lead</button></div></div></form>`);
  $('#lead-update-cancel').onclick=closeAdminModal;$('#lead-next-status').onchange=()=>{$('#lead-status-reason').required=$('#lead-next-status').value==='OTHER'};$('#lead-update-form').onsubmit=async e=>{e.preventDefault();const status=$('#lead-next-status').value,reason=$('#lead-status-reason').value.trim();if(!status)return;if(status==='OTHER'&&!reason){toast('Vui lòng nhập lý do.','bad');return;}try{await API.request(`/leads/${customerId}/status`,{method:'POST',body:JSON.stringify({status,reason})});closeAdminModal();state.leadLoadedAt=0;await loadLeads(true);renderLeads($('#main'));toast('Đã cập nhật tiến trình Lead.');}catch(err){toast(err.message,'bad')}};
}

function v81_override_renderEmployees(main){
  const role=state.session.user.role;if(role==='sale'){main.innerHTML='<div class="empty">Bạn không có quyền truy cập Nhân sự.</div>';return;}const isAdmin=(role==='admin'||role==='sup'),ownTeam=String(state.session.user.team_id||'');if(role==='teamlead')state.employeeTeamFilter=ownTeam;
  const all=state.users.filter(u=>u.active!==0&&(isAdmin||String(u.team_id)===ownTeam)),teams=(isAdmin?state.teamObjects:state.teamObjects.filter(t=>String(t.id)===ownTeam));const selected=String(state.employeeTeamFilter||''),q=(state.premiumEmployeeSearch||'').toLowerCase(),rf=state.premiumEmployeeRole||'';
  const rows=all.filter(u=>(!selected||String(u.team_id)===selected)&&matchesStaffRoleFilter(u,rf)&&(!q||`${u.display_name} ${u.username} ${u.team||''}`.toLowerCase().includes(q))).sort((a,b)=>(v1032RoleOrder[staffRoleKey(a)]??9)-(v1032RoleOrder[staffRoleKey(b)]??9)||String(a.team||'').localeCompare(String(b.team||''),'vi')||String(a.display_name).localeCompare(String(b.display_name),'vi'));
  const sales=all.filter(u=>u.role==='sale'&&staffRoleKey(u)==='sales'),freelancers=all.filter(u=>u.role==='sale'&&staffRoleKey(u)==='freelancer'),leaders=all.filter(u=>u.role==='teamlead'),activeTeams=new Set(all.filter(u=>u.team_id).map(u=>String(u.team_id))).size,today=todayISO();
  const teamCounts=new Map(),assignedCounts=new Map(),todayCalls=new Map(),leaderByTeam=new Map();
  for(const u of all){if(u.team_id)teamCounts.set(String(u.team_id),(teamCounts.get(String(u.team_id))||0)+1);if(u.role==='teamlead'&&u.team_id&&!leaderByTeam.has(String(u.team_id)))leaderByTeam.set(String(u.team_id),u);}
  for(const c of state.customers){const id=Number(c.assigned_user_id||0);if(id)assignedCounts.set(id,(assignedCounts.get(id)||0)+1);}
  for(const c of state.calls){if(dateKey(c.created_at)!==today)continue;const id=Number(c.user_id||0);if(id)todayCalls.set(id,(todayCalls.get(id)||0)+1);}
  const tabs=`<div class="v81-team-tabs">${isAdmin?`<button class="v81-team-tab ${!selected?'active':''}" data-staff-team="">Tất cả <span>${all.length}</span></button>`:''}${teams.map(t=>`<button class="v81-team-tab ${selected===String(t.id)?'active':''}" data-staff-team="${t.id}">${esc(t.name)} <span>${teamCounts.get(String(t.id))||0}</span></button>`).join('')}</div>`;
  main.innerHTML=`<div class="premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Quản lý nhóm và nhân viên</h1><p>Chuyển Team bằng các tab bên dưới, sau đó tìm kiếm và quản lý nhân viên trong đúng phạm vi.</p></div><div class="premium-page-actions">${isAdmin?'<button class="btn" id="add-admin">+ Admin</button><button class="btn" id="add-team">+ Tạo nhóm</button>':''}<button class="btn primary" id="add-employee">+ Thêm nhân viên</button></div></div><section class="staff-summary-grid"><article class="staff-summary"><div class="staff-summary-icon blue">${uiIcon('users')}</div><div class="staff-summary-copy"><span>Tổng tài khoản</span><strong>${all.length}</strong><small>đang hoạt động</small></div></article><article class="staff-summary"><div class="staff-summary-icon green">${uiIcon('users')}</div><div class="staff-summary-copy"><span>Team Leader</span><strong>${leaders.length}</strong><small>người</small></div></article><article class="staff-summary"><div class="staff-summary-icon purple">${uiIcon('customers')}</div><div class="staff-summary-copy"><span>Sales</span><strong>${sales.length}</strong><small>${freelancers.length} Freelancer</small></div></article><article class="staff-summary"><div class="staff-summary-icon amber">${uiIcon('warehouse')}</div><div class="staff-summary-copy"><span>Team đang hoạt động</span><strong>${activeTeams}</strong><small>nhóm</small></div></article></section>${tabs}<div class="crm-data-toolbar v81-staff-toolbar"><input id="staff-q" placeholder="Tìm kiếm nhân viên trong Team đang chọn..." value="${esc(state.premiumEmployeeSearch||'')}"><select id="staff-role"><option value="">Tất cả vai trò</option><option value="admin" ${rf==='admin'?'selected':''}>Admin</option><option value="sup" ${rf==='sup'?'selected':''}>Sup</option><option value="teamlead" ${rf==='teamlead'?'selected':''}>Team Leader</option><option value="sale" ${rf==='sale'?'selected':''}>Sales</option><option value="freelancer" ${rf==='freelancer'?'selected':''}>Freelancer</option></select><div class="v81-selected-team-label">${selected?`Đang xem: <strong>${esc(teams.find(t=>String(t.id)===selected)?.name||'Team')}</strong>`:'Đang xem: <strong>Tất cả Team</strong>'}</div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Nhân viên</th><th>User (Tên đăng nhập)</th><th>Nhóm</th><th>Team Leader</th><th>Vai trò</th><th>Số khách được giao</th><th>Cuộc gọi hôm nay</th><th>Tiến độ KPI</th><th>Trạng thái</th><th>Thao tác</th></tr></thead><tbody>${rows.map(u=>{const leader=leaderByTeam.get(String(u.team_id||'')),assigned=assignedCounts.get(Number(u.id))||0,calls=todayCalls.get(Number(u.id))||0,target=Number(userKpiTarget(u.id).calls_daily||50),pct=u.role==='sale'?(target?Math.min(100,Math.round(calls/target*100)):0):100;return `<tr><td><span class="crm-person"><i class="crm-avatar-mini">${esc(initials(u.display_name))}</i><strong>${esc(u.display_name)}</strong></span></td><td><strong class="staff-username">@${esc(u.username||'—')}</strong></td><td>${esc(u.team||'—')}</td><td>${u.role==='admin'?'—':esc(leader?.display_name||'—')}</td><td><span class="role-pill ${staffRoleKey(u)}">${esc(staffRoleLabel(u))}</span></td><td>${assigned}</td><td>${calls}</td><td><div class="crm-kpi-cell"><div class="crm-progress"><i style="width:${pct}%"></i></div><b>${pct}%</b></div></td><td><span class="staff-status active">Hoạt động</span></td><td><div class="crm-action-buttons"><button class="crm-icon-action" data-edit-user="${u.id}" title="Sửa">✎</button>${u.role!=='admin'?`<button class="crm-icon-action" data-delete-user="${u.id}" title="Xóa">⋯</button>`:''}</div></td></tr>`}).join('')||'<tr><td colspan="10">Không có nhân viên phù hợp.</td></tr>'}</tbody></table></div></div>`;
  $$('[data-staff-team]').forEach(b=>b.onclick=()=>{state.employeeTeamFilter=b.dataset.staffTeam;state.premiumEmployeeSearch='';renderEmployees(main)});$('#staff-q').oninput=e=>{state.premiumEmployeeSearch=e.target.value;renderEmployees(main);requestAnimationFrame(()=>{$('#staff-q')?.focus()})};$('#staff-role').onchange=e=>{state.premiumEmployeeRole=e.target.value;renderEmployees(main)};if($('#add-admin'))$('#add-admin').onclick=adminUserForm;if($('#add-team'))$('#add-team').onclick=openTeamForm;$('#add-employee').onclick=()=>employeeForm();$$('[data-edit-user]').forEach(b=>b.onclick=()=>employeeForm(state.users.find(u=>u.id===Number(b.dataset.editUser))));$$('[data-delete-user]').forEach(b=>b.onclick=()=>deleteEmployee(state.users.find(u=>u.id===Number(b.dataset.deleteUser))));
}

function v81_override_renderKPI(main){
  const role=state.session.user.role;
  if(!state.kpiTo)state.kpiTo=todayISO();
  if(!state.kpiFrom)state.kpiFrom=state.kpiTo;
  const from=state.kpiFrom,to=state.kpiTo;
  if(state.mode==='d1'&&!isCallsRangeLoaded(from,to)){main.innerHTML='<div class="empty">Đang tải dữ liệu KPI…</div>';ensureCallsRange(from,to).then(()=>{if(state.page==='kpi')renderKPI(main)}).catch(e=>toast(e.message,'bad'));return;}
  let teamFilter=role==='teamlead'?String(state.session.user.team_id||''):role==='sale'?String(state.session.user.team_id||''):String(state.premiumKpiTeam||'');
  let userFilter=role==='sale'?String(state.session.user.id):String(state.premiumKpiUser||'');
  let users=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||String(u.team_id)===String(state.session.user.team_id)));
  if((role==='admin'||role==='sup')&&teamFilter)users=users.filter(u=>String(u.team_id)===teamFilter);
  if(role==='teamlead')users=users.filter(u=>String(u.team_id)===String(state.session.user.team_id));
  if(role==='sale')users=users.filter(u=>String(u.id)===String(state.session.user.id));
  if(userFilter)users=users.filter(u=>String(u.id)===userFilter);
  const days=v81DateSpan(from,to);
  const calls=v81CallsForUsers(from,to,users);
  const latest=latestCallsByCustomer(calls);
  const connected=latest.filter(x=>String(x.status).startsWith('Y')).length;
  const leadCount=latest.filter(x=>['Y01','Y02'].includes(String(x.status))).length;
  const targetCalls=users.reduce((n,u)=>n+Number(userKpiTarget(u.id).calls_daily||50)*days,0);
  const actualCalls=calls.length;
  const connRate=latest.length?Math.round(connected/latest.length*1000)/10:0;
  const canSet=(role==='admin'||role==='sup')||role==='teamlead';
  state.kpiDetailMode=(state.kpiDetailMode||'team');
  if(role==='sale')state.kpiDetailMode='user';

  const metricChartMax=Math.max(1,targetCalls,actualCalls);
  const metricBars=[{label:'Mục tiêu',value:targetCalls,cls:'target'},{label:'Thực đạt',value:actualCalls,cls:'actual'}];

  const compareBaseUsers=(()=>{
    let base=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||String(u.team_id)===String(state.session.user.team_id)));
    if((role==='admin'||role==='sup')&&teamFilter)base=base.filter(u=>String(u.team_id)===teamFilter);
    if(role==='sale')base=base.filter(u=>String(u.id)===String(state.session.user.id));
    return base;
  })();
  const teamRows=(teamFilter&&(role!=='admin'&&role!=='sup')?state.teamObjects.filter(t=>String(t.id)===teamFilter||String(t.id)===String(state.session.user.team_id)):state.teamObjects)
    .map(t=>{
      const us=compareBaseUsers.filter(u=>String(u.team_id)===String(t.id));
      if(!us.length)return null;
      const cs=v81CallsForUsers(from,to,us),l=latestCallsByCustomer(cs),tar=us.reduce((n,u)=>n+Number(userKpiTarget(u.id).calls_daily||50)*days,0),con=l.filter(x=>String(x.status).startsWith('Y')).length,lead=l.filter(x=>['Y01','Y02'].includes(String(x.status))).length,pct=tar?Math.round(cs.length/tar*100):0;
      return {key:String(t.id),name:t.name,subtitle:`${us.length} nhân viên`,calls:cs.length,target:tar,connected:con,leads:lead,connRate:l.length?Math.round(con/l.length*1000)/10:0,pct};
    }).filter(Boolean).sort((a,b)=>b.calls-a.calls);

  const userRows=users.map(u=>{const cs=v81CallsForUsers(from,to,[u]),l=latestCallsByCustomer(cs),con=l.filter(x=>String(x.status).startsWith('Y')).length,lead=l.filter(x=>['Y01','Y02'].includes(String(x.status))).length,tar=Number(userKpiTarget(u.id).calls_daily||50)*days,pct=tar?Math.round(cs.length/tar*100):0;return {key:String(u.id),name:u.display_name,subtitle:u.team||'',calls:cs.length,target:tar,connected:con,leads:lead,connRate:l.length?Math.round(con/l.length*1000)/10:0,pct};}).sort((a,b)=>b.pct-a.pct||b.calls-a.calls);
  const detailRows=state.kpiDetailMode==='user'?userRows:teamRows;
  const detailLabel=state.kpiDetailMode==='user'?'Nhân viên':'Nhóm';
  const teamOptionsKpi=(role==='admin'||role==='sup')?`<option value="">Tất cả nhóm</option>${state.teamObjects.map(t=>`<option value="${t.id}" ${String(t.id)===teamFilter?'selected':''}>${esc(t.name)}</option>`).join('')}`:`<option value="${esc(state.session.user.team_id||'')}">${esc(state.session.user.team||'Team của bạn')}</option>`;
  const userSource=role==='sale'?users:state.users.filter(u=>u.role==='sale'&&(!teamFilter||String(u.team_id)===teamFilter)&&((role==='admin'||role==='sup')||String(u.team_id)===String(state.session.user.team_id)));
  const userOptions=userSource.map(u=>`<option value="${u.id}" ${String(u.id)===userFilter?'selected':''}>${esc(u.display_name)}</option>`).join('');

  main.innerHTML=`<div class="kpi-page premium-page kpi-v92-page"><div class="premium-page-head"><div class="premium-page-title"><h1>KPI & Hiệu suất</h1><p>${shortDate(from)} - ${shortDate(to)} · Theo dõi chỉ tiêu và thực đạt theo phạm vi đã chọn.</p></div><div class="premium-page-actions">${canSet?'<button class="btn primary" id="kpi-bulk-open">Chỉnh chỉ tiêu</button>':''}</div></div>
    <section class="v81-kpi-filter-grid"><div class="v81-kpi-filter range"><label><span>Từ ngày</span><input id="kpi-from" type="date" value="${esc(from)}"></label><span class="range-arrow">→</span><label><span>Đến ngày</span><input id="kpi-to" type="date" value="${esc(to)}"></label></div><div class="v81-kpi-filter selectable ${(role!=='admin'&&role!=='sup')?'locked':''}"><label>Nhóm</label><select id="kpi-team" ${(role==='admin'||role==='sup')?'':'disabled'}>${teamOptionsKpi}</select></div><div class="v81-kpi-filter selectable ${role==='sale'?'locked':''}"><label>Nhân viên</label><select id="kpi-user" ${role==='sale'?'disabled':''}><option value="">Tất cả nhân viên</option>${userOptions}</select></div></section>
    <section class="kpi-v92-metric-grid"><article class="kpi-v92-metric-card"><span>Mục tiêu cuộc gọi</span><strong>${targetCalls.toLocaleString('vi-VN')}</strong><small>${days} ngày theo phạm vi chọn</small></article><article class="kpi-v92-metric-card"><span>Thực đạt cuộc gọi</span><strong>${actualCalls.toLocaleString('vi-VN')}</strong><small>${targetCalls?Math.round(actualCalls/Math.max(1,targetCalls)*100):0}% mục tiêu</small></article><article class="kpi-v92-metric-card"><span>Tỷ lệ kết nối</span><strong>${connRate}%</strong><small>${connected}/${latest.length} khách đã gọi</small></article><article class="kpi-v92-metric-card"><span>Lead</span><strong>${leadCount.toLocaleString('vi-VN')}</strong><small>Khách Y01 + Y02</small></article></section>
    <section class="kpi-v92-dual">
      <article class="crm-panel"><div class="crm-panel-head"><h2>KPI mục tiêu vs Thực đạt</h2><span>${shortDate(from)} - ${shortDate(to)}</span></div><div class="kpi-v92-bar-panel">${metricBars.map(r=>`<div class="kpi-v92-bar-item"><div class="kpi-v92-bar-value">${r.value.toLocaleString('vi-VN')}</div><div class="kpi-v92-bar-track"><i class="${r.cls}" style="height:${Math.max(12,Math.round(r.value/metricChartMax*100))}%"></i></div><div class="kpi-v92-bar-label">${esc(r.label)}</div></div>`).join('')}</div></article>
      <article class="crm-panel"><div class="crm-panel-head"><h2>So sánh các nhóm</h2><span>Theo tổng cuộc gọi</span></div><div class="kpi-v92-compare-list">${teamRows.map(r=>`<div class="kpi-v92-compare-row"><div class="kpi-v92-compare-copy"><strong>${esc(r.name)}</strong><small>${esc(r.subtitle)}</small></div><div class="kpi-v92-compare-track"><i style="width:${Math.min(100,r.pct)}%"></i></div><div class="kpi-v92-compare-value">${r.calls}/${r.target}</div></div>`).join('')||'<div class="empty">Không có dữ liệu nhóm.</div>'}</div></article>
    </section>
    <section class="crm-panel"><div class="kpi-v92-detail-head"><div><h2>Chi tiết theo ${state.kpiDetailMode==='user'?'nhân viên':'nhóm'}</h2><span>${detailRows.length} dòng dữ liệu</span></div><div class="kpi-v92-detail-actions"><div class="kpi-v92-toggle"><button class="${state.kpiDetailMode==='team'?'active':''}" data-kpi-mode="team" ${role==='sale'?'disabled':''}>Nhóm</button><button class="${state.kpiDetailMode==='user'?'active':''}" data-kpi-mode="user">Nhân viên</button></div>${canSet?'<button class="btn" id="kpi-adjust-bottom">Chỉnh chỉ tiêu</button>':''}</div></div><div class="table-wrap" style="border:0;border-radius:0;box-shadow:none"><table class="data-table kpi-v92-table"><thead><tr><th>#</th><th>${detailLabel}</th><th>Cuộc gọi</th><th>Kết nối</th><th>Lead</th><th>Tỷ lệ KN</th><th>KPI</th></tr></thead><tbody>${detailRows.map((r,i)=>`<tr><td>${i+1}</td><td><div class="kpi-v92-name"><strong>${esc(r.name)}</strong><small>${esc(r.subtitle||'')}</small></div></td><td><div class="kpi-v92-metric-cell"><div class="kpi-v92-number">${r.calls} / ${r.target}</div><div class="crm-progress"><i style="width:${Math.min(100,r.target?Math.round(r.calls/Math.max(1,r.target)*100):0)}%"></i></div></div></td><td><div class="kpi-v92-metric-cell"><div class="kpi-v92-number">${r.connected} / ${r.calls}</div><div class="crm-progress green"><i style="width:${Math.min(100,r.calls?Math.round(r.connected/Math.max(1,r.calls)*100):0)}%"></i></div></div></td><td><div class="kpi-v92-number">${r.leads}</div></td><td><strong>${r.connRate}%</strong></td><td><div class="kpi-v92-metric-cell"><div class="kpi-v92-number">${r.pct}%</div><div class="crm-progress amber"><i style="width:${Math.min(100,r.pct)}%"></i></div></div></td></tr>`).join('')||`<tr><td colspan="7">Không có dữ liệu.</td></tr>`}</tbody></table></div></section>
  </div>`;

  const setRange=async(a,b)=>{if(!a||!b||a>b){toast('Khoảng ngày không hợp lệ.','bad');return;}if(v81DateSpan(a,b)>366){toast('Mỗi lần xem tối đa 366 ngày.','bad');return;}state.kpiFrom=a;state.kpiTo=b;await ensureCallsRange(a,b);renderKPI(main)};
  $('#kpi-from').onchange=e=>setRange(e.target.value,state.kpiTo);
  $('#kpi-to').onchange=e=>setRange(state.kpiFrom,e.target.value);
  if((role==='admin'||role==='sup'))$('#kpi-team').onchange=e=>{state.premiumKpiTeam=e.target.value;state.premiumKpiUser='';renderKPI(main)};
  if(role!=='sale')$('#kpi-user').onchange=e=>{state.premiumKpiUser=e.target.value;renderKPI(main)};
  $$('[data-kpi-mode]').forEach(b=>b.onclick=()=>{if(b.disabled)return;state.kpiDetailMode=b.dataset.kpiMode;renderKPI(main)});
  if($('#kpi-bulk-open'))$('#kpi-bulk-open').onclick=()=>openBulkKpiForm(to);
  if($('#kpi-adjust-bottom'))$('#kpi-adjust-bottom').onclick=()=>openBulkKpiForm(to);
}

function chatUnreadBySender(){
  const read=notificationReadSet(),map=new Map();
  for(const n of state.chatNotifications||[]){
    if(read.has(notificationAlertKey(n)))continue;
    const k=String(n.sender_user_id||'');
    if(!k)continue;
    map.set(k,(map.get(k)||0)+1);
  }
  return map;
}
async function markChatConversationRead(userId){
  const id=String(userId||'');
  if(!id)return;
  for(const n of state.chatNotifications||[]) if(String(n.sender_user_id||'')===id) markNotificationRead(n);
  state.chatNotifications=(state.chatNotifications||[]).filter(n=>String(n.sender_user_id||'')!==id);
  updateNotifications();updateFloatingChatBadge();
  try{await API.request('/chat/read',{method:'POST',body:JSON.stringify({user_id:Number(id)})});}catch(_e){}
}
function openAdminBroadcastModal(){
  if(!['admin','sup','teamlead'].includes(state.session?.user?.role))return;
  state.floatingChatView='broadcast';
  stopFloatingChatPolling();
  renderFloatingChat();
}
function floatingChatContactGroups(contacts,q,unread){
  const role=state.session?.user?.role||'sale';
  const teamFilter=String(state.floatingChatTeamFilter||'');
  const match=u=>{
    const hay=`${u.display_name||''} ${u.team||''} ${u.username||''}`.toLocaleLowerCase('vi');
    if(q&&!hay.includes(q))return false;
    if((role==='admin'||role==='sup')&&teamFilter){
      if(teamFilter==='__admin__')return u.role==='admin';
      return String(u.team||'')===teamFilter;
    }
    return true;
  };
  const filtered=contacts.filter(match);
  const row=u=>{const n=unread.get(String(u.id))||0;return `<button class="floating-contact ${String(u.id)===String(state.chatSelectedUserId)?'active':''} ${n?'has-unread':''}" data-floating-user="${u.id}"><span class="chat-avatar small">${esc(initials(u.display_name))}</span><span class="floating-contact-copy"><strong>${esc(u.display_name)}</strong><small>${esc(chatRoleLabel(u.role,u.staff_type))}${u.team?` · ${esc(u.team)}`:''}</small></span>${n?`<span class="floating-contact-unread" title="${n} tin nhắn chưa đọc">${n>99?'99+':n}</span>`:''}</button>`};
  if((role!=='admin'&&role!=='sup'))return filtered.map(row).join('')||'<div class="empty small-empty">Không có liên hệ.</div>';
  const groups=[];
  const admins=filtered.filter(u=>u.role==='admin');
  if(admins.length)groups.push({name:'Quản trị',key:'__admin__',items:admins});
  const teams=[...new Set(filtered.filter(u=>u.role!=='admin').map(u=>String(u.team||'Chưa có Team'))) ].sort((a,b)=>a.localeCompare(b,'vi'));
  for(const team of teams)groups.push({name:team,key:team,items:filtered.filter(u=>u.role!=='admin'&&String(u.team||'Chưa có Team')===team)});
  if(!groups.length)return '<div class="empty small-empty">Không có liên hệ phù hợp.</div>';
  return groups.map(g=>{const nu=g.items.reduce((sum,u)=>sum+(unread.get(String(u.id))||0),0);return `<section class="floating-team-group"><div class="floating-team-title"><span>${esc(g.name)}</span><span class="floating-team-count">${g.items.length}${nu?` · <b>${nu} mới</b>`:''}</span></div>${g.items.map(row).join('')}</section>`}).join('');
}

function ensureFloatingChat(){
  if(!state.session?.user){document.getElementById('floating-chat-root')?.remove();return;}let root=document.getElementById('floating-chat-root');if(!root){root=document.createElement('div');root.id='floating-chat-root';root.innerHTML=`<button id="floating-chat-button" type="button" aria-label="Mở chat nội bộ">${uiIcon('chat')}<span id="floating-chat-badge" class="hidden">0</span></button><section id="floating-chat-panel" class="hidden"></section>`;document.body.appendChild(root);$('#floating-chat-button').onclick=()=>toggleFloatingChat();}updateFloatingChatBadge();
}
function updateFloatingChatBadge(){const badge=$('#floating-chat-badge');if(!badge)return;const read=notificationReadSet(),n=(state.chatNotifications||[]).filter(x=>!read.has(notificationAlertKey(x))).length;badge.textContent=n>99?'99+':String(n);badge.classList.toggle('hidden',n===0);}
async function toggleFloatingChat(force){ensureFloatingChat();const panel=$('#floating-chat-panel'),open=typeof force==='boolean'?force:panel.classList.contains('hidden');panel.classList.toggle('hidden',!open);if(open){await loadChatContacts(true);renderFloatingChat();startFloatingChatPolling();}else stopFloatingChatPolling();}
async function openFloatingChatWith(userId){
  ensureFloatingChat();$('#floating-chat-panel').classList.remove('hidden');await loadChatContacts(true);
  state.floatingChatView='chat';state.chatSelectedUserId=String(userId||'');state.chatMessages=[];state.chatOldestId=0;state.chatNewestId=0;state.chatHasOlder=false;
  if(state.chatSelectedUserId){await loadChatMessages('initial');await markChatConversationRead(state.chatSelectedUserId);}
  renderFloatingChat(true);startFloatingChatPolling();
}

function stopFloatingChatPolling(){if(state.floatingChatTimer)clearInterval(state.floatingChatTimer);state.floatingChatTimer=null;}
function startFloatingChatPolling(){
  stopFloatingChatPolling();if(state.mode!=='d1'||!state.chatSelectedUserId||$('#floating-chat-panel')?.classList.contains('hidden'))return;
  state.floatingChatTimer=setInterval(async()=>{if(document.hidden||$('#floating-chat-panel')?.classList.contains('hidden'))return;const n=await loadChatMessages('newer');if(n){await markChatConversationRead(state.chatSelectedUserId);renderFloatingChat(true);}},20000);
}

function renderFloatingChat(scrollBottom=false){
  const panel=$('#floating-chat-panel');if(!panel)return;
  const contacts=state.chatContacts||[],selected=contacts.find(u=>String(u.id)===String(state.chatSelectedUserId)),q=String(state.chatContactSearch||'').trim().toLocaleLowerCase('vi'),unread=chatUnreadBySender(),role=state.session?.user?.role||'sale',isAdmin=(role==='admin'||role==='sup'),isTeamlead=role==='teamlead',canBroadcast=isAdmin||isTeamlead;
  const view=canBroadcast&&state.floatingChatView==='broadcast'?'broadcast':'chat';
  const teams=isAdmin?[...new Set(contacts.filter(u=>u.role!=='admin'&&u.team).map(u=>String(u.team)))].sort((a,b)=>a.localeCompare(b,'vi')):[];
  const teamPicker=isAdmin?`<select id="floating-chat-team" aria-label="Lọc theo Team"><option value="">Tất cả Team</option><option value="__admin__" ${state.floatingChatTeamFilter==='__admin__'?'selected':''}>Quản trị</option>${teams.map(t=>`<option value="${esc(t)}" ${String(state.floatingChatTeamFilter||'')===t?'selected':''}>${esc(t)}</option>`).join('')}</select>`:'';
  const broadcastButton=canBroadcast?`<button id="floating-chat-broadcast" class="floating-chat-broadcast ${view==='broadcast'?'active':''}" type="button">${uiIcon('broadcast')}<span>${view==='broadcast'?'Quay lại Chat':isAdmin?'Thông báo chung':'Thông báo Team'}</span></button>`:'';
  const contactsHtml=floatingChatContactGroups(contacts,q,unread);
  const broadcastTitle=isAdmin?'Thông báo toàn hệ thống':`Thông báo ${esc(state.session.user.team||'Team')}`;
  const broadcastDesc=isAdmin?'Gửi một thông báo đến tất cả tài khoản đang hoạt động.':`Gửi một thông báo đến toàn bộ nhân viên đang hoạt động thuộc ${esc(state.session.user.team||'Team của bạn')}.`;
  const broadcastMeta=isAdmin?'Tất cả tài khoản sẽ nhận badge chưa đọc từ Admin.':'Mọi nhân viên trong Team sẽ nhận badge chưa đọc từ Team Leader.';
  const broadcastPane=`<div class="floating-broadcast-pane"><div class="floating-broadcast-hero"><div class="floating-broadcast-icon">${uiIcon('broadcast')}</div><div><strong>${broadcastTitle}</strong><span>${broadcastDesc}</span></div></div><form id="floating-broadcast-form" class="floating-broadcast-form"><label>Nội dung thông báo</label><textarea id="floating-broadcast-message" maxlength="1800" rows="8" placeholder="Nhập nội dung thông báo..."></textarea><div class="floating-broadcast-meta"><span>${broadcastMeta}</span><span id="floating-broadcast-count">0 / 1800</span></div><div class="floating-broadcast-actions"><button type="button" class="btn" id="floating-broadcast-back">Quay lại Chat</button><button type="submit" class="btn primary" id="floating-broadcast-send">${isAdmin?'Gửi thông báo':'Gửi tới Team'}</button></div></form></div>`;
  const chatPane=selected?`<div class="floating-thread-title"><button id="floating-chat-back">‹</button><div><strong>${esc(selected.display_name)}</strong><small>${esc(chatRoleLabel(selected.role,selected.staff_type))}${selected.team?` · ${esc(selected.team)}`:''}</small></div></div><div id="floating-chat-messages" class="floating-chat-messages">${state.chatMessages.map(m=>{const mine=Number(m.sender_user_id)===Number(state.session.user.id),notice=String(m.message||'').startsWith('📢 THÔNG BÁO');return `<div class="chat-message-row ${mine?'mine':'theirs'} ${notice?'system-notice':''}"><div class="chat-bubble"><div class="chat-message-text">${esc(m.message).replace(/\n/g,'<br>')}</div><small>${fmtDate(m.created_at)}</small></div></div>`}).join('')||'<div class="chat-empty-thread">Chưa có tin nhắn.</div>'}</div><form id="floating-chat-compose" class="floating-chat-compose"><textarea id="floating-chat-input" rows="2" maxlength="2000" placeholder="Nhập tin nhắn…"></textarea><button class="btn primary" type="submit">Gửi</button></form>`:`<div class="floating-chat-placeholder">${uiIcon('chat')}<strong>Chọn một người để bắt đầu chat</strong><span>${isAdmin?'Danh sách bên trái đã được chia theo từng Team.':'Tin nhắn chưa đọc sẽ nhấp nháy ngay cạnh người gửi.'}</span></div>`;
  panel.innerHTML=`<div class="floating-chat-head"><div><strong>${view==='broadcast'?(isAdmin?'Thông báo toàn hệ thống':`Thông báo ${esc(state.session.user.team||'Team')}`):'Chat nội bộ'}</strong><small>${isAdmin?(view==='broadcast'?'Soạn thông báo gửi tới tất cả tài khoản đang hoạt động':'Danh sách liên hệ được chia theo từng Team'):isTeamlead?(view==='broadcast'?`Gửi thông báo tới toàn bộ nhân viên ${esc(state.session.user.team||'Team của bạn')}`:'Admin và nhân viên trong Team'):'Admin, Team Leader và đồng đội cùng Team'}</small></div><div class="floating-chat-head-actions">${broadcastButton}<button id="floating-chat-close" aria-label="Đóng">×</button></div></div><div class="floating-chat-body ${selected&&view==='chat'?'has-thread':''}"><aside class="floating-chat-contacts"><div class="floating-chat-contact-tools"><input id="floating-chat-search" placeholder="Tìm người chat…" value="${esc(state.chatContactSearch||'')}">${teamPicker}</div><div class="floating-chat-contact-list">${contactsHtml}</div></aside><section class="floating-chat-thread ${view==='broadcast'?'broadcast-mode':''}">${view==='broadcast'?broadcastPane:chatPane}</section></div>`;
  $('#floating-chat-close').onclick=()=>toggleFloatingChat(false);
  if($('#floating-chat-broadcast'))$('#floating-chat-broadcast').onclick=()=>{state.floatingChatView=view==='broadcast'?'chat':'broadcast';if(state.floatingChatView==='broadcast')stopFloatingChatPolling();renderFloatingChat();if(state.floatingChatView==='chat'&&state.chatSelectedUserId)startFloatingChatPolling();};
  $('#floating-chat-search').oninput=e=>{state.chatContactSearch=e.target.value;renderFloatingChat()};
  if($('#floating-chat-team'))$('#floating-chat-team').onchange=e=>{state.floatingChatTeamFilter=e.target.value||'';renderFloatingChat()};
  $$('[data-floating-user]',panel).forEach(b=>b.onclick=()=>{state.floatingChatView='chat';openFloatingChatWith(b.dataset.floatingUser)});
  if($('#floating-chat-back'))$('#floating-chat-back').onclick=()=>{state.chatSelectedUserId='';state.chatMessages=[];stopFloatingChatPolling();renderFloatingChat()};
  if(view==='broadcast'){
    const input=$('#floating-broadcast-message'),count=$('#floating-broadcast-count');
    input.oninput=()=>{count.textContent=`${input.value.length} / 1800`};
    $('#floating-broadcast-back').onclick=()=>{state.floatingChatView='chat';renderFloatingChat();if(state.chatSelectedUserId)startFloatingChatPolling();};
    $('#floating-broadcast-form').onsubmit=async e=>{e.preventDefault();const message=input.value.trim(),btn=$('#floating-broadcast-send');if(!message){toast('Hãy nhập nội dung thông báo.','bad');return;}btn.disabled=true;btn.textContent='Đang gửi…';try{const r=await API.request('/chat/broadcast',{method:'POST',body:JSON.stringify({message})});toast(isAdmin?`Đã gửi thông báo tới ${Number(r.sent||0)} tài khoản.`:`Đã gửi thông báo tới ${Number(r.sent||0)} nhân viên trong Team.`);state.floatingChatView='chat';renderFloatingChat();if(state.chatSelectedUserId)startFloatingChatPolling();}catch(err){btn.disabled=false;btn.textContent='Gửi thông báo';toast(err.message,'bad')}};
  }
  if(view==='chat'&&selected){$('#floating-chat-compose').onsubmit=async e=>{e.preventDefault();const input=$('#floating-chat-input'),message=input.value.trim();if(!message)return;try{const r=await API.request('/chat/messages',{method:'POST',body:JSON.stringify({recipient_user_id:Number(state.chatSelectedUserId),message})});if(r.item){state.chatMessages.push(r.item);state.chatNewestId=Number(r.item.id)||state.chatNewestId;}input.value='';renderFloatingChat(true);}catch(err){toast(err.message,'bad')}};$('#floating-chat-input').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('#floating-chat-compose').requestSubmit();}};requestAnimationFrame(()=>{const box=$('#floating-chat-messages');if(box&&scrollBottom)box.scrollTop=box.scrollHeight;});}
}



/* Activate V8.1 UI overrides before bootstrap */
premiumPageTitle=v81_override_premiumPageTitle;
allowedPagesForRole=v81_override_allowedPagesForRole;
premiumDateLabel=v81_override_premiumDateLabel;
premiumSidebarItems=v81_override_premiumSidebarItems;
renderSidebar=v81_override_renderSidebar;
mobileNavItems=v81_override_mobileNavItems;
navigate=v81_override_navigate;
render=v81_override_render;
renderDashboard=v81_override_renderDashboard;
leadStagePill=v81_override_leadStagePill;
leadDateScopeRows=v81_override_leadDateScopeRows;
leadFilteredRows=v81_override_leadFilteredRows;
leadTeamTabsHtml=v81_override_leadTeamTabsHtml;
leadRowsHtml=v81_override_leadRowsHtml;
leadExportRows=v81_override_leadExportRows;
renderLeads=v81_override_renderLeads;
openLeadUpdateModal=v81_override_openLeadUpdateModal;
renderEmployees=v81_override_renderEmployees;
renderKPI=v81_override_renderKPI;

/* =====================================================================
   V8.2 POLISH & WORKFLOW FIXES
   - Gọn Dashboard, sửa KPI cards + donut legend
   - Bỏ trang Lịch sử cuộc gọi khỏi điều hướng
   - Lead trở về bố cục cũ, chỉ bỏ khối Nhắc cập nhật Lead
   - KPI filters gọn, bỏ chữ "Có thể chọn"
   - Agent: Data chưa gọi / Data cũ hiển thị bằng tab
   ===================================================================== */
function v82_allowedPagesForRole(role){
  const common=['dashboard','customerdb','lead','followup','kpi'];
  if((role==='admin'||role==='sup'))return new Set([...common,'teamManagement','warehouseAdmin','io','settings','audit']);
  if(role==='teamlead')return new Set([...common,'teamManagement','warehouseAdmin']);
  return new Set(common);
}
function v82_premiumSidebarItems(role){
  const core=[
    ['dashboard','dashboard','Bảng điều khiển'],
    ['customerdb','customers','Chi tiết cuộc gọi'],
    ['lead','lead','Quản lý Lead'],
    ['followup','calendar','Follow-up']
  ];
  if(role==='sale')return [...core,['kpi','kpi','KPI & Hiệu suất']];
  const manage=[['teamManagement','users','Quản lý nhóm và nhân viên'],['kpi','kpi','KPI & Hiệu suất'],['warehouseAdmin','warehouse',role==='teamlead'?'Kho Data Team':'Kho dữ liệu']];
  if((role==='admin'||role==='sup'))manage.push(['io','import','Nhập / Xuất dữ liệu'],['settings','settings','Cài đặt']);
  return [...core,...manage];
}
function v82_renderSidebar(active){
  const u=state.session.user,role=u.role,items=premiumSidebarItems(role);
  const dividerIndex=role==='sale'?99:4;
  const rows=items.map((x,i)=>`${i===dividerIndex?'<div class="sidebar-divider"></div><div class="sidebar-caption">Quản trị & vận hành</div>':''}<button class="menu-item ${x[0]===active?'active':''}" data-nav="${x[0]}"><span class="menu-item-icon">${uiIcon(x[1])}</span><span class="menu-item-label">${x[2]}</span></button>`).join('');
  $('#sidebar-menu').innerHTML=`<div class="sidebar-brand"><div class="sidebar-brand-mark">A4</div><div><strong>An Đông 4</strong><span>Shinhan Finance</span></div></div><div class="sidebar-nav-scroll">${rows}</div><div class="sidebar-profile"><div class="sidebar-profile-avatar">${esc(initials(u.display_name))}</div><div class="sidebar-profile-copy"><strong>${esc(u.display_name)}</strong><small>${esc(premiumRoleLabel(role,u.staff_type))}</small></div><span class="sidebar-profile-status"></span></div>`;
  $$('[data-nav]',$('#sidebar-menu')).forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
}
function v82_renderDashboard(main){
  v81_override_renderDashboard(main);
  const historyBtn=$('#dash-open-history');
  if(historyBtn){historyBtn.textContent='Xem chi tiết cuộc gọi';historyBtn.onclick=()=>navigate('customerdb');}
}

// Lead V8.2: dùng lại cách trình bày quen thuộc trước V8.1, không có khối nhắc cập nhật.
function v82_leadStagePill(status){
  if(!status)return '<span class="lead-stage new">Chưa xử lý</span>';
  const cls=status==='LOGIN_APP'?'login':status==='SIGNED'?'signed':LEAD_NEGATIVE_STATUSES.has(status)?'negative':'new';
  return `<span class="lead-stage ${cls}">${esc(LEAD_STATUS_LABELS[status]||status)}</span>`;
}
function v82_leadDateScopeRows(){
  const rows=leadScopeRows(),from=String(state.leadDateFrom||'').trim(),to=String(state.leadDateTo||'').trim();
  if(!from&&!to)return rows;
  return rows.filter(x=>{const d=dateKey(x.lead_created_at);if(!d)return false;if(from&&d<from)return false;if(to&&d>to)return false;return true;});
}
function v82_leadFilteredRows(){
  const q=(state.leadSearch||'').trim().toLowerCase();
  return leadDateScopeRows().filter(x=>{
    if(state.leadStatusFilter==='UNPROCESSED'&&x.lead_status)return false;
    if(state.leadStatusFilter&&state.leadStatusFilter!=='UNPROCESSED'&&x.lead_status!==state.leadStatusFilter)return false;
    if(q&&!`${x.name||''} ${x.phone||''} ${x.owner||''} ${x.source||''}`.toLowerCase().includes(q))return false;
    return true;
  }).sort((a,b)=>String(b.lead_created_at||'').localeCompare(String(a.lead_created_at||''))||Number(b.customer_id)-Number(a.customer_id));
}
function v82_leadTeamTabsHtml(){
  const role=state.session.user.role;
  if(role==='sale')return '';
  if(role==='teamlead')return `<div class="lead-team-tabs"><button class="lead-team-tab active" type="button">${esc(state.session.user.team||'Team của bạn')}</button></div>`;
  const dateRows=(state.leads||[]).filter(x=>{const d=dateKey(x.lead_created_at);if(!d)return false;const from=String(state.leadDateFrom||'').trim(),to=String(state.leadDateTo||'').trim();if(from&&d<from)return false;if(to&&d>to)return false;return true;});
  return `<div class="lead-team-tabs"><button class="lead-team-tab ${!state.leadTeamFilter?'active':''}" type="button" data-lead-team-tab="">Tất cả Team <span>${dateRows.length}</span></button>${(state.teamObjects||[]).map(t=>{const count=dateRows.filter(x=>String(x.team_id)===String(t.id)).length;return `<button class="lead-team-tab ${String(state.leadTeamFilter)===String(t.id)?'active':''}" type="button" data-lead-team-tab="${t.id}">${esc(t.name)} <span>${count}</span></button>`}).join('')}</div>`;
}
function v82_leadRowsHtml(){
  const role=state.session.user.role,rows=leadFilteredRows(),colCount=(role==='admin'||role==='sup')?9:role==='sale'?7:8;
  if(!rows.length)return `<tr><td colspan="${colCount}"><div class="empty">Không có Lead phù hợp.</div></td></tr>`;
  const grouped=new Map();
  for(const x of rows){const day=dateKey(x.lead_created_at)||'Không rõ ngày';if(!grouped.has(day))grouped.set(day,[]);grouped.get(day).push(x);}
  return [...grouped.entries()].map(([day,items])=>{
    const label=day==='Không rõ ngày'?day:shortDate(day);
    const head=`<tr class="lead-date-group"><td colspan="${colCount}"><div><strong>${esc(label)}</strong><span>${items.length} Lead phát sinh</span></div></td></tr>`;
    const itemRows=items.map(x=>{
      const callChanged=String(x.call_status||'')!==String(x.source_call_status||''),callNote=String(x.last_call_note||'').trim();
      const latestCall=`<div class="lead-latest-call">${x.call_status?statusPill(x.call_status):'<span class="muted">—</span>'}${callNote?`<small title="${esc(callNote)}">${esc(callNote)}</small>`:''}${x.last_call_at?`<small>${fmtDate(x.last_call_at)}${callChanged?' · đã gọi lại':''}</small>`:''}</div>`;
      const note=String(x.latest_lead_note||'').trim(),noteMeta=[x.latest_lead_note_by||'',x.latest_lead_note_at?fmtDate(x.latest_lead_note_at):''].filter(Boolean).join(' · ');
      const row=`<tr class="lead-main-row"><td><div class="lead-customer"><strong>${esc(x.name)}</strong><small>${esc(x.phone||'')}</small></div></td><td>${v1027ManualLeadOriginPill(x)}</td><td>${String(x.lead_origin||'').toUpperCase()==='MANUAL'&&!x.last_call_at?'<div class="lead-latest-call"><span class="muted">Chưa có cuộc gọi</span></div>':latestCall}</td><td>${esc(x.source||'—')}</td>${(role==='admin'||role==='sup')?`<td>${esc(x.team||'—')}</td>`:''}${role!=='sale'?`<td>${esc(x.owner||'Chưa giao')}</td>`:''}<td><div class="lead-stage-with-reason">${leadStagePill(x.lead_status)}${x.lead_status==='NO_LOGIN'&&x.lead_reason?`<small>${esc(x.lead_reason)}</small>`:''}</div></td><td>${x.lead_updated_at?fmtDate(x.lead_updated_at):'<span class="muted">Chưa xử lý</span>'}</td><td><div class="lead-actions">${role==='sale'?`<button class="btn small primary" data-lead-update="${x.customer_id}">Cập nhật</button><button class="btn small" data-lead-note="${x.customer_id}">+ Ghi chú</button><button class="btn small" data-lead-history="${x.customer_id}">Lịch sử</button>`:`<button class="btn small primary" data-lead-row-remind="${Number(x.assigned_user_id||0)}" data-lead-row-name="${esc(x.name||'Khách hàng')}" ${x.assigned_user_id?'':'disabled'}>🔔 Nhắc cập nhật</button>`}${['admin','sup','teamlead'].includes(role)?`<button class="btn small danger" data-lead-delete="${x.customer_id}">Xóa</button>`:''}</div></td></tr>`;
      const noteRow=note?`<tr class="lead-inline-note-row"><td colspan="${colCount}"><div class="lead-inline-note"><span class="lead-inline-note-icon">●</span><div><p>${esc(note)}</p>${noteMeta?`<small>${esc(noteMeta)}</small>`:''}</div></div></td></tr>`:'';
      return row+noteRow;
    }).join('');
    return head+itemRows;
  }).join('');
}
function v82_leadExportRows(){
  return leadFilteredRows().map((x,i)=>({'STT':i+1,'Khách hàng':x.name||'','Số điện thoại':String(x.phone||''),'Ngày phát sinh Lead':dateKey(x.lead_created_at)||'','Giờ phát sinh':vnParts(x.lead_created_at)?.time?.slice(0,5)||'','Nguồn phát sinh Lead':String(x.lead_origin||'').toUpperCase()==='MANUAL'?'Thủ công':'Cuộc gọi','Mã cuộc gọi tạo Lead':String(x.lead_origin||'').toUpperCase()==='MANUAL'?'':(x.source_call_status||''),'Kết quả tạo Lead':String(x.lead_origin||'').toUpperCase()==='MANUAL'?'Lead thủ công':(STATUS_LABELS[x.source_call_status]||x.source_call_status||''),'Cuộc gọi mới nhất':x.last_call_at?fmtDate(x.last_call_at):'','Mã kết quả mới nhất':x.call_status||'','Kết quả cuộc gọi mới nhất':STATUS_LABELS[x.call_status]||x.call_status||'','Nguồn Data':x.source||'','Team':x.team||'','Nhân viên':x.owner||'','Tiến trình Lead':x.lead_status?(LEAD_STATUS_LABELS[x.lead_status]||x.lead_status):'Chưa xử lý','Ghi chú mới nhất':x.latest_lead_note||'','Cập nhật Lead lúc':x.lead_updated_at?fmtDate(x.lead_updated_at):'','Người cập nhật':x.changed_by||''}));
}

function v1027ManualLeadOriginPill(x){
  return String(x?.lead_origin||'').toUpperCase()==='MANUAL'
    ? '<span class="lead-origin-pill manual">Thủ công</span>'
    : statusPill(x?.source_call_status||'Y01');
}
function v1027ManualLeadOwnerOptions(){
  const role=state.session.user.role;
  if(role==='sale')return [];
  return (state.users||[]).filter(u=>{
    if(u.role!=='sale'||Number(u.active)===0)return false;
    if(role==='teamlead'&&String(u.team_id)!==String(state.session.user.team_id||''))return false;
    return true;
  }).sort((a,b)=>String(a.team||'').localeCompare(String(b.team||''),'vi')||String(a.display_name||'').localeCompare(String(b.display_name||''),'vi'));
}
function v1027OpenManualLeadModal(){
  const role=state.session.user.role,owners=v1027ManualLeadOwnerOptions();
  const ownerField=role==='sale'
    ? `<input type="hidden" id="manual-lead-owner" value="${Number(state.session.user.id||0)}"><div class="form-field"><label>Nhân viên phụ trách</label><input value="${esc(state.session.user.display_name||'Bạn')}" disabled></div>`
    : `<div class="form-field"><label>Nhân viên phụ trách *</label><select id="manual-lead-owner" required><option value="">-- Chọn nhân viên --</option>${owners.map(u=>`<option value="${u.id}">${esc(u.display_name)}${u.team?` · ${esc(u.team)}`:''}${staffRoleKey(u)==='freelancer'?' · Freelancer':''}</option>`).join('')}</select></div>`;
  openAdminModal('Thêm Lead thủ công',`<form id="manual-lead-form" class="form-grid manual-lead-form">
    <div class="form-field"><label>Tên khách hàng *</label><input id="manual-lead-name" maxlength="160" required placeholder="Nhập tên khách hàng"></div>
    <div class="form-field"><label>Số điện thoại *</label><input id="manual-lead-phone" inputmode="numeric" maxlength="10" required placeholder="VD: 0901234567"></div>
    <div class="form-field"><label>Nguồn khách hàng *</label><select id="manual-lead-source" required><option value="Data">Data</option><option value="TikTok">TikTok</option><option value="Facebook">Facebook</option><option value="Thị trường">Thị trường</option><option value="CTV">CTV</option><option value="Khác">Khác</option></select></div>
    ${ownerField}
    <div class="form-field full"><label>Ghi chú</label><textarea id="manual-lead-note" rows="4" maxlength="1000" placeholder="Nhu cầu khách hàng, số tiền quan tâm, thời gian liên hệ lại..."></textarea></div>
    <div class="form-field full"><div class="notice">Lead này được ghi nhận là <strong>Lead thủ công</strong>, không tạo cuộc gọi giả. Sau đó nhân viên xử lý Lead → Login App như Lead thông thường.</div></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="manual-lead-cancel">Hủy</button><button type="submit" class="btn primary" id="manual-lead-save">Thêm vào Lead</button></div></div>
  </form>`);
  const phone=$('#manual-lead-phone');if(phone)phone.oninput=()=>{phone.value=String(phone.value||'').replace(/\D/g,'').slice(0,10)};
  $('#manual-lead-cancel').onclick=closeAdminModal;
  $('#manual-lead-form').onsubmit=async e=>{
    e.preventDefault();
    const body={customer_name:$('#manual-lead-name').value.trim(),phone:$('#manual-lead-phone').value.trim(),source:$('#manual-lead-source').value,assigned_user_id:Number($('#manual-lead-owner').value||0),note:$('#manual-lead-note').value.trim()};
    if(!/^0\d{9}$/.test(body.phone)){toast('Số điện thoại phải đúng 10 số và bắt đầu bằng 0.','bad');return;}
    const btn=$('#manual-lead-save');btn.disabled=true;btn.textContent='Đang thêm…';
    try{
      await API.request('/leads/manual',{method:'POST',body:JSON.stringify(body)});
      closeAdminModal();state.leadLoadedAt=0;state.leadDateFrom=todayISO();state.leadDateTo=todayISO();await loadLeads(true);renderLeads($('#main'));toast('Đã thêm khách hàng vào Lead.');
    }catch(err){toast(err.message,'bad');btn.disabled=false;btn.textContent='Thêm vào Lead';}
  };
}

function v82_renderLeads(main){
  const role=state.session.user.role;state.leadEmployeeFilter='';
  if(!state.leadDateFrom&&!state.leadDateTo){const d=todayISO();state.leadDateFrom=d;state.leadDateTo=d;}
  if(state.mode==='d1'&&(!state.leadLoadedAt||Date.now()-state.leadLoadedAt>60000)&&!state.leadLoading){main.innerHTML=`${pageHead('Lead','Khách phát sinh từ cuộc gọi Y01 hoặc Y02. Khi xác nhận Login App, khách sẽ tự chuyển sang module Login App.')}<div class="card"><div class="lead-loading">Đang tải Lead…</div></div>`;loadLeads().then(()=>{if(state.page==='lead')renderLeads(main)});return;}
  const scope=leadDateScopeRows(),unprocessed=scope.filter(x=>!x.lead_status).length,login=scope.filter(x=>x.lead_status==='LOGIN_APP').length;
  const scopeText=role==='sale'?'Lead từ cuộc gọi và Lead thủ công của chính bạn.':role==='teamlead'?`Lead từ cuộc gọi và Lead thủ công của nhân viên thuộc ${esc(state.session.user.team||'Team của bạn')}.`:'Admin xem toàn bộ Lead và có thể lọc theo Team.';
  main.innerHTML=`${pageHead('Lead',scopeText)}${state.leadError?`<div class="notice warning">${esc(state.leadError)}</div>`:''}<div class="lead-summary lead-summary-v99"><div class="lead-total-card"><span>Tổng Lead phát sinh</span><strong>${scope.length}</strong><small>${esc(leadDateCaption())}</small></div><div><span>Chưa xử lý</span><strong>${unprocessed}</strong><small>Cần xác định Login App</small></div><div><span>Đã login app</span><strong>${login}</strong><small>Đã chuyển sang Login App</small></div></div><div class="card lead-card"><div class="card-head"><div><h3>Danh sách Lead theo khoảng ngày</h3><span class="muted">Lead được xử lý theo 2 hướng: Đã Login App hoặc Không login kèm lý do.</span></div><div class="actions lead-head-actions"><button class="btn primary" id="lead-add-manual">＋ Thêm Lead thủ công</button><button class="btn" id="lead-export-excel">Xuất Excel</button><button class="btn" id="lead-refresh">Làm mới</button></div></div><div class="card-body"><div class="lead-day-controls lead-range-controls"><label class="lead-day-picker"><span>Từ ngày</span><input type="date" id="lead-date-from" value="${esc(state.leadDateFrom||todayISO())}"></label><span class="range-arrow">→</span><label class="lead-day-picker"><span>Đến ngày</span><input type="date" id="lead-date-to" value="${esc(state.leadDateTo||todayISO())}"></label><div class="lead-day-current">Đang xem: <strong>${esc(leadDateCaption())}</strong></div></div>${leadTeamTabsHtml()}<div class="toolbar lead-toolbar lead-toolbar-simple"><input id="lead-search" class="search" placeholder="Tìm tên, SĐT, nhân viên, nguồn…" value="${esc(state.leadSearch)}"><select id="lead-status-filter"><option value="">Tất cả tiến trình</option><option value="UNPROCESSED" ${state.leadStatusFilter==='UNPROCESSED'?'selected':''}>Chưa xử lý</option>${LEAD_SELECTABLE_STATUSES.map(k=>`<option value="${k}" ${state.leadStatusFilter===k?'selected':''}>${esc(LEAD_STATUS_LABELS[k])}</option>`).join('')}</select></div></div><div class="table-wrap"><table class="data-table lead-table"><thead><tr><th>Khách hàng</th><th>Lead phát sinh</th><th>Cuộc gọi mới nhất</th><th>Nguồn Data</th>${(role==='admin'||role==='sup')?'<th>Team</th>':''}${role!=='sale'?'<th>Nhân viên</th>':''}<th>Tiến trình Lead</th><th>Cập nhật lúc</th><th>Thao tác</th></tr></thead><tbody id="lead-table-body">${leadRowsHtml()}</tbody></table></div></div>`;
  $('#lead-refresh').onclick=async()=>{state.leadLoadedAt=0;await loadLeads(true);renderLeads(main)};$('#lead-export-excel').onclick=exportLeadsExcel;$('#lead-add-manual')?.addEventListener('click',v1027OpenManualLeadModal);
  $('#lead-date-from').onchange=e=>{state.leadDateFrom=e.target.value||'';if(state.leadDateTo&&state.leadDateFrom>state.leadDateTo)state.leadDateTo=state.leadDateFrom;renderLeads(main)};
  $('#lead-date-to').onchange=e=>{state.leadDateTo=e.target.value||'';if(state.leadDateFrom&&state.leadDateTo<state.leadDateFrom)state.leadDateFrom=state.leadDateTo;renderLeads(main)};
  $('#lead-search').oninput=e=>{state.leadSearch=e.target.value;refreshLeadTableOnly()};$('#lead-status-filter').onchange=e=>{state.leadStatusFilter=e.target.value;renderLeads(main)};
  $$('[data-lead-team-tab]').forEach(b=>b.onclick=()=>{state.leadTeamFilter=b.dataset.leadTeamTab||'';renderLeads(main)});bindLeadRows();
}
function v82_openLeadUpdateModal(customerId){
  const x=(state.leads||[]).find(v=>Number(v.customer_id)===Number(customerId));if(!x)return;
  openAdminModal(`Cập nhật Lead · ${x.name}`,`<form id="lead-update-form" class="form-grid"><div class="form-field full"><label>Trạng thái hiện tại</label><div>${leadStagePill(x.lead_status)}</div></div><div class="form-field full"><label>Kết quả Lead</label><select id="lead-next-status" required><option value="">Chọn kết quả…</option><option value="LOGIN_APP">Đã Login App</option><option value="NO_LOGIN">Không Login</option></select></div><div class="form-field full hidden" id="lead-no-login-reason"><label>Lý do không Login</label><textarea id="lead-no-login-note" rows="4" maxlength="500" placeholder="Nhập lý do khách không Login App…"></textarea><small class="muted">Bắt buộc nhập lý do khi chọn Không Login.</small></div><div class="form-field full"><div class="notice">Chọn <strong>Đã Login App</strong> sẽ tự chuyển thông tin khách sang module Login App. Chọn <strong>Không Login</strong> sẽ lưu lý do vào lịch sử Lead.</div></div><div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="lead-update-cancel">Hủy</button><button class="btn primary" type="submit">Lưu kết quả</button></div></div></form>`);
  const sel=$('#lead-next-status'),reasonBox=$('#lead-no-login-reason'),reason=$('#lead-no-login-note');
  const sync=()=>{const no=sel.value==='NO_LOGIN';reasonBox.classList.toggle('hidden',!no);reason.required=no;};sel.onchange=sync;sync();
  $('#lead-update-cancel').onclick=closeAdminModal;$('#lead-update-form').onsubmit=async e=>{e.preventDefault();const status=sel.value;if(!status)return;const why=reason.value.trim();if(status==='NO_LOGIN'&&!why){toast('Vui lòng nhập lý do khách không Login.','bad');reason.focus();return;}try{await API.request(`/leads/${customerId}/status`,{method:'POST',body:JSON.stringify({status,reason:why})});closeAdminModal();state.leadLoadedAt=0;state.loginAppsLoadedAt=0;await loadLeads(true);renderLeads($('#main'));toast(status==='LOGIN_APP'?'Đã chuyển khách sang Login App.':'Đã lưu trạng thái Không Login và lý do.');}catch(err){toast(err.message,'bad')}};
}

// Agent: đổi chọn loại Data từ dropdown sang tab rõ ràng.
const v82_baseRenderTelesale=renderTelesale;
function v82_renderTelesale(main){
  v82_baseRenderTelesale(main);
  if(state.session?.user?.role!=='sale')return;
  const select=$('#cc-mode');
  if(!select)return;
  const wrap=document.createElement('div');
  wrap.className='v82-call-data-tabs';
  const active=state.callMode==='old'?'old':'queue';
  wrap.innerHTML=`<button type="button" class="${active==='queue'?'active':''}" data-v82-call-mode="queue">Data chưa gọi</button><button type="button" class="${active==='old'?'active':''}" data-v82-call-mode="old">Data cũ / đã gọi</button>`;
  select.replaceWith(wrap);
  $$('[data-v82-call-mode]',wrap).forEach(b=>b.onclick=()=>{state.callMode=b.dataset.v82CallMode;state.callStatusFilter='';state.selectedCustomerId=null;renderTelesale(main)});
}

allowedPagesForRole=v82_allowedPagesForRole;
premiumSidebarItems=v82_premiumSidebarItems;
renderSidebar=v82_renderSidebar;
renderDashboard=v82_renderDashboard;
leadStagePill=v82_leadStagePill;
leadDateScopeRows=v82_leadDateScopeRows;
leadFilteredRows=v82_leadFilteredRows;
leadTeamTabsHtml=v82_leadTeamTabsHtml;
leadRowsHtml=v82_leadRowsHtml;
leadExportRows=v82_leadExportRows;
renderLeads=v82_renderLeads;
openLeadUpdateModal=v82_openLeadUpdateModal;
renderTelesale=v82_renderTelesale;



/* =====================================================================
   V9.5 POST-DISBURSEMENT CUSTOMER CARE
   - Admin: toàn hệ thống
   - Team Leader: đúng Team
   - Agent: chỉ khách do chính mình phụ trách
   ===================================================================== */
// The lists remain complete in memory for counts/filtering; only 80 visible
// rows are rendered at a time to avoid expensive thousands-row DOM updates.
const V1031_PAGE_SIZE=80;
function v1031PageSlice(all,type){
 const key='_v1031Page'+type;
 const total=Math.max(1,Math.ceil(all.length/V1031_PAGE_SIZE));
 const page=Math.max(1,Math.min(total,Number(state[key]||1)));
 state[key]=page;state['_v1031Total'+type]=all.length;
 return all.slice((page-1)*V1031_PAGE_SIZE,page*V1031_PAGE_SIZE);
}
function v1031ShowPager(main,type,rerender){
 const total=Number(state['_v1031Total'+type]||0);
 const max=Math.ceil(total/V1031_PAGE_SIZE);
 const table=main.querySelector(type==='loginApp'?'.loginapp-table':'.care-v97-table');
 if(!table||max<2||main.querySelector('[data-v1031-pager]'))return;
 const page=Math.min(max,Number(state['_v1031Page'+type]||1));
 const nav=document.createElement('div');nav.className='v1031-pager';nav.dataset.v1031Pager=type;
 nav.innerHTML=`<span>Hiển thị ${(page-1)*V1031_PAGE_SIZE+1}–${Math.min(total,page*V1031_PAGE_SIZE)} / ${total} khách</span><div><button class="btn small" data-v1031-prev ${page===1?'disabled':''}>← Trước</button><b>Trang ${page}/${max}</b><button class="btn small" data-v1031-next ${page===max?'disabled':''}>Sau →</button></div>`;
 table.closest('.table-wrap')?.insertAdjacentElement('afterend',nav);
 for(const [key,delta] of [['prev',-1],['next',1]]){
  const btn=nav.querySelector(`[data-v1031-${key}]`);
  btn.onclick=()=>{state['_v1031Page'+type]=page+delta;rerender(main);main.querySelector('.v1031-pager')?.scrollIntoView({block:'nearest'});};
 }
}
async function loadLoanCare(force=false){
  if(state.mode!=='d1')return;
  if(state.loanCareLoading)return;
  if(!force&&state.loanCareLoadedAt&&Date.now()-state.loanCareLoadedAt<30000)return;
  state.loanCareLoading=true;state.loanCareError='';
  try{
    const params=new URLSearchParams();
    if(state.loanCareTeam)params.set('team_id',state.loanCareTeam);
    if(state.loanCareUser)params.set('user_id',state.loanCareUser);
    if(state.loanCareSearch)params.set('q',state.loanCareSearch);
    const r=await API.request('/loans'+(params.toString()?`?${params}`:''),{timeoutMs:20000});
    state.loanProfiles=r.items||[];state.loanCareLoadedAt=Date.now();
  }catch(e){state.loanCareError=e.message||'Không tải được dữ liệu sau giải ngân.';}
  finally{state.loanCareLoading=false;}
}
function loanMoney(v){return Number(v||0).toLocaleString('vi-VN')}
function loanDerivedStatus(x){
  if(String(x.status)==='SETTLED')return 'SETTLED';
  if(String(x.status)==='TOPUP')return 'TOPUP';
  const today=todayISO(),next=dateKey(x.next_due_date||''),maturity=dateKey(x.maturity_date||'');
  if(next&&next<today)return 'OVERDUE';
  if(next===today)return 'DUE';
  if(maturity&&maturity>=today&&maturity<=addDays(today,30))return 'NEAR_MATURITY';
  if(String(x.status)==='CARE_REQUIRED')return 'CARE_REQUIRED';
  return 'ACTIVE';
}
const LOAN_STATUS_LABELS={ACTIVE:'Bình thường',DUE:'Đến kỳ',OVERDUE:'Quá hạn',NEAR_MATURITY:'Sắp tất toán',SETTLED:'Đã tất toán',CARE_REQUIRED:'Cần chăm sóc',TOPUP:'Topup'};
function loanStatusPill(x){const s=loanDerivedStatus(x),cls={ACTIVE:'ok',DUE:'due',OVERDUE:'overdue',NEAR_MATURITY:'near',SETTLED:'settled',CARE_REQUIRED:'care',TOPUP:'care'}[s]||'ok';return `<span class="loan-status ${cls}">${esc(LOAN_STATUS_LABELS[s]||s)}</span>`}
function loanScopeCaption(){const role=state.session.user.role;return (role==='admin'||role==='sup')?'Admin xem toàn bộ khách hàng sau giải ngân.':role==='teamlead'?`Chỉ khách hàng thuộc ${esc(state.session.user.team||'Team của bạn')}.`:'Chỉ khách hàng do chính bạn phụ trách.'}
function loanFilteredRows(){
  const rows=state.loanProfiles||[],tab=state.loanCareTab||'all',q=String(state.loanCareSearch||'').trim().toLowerCase(),today=todayISO();
  return rows.filter(x=>{
    const s=loanDerivedStatus(x);
    if(tab==='due'&&s!=='DUE')return false;
    if(tab==='upcoming'){const d=dateKey(x.next_due_date||'');if(!d||d<=today||d>addDays(today,7))return false;}
    if(tab==='overdue'&&s!=='OVERDUE')return false;
    if(tab==='settled'&&s!=='SETTLED')return false;
    if(tab==='reloan'&&!Number(x.reloan_eligible))return false;
    if(q&&!`${x.customer_name||''} ${x.phone||''} ${x.contract_code||''} ${x.owner||''} ${x.team||''}`.toLowerCase().includes(q))return false;
    return true;
  });
}
function renderLoanCare(main){
  const role=state.session.user.role;
  state.loanCareTab=state.loanCareTab||'all';
  state.loanCareSearch=state.loanCareSearch||'';
  if(role==='teamlead')state.loanCareTeam=String(state.session.user.team_id||'');
  if(role==='sale'){state.loanCareTeam=String(state.session.user.team_id||'');state.loanCareUser=String(state.session.user.id||'');}
  if(state.mode==='d1'&&(!state.loanCareLoadedAt&&!(state.loanProfiles||[]).length)&&!state.loanCareLoading){
    main.innerHTML='<div class="empty">Đang tải khách hàng sau giải ngân…</div>';
    loadLoanCare(true).then(()=>{if(state.page==='loanCare')renderLoanCare(main)});return;
  }
  const rows=state.loanProfiles||[],today=todayISO();
  const active=rows.filter(x=>loanDerivedStatus(x)!=='SETTLED'),debt=active.reduce((n,x)=>n+Number(x.current_balance||0),0),due=rows.filter(x=>loanDerivedStatus(x)==='DUE').length,upcoming=rows.filter(x=>{const d=dateKey(x.next_due_date||'');return d&&d>today&&d<=addDays(today,7)}).length,overdue=rows.filter(x=>loanDerivedStatus(x)==='OVERDUE').length,near=rows.filter(x=>loanDerivedStatus(x)==='NEAR_MATURITY').length,settled=rows.filter(x=>loanDerivedStatus(x)==='SETTLED').length,reloan=rows.filter(x=>Number(x.reloan_eligible)).length;
  const visible=loanFilteredRows();
  const roleUsers=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||Number(u.team_id)===Number(state.session.user.team_id))&&(!state.loanCareTeam||String(u.team_id)===String(state.loanCareTeam)));
  const teamOptions=(role==='admin'||role==='sup')?`<select id="loan-team"><option value="">Tất cả nhóm</option>${state.teamObjects.map(t=>`<option value="${t.id}" ${String(t.id)===String(state.loanCareTeam||'')?'selected':''}>${esc(t.name)}</option>`).join('')}</select>`:'';
  const userOptions=role!=='sale'?`<select id="loan-user"><option value="">Tất cả nhân viên</option>${roleUsers.map(u=>`<option value="${u.id}" ${String(u.id)===String(state.loanCareUser||'')?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select>`:'';
  main.innerHTML=`<div class="premium-page loan-care-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Chăm sóc khách hàng</h1><p>${loanScopeCaption()} Chăm sóc khách đến hết vòng đời khoản vay.</p></div><div class="premium-page-actions"><button class="btn" id="loan-refresh">↻ Làm mới</button></div></div>${state.loanCareError?`<div class="notice warning">${esc(state.loanCareError)}</div>`:''}
  <section class="loan-summary-grid"><article><span>Tổng khách đang vay</span><strong>${active.length.toLocaleString('vi-VN')}</strong><small>Khoản vay đang quản lý</small></article><article><span>Dư nợ đang quản lý</span><strong>${loanMoney(debt)}</strong><small>VNĐ</small></article><article><span>Đến kỳ hôm nay</span><strong>${due}</strong><small>Cần liên hệ</small></article><article><span>Sắp đến hạn 7 ngày</span><strong>${upcoming}</strong><small>Cần chăm sóc</small></article><article class="danger"><span>Quá hạn</span><strong>${overdue}</strong><small>Cần xử lý ngay</small></article><article><span>Sắp tất toán 30 ngày</span><strong>${near}</strong><small>Cần chăm sóc</small></article><article class="success"><span>Đã tất toán</span><strong>${settled}</strong><small>Đã hoàn tất vòng đời</small></article><article class="success"><span>Đủ điều kiện vay lại</span><strong>${reloan}</strong><small>Có thể tạo Lead mới</small></article></section>
  <section class="crm-panel loan-care-panel"><div class="loan-tabs"><button class="${state.loanCareTab==='all'?'active':''}" data-loan-tab="all">Tất cả <span>${rows.length}</span></button><button class="${state.loanCareTab==='due'?'active':''}" data-loan-tab="due">Đến kỳ <span>${due}</span></button><button class="${state.loanCareTab==='upcoming'?'active':''}" data-loan-tab="upcoming">Sắp đến hạn <span>${upcoming}</span></button><button class="${state.loanCareTab==='overdue'?'active':''}" data-loan-tab="overdue">Quá hạn <span>${overdue}</span></button><button class="${state.loanCareTab==='settled'?'active':''}" data-loan-tab="settled">Đã tất toán <span>${settled}</span></button><button class="${state.loanCareTab==='reloan'?'active':''}" data-loan-tab="reloan">Đủ điều kiện vay lại <span>${reloan}</span></button></div>
    <div class="loan-toolbar"><input id="loan-search" placeholder="Tìm tên, SĐT, mã hợp đồng…" value="${esc(state.loanCareSearch)}">${teamOptions}${userOptions}</div>
    <div class="table-wrap loan-table-wrap"><table class="data-table loan-table"><thead><tr><th>Khách hàng</th><th>SĐT</th><th>Mã HĐ</th><th>Ngày giải ngân</th><th>Dư nợ hiện tại</th><th>Kỳ tiếp theo</th><th>Trạng thái</th><th>NV phụ trách</th><th>Thao tác</th></tr></thead><tbody>${visible.map(x=>`<tr><td><div class="loan-person"><strong>${esc(x.customer_name||'')}</strong><small>KH${String(x.customer_id).padStart(6,'0')}</small></div></td><td>${esc(x.phone||'')}</td><td>${esc(x.contract_code||'—')}</td><td>${x.disbursement_date?esc(x.disbursement_date):'—'}</td><td><strong>${loanMoney(x.current_balance)}</strong></td><td>${x.next_due_date?`<strong>${esc(x.next_due_date)}</strong>`:'—'}</td><td>${loanStatusPill(x)}</td><td><div class="loan-person"><strong>${esc(x.owner||'Chưa giao')}</strong><small>${esc(x.team||'')}</small></div></td><td><div class="loan-actions"><button class="btn small primary" data-loan-detail="${x.id}">Chi tiết</button></div></td></tr>`).join('')||'<tr><td colspan="9"><div class="empty">Chưa có khách hàng phù hợp.</div></td></tr>'}</tbody></table></div>
  </section></div>`;
  $('#loan-refresh').onclick=async()=>{state.loanCareLoadedAt=0;await loadLoanCare(true);renderLoanCare(main)};
  $('#loan-search').oninput=e=>{state.loanCareSearch=e.target.value;state._v1031PageloanCare=1;renderLoanCare(main)};
  if($('#loan-team'))$('#loan-team').onchange=async e=>{state.loanCareTeam=e.target.value;state.loanCareUser='';state.loanCareLoadedAt=0;await loadLoanCare(true);renderLoanCare(main)};
  if($('#loan-user'))$('#loan-user').onchange=async e=>{state.loanCareUser=e.target.value;state.loanCareLoadedAt=0;await loadLoanCare(true);renderLoanCare(main)};
  $$('[data-loan-tab]').forEach(b=>b.onclick=()=>{state.loanCareTab=b.dataset.loanTab;renderLoanCare(main)});
  $$('[data-loan-detail]').forEach(b=>b.onclick=()=>openLoanCareDetail(Number(b.dataset.loanDetail)));
}
async function openLoanCareDetail(id){
  const base=(state.loanProfiles||[]).find(x=>Number(x.id)===Number(id));if(!base)return;
  let history=[];try{const r=await API.request(`/loans/${id}/history`);history=r.items||[];}catch(_e){}
  const role=state.session.user.role,canEdit=((role==='admin'||role==='sup')||role==='teamlead')&&v1029Can('loanCare','update');
  const users=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||Number(u.team_id)===Number(state.session.user.team_id))&&(!base.team_id||Number(u.team_id)===Number(base.team_id)));
  const editBlock=canEdit?`<div class="loan-detail-section"><h3>Thông tin khoản vay</h3><div class="form-grid"><div class="form-field"><label>Mã hợp đồng</label><input id="loan-contract" value="${esc(base.contract_code||'')}"></div><div class="form-field"><label>Ngày giải ngân</label><input id="loan-disbursement-date" type="date" value="${esc(base.disbursement_date||'')}"></div><div class="form-field"><label>Số tiền giải ngân</label><input id="loan-amount" type="number" value="${Number(base.disbursement_amount||0)}"></div><div class="form-field"><label>Dư nợ hiện tại</label><input id="loan-balance" type="number" value="${Number(base.current_balance||0)}"></div><div class="form-field"><label>Kỳ hạn (tháng)</label><input id="loan-term" type="number" value="${Number(base.original_term_months||0)}"></div><div class="form-field"><label>Ngày thanh toán hàng tháng</label><input id="loan-due-day" type="number" min="1" max="31" value="${Number(base.monthly_due_day||0)||''}"></div><div class="form-field"><label>Kỳ thanh toán tiếp theo</label><input id="loan-next-due" type="date" value="${esc(base.next_due_date||'')}"></div><div class="form-field"><label>Ngày đáo hạn</label><input id="loan-maturity" type="date" value="${esc(base.maturity_date||'')}"></div><div class="form-field"><label>Nhân viên phụ trách</label><select id="loan-owner">${users.map(u=>`<option value="${u.id}" ${Number(u.id)===Number(base.assigned_user_id)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select></div><div class="form-field"><label>Trạng thái</label><select id="loan-status">${Object.entries(LOAN_STATUS_LABELS).map(([k,v])=>`<option value="${k}" ${String(base.status)===k?'selected':''}>${esc(v)}</option>`).join('')}</select></div><div class="form-field full"><label><input id="loan-reloan" type="checkbox" ${Number(base.reloan_eligible)?'checked':''}> Đủ điều kiện chăm sóc vay lại</label></div><div class="form-field full"><label>Ghi chú khoản vay</label><textarea id="loan-note" rows="2">${esc(base.note||'')}</textarea></div></div><button class="btn primary" id="loan-save-profile">Lưu thông tin khoản vay</button></div>`:`<div class="loan-detail-section"><h3>Thông tin khoản vay</h3><div class="loan-read-grid"><div><span>Mã hợp đồng</span><strong>${esc(base.contract_code||'—')}</strong></div><div><span>Ngày giải ngân</span><strong>${esc(base.disbursement_date||'—')}</strong></div><div><span>Dư nợ hiện tại</span><strong>${loanMoney(base.current_balance)}</strong></div><div><span>Kỳ tiếp theo</span><strong>${esc(base.next_due_date||'—')}</strong></div><div><span>Ngày đáo hạn</span><strong>${esc(base.maturity_date||'—')}</strong></div><div><span>Trạng thái</span>${loanStatusPill(base)}</div></div></div>`;
  openAdminModal(`Chăm sóc sau giải ngân · ${base.customer_name}`,`<div class="loan-detail-modal"><div class="loan-customer-head"><div><strong>${esc(base.customer_name||'')}</strong><span>${esc(base.phone||'')} · ${esc(base.team||'')}</span></div>${loanStatusPill(base)}</div>${editBlock}<div class="loan-detail-section"><h3>Ghi nhận chăm sóc</h3><div class="form-grid"><div class="form-field"><label>Kết quả</label><select id="loan-care-result"><option value="Đã liên hệ">Đã liên hệ</option><option value="Không nghe máy">Không nghe máy</option><option value="Đã nhắc kỳ thanh toán">Đã nhắc kỳ thanh toán</option><option value="Cần hỗ trợ">Cần hỗ trợ</option><option value="Có nhu cầu vay lại">Có nhu cầu vay lại</option></select></div><div class="form-field"><label>Lịch chăm sóc tiếp theo</label><input id="loan-care-next" type="date"></div><div class="form-field full"><label>Ghi chú</label><textarea id="loan-care-note" rows="3" placeholder="Nội dung trao đổi với khách hàng…"></textarea></div></div><button class="btn primary" id="loan-care-save">Ghi nhận chăm sóc</button></div><div class="loan-detail-section"><h3>Lịch sử chăm sóc</h3><div class="loan-history">${history.map(h=>`<div class="loan-history-row"><time>${fmtDate(h.created_at)}</time><div><strong>${esc(h.result||h.action_type||'Chăm sóc')}</strong><p>${esc(h.note||'')}</p><small>${esc(h.actor||'')} ${h.next_follow_up_at?`· Hẹn tiếp: ${esc(h.next_follow_up_at)}`:''}</small></div></div>`).join('')||'<div class="empty small-empty">Chưa có lịch sử chăm sóc.</div>'}</div></div></div>`);
  const loanModal=$('#admin-modal .admin-modal');if(loanModal)loanModal.classList.add('loan-care-admin-modal');
  if($('#loan-save-profile'))$('#loan-save-profile').onclick=async()=>{try{await API.request(`/loans/${id}`,{method:'PATCH',body:JSON.stringify({contract_code:$('#loan-contract').value,disbursement_date:$('#loan-disbursement-date').value,disbursement_amount:Number($('#loan-amount').value||0),current_balance:Number($('#loan-balance').value||0),original_term_months:Number($('#loan-term').value||0),monthly_due_day:Number($('#loan-due-day').value||0),next_due_date:$('#loan-next-due').value,maturity_date:$('#loan-maturity').value,assigned_user_id:Number($('#loan-owner').value||0),status:$('#loan-status').value,reloan_eligible:$('#loan-reloan').checked,note:$('#loan-note').value})});state.loanCareLoadedAt=0;await loadLoanCare(true);closeAdminModal();renderLoanCare($('#main'));toast('Đã lưu thông tin khoản vay.');}catch(e){toast(e.message,'bad')}};
  $('#loan-care-save').onclick=async()=>{try{await API.request(`/loans/${id}/care`,{method:'POST',body:JSON.stringify({result:$('#loan-care-result').value,note:$('#loan-care-note').value,next_follow_up_at:$('#loan-care-next').value})});state.loanCareLoadedAt=0;await loadLoanCare(true);closeAdminModal();renderLoanCare($('#main'));toast('Đã ghi nhận chăm sóc khách hàng.');}catch(e){toast(e.message,'bad')}};
}
function v95_allowedPagesForRole(role){const base=v82_allowedPagesForRole(role);base.add('loanCare');return base;}
function v95_premiumSidebarItems(role){const items=v82_premiumSidebarItems(role).map(x=>[...x]);const pos=items.findIndex(x=>x[0]==='followup');items.splice(pos>=0?pos+1:items.length,0,['loanCare','customers','Chăm sóc khách hàng']);return items;}
function v95_premiumPageTitle(page,role){if(page==='loanCare')return 'Chăm sóc khách hàng';return v81_override_premiumPageTitle(page,role);}
function v95_renderSidebar(active){
  const u=state.session.user,role=u.role,items=premiumSidebarItems(role);const dividerIndex=items.findIndex(x=>x[0]==='teamManagement');
  const rows=items.map((x,i)=>`${i===dividerIndex?'<div class="sidebar-divider"></div><div class="sidebar-caption">Quản trị & vận hành</div>':''}<button class="menu-item ${x[0]===active?'active':''}" data-nav="${x[0]}"><span class="menu-item-icon">${uiIcon(x[1])}</span><span class="menu-item-label">${x[2]}</span></button>`).join('');
  $('#sidebar-menu').innerHTML=`<div class="sidebar-brand"><div class="sidebar-brand-mark">A4</div><div><strong>An Đông 4</strong><span>Shinhan Finance</span></div></div><div class="sidebar-nav-scroll">${rows}</div><div class="sidebar-profile"><div class="sidebar-profile-avatar">${esc(initials(u.display_name))}</div><div class="sidebar-profile-copy"><strong>${esc(u.display_name)}</strong><small>${esc(premiumRoleLabel(role,u.staff_type))}</small></div><span class="sidebar-profile-status"></span></div>`;
  $$('[data-nav]',$('#sidebar-menu')).forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
}
function v95_render(){
  const main=$('#main'),role=state.session?.user?.role||'sale';$('#app')?.classList.remove('dashboard-redesign');
  const map={dashboard:renderDashboard,customerdb:role==='sale'?renderTelesale:renderCallDetails,lead:renderLeads,followup:renderFollowup,loanCare:renderLoanCare,teamManagement:renderEmployees,kpi:renderKPI,warehouseAdmin:renderWarehouseAdmin,io:renderImport,settings:renderSettings,audit:renderAuditLogs};
  (map[state.page]||renderDashboard)(main);ensureFloatingChat();
}
allowedPagesForRole=v95_allowedPagesForRole;
premiumSidebarItems=v95_premiumSidebarItems;
premiumPageTitle=v95_premiumPageTitle;
renderSidebar=v95_renderSidebar;
render=v95_render;


/* =====================================================================
   V9.7 LOGIN APP + CUSTOMER CARE LIFECYCLE
   - Lịch gọi lại -> Follow-up
   - Khách hàng sau giải ngân -> Chăm sóc khách hàng
   - Login App workflow: Login -> Duyệt / Từ chối -> Care / Follow-up
   ===================================================================== */
const LOGIN_APP_LABELS={LOGIN_APP:'Đã login app',APPROVED:'Được duyệt',REJECT_RETRY:'Từ chối · Có thể lên lại',REJECT_CLOSED:'Từ chối · Không lên lại'};
const LOGIN_APP_CUSTOMER_SOURCES=['Data','TikTok','Facebook','Thị trường','CTV'];
const VIETNAM_PROVINCES_2025=[
  'Hà Nội','Hải Phòng','Huế','Đà Nẵng','Cần Thơ','Thành phố Hồ Chí Minh',
  'Lai Châu','Điện Biên','Sơn La','Lạng Sơn','Cao Bằng','Tuyên Quang','Lào Cai','Thái Nguyên','Phú Thọ','Bắc Ninh','Hưng Yên','Ninh Bình',
  'Quảng Ninh','Thanh Hóa','Nghệ An','Hà Tĩnh','Quảng Trị','Quảng Ngãi','Gia Lai','Khánh Hòa','Lâm Đồng','Đắk Lắk','Đồng Nai','Tây Ninh',
  'Vĩnh Long','Đồng Tháp','Cà Mau','An Giang'
];
function v97_fmtDateOnly(v){const d=dateKey(v||'');if(!d)return '—';const [y,m,day]=d.split('-');return `${day}/${m}/${y}`}
function v97_daysSince(v){const d=dateKey(v||'');if(!d)return -1;return Math.floor((Date.parse(todayISO()+'T00:00:00Z')-Date.parse(d+'T00:00:00Z'))/86400000)}
function v97_loginPill(status){const cls={LOGIN_APP:'login',APPROVED:'approved',REJECT_RETRY:'retry',REJECT_CLOSED:'closed'}[status]||'login';return `<span class="loginapp-status ${cls}">${esc(LOGIN_APP_LABELS[status]||status)}</span>`}
async function loadLoginApps(force=false){
  if(state.mode!=='d1')return;
  if(state.loginAppsLoading)return;
  if(!force&&state.loginAppsLoadedAt&&Date.now()-state.loginAppsLoadedAt<30000)return;
  state.loginAppsLoading=true;state.loginAppsError='';
  try{
    const p=new URLSearchParams();
    if(state.loginAppsTeam)p.set('team_id',state.loginAppsTeam);
    if(state.loginAppsUser)p.set('user_id',state.loginAppsUser);
    if(state.loginAppsSearch)p.set('q',state.loginAppsSearch);
    const r=await API.request('/login-apps'+(p.toString()?`?${p}`:''),{timeoutMs:20000});
    state.loginApps=r.items||[];state.loginAppsLoadedAt=Date.now();
  }catch(e){state.loginAppsError=e.message||'Không tải được danh sách Login App.'}
  finally{state.loginAppsLoading=false;}
}
function v97_loginRows(){
  const tab=state.loginAppsTab||'active',q=String(state.loginAppsSearch||'').trim().toLowerCase();
  return (state.loginApps||[]).filter(x=>{
    if(tab==='active'&&x.status!=='LOGIN_APP')return false;
    if(tab==='approved'&&x.status!=='APPROVED')return false;
    if(tab==='retry'&&x.status!=='REJECT_RETRY')return false;
    if(tab==='closed'&&x.status!=='REJECT_CLOSED')return false;
    if(q&&!`${x.customer_name||''} ${x.phone||''} ${x.cccd||''} ${x.owner||''} ${x.team||''}`.toLowerCase().includes(q))return false;
    return true;
  });
}
function renderLoginApps(main){
  const role=state.session.user.role;state.loginAppsTab=state.loginAppsTab||'active';state.loginAppsSearch=state.loginAppsSearch||'';
  if(role==='teamlead')state.loginAppsTeam=String(state.session.user.team_id||'');
  if(role==='sale'){state.loginAppsTeam=String(state.session.user.team_id||'');state.loginAppsUser=String(state.session.user.id||'');}
  if(state.mode==='d1'&&(!state.loginAppsLoadedAt&&!(state.loginApps||[]).length)&&!state.loginAppsLoading){
    main.innerHTML='<div class="empty">Đang tải Login App…</div>';loadLoginApps(true).then(()=>{if(state.page==='loginApp')renderLoginApps(main)});return;
  }
  const rows=state.loginApps||[],active=rows.filter(x=>x.status==='LOGIN_APP').length,approved=rows.filter(x=>x.status==='APPROVED').length,retry=rows.filter(x=>x.status==='REJECT_RETRY').length,closed=rows.filter(x=>x.status==='REJECT_CLOSED').length,allVisible=v97_loginRows(),visible=v1031PageSlice(allVisible,'loginApp');
  const roleUsers=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||Number(u.team_id)===Number(state.session.user.team_id))&&(!state.loginAppsTeam||String(u.team_id)===String(state.loginAppsTeam)));
  const teamOptions=(role==='admin'||role==='sup')?`<select id="loginapp-team"><option value="">Tất cả Team</option>${state.teamObjects.map(t=>`<option value="${t.id}" ${String(t.id)===String(state.loginAppsTeam||'')?'selected':''}>${esc(t.name)}</option>`).join('')}</select>`:'';
  const userOptions=role!=='sale'?`<select id="loginapp-user"><option value="">Tất cả nhân viên</option>${roleUsers.map(u=>`<option value="${u.id}" ${String(u.id)===String(state.loginAppsUser||'')?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select>`:'';
  const scopeText=(role==='admin'||role==='sup')?'Toàn hệ thống':role==='teamlead'?`Team ${state.session.user.team||''}`:'Khách do chính bạn nhập và phụ trách';
  main.innerHTML=`<div class="premium-page loginapp-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Login App</h1><p>${esc(scopeText)} · Theo dõi từ lúc Login App đến khi duyệt giải ngân hoặc hẹn tương tác lại.</p></div><div class="premium-page-actions"><a class="btn" href="templates/Mau_nhap_Login_App.xlsx" download>⬇ File mẫu</a><button class="btn" id="loginapp-import">⇧ Nhập Excel</button>${role==='sale'?'<button class="btn primary" id="loginapp-add">+ Thêm khách Login App</button>':''}<button class="btn" id="loginapp-refresh">↻ Làm mới</button></div></div>${state.loginAppsError?`<div class="notice warning">${esc(state.loginAppsError)}</div>`:''}
    <section class="loginapp-summary"><article><span>Đã Login App</span><strong>${active}</strong><small>Đang chờ kết quả</small></article><article class="success"><span>Được duyệt</span><strong>${approved}</strong><small>Đã chuyển Chăm sóc khách hàng</small></article><article class="warn"><span>Hẹn lên lại</span><strong>${retry}</strong><small>Đã chuyển Follow-up</small></article><article class="muted"><span>Đã loại</span><strong>${closed}</strong><small>Không lên lại được</small></article></section>
    <section class="crm-panel"><div class="loginapp-tabs"><button class="${state.loginAppsTab==='active'?'active':''}" data-loginapp-tab="active">Đang xử lý <span>${active}</span></button><button class="${state.loginAppsTab==='approved'?'active':''}" data-loginapp-tab="approved">Được duyệt <span>${approved}</span></button><button class="${state.loginAppsTab==='retry'?'active':''}" data-loginapp-tab="retry">Follow-up <span>${retry}</span></button><button class="${state.loginAppsTab==='closed'?'active':''}" data-loginapp-tab="closed">Đã loại <span>${closed}</span></button></div>
      <div class="loginapp-toolbar"><input id="loginapp-search" placeholder="Tìm tên KH, SĐT, CCCD, nhân viên…" value="${esc(state.loginAppsSearch)}">${teamOptions}${userOptions}</div>
      <div class="table-wrap"><table class="data-table loginapp-table"><thead><tr><th>Tên KH</th><th>SĐT</th><th>CCCD</th><th>Nhân viên</th>${(role==='admin'||role==='sup')?'<th>Team</th>':''}<th>Trạng thái</th><th>Thời gian</th><th>Thao tác</th></tr></thead><tbody>${visible.map(x=>`<tr><td><strong>${esc(x.customer_name||'')}</strong>${Number(x.topup_requested_amount||0)>0?`<small class="loginapp-inline-note topup-note">Topup: ${loanMoney(x.topup_requested_amount)}</small>`:''}</td><td>${esc(x.phone||'')}</td><td>${esc(x.cccd||'')}</td><td>${esc(x.owner||'')}</td>${(role==='admin'||role==='sup')?`<td>${esc(x.team||'')}</td>`:''}<td>${v97_loginPill(x.status)}${x.status==='REJECT_RETRY'&&x.retry_at?`<small class="loginapp-inline-note">Hẹn lên lại: ${shortDate(dateKey(x.retry_at))}</small>`:''}</td><td><div class="loginapp-time-cell">${v1037_loginAppTimeLabel(x)}${x.status==='APPROVED'&&v1037_loginAppEffectiveDate(x)===dateKey(x.disbursement_date||'')&&dateKey(x.disbursement_date||'')&&dateKey(x.disbursement_date||'')!==dateKey(x.created_at||'')?'<small class="loginapp-inline-note">Theo ngày giải ngân</small>':''}</div></td><td><div class="lead-actions loginapp-row-actions">${x.status==='LOGIN_APP'?`<button class="btn small primary" data-loginapp-update="${x.id}">Cập nhật kết quả</button>`:''}${x.status==='REJECT_RETRY'?`<button class="btn small primary" data-loginapp-relogin="${x.id}">Đã Login lại</button><button class="btn small" data-loginapp-update="${x.id}">Đổi kết quả</button>`:''}${x.status==='APPROVED'?`<button class="btn small" data-loginapp-care="${x.id}">Xem CSKH</button>`:''}${x.status==='REJECT_CLOSED'?'<span class="muted">Đã kết thúc</span>':''}${['admin','sup','teamlead'].includes(role)?`<button class="btn small danger" data-loginapp-delete="${x.id}" data-loginapp-name="${esc(x.customer_name||'')}">Xóa</button>`:''}</div></td></tr>`).join('')||`<tr><td colspan="${(role==='admin'||role==='sup')?8:7}"><div class="empty">Không có khách phù hợp.</div></td></tr>`}</tbody></table></div>
    </section></div>`;
  $('#loginapp-refresh').onclick=async()=>{state.loginAppsLoadedAt=0;await loadLoginApps(true);renderLoginApps(main)};
  if($('#loginapp-import'))$('#loginapp-import').onclick=()=>openLoginAppImport();
  if($('#loginapp-add'))$('#loginapp-add').onclick=()=>openLoginAppCreate();
  $('#loginapp-search').oninput=e=>{state.loginAppsSearch=e.target.value;state._v1031PageloginApp=1;renderLoginApps(main)};
  if($('#loginapp-team'))$('#loginapp-team').onchange=async e=>{state.loginAppsTeam=e.target.value;state.loginAppsUser='';state.loginAppsLoadedAt=0;await loadLoginApps(true);renderLoginApps(main)};
  if($('#loginapp-user'))$('#loginapp-user').onchange=async e=>{state.loginAppsUser=e.target.value;state.loginAppsLoadedAt=0;await loadLoginApps(true);renderLoginApps(main)};
  $$('[data-loginapp-tab]').forEach(b=>b.onclick=()=>{state.loginAppsTab=b.dataset.loginappTab;renderLoginApps(main)});
  $$('[data-loginapp-update]').forEach(b=>b.onclick=()=>openLoginAppUpdate(Number(b.dataset.loginappUpdate)));
  $$('[data-loginapp-relogin]').forEach(b=>b.onclick=async()=>{try{await API.request(`/login-apps/${b.dataset.loginappRelogin}`,{method:'PATCH',body:JSON.stringify({status:'LOGIN_APP'})});state.loginAppsLoadedAt=0;await loadLoginApps(true);renderLoginApps(main);toast('Đã chuyển khách về trạng thái Login App.');}catch(e){toast(e.message,'bad')}});
  $$('[data-loginapp-care]').forEach(b=>b.onclick=()=>navigate('loanCare'));
  $$('[data-loginapp-delete]').forEach(b=>b.onclick=async()=>{if(!['admin','sup','teamlead'].includes(state.session.user.role))return;const name=b.dataset.loginappName||'khách hàng này';if(!confirm(`Xóa ${name} khỏi Login App? Dữ liệu Chăm sóc khách hàng (nếu có) sẽ không tự bị xóa.`))return;try{await API.request(`/login-apps/${b.dataset.loginappDelete}`,{method:'DELETE'});state.loginAppsLoadedAt=0;await loadLoginApps(true);renderLoginApps(main);toast('Đã xóa khách khỏi Login App.');}catch(e){toast(e.message,'bad')}});
}
function openLoginAppCreate(){
  const me=state.session.user;
  openAdminModal('Thêm khách Login App',`<form id="loginapp-create-form" class="form-grid loginapp-create-form"><div class="form-field"><label>Tên khách hàng</label><input id="loginapp-name" autocomplete="off" required></div><div class="form-field"><label>Số điện thoại <span class="field-required">*</span></label><input id="loginapp-phone" inputmode="numeric" autocomplete="off" maxlength="10" minlength="10" pattern="[0-9]{10}" placeholder="Nhập đúng 10 số" required></div><div class="form-field"><label>CCCD <span class="field-required">*</span></label><input id="loginapp-cccd" inputmode="numeric" autocomplete="off" maxlength="12" minlength="12" pattern="[0-9]{12}" placeholder="Nhập đúng 12 số" required></div><div class="form-field"><label>Nhân viên</label><input value="${esc(me.display_name)}" disabled></div><div class="form-field full"><div class="notice">Sau khi lưu, trạng thái mặc định là <strong>Đã Login App</strong>.</div></div><div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="loginapp-create-cancel">Hủy</button><button class="btn primary" type="submit">Lưu Login App</button></div></div></form>`);
  const modal=$('#admin-modal .admin-modal');if(modal)modal.classList.add('loginapp-create-admin-modal');
  const phone=$('#loginapp-phone'),cccd=$('#loginapp-cccd');
  const digitsOnly=(el,max)=>{el.value=String(el.value||'').replace(/\D/g,'').slice(0,max)};
  phone.oninput=()=>digitsOnly(phone,10);cccd.oninput=()=>digitsOnly(cccd,12);
  $('#loginapp-create-cancel').onclick=closeAdminModal;
  $('#loginapp-create-form').onsubmit=async e=>{e.preventDefault();digitsOnly(phone,10);digitsOnly(cccd,12);if(!/^\d{10}$/.test(phone.value)){toast('Số điện thoại bắt buộc đúng 10 số.','bad');phone.focus();return;}if(!/^\d{12}$/.test(cccd.value)){toast('CCCD bắt buộc đúng 12 số.','bad');cccd.focus();return;}try{await API.request('/login-apps',{method:'POST',body:JSON.stringify({customer_name:$('#loginapp-name').value,phone:phone.value,cccd:cccd.value,assigned_user_id:me.id})});state.loginAppsLoadedAt=0;await loadLoginApps(true);closeAdminModal();renderLoginApps($('#main'));toast('Đã thêm khách Login App.');}catch(err){toast(err.message,'bad')}};
}
function loginAppImportPrior(v){
  const s=String(v??'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d');
  if(['co','1','yes','y','true'].includes(s))return 1;
  if(['chua','0','no','n','false'].includes(s))return 0;
  return null;
}
function normalizeLoginAppImportPhone(v){
  let s=String(v??'').trim().replace(/\.0$/,'').replace(/\D/g,'');
  if(s.startsWith('84')&&s.length===11)s='0'+s.slice(2);
  if(s.length===9)s='0'+s; // Excel thường làm mất đúng 1 số 0 ở đầu.
  return s;
}
function normalizeLoginAppImportCccd(v){
  let s=String(v??'').trim().replace(/\.0$/,'').replace(/\D/g,'');
  if(s.length===11)s='0'+s; // CCCD có thể mất đúng 1 số 0 đầu khi Excel coi là Number.
  return s;
}
function loginAppImportLengthError(label,value,expected){
  const len=String(value||'').length;if(len===expected)return '';
  if(len>expected)return `${label} dư ${len-expected} số`;
  return `${label} thiếu ${expected-len} số`;
}
function mapLoginAppImportRow(row,rowNumber){
  const name=String(cell(row,['ten khach hang','ten kh','ho ten khach hang','ho ten','khach hang','customer name'])||'').trim();
  const phone=normalizeLoginAppImportPhone(cell(row,['sdt','so dien thoai','dien thoai','phone','phone number']));
  const cccd=normalizeLoginAppImportCccd(cell(row,['cccd','can cuoc cong dan','so cccd','cmnd cccd']));
  return {row_number:rowNumber,customer_name:name,phone,cccd};
}
async function readLoginAppImportFile(file){
  if(!window.XLSX)throw new Error('Không tải được thư viện Excel. Hãy kiểm tra Internet rồi tải lại trang.');
  const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true});
  if(!wb.SheetNames.length)return [];
  const rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:'',raw:true});
  return rows.map((r,i)=>mapLoginAppImportRow(r,i+2)).filter(x=>x.customer_name||x.phone||x.cccd);
}
function openLoginAppImport(){
  const role=state.session.user.role;
  const allowedUsers=state.users.filter(u=>u.role==='sale'&&u.active!==0&&((role==='admin'||role==='sup')||role==='sale'&&Number(u.id)===Number(state.session.user.id)||role==='teamlead'&&Number(u.team_id)===Number(state.session.user.team_id)));
  const ownerSelect=role==='sale'
    ? `<div class="form-field full"><div class="notice"><strong>Nhân viên phụ trách:</strong> ${esc(state.session.user.display_name)}. CRM tự gán toàn bộ khách trong file cho tài khoản đang đăng nhập.</div></div>`
    : `<div class="form-field full"><label>Nhân viên phụ trách <span class="field-required">*</span></label><select id="loginapp-import-default-user" required><option value="">-- Chọn nhân viên nhận khách --</option>${allowedUsers.map(u=>`<option value="${u.id}">${esc(u.display_name)}</option>`).join('')}</select><small class="muted">Không cần cột nhân viên trong Excel. Toàn bộ khách trong file sẽ được gán cho nhân viên được chọn.</small></div>`;
  openAdminModal('Nhập Login App từ Excel',`<div class="loginapp-import-modal"><div class="notice"><strong>File chỉ cần 3 cột:</strong> Tên khách hàng, SĐT, CCCD.<br><small>SĐT 9 số hoặc CCCD 11 số do mất số 0 đầu sẽ được tự bổ sung 0. Dư số hoặc thiếu nhiều hơn 1 số sẽ báo lỗi.</small></div><div class="loginapp-import-actions"><button type="button" class="btn" id="loginapp-download-template">⬇ Tải file Excel mẫu</button></div><form id="loginapp-import-form" class="form-grid"><div class="form-field full"><label>Chọn file Excel</label><input id="loginapp-import-file" type="file" accept=".xlsx,.xls" required></div>${ownerSelect}<div class="form-field full"><div id="loginapp-import-summary" class="loginapp-import-summary muted">Chọn file để xem trước dữ liệu.</div></div><div class="form-field full loginapp-import-preview-field"><div id="loginapp-import-preview"></div></div><div class="form-field full loginapp-import-footer"><div class="call-actions"><button type="button" class="btn" id="loginapp-import-cancel">Hủy</button><button type="submit" class="btn primary" id="loginapp-import-submit" disabled>Nhập vào Login App</button></div></div></form></div>`);
  const modal=$('#admin-modal .admin-modal');if(modal)modal.classList.add('loginapp-import-admin-modal');
  const fileInput=$('#loginapp-import-file'),submit=$('#loginapp-import-submit'),summary=$('#loginapp-import-summary'),preview=$('#loginapp-import-preview');
  const templateBtn=$('#loginapp-download-template');
  if(templateBtn)templateBtn.onclick=()=>{
    if(!window.XLSX){toast('Không tải được thư viện Excel. Hãy tải lại trang.','bad');return;}
    const ws=XLSX.utils.aoa_to_sheet([
      ['Tên khách hàng','SĐT','CCCD'],
      ['Nguyễn Văn A','0901234567','079123456789'],
      ['Trần Thị B','0912345678','079987654321']
    ]);
    ws['!cols']=[{wch:28},{wch:18},{wch:20}];
    const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Login App');
    XLSX.writeFile(wb,'Mau_nhap_Login_App_V10.16.xlsx');
  };
  let rawRows=[];
  const getDefaultUser=()=>role==='sale'?Number(state.session.user.id):Number($('#loginapp-import-default-user')?.value||0);
  const validate=()=>{
    const defaultUser=getDefaultUser();
    const owner=allowedUsers.find(u=>Number(u.id)===Number(defaultUser));
    const seenPhone=new Set(),seenCccd=new Set();
    const rows=rawRows.map(x=>{
      const y={...x},errors=[];
      if(!y.customer_name)errors.push('Thiếu tên KH');
      const phoneError=loginAppImportLengthError('SĐT',y.phone,10);if(phoneError)errors.push(phoneError);
      const cccdError=loginAppImportLengthError('CCCD',y.cccd,12);if(cccdError)errors.push(cccdError);
      if(!owner)errors.push(role==='sale'?'Không xác định được tài khoản nhân viên':'Chưa chọn nhân viên phụ trách');
      if(owner){y.assigned_user_id=owner.id;y.owner_name=owner.display_name;}
      if(y.phone&&seenPhone.has(y.phone))errors.push('Trùng SĐT trong file');
      if(y.cccd&&seenCccd.has(y.cccd))errors.push('Trùng CCCD trong file');
      if(y.phone)seenPhone.add(y.phone);if(y.cccd)seenCccd.add(y.cccd);
      y.error=errors.join(' · ');return y;
    });
    const valid=rows.filter(x=>!x.error),bad=rows.length-valid.length;
    summary.innerHTML=rawRows.length?`<strong>${rawRows.length}</strong> dòng · <span class="good"><strong>${valid.length}</strong> hợp lệ</span>${bad?` · <span class="duplicate"><strong>${bad}</strong> cần sửa</span>`:''}`:'Chưa có dữ liệu.';
    preview.innerHTML=rows.length?`<div class="table-wrap loginapp-import-preview"><table class="data-table"><thead><tr><th>Dòng</th><th>Tên KH</th><th>SĐT</th><th>CCCD</th><th>Phụ trách</th><th>Kiểm tra</th></tr></thead><tbody>${rows.slice(0,20).map(x=>`<tr class="${x.error?'import-duplicate':''}"><td>${x.row_number}</td><td>${esc(x.customer_name)}</td><td>${esc(x.phone)}</td><td>${esc(x.cccd)}</td><td>${esc(x.owner_name||'')}</td><td>${x.error?`<span class="import-error-text">${esc(x.error)}</span>`:'<span class="good">✓ Hợp lệ</span>'}</td></tr>`).join('')}</tbody></table>${rows.length>20?`<div class="muted preview-note">Hiển thị 20/${rows.length} dòng.</div>`:''}</div>`:'';
    submit.disabled=!valid.length;return {rows,valid};
  };
  fileInput.onchange=async()=>{const file=fileInput.files?.[0];if(!file)return;submit.disabled=true;summary.textContent='Đang đọc file…';preview.innerHTML='';try{rawRows=await readLoginAppImportFile(file);validate();}catch(e){rawRows=[];summary.textContent='Không đọc được file.';toast(e.message,'bad')}};
  if($('#loginapp-import-default-user'))$('#loginapp-import-default-user').onchange=validate;
  $('#loginapp-import-cancel').onclick=closeAdminModal;
  $('#loginapp-import-form').onsubmit=async e=>{
    e.preventDefault();const {valid}=validate();if(!valid.length)return;
    const ownerId=getDefaultUser();if(!ownerId){toast('Vui lòng chọn nhân viên phụ trách.','bad');return;}
    submit.disabled=true;const old=submit.textContent;let inserted=0,skipped=0,serverSkipped=[];
    try{
      for(let i=0;i<valid.length;i+=100){const chunk=valid.slice(i,i+100).map(x=>({row_number:x.row_number,customer_name:x.customer_name,phone:x.phone,cccd:x.cccd}));submit.textContent=`Đang nhập ${Math.min(i+chunk.length,valid.length)}/${valid.length}…`;const r=await API.request('/login-apps/import',{method:'POST',body:JSON.stringify({items:chunk,default_assigned_user_id:ownerId})});inserted+=Number(r.inserted||0);skipped+=Number(r.skipped_count||0);serverSkipped.push(...(r.skipped||[]));}
      state.loginAppsLoadedAt=0;await loadLoginApps(true);closeAdminModal();renderLoginApps($('#main'));toast(`Đã nhập ${inserted} khách Login App${skipped?` · bỏ qua ${skipped} dòng`:''}.`);
      if(serverSkipped.length)console.warn('Login App import skipped',serverSkipped);
    }catch(err){submit.disabled=false;submit.textContent=old;toast(err.message||'Nhập Excel thất bại.','bad')}
  };
}

function openLoginAppUpdate(id){
  const x=(state.loginApps||[]).find(z=>Number(z.id)===Number(id));if(!x)return;
  const sourceOptions=LOGIN_APP_CUSTOMER_SOURCES.map(v=>`<option value="${esc(v)}" ${String(x.customer_source||'')===v?'selected':''}>${esc(v)}</option>`).join('');
  const provinceOptions=VIETNAM_PROVINCES_2025.map(v=>`<option value="${esc(v)}"></option>`).join('');
  openAdminModal(`Cập nhật Login App · ${x.customer_name}`,`<form id="loginapp-update-form" class="form-grid loginapp-update-v1021">
    <div class="form-field full"><label>Trạng thái hiện tại</label>${v97_loginPill(x.status)}</div>
    <div class="form-field full"><label>Kết quả</label><select id="loginapp-result" required><option value="">-- Chọn kết quả --</option><option value="APPROVED">Được duyệt / Giải ngân</option><option value="REJECT_RETRY">Từ chối · Có thể lên lại</option><option value="REJECT_CLOSED">Từ chối · Không lên lại được</option></select></div>
    <div class="form-field full loginapp-result-block hidden loginapp-profile-fields" id="loginapp-profile-fields">
      <div class="loginapp-profile-title">Thông tin khách hàng bắt buộc</div>
      <div class="form-grid">
        <div class="form-field"><label>Thu nhập</label><div class="vnd-money-shell"><input id="loginapp-income" class="vnd-money-input" type="text" inputmode="numeric" autocomplete="off" placeholder="VD: 15.000.000" value="${Number(x.income_amount||0)>0?Number(x.income_amount).toLocaleString('vi-VN'):''}"><span>VNĐ</span></div></div>
        <div class="form-field"><label>Nguồn KH</label><select id="loginapp-customer-source" required><option value="">-- Chọn nguồn KH --</option>${sourceOptions}</select></div>
        <div class="form-field"><label>Tên Công ty</label><input id="loginapp-company-name" type="text" maxlength="180" value="${esc(x.company_name||'')}" placeholder="Nhập tên công ty"></div>
        <div class="form-field"><label>MST</label><input id="loginapp-company-tax-code" type="text" maxlength="30" inputmode="numeric" value="${esc(x.company_tax_code||'')}" placeholder="Nhập mã số thuế"></div>
        <div class="form-field full"><label>Nơi ở KH</label><input id="loginapp-province" type="text" list="loginapp-province-list" autocomplete="off" value="${esc(x.residence_province||'')}" placeholder="Gõ để tìm tỉnh/thành..."><datalist id="loginapp-province-list">${provinceOptions}</datalist><small class="field-help">Gõ tên tỉnh/thành để tìm nhanh trong 34 tỉnh/thành sau sắp xếp.</small></div>
      </div>
    </div>
    <div class="form-field full loginapp-result-block hidden" id="loginapp-approved-fields"><div class="form-grid">
      <div class="form-field"><label>Số tiền giải ngân</label><div class="vnd-money-shell"><input id="loginapp-disbursement-amount" class="vnd-money-input" type="text" inputmode="numeric" autocomplete="off" placeholder="VD: 10.000.000"><span>VNĐ</span></div></div>
      <div class="form-field"><label>Số tiền đóng hàng tháng</label><div class="vnd-money-shell"><input id="loginapp-monthly-payment" class="vnd-money-input" type="text" inputmode="numeric" autocomplete="off" placeholder="VD: 2.000.000"><span>VNĐ</span></div></div>
      <div class="form-field"><label>Thời gian giải ngân</label><input id="loginapp-disbursement-date" type="date"></div>
      <div class="form-field"><label>Kỳ hạn vay (tháng)</label><input id="loginapp-term" type="number" min="1"></div>
    </div></div>
    <div class="form-field full loginapp-result-block hidden" id="loginapp-retry-fields"><label>Ngày có thể lên lại</label><input id="loginapp-retry-at" type="date"></div>
    <div class="form-field full loginapp-result-block hidden" id="loginapp-reason-fields"><label>Lý do / ghi chú</label><textarea id="loginapp-reason" rows="3" placeholder="Nhập lý do từ chối hoặc ghi chú…">${esc(x.reject_reason||'')}</textarea></div>
    <div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="loginapp-update-cancel">Hủy</button><button class="btn primary" type="submit">Lưu kết quả</button></div></div>
  </form>`);
  const updateModal=$('#admin-modal .admin-modal');if(updateModal)updateModal.classList.add('loginapp-update-admin-modal');
  const result=$('#loginapp-result');
  const moneyDigits=v=>String(v||'').replace(/\D/g,'');
  const moneyNumber=v=>Number(moneyDigits(v)||0);
  const bindMoneyInput=(el)=>{if(!el)return;el.oninput=()=>{const digits=moneyDigits(el.value).slice(0,15);el.value=digits?Number(digits).toLocaleString('vi-VN'):'';};el.onblur=()=>{let n=moneyNumber(el.value);if(n>0&&n<1000000)n*=1000;el.value=n?n.toLocaleString('vi-VN'):'';};};
  bindMoneyInput($('#loginapp-income'));bindMoneyInput($('#loginapp-disbursement-amount'));bindMoneyInput($('#loginapp-monthly-payment'));
  const sync=()=>{const v=result.value;$('#loginapp-profile-fields').classList.toggle('hidden',!v);$('#loginapp-approved-fields').classList.toggle('hidden',v!=='APPROVED');$('#loginapp-retry-fields').classList.toggle('hidden',v!=='REJECT_RETRY');$('#loginapp-reason-fields').classList.toggle('hidden',!['REJECT_RETRY','REJECT_CLOSED'].includes(v));};result.onchange=sync;sync();
  $('#loginapp-update-cancel').onclick=closeAdminModal;
  $('#loginapp-update-form').onsubmit=async e=>{
    e.preventDefault();const status=result.value;if(!status)return;
    const income=moneyNumber($('#loginapp-income')?.value);
    const customerSource=$('#loginapp-customer-source')?.value||'';
    const companyName=($('#loginapp-company-name')?.value||'').trim();
    const companyTaxCode=($('#loginapp-company-tax-code')?.value||'').trim();
    const residenceProvince=($('#loginapp-province')?.value||'').trim();
    if(!income){toast('Vui lòng nhập Thu nhập của khách hàng.','bad');$('#loginapp-income')?.focus();return;}
    if(!LOGIN_APP_CUSTOMER_SOURCES.includes(customerSource)){toast('Vui lòng chọn Nguồn KH.','bad');$('#loginapp-customer-source')?.focus();return;}
    if(!companyName){toast('Vui lòng nhập Tên Công ty.','bad');$('#loginapp-company-name')?.focus();return;}
    if(!companyTaxCode){toast('Vui lòng nhập MST.','bad');$('#loginapp-company-tax-code')?.focus();return;}
    if(!VIETNAM_PROVINCES_2025.includes(residenceProvince)){toast('Vui lòng chọn Nơi ở KH trong danh sách tỉnh/thành.','bad');$('#loginapp-province')?.focus();return;}
    const body={status,reject_reason:$('#loginapp-reason')?.value||'',income_amount:income,customer_source:customerSource,company_name:companyName,company_tax_code:companyTaxCode,residence_province:residenceProvince};
    if(status==='APPROVED'){
      const disbursement=moneyNumber($('#loginapp-disbursement-amount').value),monthly=moneyNumber($('#loginapp-monthly-payment').value);
      if(!disbursement){toast('Vui lòng nhập số tiền giải ngân.','bad');$('#loginapp-disbursement-amount').focus();return;}
      if(!monthly){toast('Vui lòng nhập số tiền đóng hàng tháng.','bad');$('#loginapp-monthly-payment').focus();return;}
      Object.assign(body,{disbursement_amount:disbursement,monthly_payment:monthly,disbursement_date:$('#loginapp-disbursement-date').value,term_months:Number($('#loginapp-term').value||0)});
    }
    if(status==='REJECT_RETRY')body.retry_at=$('#loginapp-retry-at').value;
    try{
      await API.request(`/login-apps/${id}`,{method:'PATCH',body:JSON.stringify(body)});
      state.loginAppsLoadedAt=0;state.loanCareLoadedAt=0;await loadLoginApps(true);closeAdminModal();renderLoginApps($('#main'));
      toast(status==='APPROVED'?'Đã duyệt và chuyển vào Chăm sóc khách hàng.':status==='REJECT_RETRY'?'Đã chuyển khách sang Follow-up.':'Đã loại khách khỏi danh sách xử lý.');
    }catch(err){toast(err.message,'bad')}
  };
}

function v98_loanLifecycle(x){
  const age=v97_daysSince(x.disbursement_date);
  if(String(x.status)==='TOPUP')return {key:'topup_active',label:'Topup · Đã chuyển Login App',cls:'topup',age:Math.max(0,age)};
  if(!x.disbursement_date||age<0)return {key:'unknown',label:'Chưa đủ thông tin',cls:'unknown',age:0};
  if(age<30)return {key:'new',label:'Mới giải ngân',cls:'new',age};
  if(age<60){
    if(Number(x.care30_done))return {key:'care30_done',label:'Đã chăm sóc lần 1',cls:'done',age};
    return {key:'care30',label:'Đủ 1 tháng · cần CS',cls:'care30',age};
  }
  if(age<90){
    if(Number(x.care60_done))return {key:'care60_done',label:'Đã chăm sóc lần 2',cls:'done',age};
    return {key:'care60',label:'Đủ 2 tháng · cần CS',cls:'care60',age};
  }
  return {key:'topup',label:'Đủ điều kiện Topup',cls:'topup',age};
}
function v98_lifecyclePill(x){const s=v98_loanLifecycle(x);return `<span class="care-stage-pill ${s.cls}">${esc(s.label)}</span><small class="care-stage-age">${s.key==='unknown'?'':`${s.age} ngày sau giải ngân`}</small>`;}

function v97_loanCareStats(rows){
  const today=todayISO();
  const active=rows.filter(x=>String(x.status)!=='SETTLED');
  const totalDebt=active.reduce((n,x)=>n+Number(x.current_balance||0),0);
  const dueToday=active.filter(x=>dateKey(x.next_due_date||'')===today).length;
  const care30=active.filter(x=>v97_daysSince(x.disbursement_date)>=30&&!Number(x.care30_done)).length;
  const care60=active.filter(x=>v97_daysSince(x.disbursement_date)>=60&&!Number(x.care60_done)).length;
  const topup=active.filter(x=>v97_daysSince(x.disbursement_date)>=90&&String(x.status)!=='TOPUP').length;
  const nearEnd=active.filter(x=>{const d=dateKey(x.maturity_date||'');return d&&d>=today&&d<=addDays(today,30)}).length;
  return {total:rows.length,totalDebt,dueToday,care30,care60,topup,nearEnd};
}
function v97_loanFilteredRows(){
  const rows=state.loanProfiles||[],tab=state.loanCareTab||'all',q=String(state.loanCareSearch||'').trim().toLowerCase(),today=todayISO();
  return rows.filter(x=>{
    const age=v97_daysSince(x.disbursement_date),active=String(x.status)!=='SETTLED';
    if(tab==='dueToday'&&!(active&&dateKey(x.next_due_date||'')===today))return false;
    if(tab==='care30'&&!(active&&age>=30&&!Number(x.care30_done)))return false;
    if(tab==='care60'&&!(active&&age>=60&&!Number(x.care60_done)))return false;
    if(tab==='topup'&&!(active&&age>=90&&String(x.status)!=='TOPUP'))return false;
    if(tab==='nearEnd'){const d=dateKey(x.maturity_date||'');if(!(active&&d&&d>=today&&d<=addDays(today,30)))return false;}
    if(q&&!`${x.customer_name||''} ${x.phone||''} ${x.cccd||''} ${x.owner||''} ${x.team||''}`.toLowerCase().includes(q))return false;
    return true;
  });
}
function v97_renderLoanCare(main){
  const role=state.session.user.role;state.loanCareTab=state.loanCareTab||'all';state.loanCareSearch=state.loanCareSearch||'';
  if(role==='teamlead')state.loanCareTeam=String(state.session.user.team_id||'');if(role==='sale'){state.loanCareTeam=String(state.session.user.team_id||'');state.loanCareUser=String(state.session.user.id||'');}
  if(state.mode==='d1'&&(!state.loanCareLoadedAt&&!(state.loanProfiles||[]).length)&&!state.loanCareLoading){main.innerHTML='<div class="empty">Đang tải Chăm sóc khách hàng…</div>';loadLoanCare(true).then(()=>{if(state.page==='loanCare')renderLoanCare(main)});return;}
  const rows=state.loanProfiles||[],stats=v97_loanCareStats(rows),allVisible=v97_loanFilteredRows(),visible=v1031PageSlice(allVisible,'loanCare');
  const roleUsers=state.users.filter(u=>u.role==='sale'&&((role==='admin'||role==='sup')||Number(u.team_id)===Number(state.session.user.team_id))&&(!state.loanCareTeam||String(u.team_id)===String(state.loanCareTeam)));
  const teamTabs=(role==='admin'||role==='sup')
    ? `<div class="loan-care-team-tabs"><button type="button" class="loan-care-team-tab ${!state.loanCareTeam?'active':''}" data-loan-team-tab="">Tất cả Team</button>${state.teamObjects.map(t=>`<button type="button" class="loan-care-team-tab ${String(t.id)===String(state.loanCareTeam||'')?'active':''}" data-loan-team-tab="${t.id}">${esc(t.name)}</button>`).join('')}</div>`
    : role==='teamlead'
      ? `<div class="loan-care-team-tabs"><button type="button" class="loan-care-team-tab active" data-loan-team-tab="${esc(String(state.session.user.team_id||''))}">${esc(state.session.user.team||'Team của bạn')}</button></div>`
      : '';
  const userOptions=role!=='sale'?`<select id="loan-user"><option value="">Tất cả nhân viên</option>${roleUsers.map(u=>`<option value="${u.id}" ${String(u.id)===String(state.loanCareUser||'')?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select>`:'';
  main.innerHTML=`<div class="premium-page loan-care-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Chăm sóc khách hàng</h1></div><div class="premium-page-actions"><button class="btn" id="loan-refresh">↻ Làm mới</button></div></div>${teamTabs}${state.loanCareError?`<div class="notice warning">${esc(state.loanCareError)}</div>`:''}
    <section class="care-summary-top"><article><span>Tổng KH</span><strong>${stats.total.toLocaleString('vi-VN')}</strong><small>Khách đang quản lý</small></article><article><span>Tổng Dư nợ</span><strong>${loanMoney(stats.totalDebt)}</strong><small>VNĐ</small></article><article><span>KH đến ngày TT hôm nay</span><strong>${stats.dueToday}</strong><small>Cần liên hệ thanh toán</small></article></section>
    <section class="care-summary-bottom"><article><span>KH đến hạn chăm sóc lần 1</span><strong>${stats.care30}</strong><small>Khách sau 30 ngày</small></article><article><span>KH đến hạn chăm sóc lần 2</span><strong>${stats.care60}</strong><small>Khách sau 60 ngày</small></article><article class="success"><span>KH đủ điều kiện Topup</span><strong>${stats.topup}</strong><small>Khách sau 90 ngày</small></article><article><span>KH sắp kết thúc hợp đồng</span><strong>${stats.nearEnd}</strong><small>Trong 30 ngày tới</small></article></section>
    <section class="crm-panel loan-care-panel"><div class="loan-tabs"><button class="${state.loanCareTab==='all'?'active':''}" data-loan-tab="all">Tất cả <span>${rows.length}</span></button><button class="${state.loanCareTab==='care30'?'active':''}" data-loan-tab="care30">CS lần 1 <span>${stats.care30}</span></button><button class="${state.loanCareTab==='care60'?'active':''}" data-loan-tab="care60">CS lần 2 <span>${stats.care60}</span></button><button class="${state.loanCareTab==='topup'?'active':''}" data-loan-tab="topup">Topup <span>${stats.topup}</span></button><button class="${state.loanCareTab==='nearEnd'?'active':''}" data-loan-tab="nearEnd">Sắp kết thúc <span>${stats.nearEnd}</span></button></div><div class="loan-toolbar"><input id="loan-search" placeholder="Tìm tên KH, SĐT, CCCD…" value="${esc(state.loanCareSearch)}">${userOptions}</div>
      <div class="table-wrap loan-table-wrap care-v1022-wrap"><table class="data-table loan-table care-v97-table care-v98-table care-v1022-table ${role!=='sale'?'care-with-owner':'care-sale-only'}"><colgroup>${role!=='sale'?'<col style="width:14%"><col style="width:10%"><col style="width:14%"><col style="width:13%"><col style="width:14%"><col style="width:8%"><col style="width:9%"><col style="width:8%"><col style="width:10%">':'<col style="width:15%"><col style="width:12%"><col style="width:16%"><col style="width:14%"><col style="width:17%"><col style="width:9%"><col style="width:9%"><col style="width:8%">'}</colgroup><thead><tr><th>Tên KH</th><th>Liên hệ</th><th>Hồ sơ KH</th><th>Công việc</th><th>Khoản vay</th><th>Giải ngân</th><th>Trạng thái</th>${role!=='sale'?'<th>NV phụ trách</th>':''}<th>Thao tác</th></tr></thead><tbody>${visible.map(x=>`<tr><td><strong class="care-customer-name">${esc(x.customer_name||'')}</strong></td><td><div class="care-compact-stack"><span>${esc(x.phone||'—')}</span><small>CCCD: ${esc(x.cccd||'—')}</small></div></td><td><div class="care-compact-stack"><span><b>TN:</b> ${Number(x.income_amount||0)>0?loanMoney(x.income_amount):'—'}</span><small><b>Nguồn:</b> ${esc(x.customer_source||'—')}</small><small><b>Nơi ở:</b> ${esc(x.residence_province||'—')}</small></div></td><td><div class="care-compact-stack"><span>${esc(x.company_name||'—')}</span><small><b>MST:</b> ${esc(x.company_tax_code||'—')}</small></div></td><td><div class="care-compact-stack care-loan-stack"><span><b>GN:</b> ${loanMoney(x.disbursement_amount)}</span><small><b>Đóng:</b> ${loanMoney(x.monthly_payment)}</small><small><b>Kỳ hạn:</b> ${Number(x.original_term_months||0)} tháng</small></div></td><td>${v97_fmtDateOnly(x.disbursement_date)}</td><td><div class="care-stage-cell">${v98_lifecyclePill(x)}</div></td>${role!=='sale'?`<td><div class="loan-person"><strong>${esc(x.owner||'')}</strong><small>${esc(x.team||'')}</small></div></td>`:''}<td><div class="loan-actions care-row-actions"><button class="btn small primary care-action-btn" data-loan-detail="${x.id}">Chăm sóc</button>${v98_loanLifecycle(x).key==='topup'?`<button class="btn small success" data-loan-topup="${x.id}">Topup</button>`:String(x.status)==='TOPUP'?'<span class="care-topup-done">Đã Topup</span>':''}${['admin','sup','teamlead'].includes(role)?`<button class="btn small danger" data-loan-delete="${x.id}" data-loan-name="${esc(x.customer_name||'Khách hàng')}">Xóa</button>`:''}</div></td></tr>`).join('')||`<tr><td colspan="${role!=='sale'?9:8}"><div class="empty">Chưa có khách hàng phù hợp.</div></td></tr>`}</tbody></table></div>
    </section></div>`;
  $('#loan-refresh').onclick=async()=>{state.loanCareLoadedAt=0;await loadLoanCare(true);renderLoanCare(main)};$('#loan-search').oninput=e=>{state.loanCareSearch=e.target.value;state._v1031PageloanCare=1;renderLoanCare(main)};
  $$('[data-loan-team-tab]').forEach(b=>b.onclick=async()=>{const next=String(b.dataset.loanTeamTab||'');if(role==='teamlead'&&next!==String(state.session.user.team_id||''))return;state.loanCareTeam=next;state.loanCareUser='';state.loanCareLoadedAt=0;await loadLoanCare(true);renderLoanCare(main)});
  if($('#loan-user'))$('#loan-user').onchange=async e=>{state.loanCareUser=e.target.value;state.loanCareLoadedAt=0;await loadLoanCare(true);renderLoanCare(main)};
  $$('[data-loan-tab]').forEach(b=>b.onclick=()=>{state.loanCareTab=b.dataset.loanTab;renderLoanCare(main)});$$('[data-loan-detail]').forEach(b=>b.onclick=()=>v97_openLoanCareDetail(Number(b.dataset.loanDetail)));
  $$('[data-loan-topup]').forEach(b=>b.onclick=()=>openLoanTopup(Number(b.dataset.loanTopup)));
  $$('[data-loan-delete]').forEach(b=>b.onclick=async()=>{if(!['admin','sup','teamlead'].includes(state.session.user.role))return;const name=b.dataset.loanName||'khách hàng này';if(!confirm(`Xóa ${name} khỏi Chăm sóc khách hàng? Lịch sử chăm sóc của hồ sơ này cũng sẽ bị xóa.`))return;try{await API.request(`/loans/${b.dataset.loanDelete}`,{method:'DELETE'});state.loanCareLoadedAt=0;await loadLoanCare(true);renderLoanCare(main);toast('Đã xóa khách khỏi Chăm sóc khách hàng.');}catch(e){toast(e.message,'bad')}});
}
function openLoanTopup(id){
  const x=(state.loanProfiles||[]).find(v=>Number(v.id)===Number(id));if(!x)return;
  openAdminModal(`Topup · ${x.customer_name}`,`<form id="loan-topup-form" class="form-grid"><div class="form-field full"><div class="notice">Khách đã từng vay Shinhan. Sau khi tạo Topup, khách sẽ được thêm vào <strong>Login App</strong> và trạng thái chăm sóc chuyển thành <strong>Topup</strong>.</div></div><div class="form-field full"><label>Số tiền khách muốn vay thêm</label><input id="loan-topup-amount" type="number" min="1" placeholder="Ví dụ: 50000000" required></div><div class="form-field full"><label>Ghi chú</label><textarea id="loan-topup-note" rows="3" placeholder="Nhu cầu Topup của khách…"></textarea></div><div class="form-field full"><div class="call-actions"><button type="button" class="btn" id="loan-topup-cancel">Hủy</button><button type="submit" class="btn primary">Tạo Login App Topup</button></div></div></form>`);
  $('#loan-topup-cancel').onclick=closeAdminModal;
  $('#loan-topup-form').onsubmit=async e=>{e.preventDefault();const amount=Number($('#loan-topup-amount').value||0);if(!(amount>0)){toast('Vui lòng nhập số tiền khách muốn vay thêm.','bad');return;}try{await API.request(`/loans/${id}/topup`,{method:'POST',body:JSON.stringify({requested_amount:amount,note:$('#loan-topup-note').value})});state.loanCareLoadedAt=0;state.loginAppsLoadedAt=0;await loadLoanCare(true);closeAdminModal();renderLoanCare($('#main'));toast('Đã chuyển khách Topup sang Login App.');}catch(err){toast(err.message,'bad')}};
}
async function v97_openLoanCareDetail(id){
  const base=(state.loanProfiles||[]).find(x=>Number(x.id)===Number(id));if(!base)return;let history=[];try{const r=await API.request(`/loans/${id}/history`);history=r.items||[]}catch(_e){}
  const role=state.session.user.role,canEdit=((role==='admin'||role==='sup')||role==='teamlead')&&v1029Can('loanCare','update');
  const info=canEdit?`<div class="loan-detail-section"><h3>Thông tin khách hàng & khoản vay</h3><div class="form-grid"><div class="form-field"><label>Tên KH</label><input value="${esc(base.customer_name||'')}" disabled></div><div class="form-field"><label>SĐT</label><input value="${esc(base.phone||'')}" disabled></div><div class="form-field"><label>CCCD</label><input id="loan-cccd" value="${esc(base.cccd||'')}"></div><div class="form-field"><label>Số tiền giải ngân</label><input id="loan-amount" type="number" value="${Number(base.disbursement_amount||0)}"></div><div class="form-field care-combined-field"><label>Số tiền đóng hàng tháng / Kỳ hạn vay</label><div class="care-combined-inputs"><input id="loan-monthly-payment" type="number" value="${Number(base.monthly_payment||0)}" placeholder="Số tiền/tháng"><div class="care-term-input"><input id="loan-term" type="number" min="1" value="${Number(base.original_term_months||0)}" placeholder="Kỳ hạn"><span>tháng</span></div></div></div><div class="form-field"><label>Thời gian giải ngân</label><input id="loan-disbursement-date" type="date" value="${esc(base.disbursement_date||'')}"></div><div class="form-field"><label>Dư nợ hiện tại</label><input id="loan-balance" type="number" value="${Number(base.current_balance||0)}"></div></div><button class="btn primary" id="loan-save-profile">Lưu thông tin</button></div>`:`<div class="loan-detail-section"><h3>Thông tin khách hàng</h3><div class="loan-read-grid"><div><span>Tên KH</span><strong>${esc(base.customer_name||'')}</strong></div><div><span>SĐT</span><strong>${esc(base.phone||'')}</strong></div><div><span>CCCD</span><strong>${esc(base.cccd||'—')}</strong></div><div><span>Số tiền giải ngân</span><strong>${loanMoney(base.disbursement_amount)}</strong></div><div><span>Số tiền đóng hàng tháng / Kỳ hạn</span><strong>${loanMoney(base.monthly_payment)} <small class="care-inline-term">· ${Number(base.original_term_months||0)} tháng</small></strong></div><div><span>Thời gian giải ngân</span><strong>${v97_fmtDateOnly(base.disbursement_date)}</strong></div></div></div>`;
  const selectedAction=state.loanCareTab==='care30'?'CARE_30':state.loanCareTab==='care60'?'CARE_60':state.loanCareTab==='topup'?'TOPUP':'CARE';
  const loginProfile=`<div class="loan-detail-section care-login-profile"><h3>Thông tin hồ sơ Login App</h3><div class="loan-read-grid care-profile-read-grid"><div><span>Thu nhập</span><strong>${Number(base.income_amount||0)>0?loanMoney(base.income_amount):'—'}</strong></div><div><span>Nguồn KH</span><strong>${esc(base.customer_source||'—')}</strong></div><div><span>Tên công ty</span><strong>${esc(base.company_name||'—')}</strong></div><div><span>MST</span><strong>${esc(base.company_tax_code||'—')}</strong></div><div class="wide"><span>Nơi ở KH</span><strong>${esc(base.residence_province||'—')}</strong></div></div></div>`;
  const lifecycle=v98_loanLifecycle(base);
  openAdminModal(`Chăm sóc khách hàng · ${base.customer_name}`,`<div class="loan-detail-modal"><div class="loan-care-stage-banner ${lifecycle.cls}"><div><span>Trạng thái vòng đời</span><strong>${esc(lifecycle.label)}</strong></div><small>${base.disbursement_date?`${lifecycle.age} ngày sau giải ngân · Giải ngân ${v97_fmtDateOnly(base.disbursement_date)}`:'Chưa có ngày giải ngân'}</small></div>${info}${loginProfile}<div class="loan-detail-section"><h3>Ghi nhận chăm sóc</h3><div class="form-grid"><div class="form-field"><label>Loại chăm sóc</label><select id="loan-care-action"><option value="CARE" ${selectedAction==='CARE'?'selected':''}>Chăm sóc thường</option><option value="CARE_30" ${selectedAction==='CARE_30'?'selected':''}>Chăm sóc lần 1 · 30 ngày</option><option value="CARE_60" ${selectedAction==='CARE_60'?'selected':''}>Chăm sóc lần 2 · 60 ngày</option><option value="TOPUP" ${selectedAction==='TOPUP'?'selected':''}>Tư vấn Topup · sau 90 ngày</option></select></div><div class="form-field"><label>Kết quả</label><select id="loan-care-result"><option value="Đã liên hệ">Đã liên hệ</option><option value="Không nghe máy">Không nghe máy</option><option value="Đã chăm sóc">Đã chăm sóc</option><option value="Có nhu cầu Topup">Có nhu cầu Topup</option><option value="Chưa có nhu cầu">Chưa có nhu cầu</option></select></div><div class="form-field"><label>Lịch chăm sóc tiếp theo</label><input id="loan-care-next" type="date"></div><div class="form-field full"><label>Ghi chú</label><textarea id="loan-care-note" rows="3"></textarea></div></div><button class="btn primary" id="loan-care-save">Ghi nhận chăm sóc</button></div><div class="loan-detail-section"><h3>Lịch sử chăm sóc</h3><div class="loan-history">${history.map(h=>`<div class="loan-history-row"><time>${fmtDate(h.created_at)}</time><div><strong>${esc(h.result||h.action_type||'Chăm sóc')}</strong><p>${esc(h.note||'')}</p><small>${esc(h.actor||'')} · ${esc(h.action_type||'CARE')}${h.next_follow_up_at?` · Hẹn tiếp: ${v97_fmtDateOnly(h.next_follow_up_at)}`:''}</small></div></div>`).join('')||'<div class="empty small-empty">Chưa có lịch sử chăm sóc.</div>'}</div></div></div>`);
  const loanCareModal=$('#admin-modal .admin-modal');
  if(loanCareModal){
    loanCareModal.classList.add('loan-care-admin-modal');
    const loanCareBody=$('#admin-modal-body');
    if(loanCareBody) loanCareBody.scrollTop=0;
  }
  // Edit loan-record status independently from automatic lifecycle milestones.
  if(canEdit && $('#loan-save-profile')){
    const grid=$('#loan-save-profile').closest('.loan-detail-section')?.querySelector('.form-grid');
    if(grid){
      const item=document.createElement('div');item.className='form-field full';
      const states=[['ACTIVE','Đang vay'],['DUE','Đến hạn thanh toán'],['OVERDUE','Quá hạn'],['NEAR_MATURITY','Sắp kết thúc hợp đồng'],['SETTLED','Đã tất toán'],['CARE_REQUIRED','Cần chăm sóc'],['TOPUP','Topup']];
      item.innerHTML=`<label>Trạng thái hồ sơ khoản vay</label><select id="loan-record-status">${states.map(([k,v])=>`<option value="${k}" ${base.status===k?'selected':''}>${v}</option>`).join('')}</select><label class="loan-record-check"><input type="checkbox" id="loan-record-reloan" ${Number(base.reloan_eligible)?'checked':''}> Đủ điều kiện vay thêm</label><small>Trạng thái CS lần 1 / lần 2 vẫn được tính theo ngày giải ngân và lịch sử chăm sóc.</small>`;
      grid.appendChild(item);
    }
  }
  if($('#loan-save-profile'))$('#loan-save-profile').onclick=async()=>{try{const date=$('#loan-disbursement-date').value,term=Number($('#loan-term').value||0);await API.request(`/loans/${id}`,{method:'PATCH',body:JSON.stringify({cccd:$('#loan-cccd').value,disbursement_date:date,disbursement_amount:Number($('#loan-amount').value||0),monthly_payment:Number($('#loan-monthly-payment').value||0),original_term_months:term,current_balance:Number($('#loan-balance').value||0),status:$('#loan-record-status')?.value||base.status,reloan_eligible:!!$('#loan-record-reloan')?.checked})});state.loanCareLoadedAt=0;await loadLoanCare(true);closeAdminModal();renderLoanCare($('#main'));toast('Đã lưu thông tin khách hàng.');}catch(e){toast(e.message,'bad')}};
  $('#loan-care-save').onclick=async()=>{try{const action=$('#loan-care-action').value,result=$('#loan-care-result').value;await API.request(`/loans/${id}/care`,{method:'POST',body:JSON.stringify({action_type:action,result,note:$('#loan-care-note').value,next_follow_up_at:$('#loan-care-next').value})});state.loanCareLoadedAt=0;await loadLoanCare(true);closeAdminModal();renderLoanCare($('#main'));toast(result==='Có nhu cầu Topup'?'Đã ghi nhận nhu cầu Topup. Bấm Topup để chuyển khách sang Login App.':action==='CARE_30'?'Đã chăm sóc lần 1.':action==='CARE_60'?'Đã chăm sóc lần 2.':action==='TOPUP'?'Đã ghi nhận tư vấn Topup.':'Đã ghi nhận chăm sóc.');}catch(e){toast(e.message,'bad')}};
}

const v97_baseRenderFollowup=renderFollowup;
function v97_renderFollowup(main){v97_baseRenderFollowup(main);const h=main.querySelector('.premium-page-title h1');if(h)h.textContent='Follow-up';const p=main.querySelector('.premium-page-title p');if(p)p.textContent='Khách bị từ chối hồ sơ cần chăm sóc và khách hàng hẹn gọi lại.';}
function v97_allowedPagesForRole(role){const base=v95_allowedPagesForRole(role);base.add('loginApp');return base;}
function v97_premiumSidebarItems(role){
  const items=v95_premiumSidebarItems(role).map(x=>[...x]);
  for(const x of items){if(x[0]==='followup')x[2]='Follow-up';if(x[0]==='loanCare')x[2]='Chăm sóc khách hàng';}
  const leadPos=items.findIndex(x=>x[0]==='lead');if(!items.some(x=>x[0]==='loginApp'))items.splice(leadPos>=0?leadPos+1:2,0,['loginApp','apps','Login App']);
  const followIndex=items.findIndex(x=>x[0]==='followup'),loginIndex=items.findIndex(x=>x[0]==='loginApp');
  if(followIndex>=0&&loginIndex>=0&&followIndex>loginIndex){const [follow]=items.splice(followIndex,1);items.splice(loginIndex,0,follow);}
  return items;
}
function v97_premiumPageTitle(page,role){if(page==='loginApp')return 'Login App';if(page==='followup')return 'Follow-up';if(page==='loanCare')return 'Chăm sóc khách hàng';return v95_premiumPageTitle(page,role);}
function v97_renderSidebar(active){
  const u=state.session.user,role=u.role,items=premiumSidebarItems(role),dividerIndex=items.findIndex(x=>x[0]==='teamManagement');
  const rows=items.map((x,i)=>`${i===dividerIndex?'<div class="sidebar-divider"></div><div class="sidebar-caption">Quản trị & vận hành</div>':''}<button class="menu-item ${x[0]===active?'active':''}" data-nav="${x[0]}"><span class="menu-item-icon">${uiIcon(x[1])}</span><span class="menu-item-label">${x[2]}</span></button>`).join('');
  $('#sidebar-menu').innerHTML=`<div class="sidebar-brand"><div class="sidebar-brand-mark">A4</div><div><strong>An Đông 4</strong><span>Shinhan Finance</span></div></div><div class="sidebar-nav-scroll">${rows}</div><div class="sidebar-profile"><div class="sidebar-profile-avatar">${esc(initials(u.display_name))}</div><div class="sidebar-profile-copy"><strong>${esc(u.display_name)}</strong><small>${esc(premiumRoleLabel(role,u.staff_type))}</small></div><span class="sidebar-profile-status"></span></div>`;$$('[data-nav]',$('#sidebar-menu')).forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
}
function v97_render(){
  const main=$('#main'),role=state.session?.user?.role||'sale';$('#app')?.classList.remove('dashboard-redesign');
  const map={dashboard:renderDashboard,customerdb:role==='sale'?renderTelesale:renderCallDetails,lead:renderLeads,loginApp:renderLoginApps,followup:v97_renderFollowup,loanCare:v97_renderLoanCare,teamManagement:renderEmployees,kpi:renderKPI,warehouseAdmin:renderWarehouseAdmin,io:renderImport,settings:renderSettings,audit:renderAuditLogs};
  (map[state.page]||renderDashboard)(main);ensureFloatingChat();
}
allowedPagesForRole=v97_allowedPagesForRole;
premiumSidebarItems=v97_premiumSidebarItems;
premiumPageTitle=v97_premiumPageTitle;
renderSidebar=v97_renderSidebar;
renderLoanCare=v97_renderLoanCare;
renderFollowup=v97_renderFollowup;
render=v97_render;


/* =====================================================================
   V10.9 - Click-through KPI cards + reminder actions
   - Summary cards open the matching filtered customer list.
   - Dashboard Lead card opens Lead with the same date range.
   - Admin / Team Leader actions remind the assigned employee via chat.
   ===================================================================== */
async function v109_remindEmployee(userId, customerName, contextLabel){
  const role=state.session?.user?.role;
  if(!['admin','sup','teamlead'].includes(role))return;
  const uid=Number(userId||0);
  if(!uid){toast('Khách hàng chưa có nhân viên phụ trách.','bad');return;}
  const employee=(state.users||[]).find(u=>Number(u.id)===uid);
  const name=String(customerName||'khách hàng').trim()||'khách hàng';
  const context=String(contextLabel||'CRM').trim()||'CRM';
  const message=`🔔 Nhắc nhở xử lý ${context}: Khách ${name} đang cần bạn kiểm tra và cập nhật. Vui lòng xử lý trên CRM.`;
  try{
    await API.request('/chat/messages',{method:'POST',body:JSON.stringify({recipient_user_id:uid,message})});
    toast(`Đã nhắc ${employee?.display_name||'nhân viên'} về khách ${name}.`);
  }catch(e){toast(e.message||'Không gửi được nhắc nhở.','bad');}
}
function v109_scrollTo(selector){
  const el=$(selector);if(!el)return;
  try{el.scrollIntoView({behavior:'smooth',block:'start'});}catch(_e){el.scrollIntoView();}
}

const v109_baseRenderLoginApps=renderLoginApps;
function v109_renderLoginApps(main){
  v109_baseRenderLoginApps(main);
  if(state.page!=='loginApp')return;
  const role=state.session.user.role;
  const summaryTabs=['active','approved','retry','closed'];
  $$('.loginapp-summary article').forEach((card,i)=>{
    const tab=summaryTabs[i];if(!tab)return;
    card.classList.add('crm-click-card');card.tabIndex=0;card.setAttribute('role','button');
    const go=()=>{state.loginAppsTab=tab;v109_renderLoginApps(main);requestAnimationFrame(()=>v109_scrollTo('.crm-panel'));};
    card.onclick=go;card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};
  });
  if(role!=='sale'){
    const visible=v97_loginRows();
    const trs=$$('.loginapp-table tbody tr').filter(tr=>!tr.querySelector('.empty'));
    trs.forEach((tr,i)=>{
      const x=visible[(Number(state._v1031PageloginApp||1)-1)*V1031_PAGE_SIZE+i];if(!x)return;
      const td=tr.lastElementChild;if(!td)return;
      td.innerHTML=`<div class="lead-actions loginapp-row-actions"><button class="btn small primary v109-remind-btn" data-v109-remind="${Number(x.assigned_user_id||0)}" data-v109-name="${esc(x.customer_name||'Khách hàng')}" data-v109-context="Login App">🔔 Nhắc</button>${['admin','sup','teamlead'].includes(role)?`<button class="btn small danger" data-loginapp-delete="${x.id}" data-loginapp-name="${esc(x.customer_name||'')}">Xóa</button>`:''}</div>`;
    });
    $$('[data-v109-remind]').forEach(b=>b.onclick=async()=>{b.disabled=true;const old=b.textContent;b.textContent='Đang gửi…';await v109_remindEmployee(b.dataset.v109Remind,b.dataset.v109Name,b.dataset.v109Context);b.textContent='✓ Đã nhắc';setTimeout(()=>{b.disabled=false;b.textContent=old},1600);});
    $$('[data-loginapp-delete]').forEach(b=>b.onclick=async()=>{if(!['admin','sup','teamlead'].includes(role))return;const name=b.dataset.loginappName||'khách hàng này';if(!confirm(`Xóa ${name} khỏi Login App? Dữ liệu Chăm sóc khách hàng (nếu có) sẽ không tự bị xóa.`))return;try{await API.request(`/login-apps/${b.dataset.loginappDelete}`,{method:'DELETE'});state.loginAppsLoadedAt=0;await loadLoginApps(true);v109_renderLoginApps(main);toast('Đã xóa khách khỏi Login App.');}catch(e){toast(e.message,'bad')}});
  }
}

const v109_baseRenderFollowup=renderFollowup;
function v109_renderFollowup(main){
  v109_baseRenderFollowup(main);
  if(state.page!=='followup')return;
  const role=state.session.user.role;
  const buckets=['today','overdue','upcoming'];
  $$('.followup-summary-grid .followup-summary-card').forEach((card,i)=>{
    const bucket=buckets[i];if(!bucket)return;
    card.classList.add('crm-click-card');card.tabIndex=0;card.setAttribute('role','button');
    const go=()=>{state.followupBucket=bucket;v109_renderFollowup(main);requestAnimationFrame(()=>v109_scrollTo('.followup-panel'));};
    card.onclick=go;card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};
  });
  if(role!=='sale'){
    $$('.followup-table tbody tr').forEach(tr=>{
      const customerEl=tr.querySelector('[data-customer]');if(!customerEl)return;
      const c=(visibleCustomers()||[]).find(x=>String(x.id)===String(customerEl.dataset.customer));if(!c)return;
      const cell=tr.querySelector('.followup-action-cell');if(!cell)return;
      cell.innerHTML=`<div class="followup-action-buttons"><button class="btn primary small v109-remind-btn" data-v109-remind="${Number(c.assigned_user_id||0)}" data-v109-name="${esc(c.name||'Khách hàng')}" data-v109-context="Follow-up">🔔 Nhắc nhân viên</button>${(role==='admin'||role==='sup')?`<button class="btn danger small" data-followup-delete="${c.id}" data-followup-name="${esc(c.name||'Khách hàng')}">Xóa</button>`:''}</div>`;
    });
    $$('[data-v109-remind]').forEach(b=>b.onclick=async()=>{b.disabled=true;const old=b.textContent;b.textContent='Đang gửi…';await v109_remindEmployee(b.dataset.v109Remind,b.dataset.v109Name,b.dataset.v109Context);b.textContent='✓ Đã nhắc';setTimeout(()=>{b.disabled=false;b.textContent=old},1600);});
    $$('[data-followup-delete]').forEach(b=>b.onclick=async()=>{if((role!=='admin'&&role!=='sup'))return;const name=b.dataset.followupName||'khách hàng này';if(!confirm(`Xóa ${name} khỏi Follow-up?`))return;try{await API.request(`/followups/${b.dataset.followupDelete}`,{method:'DELETE'});await refreshCustomersOnly();state.loginAppsLoadedAt=0;v109_renderFollowup(main);toast('Đã xóa khách khỏi Follow-up.');}catch(e){toast(e.message,'bad')}});
  }
}

const v109_baseRenderLoanCare=v97_renderLoanCare;
function v109_renderLoanCare(main){
  v109_baseRenderLoanCare(main);
  if(state.page!=='loanCare')return;
  const role=state.session.user.role;
  const summaryTabs=['all','all','dueToday','care30','care60','topup','nearEnd'];
  const cards=[...$$('.care-summary-top article'),...$$('.care-summary-bottom article')];
  cards.forEach((card,i)=>{
    const tab=summaryTabs[i];if(!tab)return;
    card.classList.add('crm-click-card');card.tabIndex=0;card.setAttribute('role','button');
    const go=()=>{state.loanCareTab=tab;v109_renderLoanCare(main);requestAnimationFrame(()=>v109_scrollTo('.loan-care-panel'));};
    card.onclick=go;card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};
  });
  const tabs=$('.loan-tabs');
  if(tabs&&!tabs.querySelector('[data-loan-tab="dueToday"]')){
    const btn=document.createElement('button');btn.dataset.loanTab='dueToday';btn.className=state.loanCareTab==='dueToday'?'active':'';btn.innerHTML=`TT hôm nay <span>${v97_loanCareStats(state.loanProfiles||[]).dueToday}</span>`;
    tabs.insertBefore(btn,tabs.children[1]||null);
    btn.onclick=()=>{state.loanCareTab='dueToday';v109_renderLoanCare(main)};
  }
  if(role!=='sale'){
    const visible=v97_loanFilteredRows();
    const trs=$$('.loan-table tbody tr').filter(tr=>!tr.querySelector('.empty'));
    trs.forEach((tr,i)=>{
      const x=visible[(Number(state._v1031PageloanCare||1)-1)*V1031_PAGE_SIZE+i];if(!x)return;
      const td=tr.lastElementChild;if(!td)return;
      td.innerHTML=`<div class="loan-actions care-row-actions"><button class="btn small primary v109-remind-btn" data-v109-remind="${Number(x.assigned_user_id||0)}" data-v109-name="${esc(x.customer_name||'Khách hàng')}" data-v109-context="Chăm sóc khách hàng">🔔 Nhắc nhân viên</button>${['admin','sup','teamlead'].includes(role)?`<button class="btn small danger" data-loan-delete="${x.id}" data-loan-name="${esc(x.customer_name||'Khách hàng')}">Xóa</button>`:''}</div>`;
    });
    $$('[data-v109-remind]').forEach(b=>b.onclick=async()=>{b.disabled=true;const old=b.textContent;b.textContent='Đang gửi…';await v109_remindEmployee(b.dataset.v109Remind,b.dataset.v109Name,b.dataset.v109Context);b.textContent='✓ Đã nhắc';setTimeout(()=>{b.disabled=false;b.textContent=old},1600);});
    $$('[data-loan-delete]').forEach(b=>b.onclick=async()=>{if(!['admin','sup','teamlead'].includes(role))return;const name=b.dataset.loanName||'khách hàng này';if(!confirm(`Xóa ${name} khỏi Chăm sóc khách hàng? Lịch sử chăm sóc của hồ sơ này cũng sẽ bị xóa.`))return;try{await API.request(`/loans/${b.dataset.loanDelete}`,{method:'DELETE'});state.loanCareLoadedAt=0;await loadLoanCare(true);v109_renderLoanCare(main);toast('Đã xóa khách khỏi Chăm sóc khách hàng.');}catch(e){toast(e.message,'bad')}});
  }
}

const v109_baseRenderLeads=renderLeads;
function v109_renderLeads(main){
  v109_baseRenderLeads(main);
  if(state.page!=='lead')return;
  const filters=['','UNPROCESSED','LOGIN_APP'];
  $$('.lead-summary-v99 > div').forEach((card,i)=>{
    const filter=filters[i];if(filter===undefined)return;
    card.classList.add('crm-click-card');card.tabIndex=0;card.setAttribute('role','button');
    const go=()=>{state.leadStatusFilter=filter;renderLeads(main);requestAnimationFrame(()=>v109_scrollTo('.lead-card'));};
    card.onclick=go;card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};
  });
}

const v109_baseRenderDashboard=renderDashboard;
function v109_renderDashboard(main){
  v109_baseRenderDashboard(main);
  if(state.page!=='dashboard')return;
  const cards=$$('.crm-kpi-grid .crm-kpi-card');
  const leadCard=cards[3];
  if(leadCard){
    leadCard.classList.add('crm-click-card');leadCard.tabIndex=0;leadCard.setAttribute('role','button');leadCard.title='Mở danh sách Lead trong khoảng ngày đang xem';
    const go=()=>{state.leadDateFrom=state.dashboardFrom||todayISO();state.leadDateTo=state.dashboardTo||todayISO();state.leadStatusFilter='';navigate('lead');};
    leadCard.onclick=go;leadCard.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};
  }
}

function v109_render(){
  const main=$('#main'),role=state.session?.user?.role||'sale';$('#app')?.classList.remove('dashboard-redesign');
  const map={dashboard:v109_renderDashboard,customerdb:role==='sale'?renderTelesale:renderCallDetails,lead:v109_renderLeads,loginApp:v109_renderLoginApps,followup:v109_renderFollowup,loanCare:v109_renderLoanCare,teamManagement:renderEmployees,kpi:renderKPI,warehouseAdmin:renderWarehouseAdmin,io:renderImport,settings:renderSettings,audit:renderAuditLogs};
  (map[state.page]||v109_renderDashboard)(main);ensureFloatingChat();
}
renderDashboard=v109_renderDashboard;
renderLeads=v109_renderLeads;
renderLoginApps=v109_renderLoginApps;
renderFollowup=v109_renderFollowup;
renderLoanCare=v109_renderLoanCare;
render=v109_render;


/* =====================================================================
   V10.19 - Bộ lọc tháng số + tiếng Việt cho Chăm sóc KH / Login App / Follow-up
   - CSKH: lọc theo tháng giải ngân.
   - Login App: lọc theo tháng tạo Login App.
   - Follow-up: lọc theo tháng lịch hẹn.
   - Mặc định để trống = Tất cả tháng, không làm mất dữ liệu đang xem.
   ===================================================================== */
function v1018_monthKey(value){
  const d=dateKey(value||'');
  return /^\d{4}-\d{2}-\d{2}$/.test(d)?d.slice(0,7):'';
}
function v1037_loginAppEffectiveDate(item){
  if(!item)return '';
  const created=dateKey(item.created_at||item.updated_at||'');
  const disb=dateKey(item.disbursement_date||'');
  if(item.status==='APPROVED'&&created&&disb){
    const createdTs=Date.parse(created),disbTs=Date.parse(disb);
    if(Number.isFinite(createdTs)&&Number.isFinite(disbTs)&&createdTs-disbTs>45*24*60*60*1000)return disb;
  }
  return created||disb||'';
}
function v1037_loginAppTimeLabel(item){
  const display=v1037_loginAppEffectiveDate(item);
  const base=display||dateKey(item.updated_at||item.created_at||'');
  return shortDate(base)||fmtDate(item.updated_at||item.created_at);
}
function v1018_monthLabel(value){
  if(!/^\d{4}-\d{2}$/.test(String(value||'')))return 'Tất cả tháng';
  const [y,m]=String(value).split('-');
  return `Tháng ${Number(m)}/${y}`;
}
function v1018_monthControl(id,value,label){
  const now=new Date();
  const currentYear=now.getFullYear();
  const selected=/^\d{4}-\d{2}$/.test(String(value||''))?String(value).split('-'):['',''];
  const selectedYear=Number(selected[0]||currentYear);
  const selectedMonth=selected[1]||'';
  const minYear=Math.min(currentYear-5,selectedYear||currentYear);
  const maxYear=Math.max(currentYear+3,selectedYear||currentYear);
  const monthOptions=['<option value="">Tất cả tháng</option>'].concat(Array.from({length:12},(_,i)=>{
    const m=String(i+1).padStart(2,'0');
    return `<option value="${m}" ${selectedMonth===m?'selected':''}>Tháng ${i+1}</option>`;
  })).join('');
  const yearOptions=Array.from({length:maxYear-minYear+1},(_,i)=>{
    const y=maxYear-i;
    return `<option value="${y}" ${selectedYear===y?'selected':''}>${y}</option>`;
  }).join('');
  return `<div class="month-filter-control month-filter-vi" id="${id}-wrap"><label>${esc(label||'Tháng')}</label><select id="${id}" class="month-filter-month">${monthOptions}</select><select id="${id}-year" class="month-filter-year">${yearOptions}</select><button class="btn month-filter-clear" type="button" id="${id}-clear" ${value?'':'disabled'}>Xóa chọn</button></div>`;
}
function v1018_bindMonthControl(id,stateKey,rerender){
  const month=$('#'+id),year=$('#'+id+'-year'),clear=$('#'+id+'-clear');
  const apply=()=>{
    const m=month?.value||'';
    const y=year?.value||'';
    state[stateKey]=(m&&y)?`${y}-${m}`:'';
    rerender();
  };
  if(month)month.onchange=apply;
  if(year)year.onchange=()=>{if(month?.value)apply();};
  if(clear)clear.onclick=()=>{state[stateKey]='';rerender();};
}
function v1018_rebindClickableCards(selector,keys,handler){
  $$(selector).forEach((card,i)=>{
    const key=keys[i];if(key===undefined)return;
    const go=()=>handler(key);
    card.onclick=go;
    card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};
  });
}

const v1018_baseRenderLoginApps=renderLoginApps;
function v1018_renderLoginApps(main){
  state.loginAppsMonth=state.loginAppsMonth||'';
  const all=state.loginApps||[];
  const month=state.loginAppsMonth;
  const filtered=month?all.filter(x=>v1018_monthKey(v1037_loginAppEffectiveDate(x))===month):all;
  state.loginApps=filtered;
  try{v1018_baseRenderLoginApps(main);}finally{state.loginApps=all;}
  if(state.page!=='loginApp')return;
  const toolbar=$('.loginapp-toolbar');
  if(toolbar&&!$('#loginapp-month-wrap'))toolbar.insertAdjacentHTML('beforeend',v1018_monthControl('loginapp-month',month,'Tháng Login App'));
  v1018_bindMonthControl('loginapp-month','loginAppsMonth',()=>{state._v1031PageloginApp=1;renderLoginApps(main)});
  v1018_rebindClickableCards('.loginapp-summary article',['active','approved','retry','closed'],tab=>{state.loginAppsTab=tab;renderLoginApps(main);requestAnimationFrame(()=>v109_scrollTo('.crm-panel'));});
}

const v1018_baseRenderFollowup=renderFollowup;
function v1018_renderFollowup(main){
  state.followupMonth=state.followupMonth||'';
  const all=state.customers||[];
  const month=state.followupMonth;
  const filtered=month?all.filter(x=>!x.follow_up||v1018_monthKey(x.follow_up)===month):all;
  state.customers=filtered;
  try{v1018_baseRenderFollowup(main);}finally{state.customers=all;}
  if(state.page!=='followup')return;
  const filters=$('.followup-filters');
  if(filters&&!$('#followup-month-wrap'))filters.insertAdjacentHTML('afterbegin',v1018_monthControl('followup-month',month,'Tháng hẹn'));
  const followMonthInput=$('#followup-month'),followYearInput=$('#followup-month-year'),followMonthClear=$('#followup-month-clear');
  const applyFollowupMonth=()=>{const m=followMonthInput?.value||'',y=followYearInput?.value||'';state.followupMonth=(m&&y)?`${y}-${m}`:'';state.followupBucket=state.followupMonth?'month':'today';v1018_renderFollowup(main);};
  if(followMonthInput)followMonthInput.onchange=applyFollowupMonth;
  if(followYearInput)followYearInput.onchange=()=>{if(followMonthInput?.value)applyFollowupMonth();};
  if(followMonthClear)followMonthClear.onclick=()=>{state.followupMonth='';state.followupBucket='today';v1018_renderFollowup(main);};
  const followTabs=$('.followup-tabs');
  if(month&&followTabs&&!followTabs.querySelector('[data-followup-bucket="month"]')){
    const monthBtn=document.createElement('button');monthBtn.className='followup-tab '+(state.followupBucket==='month'?'active':'');monthBtn.dataset.followupBucket='month';monthBtn.innerHTML=`Cả ${esc(v1018_monthLabel(month).toLowerCase())}`;followTabs.insertBefore(monthBtn,followTabs.firstChild);
  }
  $$('[data-followup-bucket]').forEach(b=>b.onclick=()=>{state.followupBucket=b.dataset.followupBucket;v1018_renderFollowup(main);});
  v1018_rebindClickableCards('.followup-summary-grid .followup-summary-card',['today','overdue','upcoming'],bucket=>{state.followupBucket=bucket;v1018_renderFollowup(main);requestAnimationFrame(()=>v109_scrollTo('.followup-panel'));});
}

const v1018_baseRenderLoanCare=renderLoanCare;
function v1018_renderLoanCare(main){
  state.loanCareMonth=state.loanCareMonth||'';
  const all=state.loanProfiles||[];
  const month=state.loanCareMonth;
  const filtered=month?all.filter(x=>v1018_monthKey(x.disbursement_date)===month):all;
  state.loanProfiles=filtered;
  try{v1018_baseRenderLoanCare(main);}finally{state.loanProfiles=all;}
  if(state.page!=='loanCare')return;
  const toolbar=$('.loan-toolbar');
  if(toolbar&&!$('#loan-care-month-wrap'))toolbar.insertAdjacentHTML('afterbegin',v1018_monthControl('loan-care-month',month,'Tháng giải ngân'));
  v1018_bindMonthControl('loan-care-month','loanCareMonth',()=>{state._v1031PageloanCare=1;renderLoanCare(main)});
  const summaryKeys=['all','all','dueToday','care30','care60','topup','nearEnd'];
  v1018_rebindClickableCards('.care-summary-top article, .care-summary-bottom article',summaryKeys,tab=>{state.loanCareTab=tab;renderLoanCare(main);requestAnimationFrame(()=>v109_scrollTo('.loan-care-panel'));});
  // Các tab trạng thái vẫn phải render lại qua wrapper V10.19 để giữ bộ lọc tháng.
  $$('[data-loan-tab]').forEach(b=>b.onclick=()=>{state.loanCareTab=b.dataset.loanTab;renderLoanCare(main)});
}

function v1018_render(){
  const main=$('#main'),role=state.session?.user?.role||'sale';
  $('#app')?.classList.remove('dashboard-redesign');
  const map={dashboard:v109_renderDashboard,customerdb:role==='sale'?renderTelesale:renderCallDetails,lead:v109_renderLeads,loginApp:v1018_renderLoginApps,followup:v1018_renderFollowup,loanCare:v1018_renderLoanCare,teamManagement:renderEmployees,kpi:renderKPI,warehouseAdmin:renderWarehouseAdmin,io:renderImport,settings:renderSettings,audit:renderAuditLogs};
  (map[state.page]||v109_renderDashboard)(main);ensureFloatingChat();
}
renderLoginApps=v1018_renderLoginApps;
renderFollowup=v1018_renderFollowup;
renderLoanCare=v1018_renderLoanCare;
render=v1018_render;

bootstrap();

/* V10.20 - Dashboard: bấm Tổng cuộc gọi để mở Chi tiết cuộc gọi với đúng khoảng ngày/phạm vi. */

/* ===== V10.24: PWA install + mobile app helpers ===== */
(function(){
  let deferredPwaPrompt = null;
  const isStandalone = () =>
    window.matchMedia?.('(display-mode: standalone)').matches ||
    window.navigator.standalone === true;

  function setStandaloneClass(){
    document.body.classList.toggle('pwa-standalone', isStandalone());
  }

  function ensureInstallMenuItem(){
    const menu = document.getElementById('user-menu');
    if(!menu || document.getElementById('pwa-install-menu')) return;
    const btn = document.createElement('button');
    btn.id = 'pwa-install-menu';
    btn.className = 'pwa-install-menu-item';
    btn.type = 'button';
    btn.innerHTML = '📱 <span>Cài ứng dụng trên điện thoại</span>';
    btn.onclick = () => requestPwaInstall();
    menu.insertBefore(btn, menu.firstChild);
  }

  function ensureInstallBanner(){
    if(typeof isMobileLayout !== 'function' || !isMobileLayout() || isStandalone() || sessionStorage.getItem('pwaInstallDismissed') === '1') return;
    const main = document.getElementById('main');
    if(!main || document.getElementById('pwa-install-banner')) return;
    const banner = document.createElement('div');
    banner.id = 'pwa-install-banner';
    banner.innerHTML = `
      <span class="pwa-install-mark">A4</span>
      <span class="pwa-install-copy"><strong>Cài An Đông 4 như một ứng dụng</strong><small>Mở nhanh từ màn hình chính, giao diện toàn màn hình.</small></span>
      <span class="pwa-install-actions"><button class="btn primary small" type="button" id="pwa-install-now">Cài app</button><button class="pwa-install-close" type="button" aria-label="Đóng">×</button></span>`;
    main.prepend(banner);
    banner.querySelector('#pwa-install-now')?.addEventListener('click', requestPwaInstall);
    banner.querySelector('.pwa-install-close')?.addEventListener('click', () => {
      sessionStorage.setItem('pwaInstallDismissed','1');
      banner.remove();
    });
  }

  async function requestPwaInstall(){
    if(isStandalone()){
      try{ toast('Ứng dụng An Đông 4 đã được cài trên thiết bị.'); }catch(_e){}
      return;
    }
    if(deferredPwaPrompt){
      deferredPwaPrompt.prompt();
      try{ await deferredPwaPrompt.userChoice; }catch(_e){}
      deferredPwaPrompt = null;
      document.getElementById('pwa-install-banner')?.remove();
      return;
    }
    const ua = navigator.userAgent || '';
    const ios = /iPhone|iPad|iPod/i.test(ua);
    const msg = ios
      ? 'Trên iPhone/iPad: mở bằng Safari → nút Chia sẻ → Thêm vào Màn hình chính.'
      : 'Mở menu trình duyệt → chọn Cài đặt ứng dụng hoặc Thêm vào màn hình chính.';
    try{ toast(msg); }catch(_e){ alert(msg); }
  }
  window.requestPwaInstall = requestPwaInstall;

  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPwaPrompt = e;
    ensureInstallMenuItem();
    ensureInstallBanner();
  });

  window.addEventListener('appinstalled', () => {
    deferredPwaPrompt = null;
    setStandaloneClass();
    document.getElementById('pwa-install-banner')?.remove();
    try{ toast('Đã cài An Đông 4 trên thiết bị.'); }catch(_e){}
  });

  function labelTable(table){
    if(!table) return;
    const headers = [...table.querySelectorAll('thead th')].map(th => (th.textContent||'').trim());
    table.querySelectorAll('tbody tr').forEach(tr => {
      if(tr.classList.contains('lead-date-group')) return;
      [...tr.children].forEach((td, i) => {
        if(td.tagName === 'TD') td.dataset.label = headers[i] || td.dataset.label || '';
      });
    });
  }

  function enhanceMobileTables(root=document){
    root.querySelectorAll?.('.loginapp-table,.care-v1022-table,.followup-table,.lead-table,.v81-lead-table').forEach(labelTable);
  }
  window.enhanceMobileTables = enhanceMobileTables;

  const observer = new MutationObserver(mutations => {
    for(const m of mutations){
      for(const node of m.addedNodes){
        if(node.nodeType !== 1) continue;
        if(node.matches?.('.loginapp-table,.care-v1022-table,.followup-table,.lead-table,.v81-lead-table')) labelTable(node);
        enhanceMobileTables(node);
      }
    }
    if(typeof isMobileLayout === 'function' && isMobileLayout() && state?.session) ensureInstallBanner();
  });

  document.addEventListener('DOMContentLoaded', () => {
    setStandaloneClass();
    ensureInstallMenuItem();
    enhanceMobileTables();
    observer.observe(document.body,{childList:true,subtree:true});
    if('serviceWorker' in navigator){
      navigator.serviceWorker.register('/sw.js?v=10.31', {scope:'/'})
        .then(reg => reg.update().catch(()=>{}))
        .catch(()=>{});
    }
    setTimeout(() => {
      if(typeof isMobileLayout === 'function' && isMobileLayout() && state?.session) ensureInstallBanner();
    }, 800);
  });

  window.matchMedia?.('(display-mode: standalone)').addEventListener?.('change', setStandaloneClass);
})();

/* ===== V10.25: Mobile Pro shell ===== */
(function(){
  const mq = window.matchMedia?.('(max-width:1024px)');
  function syncMobileV1025(){
    const mobile = !!mq?.matches;
    document.body.classList.toggle('mobile-shell-v1025', mobile);
    if(!mobile){
      document.body.classList.remove('mobile-drawer-open');
      return;
    }
    // Keep the browser/app chrome tidy when the sidebar drawer is open.
    const sidebar = document.getElementById('sidebar');
    document.body.classList.toggle('mobile-drawer-open', !!sidebar?.classList.contains('mobile-open'));
    // Bottom navigation should expose the active item semantically too.
    document.querySelectorAll('#mobile-bottom-nav .mobile-nav-item').forEach(btn => {
      if(btn.classList.contains('active')) btn.setAttribute('aria-current','page');
      else btn.removeAttribute('aria-current');
    });
  }
  syncMobileV1025();
  mq?.addEventListener?.('change', syncMobileV1025);
  window.addEventListener('resize', syncMobileV1025, {passive:true});

  const observer = new MutationObserver(() => syncMobileV1025());
  const app = document.getElementById('app');
  if(app) observer.observe(app,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});

  // Avoid leaving the drawer open after choosing a function from the drawer.
  document.addEventListener('click', e => {
    if(!mq?.matches) return;
    const item=e.target.closest?.('#sidebar .menu-item');
    if(item) setTimeout(()=>{ try{ closeMobileSidebar(); }catch(_e){} syncMobileV1025(); },0);
  });
})();

/* ===== V10.29: Admin-managed per-user access policies (backend-authorized) ===== */
const V1029_MODULES=[
 ['dashboard','Bảng điều khiển'],['calls','Chi tiết cuộc gọi'],['lead','Quản lý Lead'],
 ['loginApp','Login App'],['followup','Follow-up'],['loanCare','Chăm sóc khách hàng'],
 ['teamManagement','Nhân sự & Team'],['kpi','KPI & Hiệu suất'],['warehouse','Kho dữ liệu'],
 ['import','Nhập / Xuất dữ liệu'],['chat','Chat & thông báo']
];
const V1029_ACTIONS=[
 ['view','Xem'],['create','Thêm'],['update','Sửa / cập nhật trạng thái'],
 ['delete','Xóa'],['remind','Nhắc nhở'],['export','Xuất'],['assign','Phân công']
];
const V1029_MODULE_ACTIONS={
 dashboard:['view'],calls:['view','update','export'],lead:['view','create','update','delete','remind','export'],
 loginApp:['view','create','update','delete','remind','export'],followup:['view','update','delete','remind'],
 loanCare:['view','create','update','delete','remind','export'],teamManagement:['view','create','update','delete','assign'],
 kpi:['view','update','export'],warehouse:['view','create','update','delete','assign'],
 import:['view','create','export','assign'],chat:['view','create','remind']
};

function v1029Can(module,action){
 const role=state.session?.user?.role;
 const granted=state.session?.access?.[module]?.[action];
 if(typeof granted==='boolean')return granted;
 if((role==='admin'||role==='sup'))return true;
 // While permissions load, fall back to the restrictive legacy defaults.
 if(module==='lead'||module==='loginApp'||module==='loanCare'){
  if(action==='update')return role==='sale';
  if(action==='delete'||action==='remind')return role==='teamlead';
  if(action==='view')return true;
 }
 return false;
}
let v1029RightsLoading=false;
function v1029LoadMyRights(){
 if(!state.session||state.session.token==='demo'||v1029RightsLoading)return;
 const now=Date.now();
 if(state.session.access&&now-(state._v1029RightsCheckedAt||0)<30000)return;
 state._v1029RightsCheckedAt=now;
 v1029RightsLoading=true;
 API.request('/access/me').then(r=>{
  if(!state.session)return;
  const changed=JSON.stringify(state.session.access||{})!==JSON.stringify(r.rights);
  state.session.access=r.rights;
  localStorage.setItem('a4_session',JSON.stringify(state.session));
  if(changed&&['teamManagement','lead','loginApp','loanCare'].includes(state.page))render();
 }).catch(()=>{}).finally(()=>{v1029RightsLoading=false});
}

const v1029OriginalEmployees=renderEmployees;
function v1029RenderEmployees(main){
 // Single employee/account table; permissions live inside each account's action column.
 v1029OriginalEmployees(main);
 if(state.session?.user?.role!=='admin')return;
 main.querySelectorAll('[data-edit-user]').forEach(edit=>{
  const id=Number(edit.dataset.editUser),u=(state.users||[]).find(x=>Number(x.id)===id);
  if(!u)return;
  const actionCell=edit.closest('.crm-action-buttons');
  if(!actionCell||actionCell.querySelector('[data-inline-access]'))return;
  const button=document.createElement('button');
  button.type='button';button.className='crm-icon-action v1031-access-action';
  button.dataset.inlineAccess=String(id);
  button.title=`Phân quyền tài khoản ${u.display_name}`;
  button.setAttribute('aria-label',button.title);
  button.innerHTML=`${uiIcon('users','ui-svg mini')}<span>Quyền</span>`;
  button.onclick=()=>v1031OpenAccountAccess(u);
  edit.insertAdjacentElement('afterend',button);
 });
}

function v1031OpenAccountAccess(user){
 if(state.session?.user?.role!=='admin')return;
 const id=Number(user.id);
 const scope=user.role==='admin'?'Toàn hệ thống':user.role==='teamlead'?'Chỉ dữ liệu và nhân sự thuộc Team của tài khoản':'Chỉ dữ liệu của chính tài khoản';
 openAdminModal(`Phân quyền · ${user.display_name}`,`<div class="v1031-access-identity"><span class="crm-avatar-mini">${esc(initials(user.display_name))}</span><div><b>${esc(user.display_name)}</b><small>@${esc(user.username||'')} · ${esc(staffRoleLabel(user))} · ${esc(user.team||'Toàn hệ thống')}</small></div></div><div class="v1031-access-scope">${uiIcon('users')} <span><b>Phạm vi không thay đổi:</b> ${esc(scope)}. Cấp quyền thao tác không mở rộng quyền xem dữ liệu sang Team khác.</span></div><div id="v1031-inline-access"><div class="access-loading">Đang tải phân quyền tài khoản…</div></div>`);
 const modal=$('#admin-modal .admin-modal');modal?.classList.add('v1031-access-modal');
 const host=$('#v1031-inline-access');
 if(state.mode!=='d1'){
  host.innerHTML='<div class="notice warning">Chỉnh quyền cần kết nối D1 Online.</div>';return;
 }
 API.request(`/access/users/${id}`).then(data=>{
  if(!host.isConnected||Number(data.user?.id)!==id)return;
  const draft=structuredClone(data.rights||{});
  let active='lead',dirty=false,saving=false;
  const paint=()=>{
   if(!host.isConnected)return;
   const label=V1029_MODULES.find(([k])=>k===active)?.[1]||'';
   host.innerHTML=`<div class="v1031-access-editor"><nav class="v1031-access-tabs" aria-label="Chức năng phân quyền">${V1029_MODULES.map(([key,title])=>`<button type="button" data-v1031-module="${key}" class="${key===active?'active':''}">${esc(title)}</button>`).join('')}</nav><div class="v1031-access-content"><h3>${esc(label)}</h3><p>Chọn thao tác tài khoản được phép sử dụng trong mục này.</p><div class="v1031-rights-grid">${V1029_ACTIONS.filter(([a])=>(V1029_MODULE_ACTIONS[active]||[]).includes(a)).map(([action,title])=>`<label class="access-permission"><span>${esc(title)}</span><input type="checkbox" data-v1031-action="${action}" ${draft[active]?.[action]?'checked':''} ${user.role==='admin'&&active==='teamManagement'&&action==='view'?'disabled':''}><span class="access-slider"></span></label>`).join('')}</div><div class="v1031-access-footer"><small>${dirty?'Có thay đổi chưa lưu':'Các quyền được lưu riêng cho từng tài khoản.'}</small><button type="button" id="v1031-save-rights" class="btn primary" ${saving?'disabled':''}>${saving?'Đang lưu…':'Lưu phân quyền'}</button></div></div></div>`;
   host.querySelectorAll('[data-v1031-module]').forEach(b=>b.onclick=()=>{active=b.dataset.v1031Module;paint()});
   host.querySelectorAll('[data-v1031-action]').forEach(box=>box.onchange=()=>{draft[active][box.dataset.v1031Action]=box.checked;dirty=true;host.querySelector('.v1031-access-footer small').textContent='Có thay đổi chưa lưu';});
   host.querySelector('#v1031-save-rights').onclick=async()=>{
    if(saving)return;saving=true;paint();
    const overrides=[];
    for(const [module] of V1029_MODULES)for(const [action] of V1029_ACTIONS)overrides.push({module,action,allowed:Boolean(draft[module]?.[action])});
    try{
     const result=await API.request(`/access/users/${id}`,{method:'PUT',body:JSON.stringify({overrides}),timeoutMs:20000});
     if(!host.isConnected)return;
     if(Number(state.session.user.id)===id){state.session.access=result.rights;localStorage.setItem('a4_session',JSON.stringify(state.session));}
     dirty=false;saving=false;toast(`Đã lưu phân quyền cho ${user.display_name}.`);closeAdminModal();
    }catch(e){saving=false;paint();toast(e.message,'bad')}
   };
  };
  paint();
 }).catch(e=>{if(host.isConnected)host.innerHTML=`<div class="notice warning">${esc(e.message||'Không tải được phân quyền.')}</div>`;});
}
renderEmployees=v1029RenderEmployees;

// Manager editing of Lead status is an explicit grant; reminders remain separate.
const v1029BaseLeads=renderLeads;
function v1029RenderLeads(main,decorateOnly=false){
 if(!decorateOnly)v1029BaseLeads(main);
 if(state.page!=='lead')return;
 main.querySelectorAll('#lead-table-body tr.lead-main-row').forEach(tr=>{tr.dataset.accessLeadId=tr.querySelector('[data-lead-delete]')?.dataset.leadDelete||'';});
 if(!v1029Can('lead','delete'))main.querySelectorAll('[data-lead-delete]').forEach(b=>b.remove());
 if(!v1029Can('lead','remind'))main.querySelectorAll('[data-lead-row-remind]').forEach(b=>b.remove());
 if(!v1029Can('lead','update'))main.querySelectorAll('[data-lead-update],[data-lead-note]').forEach(b=>b.remove());
 if(!v1029Can('lead','create'))main.querySelector('#lead-add-manual')?.remove();
 if(!v1029Can('lead','export'))main.querySelector('#lead-export-excel')?.remove();
 if(['admin','sup','teamlead'].includes(state.session.user.role)&&v1029Can('lead','update')){
  main.querySelectorAll('#lead-table-body tr.lead-main-row').forEach(tr=>{
   const del=tr.querySelector('[data-lead-delete]');
   const id=Number(del?.dataset.leadDelete||tr.dataset.accessLeadId||0);
   const actions=tr.querySelector('.lead-actions');
   if(id&&actions&&!actions.querySelector('[data-lead-update]')){
    const btn=document.createElement('button');btn.className='btn small primary';btn.textContent='Sửa trạng thái';
    btn.onclick=()=>openLeadUpdateModal(id);actions.prepend(btn);
   }
  });
 }
}
renderLeads=v1029RenderLeads;

const v1029BaseLoginApps=renderLoginApps;
function v1029RenderLoginApps(main,decorateOnly=false){
 if(!decorateOnly)v1029BaseLoginApps(main);
 if(state.page!=='loginApp')return;
 if(!v1029Can('loginApp','delete'))main.querySelectorAll('[data-loginapp-delete]').forEach(b=>b.remove());
 if(!v1029Can('loginApp','remind'))main.querySelectorAll('[data-v109-remind]').forEach(b=>b.remove());
 if(!v1029Can('loginApp','update'))main.querySelectorAll('[data-loginapp-update],[data-loginapp-relogin]').forEach(b=>b.remove());
 if(!v1029Can('loginApp','create'))main.querySelectorAll('#loginapp-import,#loginapp-add').forEach(b=>b.remove());
 if(['admin','sup','teamlead'].includes(state.session.user.role)&&v1029Can('loginApp','update')){
  const full=state.loginApps||[],month=state.loginAppsMonth||'';
  const subset=month?full.filter(x=>v1018_monthKey(v1037_loginAppEffectiveDate(x))===month):full;
  const saved=state.loginApps;state.loginApps=subset;
  let visible=[];try{visible=v97_loginRows()}finally{state.loginApps=saved}
  main.querySelectorAll('.loginapp-table tbody tr').forEach((tr,i)=>{
   const entry=visible[(Number(state._v1031PageloginApp||1)-1)*V1031_PAGE_SIZE+i],cell=tr.lastElementChild;if(!entry||!cell||tr.querySelector('.empty'))return;
   if(cell.querySelector('[data-access-login-edit]'))return;
   const btn=document.createElement('button');btn.className='btn small primary';btn.textContent='Sửa trạng thái';btn.dataset.accessLoginEdit=String(entry.id);
   btn.onclick=()=>openLoginAppUpdate(Number(entry.id));cell.querySelector('.loginapp-row-actions')?.prepend(btn);
  });
 }
}
const v1031BaseLoginAppsWithAccess=v1029RenderLoginApps;
function v1031RenderLoginApps(main,decorateOnly=false){
 v1031BaseLoginAppsWithAccess(main,decorateOnly);
 v1031ShowPager(main,'loginApp',(el)=>renderLoginApps(el));
 if(state.page==='loginApp'&&state.mode==='d1'&&(state.loginAppsLoadedAt||state.loginApps?.length)&&!state.loginAppsLoading&&Date.now()-(state.loginAppsLoadedAt||0)>240000){
  if(Date.now()-(state._v1031LoginCheck||0)>30000){
   state._v1031LoginCheck=Date.now();loadLoginApps(true).then(()=>{if(state.page==='loginApp')renderLoginApps(main)});
  }
 }
}
renderLoginApps=v1031RenderLoginApps;

const v1029BaseLoanCare=renderLoanCare;
function v1029RenderLoanCare(main,decorateOnly=false){
 if(!decorateOnly)v1029BaseLoanCare(main);
 if(state.page!=='loanCare')return;
 if(!v1029Can('loanCare','delete'))main.querySelectorAll('[data-loan-delete]').forEach(b=>b.remove());
 if(!v1029Can('loanCare','remind'))main.querySelectorAll('[data-v109-remind]').forEach(b=>b.remove());
 if(['admin','sup','teamlead'].includes(state.session.user.role)&&v1029Can('loanCare','update')){
  const full=state.loanProfiles||[],month=state.loanCareMonth||'';
  const subset=month?full.filter(x=>v1018_monthKey(x.disbursement_date)===month):full;
  const saved=state.loanProfiles;state.loanProfiles=subset;
  let visible=[];try{visible=v97_loanFilteredRows()}finally{state.loanProfiles=saved}
  main.querySelectorAll('.loan-table tbody tr').forEach((tr,i)=>{
   const entry=visible[(Number(state._v1031PageloanCare||1)-1)*V1031_PAGE_SIZE+i],actions=tr.querySelector('.care-row-actions');if(!entry||!actions)return;
   if(actions.querySelector('[data-access-care-edit]'))return;
   const btn=document.createElement('button');btn.className='btn small primary';btn.textContent='Sửa hồ sơ';btn.dataset.accessCareEdit=String(entry.id);
   btn.onclick=()=>v97_openLoanCareDetail(Number(entry.id));actions.prepend(btn);
  });
 }
}
const v1031BaseLoanCareWithAccess=v1029RenderLoanCare;
function v1031RenderLoanCare(main,decorateOnly=false){
 v1031BaseLoanCareWithAccess(main,decorateOnly);
 v1031ShowPager(main,'loanCare',(el)=>renderLoanCare(el));
 if(state.page==='loanCare'&&state.mode==='d1'&&(state.loanCareLoadedAt||state.loanProfiles?.length)&&!state.loanCareLoading&&Date.now()-(state.loanCareLoadedAt||0)>240000){
  if(Date.now()-(state._v1031LoanCheck||0)>30000){
   state._v1031LoanCheck=Date.now();loadLoanCare(true).then(()=>{if(state.page==='loanCare')renderLoanCare(main)});
  }
 }
}
renderLoanCare=v1031RenderLoanCare;

// Final page dispatcher must use dynamically replaced render functions.
const v1029BaseRender=render;
render=function(){
 v1029LoadMyRights();
 const page=state.page,main=document.getElementById('main');
 if(!main)return;
 const mapped={dashboard:'dashboard',customerdb:'calls',lead:'lead',loginApp:'loginApp',followup:'followup',loanCare:'loanCare',teamManagement:'teamManagement',kpi:'kpi',warehouseAdmin:'warehouse',io:'import'};
 const module=mapped[page];
 if(module&&state.session?.access&&!v1029Can(module,'view')){
  main.innerHTML=`<div class="premium-page"><section class="crm-panel access-no-view"><h2>Không có quyền truy cập</h2><p>Tài khoản hiện chưa được cấp quyền Xem mục này. Vui lòng liên hệ Admin để được cấp quyền.</p></section></div>`;
  return;
 }
 v1029BaseRender();
 if(state.session?.access){
  document.querySelectorAll('#sidebar-menu [data-nav],#mobile-bottom-nav [data-mobile-nav]').forEach(b=>{
   const mod=mapped[b.dataset.nav||b.dataset.mobileNav];if(mod)b.hidden=!v1029Can(mod,'view');
  });
 }
 if(page==='lead')v1029RenderLeads(main,true);
 if(page==='loginApp')v1031RenderLoginApps(main,true);
 if(page==='loanCare')v1031RenderLoanCare(main,true);
};


/* V10.32 — Sup hierarchy, persisted audit view and Excel for CSKH. */
const v1032OriginalStaff=renderEmployees;
renderEmployees=function(main){
 v1032OriginalStaff(main);
 const role=state.session?.user?.role;
 if(role==='sup'){
  main.querySelector('#add-admin')?.remove();
  for(const u of state.users||[]){
   if(!['admin','sup'].includes(u.role))continue;
   main.querySelector(`[data-edit-user="${u.id}"]`)?.remove();
   main.querySelector(`[data-delete-user="${u.id}"]`)?.remove();
  }
 }
 // Sort ALL accounts in correct hierarchy even after changing the team tab.
};

// Admin only can set elevated roles; Sup can create Sales/Team Leader/Freelancer.
const v1032OriginalEmployeeForm=employeeForm;
employeeForm=function(user=null){
 if(state.session?.user?.role==='sup'&&['admin','sup'].includes(user?.role)){
  toast('Sup không được thay đổi tài khoản Admin hoặc Sup.','bad');return;
 }
 v1032OriginalEmployeeForm(user);
};

const v1032BaseAllowed=allowedPagesForRole;
allowedPagesForRole=function(role){
 const pages=v1032BaseAllowed(role==='sup'?'admin':role);
 if(role==='sup')pages.delete('settings');
 if(!['admin','sup'].includes(role))pages.delete('audit');
 return pages;
};
const v1032BaseSidebar=premiumSidebarItems;
premiumSidebarItems=function(role){
 const items=v1032BaseSidebar(role==='sup'?'admin':role).map(x=>[...x]);
 if(role==='sup'){
  const settingsIndex=items.findIndex(x=>x[0]==='settings');
  if(settingsIndex>=0)items.splice(settingsIndex,1);
 }
 if(['admin','sup'].includes(role)&&!items.some(x=>x[0]==='audit')){
  items.push(['audit','settings','Nhật ký thao tác']);
 }
 return items;
};

// Export all rows matching month, team, employee, tab and search — not just visible 80 rows.
async function v1032ExportLoanCareExcel(){
 if(!v1029Can('loanCare','export')){toast('Tài khoản chưa được cấp quyền Xuất Chăm sóc khách hàng.','bad');return;}
 if(!window.XLSX){toast('Không tải được thư viện Excel. Hãy kiểm tra Internet.','bad');return;}
 const all=state.loanProfiles||[],month=String(state.loanCareMonth||'');
 let data=[];
 const old=state.loanProfiles;
 try{
  state.loanProfiles=month?all.filter(x=>v1018_monthKey(x.disbursement_date)===month):all;
  data=v97_loanFilteredRows();
 }finally{state.loanProfiles=old;}
 if(!data.length){toast('Không có khách hàng phù hợp với bộ lọc để xuất.','bad');return;}
 const headers=['STT','Khách hàng','Số điện thoại','CCCD','Team','Nhân viên phụ trách','Mã hợp đồng','Ngày giải ngân','Số tiền giải ngân (VNĐ)','Dư nợ hiện tại (VNĐ)','Đóng hàng tháng (VNĐ)','Kỳ hạn (tháng)','Kỳ thanh toán tiếp theo','Ngày đáo hạn','Trạng thái','Giai đoạn chăm sóc','Chăm sóc lần 1','Chăm sóc lần 2','Nguồn khách hàng','Thu nhập (VNĐ)','Công ty','MST','Tỉnh/Thành phố','Ghi chú'];
 const rows=data.map((x,i)=>({
  'STT':i+1,'Khách hàng':x.customer_name||'','Số điện thoại':String(x.phone||''),'CCCD':String(x.cccd||''),
  'Team':x.team||'','Nhân viên phụ trách':x.owner||'','Mã hợp đồng':x.contract_code||'',
  'Ngày giải ngân':v97_fmtDateOnly(x.disbursement_date),'Số tiền giải ngân (VNĐ)':Number(x.disbursement_amount||0),
  'Dư nợ hiện tại (VNĐ)':Number(x.current_balance||0),'Đóng hàng tháng (VNĐ)':Number(x.monthly_payment||0),
  'Kỳ hạn (tháng)':Number(x.original_term_months||0),'Kỳ thanh toán tiếp theo':v97_fmtDateOnly(x.next_due_date),
  'Ngày đáo hạn':v97_fmtDateOnly(x.maturity_date),'Trạng thái':String(x.status||''),
  'Giai đoạn chăm sóc':v98_loanLifecycle(x).label,'Chăm sóc lần 1':Number(x.care30_done)?'Đã CS':'Chưa CS',
  'Chăm sóc lần 2':Number(x.care60_done)?'Đã CS':'Chưa CS', 'Nguồn khách hàng':x.customer_source||'',
  'Thu nhập (VNĐ)':Number(x.income_amount||0),'Công ty':x.company_name||'','MST':String(x.company_tax_code||''),
  'Tỉnh/Thành phố':x.residence_province||'','Ghi chú':x.note||''
 }));
 if(state.mode==='d1'){
  try{
   await API.request('/loan-care/export',{method:'POST',body:JSON.stringify({rows:rows.length,team:state.loanCareTeam||'',month,tab:state.loanCareTab||'all'})});
  }catch(err){toast(err.message||'Không có quyền xuất Excel.','bad');return;}
 }
 const sheet=XLSX.utils.json_to_sheet(rows,{header:headers});
 sheet['!cols']=headers.map(h=>({wch:/Ghi chú/.test(h)?40:/khách hàng|Công ty|Giai đoạn/.test(h)?27:/Số điện thoại|CCCD|MST/.test(h)?19:20}));
 for(const colName of ['Số điện thoại','CCCD','MST']){
  const col=headers.indexOf(colName);
  for(let row=1;row<=rows.length;row++){
   const addr=XLSX.utils.encode_cell({r:row,c:col});
   if(sheet[addr]){sheet[addr].t='s';sheet[addr].v=String(sheet[addr].v??'');sheet[addr].z='@';}
  }
 }
 sheet['!autofilter']={ref:XLSX.utils.encode_range({s:{r:0,c:0},e:{r:rows.length,c:headers.length-1}})};
 const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,sheet,'Cham soc KH');
 const suffix=month||todayISO();
 XLSX.writeFile(book,`An_Dong_4_Cham_Soc_Khach_Hang_${suffix}.xlsx`);
 toast(`Đã xuất ${rows.length.toLocaleString('vi-VN')} khách hàng ra Excel.`);
}
const v1032PreviousLoanCare=renderLoanCare;
renderLoanCare=function(main,decorateOnly=false){
 v1032PreviousLoanCare(main,decorateOnly);
 if(state.page!=='loanCare'||!v1029Can('loanCare','export'))return;
 const toolbar=main.querySelector('.premium-page-actions');
 if(toolbar&&!toolbar.querySelector('#loan-export-excel')){
  const btn=document.createElement('button');btn.id='loan-export-excel';btn.type='button';
  btn.className='btn primary';btn.textContent='⬇ Xuất Excel';
  btn.onclick=v1032ExportLoanCareExcel;
  toolbar.prepend(btn);
 }
};

const V1032_AUDIT_LABELS={...AUDIT_ACTION_LABELS,
 AUDIT_UNDO:'Hoàn tác thao tác',
 LOGIN_SUCCESS:'Đăng nhập thành công',PASSWORD_CHANGE:'Đổi mật khẩu',ACCESS_DENIED:'Truy cập bị từ chối',
 LEAD_STATUS_UPDATE:'Đổi trạng thái Lead',LOAN_CARE_RECORDED:'Ghi nhận chăm sóc',LOAN_CARE_EXPORT:'Xuất Excel CSKH',
 ACCESS_POLICY_UPDATE:'Chỉnh phân quyền',LOGIN_APP_CREATE:'Thêm Login App',LOGIN_APP_IMPORT:'Nhập Login App',
 LOGIN_APP_DELETE:'Xóa Login App',LOGIN_APP_APPROVED:'Duyệt Login App',LOGIN_APP_RETRY:'Từ chối · lên lại',
 LOGIN_APP_CLOSED:'Đóng hồ sơ Login App',LOAN_PROFILE_CREATE:'Thêm hồ sơ CSKH',LOAN_PROFILE_UPDATE:'Cập nhật CSKH',
 LOAN_PROFILE_DELETE:'Xóa hồ sơ CSKH',LOAN_TOPUP_TO_LOGIN_APP:'Tạo Topup',FOLLOWUP_DELETE:'Xóa Follow-up',
 BULK_JOB_CREATE:'Tạo tác vụ Kho',BULK_JOB_COMPLETE:'Hoàn tất tác vụ Kho',CHAT_BROADCAST:'Thông báo toàn bộ',CHAT_TEAM_BROADCAST:'Thông báo Team'
};
state.v1032AuditPage=0;
state.v1032AuditTotal=0;
state.v1032AuditFrom='';
state.v1032AuditTo='';
state.v1032AuditUser='';
state.auditActionFilter='';
let v1032AuditRequest=0;
loadAuditLogs=async function(force=false){
 if(!['admin','sup'].includes(state.session?.user?.role))return;
 if(state.mode!=='d1'){state.auditLogs=[];state.v1032AuditTotal=0;state.auditLoadedAt=Date.now();return;}
 if(!force&&state.auditLoadedAt&&Date.now()-state.auditLoadedAt<30000)return;
 const current=++v1032AuditRequest;
 state.auditLoading=true;
 const params=new URLSearchParams({limit:'80',offset:String(80*(state.v1032AuditPage||0))});
 if(state.auditActionFilter)params.set('action',state.auditActionFilter);
 if(state.v1032AuditUser)params.set('user_id',state.v1032AuditUser);
 if(state.v1032AuditFrom)params.set('from',state.v1032AuditFrom);
 if(state.v1032AuditTo)params.set('to',state.v1032AuditTo);
 if(state.auditSearch)params.set('q',state.auditSearch);
 try{
  const data=await API.request('/audit-logs?'+params.toString());
  if(current!==v1032AuditRequest)return;
  state.auditLogs=data.items||[];
  state.v1032AuditTotal=Number(data.total||0);
  state.auditLoadedAt=Date.now();
 }catch(e){if(current===v1032AuditRequest){state.auditLoadedAt=Date.now();toast(e.message,'bad');}}
 finally{if(current===v1032AuditRequest)state.auditLoading=false;}
};
// V10.34 — natural-language explanations, without backend field names or IP addresses.
const V1034_AUDIT_STATUS={LOGIN_APP:'Đã Login App',SIGNED:'Đã ký / giải ngân',NO_LOGIN:'Không Login App',HIGH_DEBT:'Khách dư nợ cao',BAD_DEBT:'Khách có nợ xấu',NEW_DEBT:'Khách mới vay nơi khác',OTHER:'Trạng thái khác',APPROVED:'Đã duyệt',REJECTED:'Từ chối',ACTIVE:'Đang hoạt động',TOPUP:'Đủ điều kiện Topup',Y01:'Y01 – Khách có nhu cầu',Y02:'Y02 – Khách suy nghĩ',Y03:'Y03 – Không có nhu cầu',REJECT_CLOSED:'Đã đóng hồ sơ'};
function v1034AuditStatus(v){return v==null||v===''?'Chưa có trạng thái':V1034_AUDIT_STATUS[String(v)]||String(v).replace(/_/g,' ').toLowerCase();}
function v1034AuditDetail(item){
 const action=String(item.action||''), o=(()=>{try{return typeof item.detail==='string'?JSON.parse(item.detail||'{}'):(item.detail||{});}catch{return {};}})();
 const actor=item.display_name||'Người dùng';
 const count=(value)=>Number(value||0).toLocaleString('vi-VN');
 const person=(value)=>String(value||'').trim();
 const notes={
  LOGIN_SUCCESS:()=>`${actor} đã đăng nhập hệ thống.`,PASSWORD_CHANGE:()=>`${actor} đã đổi mật khẩu đăng nhập.`,
  ACCESS_DENIED:()=>`Một yêu cầu truy cập không được phép của ${actor} đã bị hệ thống từ chối.`,
  ACCESS_POLICY_UPDATE:()=>`${actor} đã cập nhật quyền truy cập cho tài khoản ${person(o.target_username)||'được chọn'}.`,
  USER_CREATE:()=>`Đã tạo tài khoản ${person(o.display_name)||person(o.username)||'mới'} (${v1034AuditStatus(o.role||'Sales')}).`,
  USER_UPDATE:()=>`Đã chỉnh sửa thông tin tài khoản ${person(o.display_name)||person(o.username)||'nhân viên'}.${o.password_changed?' Có thay đổi mật khẩu.':''}${o.role?' Vai trò được chọn: '+v1034AuditStatus(o.role)+'.':''}`,
  USER_DELETE:()=>`Đã vô hiệu hóa tài khoản của ${person(o.display_name)||person(o.username)||'nhân viên'} và trả Data về Kho.`,
  TEAM_CREATE:()=>`Đã tạo nhóm ${person(o.name)||'mới'}.`,TEAM_DELETE:()=>`Đã xóa nhóm ${person(o.name)||'được chọn'}.`,
  CUSTOMER_IMPORT:()=>`Đã nhập ${count(o.inserted)} khách hàng mới, cập nhật ${count(o.updated)} khách và bỏ qua ${count(o.skipped)} dòng không hợp lệ hoặc trùng.`,
  CUSTOMER_UPDATE:()=>`Đã cập nhật thông tin khách hàng.${o.status?' Trạng thái mới: '+v1034AuditStatus(o.status)+'.':''}${o.note?' Có chỉnh sửa ghi chú.':''}`,
  LEAD_STATUS_UPDATE:()=>`Đã đổi trạng thái Lead từ “${v1034AuditStatus(o.previous_status)}” sang “${v1034AuditStatus(o.new_status)}”.${o.reason?' Lý do: '+o.reason+'.':''}`,
  LEAD_DELETE:()=>`Đã xóa Lead khỏi danh sách quản lý${o.customer_name?' của '+o.customer_name:''}; không xóa lịch sử gọi.`,
  LEAD_MANUAL_CREATE:()=>`Đã thêm Lead mới vào hệ thống.`,
  LOGIN_APP_CREATE:()=>`Đã thêm hồ sơ Login App mới.`,LOGIN_APP_IMPORT:()=>`Đã nhập ${count(o.inserted)} hồ sơ Login App; bỏ qua ${count(o.skipped)} hồ sơ.`,
  LOGIN_APP_DELETE:()=>`Đã xóa hồ sơ Login App của ${person(o.customer_name)||'khách hàng'}.`,
  LOGIN_APP_APPROVED:()=>`Đã duyệt hồ sơ Login App${o.amount?' với khoản vay '+count(o.amount)+' đồng':''}${o.term_months?' trong '+count(o.term_months)+' tháng':''}.`,
  LOGIN_APP_RETRY:()=>`Hồ sơ chưa duyệt và đã hẹn ngày chăm sóc lại${o.retry_at?' vào '+o.retry_at:''}.`,
  LOGIN_APP_CLOSED:()=>`Đã đóng hồ sơ Login App${o.reason?' vì '+o.reason:''}.`,
  LOAN_PROFILE_CREATE:()=>`Đã tạo hồ sơ Chăm sóc khách hàng sau giải ngân.`,
  LOAN_PROFILE_UPDATE:()=>`Đã cập nhật thông tin hồ sơ Chăm sóc khách hàng${o.status?' (trạng thái: '+v1034AuditStatus(o.status)+')':''}.`,
  LOAN_PROFILE_DELETE:()=>`Đã xóa hồ sơ Chăm sóc khách hàng.`,
  LOAN_CARE_RECORDED:()=>`Đã ghi nhận lượt chăm sóc khách hàng${o.result?' với kết quả: '+o.result:''}.`,
  LOAN_CARE_EXPORT:()=>`Đã xuất ${count(o.rows)} khách hàng từ danh sách Chăm sóc khách hàng ra Excel.`,
  LOAN_TOPUP_TO_LOGIN_APP:()=>`Đã chuyển khách sang Login App để làm khoản vay thêm${o.requested_amount?' '+count(o.requested_amount)+' đồng':''}.`,
  FOLLOWUP_DELETE:()=>`Đã xóa lịch hẹn Follow-up${o.customer_name?' của '+o.customer_name:''}.`,
  KPI_SET:()=>`Đã đặt chỉ tiêu ${count(o.calls_daily)} cuộc gọi/ngày và ${count(o.y01_daily)} khách Y01/ngày.`,
  KPI_BULK_SET:()=>`Đã đặt KPI cho ${(o.user_ids||[]).length} nhân viên: ${count(o.calls_daily)} cuộc gọi/ngày và ${count(o.y01_daily)} Y01/ngày.`,
  WAREHOUSE_DISTRIBUTE:()=>`Đã phân phối ${count(o.updated)} khách hàng từ Kho dữ liệu.`,
  WAREHOUSE_TRANSFER:()=>`Đã chuyển ${count(o.updated||o.count)} khách hàng sang nhân viên hoặc nhóm khác.`,
  WAREHOUSE_RECYCLE:()=>`Đã chia lại ${count(o.updated)} Data đã gọi để nhân viên tiếp tục chăm sóc.`,
  DATA_RECALL:()=>`Đã thu hồi ${count(o.count||o.recalled)} khách hàng về Kho dữ liệu.`,
  DATA_DISTRIBUTE:()=>`Đã chia ${count(o.updated)} khách hàng cho các nhóm/nhân viên.`,
  BULK_JOB_CREATE:()=>`Đã tạo tác vụ phân phối ${count(o.total)} khách hàng từ Kho.`,
  BULK_JOB_COMPLETE:()=>`Đã hoàn tất phân phối ${count(o.processed)} trên ${count(o.total)} khách hàng.`,
  BULK_JOB_CANCEL:()=>`Đã hủy tác vụ phân phối Data.`,
  CATEGORY_CREATE:()=>`Đã tạo phân loại Data “${person(o.name)||'mới'}”.`,
  CATEGORY_RENAME:()=>`Đã đổi tên phân loại Data thành “${person(o.name)||'tên mới'}”.`,
  CATEGORY_DELETE:()=>`Đã xóa phân loại Data “${person(o.name)||'được chọn'}”.`,
  CATEGORY_ASSIGN:()=>`Đã thay đổi phân loại của ${count(o.count)} khách hàng.`,
  CATEGORY_ASSIGN_SCOPE:()=>`Đã thay đổi phân loại của ${count(o.count)} khách hàng trong phạm vi được chọn.`,
  CHAT_BROADCAST:()=>`Đã gửi thông báo đến ${count(o.recipients)} nhân viên trong hệ thống.`,
  CHAT_TEAM_BROADCAST:()=>`Đã gửi thông báo đến ${count(o.recipients)} thành viên trong nhóm.`,
  DAILY_REPORT_SAVE:()=>`Đã lưu báo cáo đầu ngày: ${count(o.login_count)} khách dự kiến Login App, ${count(o.sign_count)} khách dự kiến ký.`,
  KHTN_CREATE:()=>`Đã thêm khách hàng tiềm năng ${person(o.customer_name)}.`,
  KHTN_UPDATE:()=>`Đã cập nhật thông tin khách hàng tiềm năng ${person(o.customer_name)}.`,
  DEADLINE_SWEEP:()=>`Đã thu hồi ${count(o.returned)} khách quá hạn phân công.`,
  AUDIT_UNDO:()=>`Đã hoàn tác một lần ${V1032_AUDIT_LABELS[o.original_action]||'cập nhật dữ liệu'} trước đó.`,
 };
 const f=notes[action];
 if(f)return f();
 // Default deliberately does not render raw JSON, field names, IP addresses or unrecognized codes.
 return `${V1032_AUDIT_LABELS[action]||'Đã thực hiện thao tác quản lý'} trên hệ thống.`;
}

renderAuditLogs=function(main){
 if(!['admin','sup'].includes(state.session?.user?.role)){
  main.innerHTML='<div class="empty">Chỉ Admin và Sup được xem Nhật ký thao tác.</div>';return;
 }
 if(!state.auditLoadedAt&&!state.auditLoading){loadAuditLogs(true).then(()=>{if(state.page==='audit')renderAuditLogs(main);});}
 const rows=state.auditLogs||[],total=Number(state.v1032AuditTotal||0),page=Number(state.v1032AuditPage||0),pages=Math.max(1,Math.ceil(total/80));
 const opts=[...new Set([...(rows.map(x=>x.action)),...Object.keys(V1032_AUDIT_LABELS)].filter(Boolean))].sort((a,b)=>String(V1032_AUDIT_LABELS[a]||a).localeCompare(String(V1032_AUDIT_LABELS[b]||b),'vi'));
 const logRows=rows.map(x=>{
  let undoMarkup='<span class="muted" title="Nhật ký cũ hoặc thao tác không thể khôi phục an toàn">—</span>';
  if(x.undo_state==='available')undoMarkup=`<button class="btn small v1034-undo-btn" data-audit-undo="${Number(x.id)}" title="Có thể hoàn tác trong 7 ngày kể từ lúc thực hiện">↶ Hoàn tác</button>`;
  else if(x.undo_state==='undone')undoMarkup='<span class="v1034-undo-done">Đã hoàn tác</span>';
  else if(x.undo_state==='expired')undoMarkup='<span class="muted">Đã hết hạn</span>';
  return `<tr><td>${esc(fmtDate(x.created_at))}</td><td><strong>${esc(x.display_name||'—')}</strong><div class="muted">@${esc(x.username||'')}</div></td><td><span class="audit-action-tag">${esc(V1032_AUDIT_LABELS[x.action]||'Thao tác hệ thống')}</span></td><td class="audit-detail v1034-readable">${esc(v1034AuditDetail(x))}</td><td>${undoMarkup}</td></tr>`;
 }).join('');
 const userList=[...(state.users||[])].sort((a,b)=>String(a.display_name).localeCompare(String(b.display_name),'vi'));
 main.innerHTML=`<div class="premium-page v1032-audit-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Nhật ký thao tác</h1><p>Lịch sử làm việc rõ ràng, dễ theo dõi. Hoàn tác một số chỉnh sửa trong vòng 7 ngày; chỉ Admin và Sup được xem.</p></div><div class="premium-page-actions"><button class="btn" id="audit-refresh">↻ Làm mới</button></div></div>
 <div class="crm-panel"><div class="v1032-audit-filters"><input id="audit-search" placeholder="Tìm người thao tác, nội dung…" value="${esc(state.auditSearch||'')}"><select id="audit-action"><option value="">Mọi thao tác</option>${opts.map(a=>`<option value="${esc(a)}" ${state.auditActionFilter===a?'selected':''}>${esc(V1032_AUDIT_LABELS[a]||'Thao tác khác')}</option>`).join('')}</select><select id="audit-user"><option value="">Mọi tài khoản</option>${userList.map(u=>`<option value="${u.id}" ${String(state.v1032AuditUser)===String(u.id)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select><label>Từ ngày <input id="audit-from" type="date" value="${esc(state.v1032AuditFrom)}"></label><label>Đến ngày <input id="audit-to" type="date" value="${esc(state.v1032AuditTo)}"></label></div>
 <div class="table-wrap"><table class="data-table audit-table"><thead><tr><th>THỜI GIAN</th><th>NGƯỜI THAO TÁC</th><th>THAO TÁC</th><th>NỘI DUNG DỄ HIỂU</th><th>HOÀN TÁC</th></tr></thead><tbody>${logRows||`<tr><td colspan="5"><div class="empty">${state.auditLoading?'Đang tải nhật ký…':'Không có thao tác phù hợp.'}</div></td></tr>`}</tbody></table></div>
 <div class="v1032-audit-pagination"><span>${total.toLocaleString('vi-VN')} bản ghi · Trang ${Math.min(page+1,pages)}/${pages}</span><div class="actions"><button class="btn small" id="audit-prev" ${page===0?'disabled':''}>← Trước</button><button class="btn small" id="audit-next" ${page>=pages-1?'disabled':''}>Sau →</button></div></div></div>
 ${state.mode!=='d1'?'<div class="notice warning">Chế độ Demo Local không ghi nhật ký. Chỉ D1 Online lưu thao tác thật.</div>':''}</div>`;
 const update=()=>{state.v1032AuditPage=0;state.auditLoadedAt=0;loadAuditLogs(true).then(()=>{if(state.page==='audit')renderAuditLogs(main);});};
 for(const [id,key] of [['audit-action','auditActionFilter'],['audit-user','v1032AuditUser'],['audit-from','v1032AuditFrom'],['audit-to','v1032AuditTo']]){
  main.querySelector('#'+id)?.addEventListener('change',e=>{state[key]=e.target.value;update();});
 }
 main.querySelectorAll('[data-audit-undo]').forEach(btn=>btn.addEventListener('click',async()=>{
  const id=Number(btn.dataset.auditUndo),entry=rows.find(x=>Number(x.id)===id);
  if(!entry||entry.undo_state!=='available'||state.mode!=='d1')return;
  const label=V1032_AUDIT_LABELS[entry.action]||'thao tác này';
  if(!window.confirm(`Bạn có chắc chắn muốn HOÀN TÁC “${label}”?\n\nHệ thống sẽ khôi phục thông tin trước khi chỉnh sửa. Nếu dữ liệu đã được cập nhật tiếp, hệ thống sẽ từ chối để tránh mất thay đổi mới.\n\nChỉ có thể hoàn tác trong vòng 7 ngày.`))return;
  btn.disabled=true;btn.textContent='Đang hoàn tác…';
  try{
   await API.request(`/audit-logs/${id}/undo`,{method:'POST',body:'{}'});
   state.auditLoadedAt=0;state.loanCareLoadedAt=0;state.loginAppsLoadedAt=0;
   await loadAuditLogs(true);if(state.page==='audit')renderAuditLogs(main);
   toast('Hoàn tác thành công. Dữ liệu sẽ được tải lại khi bạn mở mục tương ứng.');
  }catch(e){btn.disabled=false;btn.textContent='↶ Hoàn tác';toast(e.message||'Không thể hoàn tác.','bad');}
 }));
 main.querySelector('#audit-search')?.addEventListener('change',e=>{state.auditSearch=e.target.value.trim();update()});
 main.querySelector('#audit-refresh')?.addEventListener('click',update);
 main.querySelector('#audit-prev')?.addEventListener('click',()=>{state.v1032AuditPage=Math.max(0,page-1);state.auditLoadedAt=0;loadAuditLogs(true).then(()=>renderAuditLogs(main));});
 main.querySelector('#audit-next')?.addEventListener('click',()=>{state.v1032AuditPage=page+1;state.auditLoadedAt=0;loadAuditLogs(true).then(()=>renderAuditLogs(main));});
};

// Initial page is rendered by a legacy dispatcher that bypasses the dynamic CSKH function.
// Inject the export action here too, without duplicating it during later rerenders.
const v1032FinalRender=render;
render=function(){
 v1032FinalRender();
 if(state.page==='loanCare'&&v1029Can('loanCare','export')){
  const bar=document.querySelector('#main .loan-care-page .premium-page-actions');
  if(bar&&!bar.querySelector('#loan-export-excel')){
   const button=document.createElement('button');button.id='loan-export-excel';button.className='btn primary';
   button.textContent='⬇ Xuất Excel';button.onclick=v1032ExportLoanCareExcel;
   bar.prepend(button);
  }
 }
};


/* =====================================================================
   V10.33 — Simplify navigation
   - Hide Settings from all roles and block navigation to its legacy view.
   - Remove duplicate account summary at the bottom of the left sidebar.
     The header account menu remains intact (password / sign out).
   - Keep Audit Log visible to Admin and Sup as before.
   ===================================================================== */
const v1033AllowedPagesForRole = allowedPagesForRole;
allowedPagesForRole = function(role) {
  const pages = v1033AllowedPagesForRole(role);
  pages.delete('settings');
  return pages;
};

const v1033PremiumSidebarItems = premiumSidebarItems;
premiumSidebarItems = function(role) {
  return v1033PremiumSidebarItems(role).filter(item => item[0] !== 'settings');
};

const v1033RenderSidebar = renderSidebar;
renderSidebar = function(active) {
  v1033RenderSidebar(active);
  // Legacy renderers reconstruct the sidebar every time a page is opened.
  const menu = document.getElementById('sidebar-menu');
  menu?.querySelector('.sidebar-profile')?.remove();
  menu?.querySelectorAll('[data-nav="settings"]').forEach(element => element.remove());
};

const v1033Navigate = navigate;
navigate = function(page) {
  return v1033Navigate(page === 'settings' ? 'dashboard' : page);
};

const v1033Render = render;
render = function() {
  // Covers any stale in-memory page value from the prior version.
  if (state.page === 'settings') {
    state.page = 'dashboard';
    state.app = 'dashboard';
    const title = document.getElementById('current-app-title');
    if (title) title.textContent = premiumPageTitle('dashboard', state.session?.user?.role || 'sale');
    if (state.session) renderSidebar('dashboard');
  }
  return v1033Render();
};


/* ================================================================
   V10.35 — TWO COLLAPSIBLE WORKSPACES + REAL MONTHLY REVENUE KPI
   Scope is enforced independently by the backend. Nothing here
   changes existing customer records or legacy call KPIs.
   ================================================================ */
const v1035PrevAllowed=allowedPagesForRole;
allowedPagesForRole=function(role){
 const pages=v1035PrevAllowed(role);pages.add('loginDashboard');pages.add('revenueKpi');
 // Respect per-account permissions in addition to the immutable Team data scope.
 if(state.session?.access?.loginApp?.view===false)pages.delete('loginDashboard');
 if(state.session?.access?.kpi?.view===false)pages.delete('revenueKpi');
 return pages;
};
const v1035PrevTitle=premiumPageTitle;
premiumPageTitle=function(page,role){
 if(page==='loginDashboard')return 'Dashboard Login App';
 if(page==='revenueKpi')return 'KPI doanh số';
 if(page==='dashboard')return 'Dashboard Telesales';
 if(page==='kpi')return 'KPI cuộc gọi';
 return v1035PrevTitle(page,role);
};
state.v1035NavOpen=state.v1035NavOpen||{telesales:true,login:true};
const v1035Telesales=[
 ['dashboard','dashboard','Dashboard Telesales'],
 ['customerdb','customers','Chi tiết cuộc gọi'],
 ['followup','calendar','Follow-up Telesales'],
 ['lead','lead','Lead Telesales'],
 ['kpi','kpi','KPI cuộc gọi']
];
const v1035Login=[
 ['loginDashboard','dashboard','Dashboard Login App'],
 ['loginApp','apps','Danh sách Login App'],
 ['loginLead','lead','Lead Login App'],
 ['appFollowup','calendar','Follow-up Login App'],
 ['loanCare','customers','Chăm sóc khách hàng'],
 ['revenueKpi','kpi','KPI doanh số']
];
renderSidebar=function(active){
 const menu=document.getElementById('sidebar-menu'),me=state.session?.user;
 if(!menu||!me)return;
 const role=me.role;
 const previousSidebarScroll=menu.querySelector('.sidebar-nav-scroll')?.scrollTop||0;
 const allowed=allowedPagesForRole(role);
 const navLink=x=>allowed.has(x[0])?`<button type="button" class="menu-item ${x[0]===active?'active':''}" data-nav="${x[0]}"><span class="menu-item-icon">${uiIcon(x[1])}</span><span class="menu-item-label">${esc(x[2])}</span></button>`:'';
 const navGroup=(key,title,items,iconName)=>{
   const isOpen=!!state.v1035NavOpen[key];
   return `<section class="v1035-sidebar-workspace ${isOpen?'is-open':''}"><button type="button" class="v1035-workspace-toggle" data-workspace="${key}" aria-expanded="${isOpen}" aria-controls="v1035-menu-${key}"><span class="v1035-workspace-heading">${uiIcon(iconName)}${esc(title)}</span><span class="v1035-chevron">⌄</span></button><div id="v1035-menu-${key}" class="v1035-workspace-items">${items.map(navLink).join('')}</div></section>`;
 };
 const management=[
  ['teamManagement','users','Quản lý nhóm và nhân viên'],
  ['warehouseAdmin','warehouse','Kho dữ liệu'],
  ...(role==='admin'||role==='sup'?[['io','import','Nhập / Xuất dữ liệu'],['audit','settings','Nhật ký thao tác']]:[])
 ].filter(x=>allowed.has(x[0]));
 menu.innerHTML=`<div class="sidebar-brand"><div class="sidebar-brand-mark">A4</div><div><strong>An Đông 4</strong><span>Shinhan Finance</span></div></div><div class="sidebar-nav-scroll v1035-sidebar-scroll">${navGroup('telesales','TELESALES',v1035Telesales,'call')}${navGroup('login','LOGIN APP',v1035Login,'apps')}${management.length?`<div class="sidebar-divider"></div><div class="sidebar-caption">Quản trị & vận hành</div>${management.map(navLink).join('')}`:''}</div>`;
 menu.querySelectorAll('[data-workspace]').forEach(b=>b.onclick=()=>{
  const key=b.dataset.workspace;state.v1035NavOpen[key]=!state.v1035NavOpen[key];
  const group=menu.querySelector('#v1035-menu-'+key);if(group)group.hidden=false;
  b.setAttribute('aria-expanded',String(!!state.v1035NavOpen[key]));b.closest('.v1035-sidebar-workspace')?.classList.toggle('is-open',state.v1035NavOpen[key]);
 });
 menu.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
 const scroller=menu.querySelector('.sidebar-nav-scroll');if(scroller)scroller.scrollTop=previousSidebarScroll;
};

function v1035CurrentMonth(){return todayISO().slice(0,7);}
state.v1035RevenueMonth=state.v1035RevenueMonth||v1035CurrentMonth();
state.v1035RevenueTeam=state.v1035RevenueTeam||'';
state.v1035RevenueUser=state.v1035RevenueUser||'';
state.v1035Performance=new Map();
state.v1035Pending=new Map();
function v1035PerfKey(){
 const role=state.session?.user?.role||'sale';
 return [role,Number(state.session?.user?.id||0),Number(state.session?.user?.team_id||0),state.v1035RevenueMonth,(role==='admin'||role==='sup')?state.v1035RevenueTeam:'',role==='sale'?'':state.v1035RevenueUser].join('|');
}
async function v1035GetPerformance(force=false){
 if(state.mode!=='d1')return null;
 const key=v1035PerfKey(),cached=state.v1035Performance.get(key);
 if(!force&&cached&&Date.now()-cached.at<45000)return cached.data;
 if(state.v1035Pending.has(key))return state.v1035Pending.get(key);
 const params=new URLSearchParams({month:state.v1035RevenueMonth});
 if(state.v1035RevenueTeam&&['admin','sup'].includes(state.session.user.role))params.set('team_id',state.v1035RevenueTeam);
 if(state.v1035RevenueUser&&state.session.user.role!=='sale')params.set('user_id',state.v1035RevenueUser);
 const task=API.request('/login-performance?'+params.toString(),{timeoutMs:20000}).then(data=>{
  state.v1035Performance.set(key,{data,at:Date.now()});return data;
 }).finally(()=>state.v1035Pending.delete(key));
 state.v1035Pending.set(key,task);return task;
}
function v1035Money(n){return Number(n||0).toLocaleString('vi-VN')+' ₫';}
function v1035RevenueHeader(title){
 const role=state.session.user.role;
 const users=(state.users||[]).filter(u=>u.role==='sale'&&Number(u.active)!==0&&
    (role==='admin'||role==='sup'||(role==='teamlead'&&Number(u.team_id)===Number(state.session.user.team_id))||(role==='sale'&&Number(u.id)===Number(state.session.user.id)))&&
    (!state.v1035RevenueTeam||role!=='admin'&&role!=='sup'||Number(u.team_id)===Number(state.v1035RevenueTeam)));
 const teamSelect=['admin','sup'].includes(role)?`<label>Team<select id="v1035-perf-team"><option value="">Tất cả Team</option>${(state.teamObjects||[]).map(t=>`<option value="${t.id}" ${String(t.id)===String(state.v1035RevenueTeam)?'selected':''}>${esc(t.name)}</option>`).join('')}</select></label>`:'';
 const userSelect=role!=='sale'?`<label>Nhân viên<select id="v1035-perf-user"><option value="">Tất cả nhân viên</option>${users.map(u=>`<option value="${u.id}" ${String(u.id)===String(state.v1035RevenueUser)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select></label>`:'';
 return `<header class="v1035-perf-head"><div><h1>${title}</h1><p>Phạm vi: ${['admin','sup'].includes(role)?'Toàn hệ thống':role==='teamlead'?'Team của bạn':'Cá nhân bạn'}. Số liệu tính theo tháng.</p></div><div class="v1035-perf-filters"><label>Tháng thống kê<input id="v1035-perf-month" type="month" value="${esc(state.v1035RevenueMonth)}"></label>${teamSelect}${userSelect}<button class="btn" id="v1035-perf-refresh">↻ Làm mới</button></div></header>`;
}
function v1035BindPerformance(main,renderer){
 main.querySelector('#v1035-perf-month')?.addEventListener('change',e=>{if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(e.target.value))return;state.v1035RevenueMonth=e.target.value;renderer(main);});
 main.querySelector('#v1035-perf-team')?.addEventListener('change',e=>{state.v1035RevenueTeam=e.target.value;state.v1035RevenueUser='';renderer(main);});
 main.querySelector('#v1035-perf-user')?.addEventListener('change',e=>{state.v1035RevenueUser=e.target.value;renderer(main);});
 main.querySelector('#v1035-perf-refresh')?.addEventListener('click',async()=>{await v1035GetPerformance(true).catch(e=>toast(e.message,'bad'));if(state.page==='revenueKpi'||state.page==='loginDashboard')renderer(main);});
}
function v1035TablePerformanceRows(items,showTargets=false){
 const canSet=['admin','sup','teamlead'].includes(state.session.user.role)&&state.session?.access?.kpi?.update!==false,rows=items||[];
 return `<div class="table-wrap"><table class="data-table v1035-revenue-table"><thead><tr><th>Nhân viên</th><th>Team</th><th>APP</th><th>LOAN</th><th>Giải ngân</th>${showTargets?'<th>Chỉ tiêu tháng</th><th>Hoàn thành</th>':''}${showTargets&&canSet?'<th>Thao tác</th>':''}</tr></thead><tbody>${rows.map(u=>{
  const pct=Number(u.target_volume)>0?Math.min(100,Math.round(Number(u.volume||0)/u.target_volume*100)):0;
  return `<tr><td><strong>${esc(u.display_name||'')}</strong><small>${String(u.staff_type)==='freelancer'?'Freelancer':'Sales'}</small></td><td>${esc(u.team||'—')}</td><td>${Number(u.apps||0).toLocaleString('vi-VN')}</td><td>${Number(u.loans||0).toLocaleString('vi-VN')}</td><td><strong>${v1035Money(u.volume)}</strong></td>${showTargets?`<td><div>${v1035Money(u.target_volume)}</div><small>APP: ${u.target_apps||0} · Loan: ${u.target_loans||0}</small></td><td>${Number(u.target_volume)>0?`<div class="crm-progress"><i style="width:${pct}%"></i></div><small>${Math.round(Number(u.volume||0)/u.target_volume*100)}%</small>`:'<span class="muted">Chưa đặt KPI</span>'}</td>`:''}${showTargets&&canSet?`<td><button class="btn small" data-v1035-target="${u.id}">Đặt KPI</button></td>`:''}</tr>`;
 }).join('')||`<tr><td colspan="${showTargets?8:5}">Chưa có nhân viên trong phạm vi này.</td></tr>`}</tbody></table></div>`;
}
function v1035PerfCards(data,kpi=false){
 const items=data.items||[],sum=k=>items.reduce((n,u)=>n+Number(u[k]||0),0);
 const targetVolume=sum('target_volume'),actual=data.total||{},percent=targetVolume?Math.round(Number(actual.volume||0)/targetVolume*100):0;
 return `<div class="v1035-perf-cards"><article><span>${kpi?'APP / mục tiêu':'Số lượng APP'}</span><strong>${Number(actual.apps||0).toLocaleString('vi-VN')}${kpi?' / '+sum('target_apps').toLocaleString('vi-VN'):''}</strong><small>Hồ sơ Login App tạo trong tháng</small></article><article><span>${kpi?'Loan / mục tiêu':'Số lượng Loan'}</span><strong>${Number(actual.loans||0).toLocaleString('vi-VN')}${kpi?' / '+sum('target_loans').toLocaleString('vi-VN'):''}</strong><small>Khoản vay giải ngân trong tháng</small></article><article><span>${kpi?'Doanh số thực đạt':'Volume giải ngân'}</span><strong>${v1035Money(actual.volume)}</strong><small>${kpi?(targetVolume?`Mục tiêu ${v1035Money(targetVolume)} · Đạt ${percent}%`:'Chưa đặt chỉ tiêu doanh số'):'Tổng giá trị khoản vay giải ngân trong tháng'}</small></article></div>`;
}
function v1035RenderPerformance(main,kpi=false){
 const page=kpi?'revenueKpi':'loginDashboard';
 const renderer=el=>v1035RenderPerformance(el,kpi);
 const cached=state.v1035Performance.get(v1035PerfKey()),data=cached?.data;
 main.innerHTML=`<div class="premium-page v1035-perf-page">${v1035RevenueHeader(kpi?'KPI doanh số':'Dashboard Login App')}${state.mode!=='d1'?'<div class="notice warning">Cần kết nối Cloudflare D1 để hiển thị số liệu thực.</div>':''}${data?v1035PerfCards(data,kpi):'<div class="v1035-loading">Đang tải số liệu Login App và giải ngân…</div>'}${data?`<section class="crm-panel v1035-perf-list"><div class="crm-panel-head"><h2>${kpi?'KPI theo nhân viên':'Kết quả theo nhân viên'}</h2><span>Tháng ${esc(state.v1035RevenueMonth.split('-').reverse().join('/'))}</span></div>${v1035TablePerformanceRows(data.items,kpi)}</section>`:''}</div>`;
 v1035BindPerformance(main,renderer);
 if(data){main.querySelectorAll('[data-v1035-target]').forEach(btn=>btn.onclick=()=>v1035OpenRevenueTarget(data.items.find(u=>Number(u.id)===Number(btn.dataset.v1035Target))));}
 else if(state.mode==='d1')v1035GetPerformance().then(()=>{if(state.page===page)renderer(document.getElementById('main'));}).catch(e=>{if(state.page===page)main.querySelector('.v1035-loading').textContent='Lỗi tải thống kê: '+e.message;});
}
function v1035OpenRevenueTarget(row){
 if(!row||!['admin','sup','teamlead'].includes(state.session.user.role)||state.session?.access?.kpi?.update===false)return;
 const month=state.v1035RevenueMonth;
 openAdminModal(`Đặt KPI doanh số · ${row.display_name}`,`<div class="v1035-target-form"><p>Tháng ${esc(month.split('-').reverse().join('/'))} · ${esc(row.team||'')}</p><label>Chỉ tiêu APP<input type="number" id="v1035-target-apps" min="0" step="1" value="${Number(row.target_apps||0)}"></label><label>Chỉ tiêu Loan<input type="number" id="v1035-target-loans" min="0" step="1" value="${Number(row.target_loans||0)}"></label><label>Chỉ tiêu doanh số giải ngân (VNĐ)<input type="number" id="v1035-target-volume" min="0" step="1000000" value="${Number(row.target_volume||0)}"></label><div class="call-actions"><button class="btn" id="v1035-target-close">Hủy</button><button class="btn primary" id="v1035-target-save">Lưu KPI tháng</button></div></div>`);
 document.getElementById('v1035-target-close').onclick=closeAdminModal;
 document.getElementById('v1035-target-save').onclick=async()=>{
  const payload={month,user_id:Number(row.id),target_apps:Number(document.getElementById('v1035-target-apps').value),target_loans:Number(document.getElementById('v1035-target-loans').value),target_volume:Number(document.getElementById('v1035-target-volume').value)};
  if(Object.values(payload).slice(2).some(n=>!Number.isSafeInteger(n)||n<0)){toast('KPI phải là số nguyên không âm.','bad');return;}
  try{await API.request('/revenue-kpi',{method:'PUT',body:JSON.stringify(payload)});state.v1035Performance.clear();closeAdminModal();v1035RenderPerformance(document.getElementById('main'),true);toast('Đã lưu KPI doanh số tháng '+month);}
  catch(e){toast(e.message,'bad');}
 };
}

// Simplified customer-care browsing: period is always clear and at the top.
state._v1035LoanMonthInit=false;
function v1035EnsureCareMonth(){
 if(state._v1035LoanMonthInit)return;
 state.loanCareMonth=v1035CurrentMonth();state._v1035LoanMonthInit=true;
}
function v1035DecorateCare(main){
 if(state.page!=='loanCare'||!main?.querySelector('.loan-care-page'))return;
 const root=main.querySelector('.loan-care-page');
 const dateWidget=root.querySelector('#loan-care-month-wrap');
 if(!root.querySelector('.v1035-care-time')){
  const head=root.querySelector('.premium-page-head');
  if(head){const box=document.createElement('div');box.className='v1035-care-time';
   box.innerHTML='<div><strong>Thời gian thống kê</strong><small>Chọn tháng giải ngân để xem khách hàng của tháng đó. Các nhóm chăm sóc bên dưới được tính theo ngày hiện tại.</small></div><div class="v1035-care-time-ctrl"></div>';
   head.after(box);
  }
 }
 if(dateWidget)root.querySelector('.v1035-care-time-ctrl')?.appendChild(dateWidget);
 const title=root.querySelector('.loan-tabs');
 if(title){
  if(!title.parentElement.querySelector('.v1035-care-help')){
   const d=document.createElement('div');d.className='v1035-care-help';d.innerHTML='<strong>Danh sách khách hàng theo nhu cầu chăm sóc</strong><span>Chọn một nhóm để xem đúng các hồ sơ cần xử lý. “Tất cả” là toàn bộ khách giải ngân trong tháng đã chọn.</span>';title.before(d);
  }
  const buttons={all:'Tất cả hồ sơ',dueToday:'Thanh toán hôm nay',care30:'Cần CS lần 1 (30 ngày)',care60:'Cần CS lần 2 (60 ngày)',topup:'Đủ 90 ngày · Topup',nearEnd:'Sắp hết hợp đồng'};
  title.querySelectorAll('[data-loan-tab]').forEach(b=>{const suffix=b.querySelector('span')?.outerHTML||'';b.innerHTML=`${buttons[b.dataset.loanTab]||b.textContent} ${suffix}`;});
  if(!title.querySelector('[data-loan-tab="dueToday"]')){
   const due=root.querySelector('.care-summary-top article:nth-child(3) strong')?.textContent||'0';
   const btn=document.createElement('button');btn.type='button';btn.dataset.loanTab='dueToday';btn.className=state.loanCareTab==='dueToday'?'active':'';btn.innerHTML=`Thanh toán hôm nay <span>${esc(due)}</span>`;
   title.querySelector('[data-loan-tab="all"]')?.after(btn);
  }
  title.querySelectorAll('[data-loan-tab]').forEach(b=>b.onclick=()=>{state.loanCareTab=b.dataset.loanTab;state._v1031PageloanCare=1;renderLoanCare(main);});
 }
 const subtitle=root.querySelector('.premium-page-title');
 if(subtitle&&!subtitle.querySelector('.v1035-care-subtitle'))subtitle.insertAdjacentHTML('beforeend','<p class="v1035-care-subtitle">Theo dõi thanh toán, chăm sóc sau 30/60 ngày và cơ hội vay thêm.</p>');
 const summaryLabels=['Khách hàng giải ngân','Dư nợ đang quản lý','Đến hạn thanh toán hôm nay','Cần chăm sóc lần 1','Cần chăm sóc lần 2','Có thể tư vấn Topup','Sắp đáo hạn hợp đồng'];
 root.querySelectorAll('.care-summary-top article, .care-summary-bottom article').forEach((el,i)=>{
   const title=el.querySelector('span');if(title)title.textContent=summaryLabels[i]||title.textContent;
   el.setAttribute('title',i===2?'Số khách phải thanh toán đúng ngày hôm nay':i===3?'Khách đủ 30 ngày nhưng chưa ghi nhận chăm sóc lần 1':i===4?'Khách đủ 60 ngày nhưng chưa ghi nhận chăm sóc lần 2':'Bấm để xem danh sách liên quan');
 });
}
const v1035OldLoanCare=renderLoanCare;
renderLoanCare=function(main,decorateOnly=false){v1035EnsureCareMonth();v1035OldLoanCare(main,decorateOnly);v1035DecorateCare(main);};

// Kho admin/Sup: choose exact SOURCE team and keep the destination within that team.
function v1035WarehouseTeamCard(main){
 if(!['admin','sup'].includes(state.session?.user?.role)||state.page!=='warehouseAdmin')return;
 const anchor=main.querySelector('.warehouse-section-tabs');
 if(!anchor||main.querySelector('#v1035-wh-team-card'))return;
 const teams=state.teamObjects||[];
 const block=document.createElement('section');block.id='v1035-wh-team-card';block.className='crm-panel v1035-team-distribution';
 block.innerHTML=`<div class="crm-panel-head"><div><h2>Chia Data theo Team</h2><small>Chọn Kho của Team M3 để chỉ chia Data M3 cho nhân viên M3. Không dùng Data Kho chung hoặc Team khác.</small></div></div><div class="v1035-wh-grid"><label>Kho nguồn<select id="v1035-source-team"><option value="">— Chọn kho Team —</option>${teams.map(t=>`<option value="${t.id}">Kho ${esc(t.name)}</option>`).join('')}</select></label><label>Cách chia<select id="v1035-distribution-mode"><option value="team">Chia đều cho Sales/Freelancer của Team</option><option value="user">Giao cho một nhân viên của Team</option></select></label><label id="v1035-wh-target-wrap" hidden>Nhân viên nhận<select id="v1035-wh-target"></select></label><label>Số lượng<input type="number" min="0" id="v1035-wh-limit" value="0" placeholder="0 = tất cả trong kho nguồn"></label><label>Thời hạn gọi (ngày)<input type="number" min="0" max="365" id="v1035-wh-days" value="7"></label><div class="v1035-wh-submit"><button type="button" class="btn primary" id="v1035-wh-distribute" disabled>Chia Data của Team</button></div></div><div class="v1035-wh-feedback" id="v1035-wh-feedback">Chọn một Kho Team để bắt đầu. Chỉ phân phối Data đang ở trạng thái chờ chia.</div>`;
 anchor.after(block);
 const source=block.querySelector('#v1035-source-team'),mode=block.querySelector('#v1035-distribution-mode'),button=block.querySelector('#v1035-wh-distribute'),target=block.querySelector('#v1035-wh-target'),wrap=block.querySelector('#v1035-wh-target-wrap'),hint=block.querySelector('#v1035-wh-feedback');
 const sync=()=>{
  const t=Number(source.value||0),users=(state.users||[]).filter(u=>u.role==='sale'&&Number(u.team_id)===t&&Number(u.active)!==0);
  target.innerHTML=users.map(u=>`<option value="${u.id}">${esc(u.display_name)} ${String(u.staff_type)==='freelancer'?'(Freelancer)':''}</option>`).join('');
  wrap.hidden=mode.value!=='user';button.disabled=!t||!users.length;
  const count=(state.customers||[]).filter(c=>Number(c.team_id)===t&&c.data_state==='POOL').length;
  hint.textContent=!t?'Chọn Kho Team để bắt đầu.':`Kho Team có ${count.toLocaleString('vi-VN')} Data chờ chia theo dữ liệu đang tải; ${users.length} nhân viên nhận phù hợp.`;
 };
 source.onchange=sync;mode.onchange=sync;sync();
 button.onclick=async()=>{
  const t=Number(source.value),userId=Number(target.value),limit=Math.max(0,Number(block.querySelector('#v1035-wh-limit').value||0)),days=Number(block.querySelector('#v1035-wh-days').value||0);
  if(!t||mode.value==='user'&&!userId||!Number.isInteger(days)||days<0||days>365){toast('Chọn Team, nhân viên và thời hạn hợp lệ.','bad');return;}
  const name=teams.find(x=>Number(x.id)===t)?.name||'Team';
  if(!confirm(`Chia ${limit||'toàn bộ'} Data chờ chia từ Kho ${name} cho ${mode.value==='team'?'các nhân viên trong '+name:'nhân viên đã chọn'}?\nKhông lấy Data từ Kho chung hay Team khác.`))return;
  const body={mode:mode.value,source_team_id:t,team_id:t,deadline_days:days};if(mode.value==='user')body.user_id=userId;
  button.disabled=true;
  try{const result=await distributeWarehouseBatched(body,limit,button);await refreshCustomersOnly();invalidateWarehousePending();renderWarehouseAdmin(main);toast(result.pending?'Đã tạo tác vụ chia Data, hệ thống tiếp tục xử lý.':`Đã chia ${Number(result.updated||0).toLocaleString('vi-VN')} Data trong ${name}.`);}
  catch(e){button.disabled=false;toast(e.message,'bad');}
 };
}
const v1035OldWarehouse=renderWarehouseAdmin;
renderWarehouseAdmin=function(main){v1035OldWarehouse(main);v1035WarehouseTeamCard(main);};
// Also improve the existing Import/Export distribution form, which uses the same backend job.
const v1035OldImport=renderImport;
renderImport=function(main){
 v1035OldImport(main);
 if(state.page!=='io'||!['admin','sup'].includes(state.session?.user?.role))return;
 const box=main.querySelector('#wh-mode')?.closest('.form-grid');if(!box)return;
 const wrap=document.createElement('div');wrap.className='form-field';wrap.innerHTML=`<label>Kho nguồn Data</label><select id="v1035-import-source-team"><option value="common">Kho chung Admin</option>${(state.teamObjects||[]).map(t=>`<option value="${t.id}">Kho ${esc(t.name)} (chỉ chia trong Team)</option>`).join('')}</select>`;box.prepend(wrap);
 const src=wrap.querySelector('select'),mode=main.querySelector('#wh-mode'),btn=main.querySelector('#wh-distribute');
 const orig=btn.onclick;const originalMode=mode.onchange;
 const sync=()=>{
  const isTeam=src.value!=='common';
  if(isTeam){mode.value='team';mode.disabled=true;}
  else mode.disabled=false;
  originalMode?.();
  const target=main.querySelector('#wh-target');if(target&&isTeam){target.value=src.value;target.disabled=true;}
  const note=main.querySelector('#wh-target-wrap .notice');if(note&&isTeam)note.textContent='Chỉ chia đúng Kho và nhân viên thuộc Team đã chọn.';
 };
 src.onchange=sync;mode.onchange=()=>{originalMode?.();sync();};sync();
 btn.onclick=async()=>{
  // The chosen source is always explicit: 'common' never includes a Team warehouse.
  const teamId=Number(src.value||0),days=Number(main.querySelector('#wh-deadline-days').value||0),limit=Number(main.querySelector('#wh-limit').value||0),category=Number(main.querySelector('#wh-category').value||0);
  const destination=main.querySelector('#wh-target');const type=src.value==='common'?mode.value:'team';
  if(!Number.isInteger(days)||days<0||days>365){toast('Thời hạn gọi không hợp lệ.','bad');return;}
  const body={source_team_id:src.value==='common'?'common':teamId,mode:type,deadline_days:days,category_id:category||null};
  if(type==='team')body.team_id=src.value==='common'?Number(destination?.value||0):teamId;
  if(type==='user')body.user_id=Number(destination?.value||0);
  if((type==='team'&&!body.team_id)||(type==='user'&&!body.user_id)){toast('Hãy chọn Team hoặc nhân viên nhận Data.','bad');return;}
  if(!confirm(src.value==='common'?'Chỉ lấy Data từ Kho chung Admin theo lựa chọn người nhận?':'Chỉ chia Data của Kho Team đã chọn cho nhân viên cùng Team?'))return;
  try{const r=await distributeWarehouseBatched(body,limit,btn);await refreshCustomersOnly();invalidateWarehousePending();renderImport(main);toast(`Đã chia ${r.updated||0} Data đúng Kho nguồn.`);}
  catch(e){toast(e.message,'bad');}
 };
};

const v1035OldRender=render;
render=function(){
 if(state.page==='loanCare')v1035EnsureCareMonth();
 if(state.page==='loginDashboard'||state.page==='revenueKpi'){
  const main=document.getElementById('main');if(main){v1035RenderPerformance(main,state.page==='revenueKpi');ensureFloatingChat();}return;
 }
 v1035OldRender();
 if(state.page==='loanCare')v1035DecorateCare(document.getElementById('main'));
};

// Never reuse cached manager totals when a different account logs in on this browser.
const v1035PreviousShowApp=showApp;
showApp=function(){
 state.v1035RevenueTeam='';state.v1035RevenueUser='';
 state.v1035RevenueMonth=v1035CurrentMonth();
 state._v1035LoanMonthInit=false;
 state.v1035Performance.clear();state.v1035Pending.clear();
 return v1035PreviousShowApp();
};

V1032_AUDIT_LABELS.REVENUE_KPI_SET='Đặt KPI doanh số';
const v1035PriorAuditDetail=v1034AuditDetail;
v1034AuditDetail=function(entry){
 if(entry?.action==='REVENUE_KPI_SET'){
  let info={};try{info=typeof entry.detail==='string'?JSON.parse(entry.detail):entry.detail||{}}catch{}
  const m=String(info.month||'').split('-');
  const month=m.length===2?`${m[1]}/${m[0]}`:'được chọn';
  return `Đã đặt KPI doanh số tháng ${month}: ${Number(info.target_apps||0)} App, ${Number(info.target_loans||0)} khoản Loan, ${Number(info.target_volume||0).toLocaleString('vi-VN')} đồng giải ngân.`;
 }
 return v1035PriorAuditDetail(entry);
};


/* V10.36 — operational upgrades: one warehouse distribution form, bulk revenue KPI,
   compared months, employee lock, Login App workflows, stable scroll positions. */
const v1036PrevAllowed=allowedPagesForRole;
allowedPagesForRole=function(role){const p=v1036PrevAllowed(role);p.add('loginLead');p.add('appFollowup');return p;};
const v1036PrevTitle=premiumPageTitle;
premiumPageTitle=function(page,role){return page==='loginLead'?'Lead Login App':page==='appFollowup'?'Follow-up Login App':v1036PrevTitle(page,role)};

// Avoid jumping the entire page to the top when an inner tab re-renders its content.
// Real navigation to a different main page is intentionally left unchanged.
document.addEventListener('click',function(event){
 const tab=event.target.closest('.warehouse-section-tabs button,.team-tabs button,.loan-tabs button,.loginapp-tabs button,.followup-summary-card,.lead-toolbar-simple button,.lead-toolbar-simple select,.v1035-workspace-toggle,[data-wh-view],[data-cat-call-chip],[data-cat-tab],[data-loan-tab],[data-v1037-bucket]');
 if(!tab||tab.closest('[data-nav]'))return;
 const y=window.scrollY;const sidebar=document.querySelector('#sidebar-menu .sidebar-nav-scroll');const sy=sidebar?.scrollTop;
 requestAnimationFrame(()=>{if(Math.abs(window.scrollY-y)>70)window.scrollTo({top:y,behavior:'instant'});if(sidebar&&sy!=null)sidebar.scrollTop=sy;});
 setTimeout(()=>{if(Math.abs(window.scrollY-y)>70)window.scrollTo({top:y,behavior:'instant'});if(sidebar&&sy!=null)sidebar.scrollTop=sy;},90);
},true);

// Warehouse category view: the duplicate "Chia Data theo Team" box is deliberately removed.
renderWarehouseAdmin=function(main){v1035OldWarehouse(main);};

// Real-time stock and strictly same-team recipients in the existing Import/Export distribution form.
const v1036BaseImport=v1035OldImport;
renderImport=function(main){
 v1036BaseImport(main);
 if(state.page!=='io'||!['admin','sup'].includes(state.session?.user?.role))return;
 const mode=main.querySelector('#wh-mode'),btn=main.querySelector('#wh-distribute');if(!mode||!btn)return;
 const form=mode.closest('.form-grid'),teams=state.teamObjects||[];
 let field=document.createElement('div');field.className='form-field';
 field.innerHTML=`<label>Kho nguồn Data</label><select id="v1036-source"><option value="common">Kho chung Admin</option>${teams.map(t=>`<option value="${t.id}">Kho ${esc(t.name)}</option>`).join('')}</select>`;
 form.prepend(field);
 mode.innerHTML='<option value="team">Chia đều cho thành viên Team</option><option value="user">Chia cho một nhân viên</option>';
 const target=main.querySelector('#wh-target-wrap');
 let totals=document.createElement('div');totals.className='v1036-stock-summary';totals.id='v1036-stock-summary';
 form.after(totals);
 const src=main.querySelector('#v1036-source');
 const sourceKey=state.v1036SourceTeam||'common';
 if([...src.options].some(x=>x.value===sourceKey))src.value=sourceKey;
 if(['team','user'].includes(state.v1036Mode))mode.value=state.v1036Mode;
 function renderTeamRecipients(data){
  const selected=src.value,team=teams.find(t=>String(t.id)===String(selected));
  const users=data?.users||[];
  const outside=selected==='common';
  let options='';
  if(outside){
   const all=(state.users||[]).filter(u=>u.role==='sale'&&Number(u.active)!==0);
   const teamSelect=`<label>Team nhận<select id="v1036-target-team"><option value="">— Chọn Team nhận —</option>${teams.map(t=>`<option value="${t.id}" ${String(state.v1036TargetTeam)===String(t.id)?'selected':''}>${esc(t.name)}</option>`).join('')}</select></label>`;
   const selectedTeam=Number(state.v1036TargetTeam||0);
   options=teamSelect+(mode.value==='user'?`<label>Nhân viên nhận<select id="v1036-target-user"><option value="">— Chọn nhân viên —</option>${all.filter(u=>Number(u.team_id)===selectedTeam).map(u=>`<option value="${u.id}">${esc(u.display_name)}</option>`).join('')}</select></label>`:'');
  }else{
   options=`<div class="v1036-team-name">${mode.value==='team'?`Chỉ chia đều cho ${users.length} Sales/Freelancer đang hoạt động của <b>${esc(team?.name||'Team')}</b>.`:`<label>Nhân viên nhận của ${esc(team?.name||'Team')}<select id="v1036-target-user"><option value="">— Chọn nhân viên —</option>${users.map(u=>`<option value="${u.id}">${esc(u.display_name)}${u.staff_type==='freelancer'?' (Freelancer)':''}</option>`).join('')}</select></label>`}</div>`;
  }
  target.classList.add('full');target.innerHTML=options;
  target.querySelector('#v1036-target-team')?.addEventListener('change',e=>{state.v1036TargetTeam=e.target.value;renderTeamRecipients(data)});
 }
 let summary=null,requestSeq=0;
 async function syncSource(){
  const token=++requestSeq;state.v1036SourceTeam=src.value;state.v1036Mode=mode.value;
  totals.innerHTML='<span class="muted">Đang kiểm tra số lượng Data tồn Kho…</span>';btn.disabled=true;
  try{
   const data=await API.request('/warehouse/source-summary?team_id='+encodeURIComponent(src.value));
   if(token!==requestSeq||!main.isConnected)return;
   summary=data;
   totals.innerHTML=`<div><span>Data sẵn sàng chia</span><strong>${Number(data.available).toLocaleString('vi-VN')}</strong></div><div><span>Chưa từng gọi (Data mới)</span><strong>${Number(data.never_called).toLocaleString('vi-VN')}</strong></div><div><span>Đã từng gọi, được trả về Kho</span><strong>${Number(data.previously_called).toLocaleString('vi-VN')}</strong></div><p>Kho chỉ chia các khách <b>chờ phân</b>; không lấy Data của Team khác.</p>`;
   renderTeamRecipients(data);btn.disabled=!data.available;
  }catch(e){if(token!==requestSeq)return;totals.innerHTML=`<div class="notice warning">${esc(e.message)}. Chưa thể xác nhận tồn Kho.</div>`;btn.disabled=true;}
 }
 src.addEventListener('change',syncSource);mode.onchange=syncSource;syncSource();
 btn.onclick=async()=>{
  const source=src.value,teamId=source==='common'?Number(target.querySelector('#v1036-target-team')?.value||0):Number(source);
  const userId=Number(target.querySelector('#v1036-target-user')?.value||0);
  const distribution=mode.value;
  const limitRaw=Number(main.querySelector('#wh-limit')?.value||0),days=Number(main.querySelector('#wh-deadline-days')?.value||0),cat=Number(main.querySelector('#wh-category')?.value||0);
  if(!summary||!Number(summary.available)||!teamId||distribution==='user'&&!userId)return toast('Chọn Team và người nhận hợp lệ.','bad');
  if(!Number.isSafeInteger(limitRaw)||limitRaw<0||!Number.isSafeInteger(days)||days<0||days>365)return toast('Số lượng hoặc số ngày không hợp lệ.','bad');
  const limit=limitRaw||Number(summary.available);
  if(limit>summary.available)return toast('Số lượng chia vượt tồn Kho.','bad');
  const body={mode:distribution,source_team_id:source==='common'?'common':Number(source),team_id:teamId,deadline_days:days,category_id:cat||null};
  if(distribution==='user')body.user_id=userId;
  const sourceName=source==='common'?'Kho chung Admin':teams.find(t=>String(t.id)===source)?.name||'Team';
  if(!confirm(`Xác nhận chia ${limit.toLocaleString('vi-VN')} Data từ ${sourceName} cho ${distribution==='user'?'nhân viên đã chọn':'nhân viên của Team đã chọn'}?`))return;
  btn.disabled=true;
  try{const r=await distributeWarehouseBatched(body,limit,btn);await refreshCustomersOnly();invalidateWarehousePending();renderImport(main);toast(r.pending?'Đã tạo tác vụ chia Data chạy nền.':`Đã chia ${r.updated||0} Data thành công.`);}
  catch(e){btn.disabled=false;toast(e.message,'bad');}
 };
};

// Monthly sales dashboard: compare the same filtered scope with the previous month.
state.v1036PriorMonths=new Map();
const v1036BasePerformance=v1035RenderPerformance;
v1035RenderPerformance=function(main,kpi=false){
 v1036BasePerformance(main,kpi);
 if(kpi||state.mode!=='d1'||!main.querySelector('.v1035-perf-cards'))return;
 const cur=state.v1035RevenueMonth,dt=new Date(cur+'-01T12:00:00Z');dt.setUTCMonth(dt.getUTCMonth()-1);
 const prev=dt.toISOString().slice(0,7),cacheKey=v1035PerfKey()+':'+prev;
 const host=document.createElement('section');host.className='crm-panel v1036-compare-months';
 main.querySelector('.v1035-perf-cards')?.after(host);
 const current=state.v1035Performance.get(v1035PerfKey())?.data?.total||{};
 const print=old=>{
  if(!host.isConnected)return;
  const vals=[['APP','apps'],['Loan','loans'],['Volume giải ngân','volume']];
  host.innerHTML=`<div class="crm-panel-head"><h2>So sánh với tháng trước</h2><small>Tháng ${esc(prev.slice(5))}/${esc(prev.slice(0,4))} → ${esc(cur.slice(5))}/${esc(cur.slice(0,4))}</small></div><div class="v1036-compare-grid">${vals.map(([label,k])=>{
   const a=Number(current[k]||0),b=Number(old?.[k]||0),difference=a-b,pct=b?Math.round(difference/b*100):null;
   return `<article><span>${label}</span><strong>${k==='volume'?v1035Money(a):a.toLocaleString('vi-VN')}</strong><small>Tháng trước: ${k==='volume'?v1035Money(b):b.toLocaleString('vi-VN')}</small><b class="${difference>=0?'up':'down'}">${difference>0?'+':''}${k==='volume'?v1035Money(difference):difference.toLocaleString('vi-VN')} ${pct===null?'(không có mốc so %)':`(${pct>0?'+':''}${pct}%)`}</b></article>`;
  }).join('')}</div>`;
 };
 if(state.v1036PriorMonths.has(cacheKey)){print(state.v1036PriorMonths.get(cacheKey));return;}
 host.textContent='Đang tải số liệu tháng trước để so sánh…';
 const query=new URLSearchParams({month:prev});if(state.v1035RevenueTeam&&['admin','sup'].includes(state.session.user.role))query.set('team_id',state.v1035RevenueTeam);
 if(state.v1035RevenueUser&&state.session.user.role!=='sale')query.set('user_id',state.v1035RevenueUser);
 API.request('/login-performance?'+query).then(result=>{state.v1036PriorMonths.set(cacheKey,result.total||{});print(result.total||{});}).catch(e=>{if(host.isConnected)host.textContent='Không tải được số liệu tháng trước: '+e.message;});
};

// Set the same monthly KPI for any selection of team staff, server validates all IDs.
const v1036OldPerfRender=v1035RenderPerformance;
v1035RenderPerformance=function(main,kpi=false){
 v1036OldPerfRender(main,kpi);
 if(!kpi||!['admin','sup','teamlead'].includes(state.session.user.role)||state.session?.access?.kpi?.update===false)return;
 const current=state.v1035Performance.get(v1035PerfKey())?.data;
 if(!current||!current.items?.length)return;
 const head=main.querySelector('.v1035-perf-head .v1035-perf-filters');
 const button=document.createElement('button');button.className='btn primary';button.id='v1036-bulk-kpi';button.textContent='Đặt KPI nhiều nhân viên';head?.appendChild(button);
 const table=main.querySelector('.v1035-revenue-table');if(!table)return;
 table.querySelector('thead tr')?.insertAdjacentHTML('afterbegin','<th><input type="checkbox" id="v1036-kpi-all" aria-label="Chọn tất cả nhân viên"></th>');
 table.querySelectorAll('tbody tr').forEach((row,i)=>{const u=current.items[i];if(u)row.insertAdjacentHTML('afterbegin',`<td><input type="checkbox" class="v1036-kpi-pick" value="${u.id}" aria-label="Chọn ${esc(u.display_name)}"></td>`);});
 main.querySelector('#v1036-kpi-all').onchange=e=>table.querySelectorAll('.v1036-kpi-pick').forEach(x=>x.checked=e.target.checked);
 button.onclick=()=>{
  const ids=[...table.querySelectorAll('.v1036-kpi-pick:checked')].map(el=>Number(el.value));
  if(!ids.length)return toast('Tích chọn nhân viên cần giao KPI.','bad');
  openAdminModal(`Đặt KPI cho ${ids.length} nhân viên`,`<div class="v1035-target-form"><p>Áp dụng chung chỉ tiêu cho <b>${ids.length}</b> nhân viên được chọn, tháng ${esc(state.v1035RevenueMonth)}. KPI riêng đã có của những người này sẽ được cập nhật.</p><label>APP / người<input id="v1036-bulk-apps" type="number" min="0" value="0"></label><label>Loan / người<input id="v1036-bulk-loans" type="number" min="0" value="0"></label><label>Volume / người (VNĐ)<input id="v1036-bulk-volume" type="number" min="0" step="1000000" value="0"></label><div class="call-actions"><button class="btn" id="v1036-bulk-cancel">Hủy</button><button class="btn primary" id="v1036-bulk-save">Áp dụng KPI</button></div></div>`);
  document.querySelector('#v1036-bulk-cancel').onclick=closeAdminModal;
  document.querySelector('#v1036-bulk-save').onclick=async()=>{
   const payload={month:state.v1035RevenueMonth,user_ids:ids,target_apps:Number(document.querySelector('#v1036-bulk-apps').value),target_loans:Number(document.querySelector('#v1036-bulk-loans').value),target_volume:Number(document.querySelector('#v1036-bulk-volume').value)};
   if([payload.target_apps,payload.target_loans,payload.target_volume].some(v=>!Number.isSafeInteger(v)||v<0))return toast('Chỉ tiêu phải là số nguyên dương hoặc 0.','bad');
   if(!confirm(`Xác nhận đặt cùng KPI tháng ${payload.month} cho ${ids.length} nhân viên?`))return;
   try{await API.request('/revenue-kpi/bulk',{method:'PUT',body:JSON.stringify(payload)});state.v1035Performance.clear();closeAdminModal();v1035RenderPerformance(document.querySelector('#main'),true);toast('Đã giao KPI cho '+ids.length+' nhân viên.');}catch(e){toast(e.message,'bad');}
  };
 };
};

// Staff lock: deactivates login but does NOT delete customers or change historical records.
const v1036BaseEmployees=renderEmployees;
renderEmployees=function(main){
 v1036BaseEmployees(main);
 if(!['admin','sup','teamlead'].includes(state.session.user.role))return;
 main.querySelectorAll('[data-edit-user]').forEach(edit=>{
  const id=Number(edit.dataset.editUser),u=state.users.find(x=>Number(x.id)===id),box=edit.closest('.crm-action-buttons');
  if(!u||u.role!=='sale'||!box||box.querySelector('[data-v1036-lock]'))return;
  const b=document.createElement('button');b.type='button';b.className='btn small v1036-lock';b.dataset.v1036Lock=String(id);b.title='Khóa đăng nhập, giữ nguyên khách hàng';b.textContent='Khóa';box.appendChild(b);
  b.onclick=async()=>{
   if(!confirm(`Khóa tài khoản ${u.display_name}? Nhân viên sẽ không đăng nhập được; tất cả Data và lịch sử vẫn được giữ để bạn thu hồi và chuyển qua người khác trong Kho.`))return;
   try{const r=await API.request(`/users/${id}/lock`,{method:'POST',body:'{}'});state.users=state.users.filter(x=>Number(x.id)!==id);renderEmployees(main);toast(`Đã khóa ${u.display_name}. Có ${r.assigned_customers||0} khách cần thu hồi/chuyển Data.`);v1036LoadLocked(main);}catch(e){toast(e.message,'bad');}
  };
 });
 if(!main.querySelector('#v1036-locked-panel')){
  const panel=document.createElement('section');panel.id='v1036-locked-panel';panel.className='crm-panel v1036-locked-panel';panel.innerHTML='<div class="crm-panel-head"><h2>Nhân viên đã khóa</h2><button class="btn small" id="v1036-refresh-locked">Tải danh sách</button></div><div id="v1036-locked-body" class="muted">Bấm Tải danh sách để xem tài khoản nghỉ việc và Data đang giữ.</div>';
  main.appendChild(panel);panel.querySelector('#v1036-refresh-locked').onclick=()=>v1036LoadLocked(main);
 }
};
async function v1036LoadLocked(main){
 const host=main.querySelector('#v1036-locked-body');if(!host)return;host.textContent='Đang tải…';
 try{const rows=(await API.request('/users/locked')).items||[];
  host.innerHTML=rows.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Nhân viên đã khóa</th><th>Team</th><th>Data còn được giao</th><th>Thao tác</th></tr></thead><tbody>${rows.map(u=>`<tr><td><strong>${esc(u.display_name)}</strong><small>@${esc(u.username)}</small></td><td>${esc(u.team||'—')}</td><td>${Number(u.assigned_count)}</td><td><button class="btn small" data-v1036-recall="${u.id}">Thu hồi Data về Kho</button> <button class="btn small" data-v1036-unlock="${u.id}">Mở khóa</button></td></tr>`).join('')}</tbody></table></div>`:'<p>Chưa có tài khoản Sales/Freelancer bị khóa.</p>';
  host.querySelectorAll('[data-v1036-recall]').forEach(b=>b.onclick=async()=>{
   const id=Number(b.dataset.v1036Recall),who=rows.find(x=>Number(x.id)===id),name=who?.display_name||'nhân viên';
   if(!confirm(`Thu hồi toàn bộ Data đang giao của ${name} về Kho Team tương ứng? Không xóa lịch sử cuộc gọi.`))return;
   let total=0;
   try{for(let i=0;i<100;i++){
    const r=await API.request('/warehouse/recall-user',{method:'POST',body:JSON.stringify({user_id:id,status:'ALL',limit:500})});total+=Number(r.updated||0);
    if(!r.updated||Number(r.updated)<500)break;
   }
   await refreshCustomersOnly();v1036LoadLocked(main);toast(`Đã thu hồi ${total} Data về Kho Team để chia lại.`);
   }catch(e){toast(e.message,'bad');}
  });
  host.querySelectorAll('[data-v1036-unlock]').forEach(b=>b.onclick=async()=>{
   const id=Number(b.dataset.v1036Unlock),who=rows.find(x=>Number(x.id)===id);if(!confirm(`Cho phép ${who?.display_name||'nhân viên'} đăng nhập lại?`))return;
   try{await API.request(`/users/${id}/unlock`,{method:'POST',body:'{}'});toast('Đã mở khóa. Tải lại trang để cập nhật danh sách nhân viên.');v1036LoadLocked(main);}catch(e){toast(e.message,'bad');}
  });
 }catch(e){host.textContent='Không tải được danh sách: '+e.message;}
}

// Login App Lead is a separate manual funnel for khách ngoài nguồn telesales.
state.v1036LoginLeads=[];state.v1036AppFollowups=[];
const v1036AppLeadSources=['Data','TikTok','Facebook','Thị trường','CTV','Giới thiệu','Khác'];
function v1037LoginLeadVisibleUsers(){
 const role=state.session.user.role;
 if(role==='sale')return state.users.filter(u=>Number(u.id)===Number(state.session.user.id));
 return state.users.filter(u=>u.role==='sale'&&u.active!==0&&((role==='admin'||role==='sup')||(Number(u.team_id)===Number(state.session.user.team_id))));
}
function v1037LeadLoginStatusLabel(s){return s==='LOGIN_APP'?'Đã Login App':s==='NO_LOGIN'?'Không login':'Đang chăm sóc';}
function v1037LeadLoginStatusClass(s){return s==='LOGIN_APP'?'success':s==='NO_LOGIN'?'muted':'primary';}
function v1037AppFollowBucket(item){if(item.status==='DONE')return 'done';const d=dateKey(item.follow_date||'');const t=todayISO();if(d<t)return 'overdue';if(d===t)return 'today';return 'upcoming';}
function v1037RenderLoginLeads(main){
 state.v1037LeadQ=state.v1037LeadQ||'';state.v1037LeadStatus=state.v1037LeadStatus||'';
 const items=state.v1036LoginLeads||[];const q=String(state.v1037LeadQ||'').toLowerCase().trim();
 const filtered=items.filter(x=>{if(state.v1037LeadStatus&&x.status!==state.v1037LeadStatus)return false;return !q||`${x.customer_name||''} ${x.phone||''} ${x.owner||''} ${x.team||''} ${x.source||''}`.toLowerCase().includes(q)});
 const total=items.length,pending=items.filter(x=>x.status==='PENDING').length,done=items.filter(x=>x.status==='LOGIN_APP').length,nologin=items.filter(x=>x.status==='NO_LOGIN').length;
 main.innerHTML=`<div class="premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Lead Login App</h1><p>Nhân viên tự thêm khách ngoài nguồn telesales để theo dõi chuyển đổi sang Login App.</p></div><div class="premium-page-actions"><button class="btn primary" id="v1037-lead-add">+ Thêm Lead thủ công</button><button class="btn" id="v1037-lead-refresh">↻ Làm mới</button></div></div>
  <section class="lead-summary-grid loginapp-summary"><article><span>Tổng Lead phát sinh</span><strong>${total}</strong><small>Lead Login App riêng</small></article><article><span>Chưa xử lý</span><strong>${pending}</strong><small>Cần xác nhận Login App</small></article><article class="success"><span>Đã login app</span><strong>${done}</strong><small>Đã chuyển sang Login App</small></article><article class="muted"><span>Không login</span><strong>${nologin}</strong><small>Đã ghi nhận lý do</small></article></section>
  <section class="crm-panel lead-card"><div class="lead-toolbar-simple"><input id="v1037-lead-search" placeholder="Tìm tên KH, SĐT, nguồn, nhân viên…" value="${esc(state.v1037LeadQ)}"><select id="v1037-lead-status"><option value="">Tất cả trạng thái</option><option value="PENDING" ${state.v1037LeadStatus==='PENDING'?'selected':''}>Đang chăm sóc</option><option value="LOGIN_APP" ${state.v1037LeadStatus==='LOGIN_APP'?'selected':''}>Đã Login App</option><option value="NO_LOGIN" ${state.v1037LeadStatus==='NO_LOGIN'?'selected':''}>Không login</option></select></div>
  <div class="table-wrap"><table class="data-table"><thead><tr><th>Khách hàng</th><th>Nguồn</th><th>Team / Nhân viên</th><th>Trạng thái Lead</th><th>Cập nhật lúc</th><th>Thao tác</th></tr></thead><tbody>${filtered.map(x=>`<tr><td><strong>${esc(x.customer_name||'')}</strong><small>${esc(x.phone||'')}</small>${x.note?`<small class="muted">${esc(x.note)}</small>`:''}</td><td><select class="v1037-lead-source" data-id="${x.id}">${v1036AppLeadSources.map(s=>`<option value="${esc(s)}" ${x.source===s?'selected':''}>${esc(s)}</option>`).join('')}</select></td><td>${esc(x.team||'—')}<small>${esc(x.owner||'—')}</small></td><td><span class="status-pill ${v1037LeadLoginStatusClass(x.status)}">${v1037LeadLoginStatusLabel(x.status)}</span>${x.no_login_reason?`<small class="loginapp-inline-note">${esc(x.no_login_reason)}</small>`:''}</td><td>${fmtDate(x.updated_at||x.created_at)}</td><td><div class="lead-actions">${x.status!=='LOGIN_APP'?`<button class="btn small primary" data-v1037-loginapp="${x.id}">Đã Login App</button>`:'<button class="btn small" data-v1037-open-loginapp="1">Mở Login App</button>'}${x.status!=='NO_LOGIN'?`<button class="btn small" data-v1037-nologin="${x.id}">Không login</button>`:`<button class="btn small" data-v1037-reopen="${x.id}">Mở lại</button>`}</div></td></tr>`).join('')||'<tr><td colspan="6"><div class="empty">Chưa có Lead Login App phù hợp.</div></td></tr>'}</tbody></table></div></section></div>`;
 const refresh=()=>v1037LoadLoginLeads(main);
 main.querySelector('#v1037-lead-refresh').onclick=refresh;
 main.querySelector('#v1037-lead-search').oninput=e=>{state.v1037LeadQ=e.target.value;v1037RenderLoginLeads(main)};
 main.querySelector('#v1037-lead-status').onchange=e=>{state.v1037LeadStatus=e.target.value;v1037RenderLoginLeads(main)};
 main.querySelector('#v1037-lead-add').onclick=()=>{
  const users=v1037LoginLeadVisibleUsers();
  openAdminModal('Thêm Lead Login App',`<div class="v1035-target-form"><label>Tên khách hàng<input id="v1037-add-name"></label><label>Số điện thoại<input id="v1037-add-phone" inputmode="numeric" maxlength="10" placeholder="10 số"></label><label>Nguồn khách<select id="v1037-add-source">${v1036AppLeadSources.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('')}</select></label>${state.session.user.role!=='sale'?`<label>Nhân viên phụ trách<select id="v1037-add-owner">${users.map(u=>`<option value="${u.id}">${esc(u.display_name)}${u.team?' · '+esc(u.team):''}</option>`).join('')}</select></label>`:''}<label>Ghi chú<input id="v1037-add-note" placeholder="Nguồn, nhu cầu, ghi chú thêm"></label><div class="call-actions"><button class="btn" id="v1037-add-cancel">Hủy</button><button class="btn primary" id="v1037-add-save">Lưu Lead</button></div></div>`);
  document.querySelector('#v1037-add-cancel').onclick=closeAdminModal;
  document.querySelector('#v1037-add-save').onclick=async()=>{try{const payload={customer_name:document.querySelector('#v1037-add-name').value,phone:String(document.querySelector('#v1037-add-phone').value||'').replace(/\D/g,'').slice(0,10),source:document.querySelector('#v1037-add-source').value,note:document.querySelector('#v1037-add-note').value};if(document.querySelector('#v1037-add-owner'))payload.assigned_user_id=Number(document.querySelector('#v1037-add-owner').value);await API.request('/login-leads',{method:'POST',body:JSON.stringify(payload)});closeAdminModal();toast('Đã thêm Lead Login App.');refresh();}catch(e){toast(e.message,'bad')}};
 };
 main.querySelectorAll('.v1037-lead-source').forEach(select=>select.onchange=async()=>{try{await API.request(`/login-leads/${Number(select.dataset.id)}/source`,{method:'PUT',body:JSON.stringify({source:select.value})});toast('Đã cập nhật nguồn.');refresh();}catch(e){toast(e.message,'bad')}});
 main.querySelectorAll('[data-v1037-loginapp]').forEach(b=>b.onclick=async()=>{try{await API.request(`/login-leads/${Number(b.dataset.v1037Loginapp)}/status`,{method:'POST',body:JSON.stringify({status:'LOGIN_APP'})});state.loginAppsLoadedAt=0;await loadLoginApps(true);toast('Đã chuyển sang Danh sách Login App.');refresh();}catch(e){toast(e.message,'bad')}});
 main.querySelectorAll('[data-v1037-nologin]').forEach(b=>b.onclick=()=>{openAdminModal('Lý do không Login App',`<div class="v1035-target-form"><label>Lý do<input id="v1037-no-login-reason" placeholder="Ví dụ: dư nợ cao, không còn nhu cầu..."></label><div class="call-actions"><button class="btn" id="v1037-no-login-cancel">Hủy</button><button class="btn primary" id="v1037-no-login-save">Lưu</button></div></div>`);document.querySelector('#v1037-no-login-cancel').onclick=closeAdminModal;document.querySelector('#v1037-no-login-save').onclick=async()=>{try{await API.request(`/login-leads/${Number(b.dataset.v1037Nologin)}/status`,{method:'POST',body:JSON.stringify({status:'NO_LOGIN',reason:document.querySelector('#v1037-no-login-reason').value})});closeAdminModal();refresh();toast('Đã ghi nhận Lead không login.');}catch(e){toast(e.message,'bad')}}});
 main.querySelectorAll('[data-v1037-reopen]').forEach(b=>b.onclick=async()=>{try{await API.request(`/login-leads/${Number(b.dataset.v1037Reopen)}/status`,{method:'POST',body:JSON.stringify({status:'PENDING'})});refresh();toast('Đã mở lại Lead.');}catch(e){toast(e.message,'bad')}});
 main.querySelectorAll('[data-v1037-open-loginapp]').forEach(b=>b.onclick=()=>navigate('loginApp'));
}
async function v1037LoadLoginLeads(main){try{const data=await API.request('/login-leads');state.v1036LoginLeads=data.items||[];if(state.page==='loginLead')v1037RenderLoginLeads(main||document.querySelector('#main'));}catch(e){if(main)main.innerHTML=`<div class="empty">${esc(e.message)}</div>`;}}

function v1037RenderAppFollowups(main){
 state.v1037AppFollowBucket=state.v1037AppFollowBucket||'all';state.v1037AppFollowType=state.v1037AppFollowType||'';state.v1037AppFollowUser=state.v1037AppFollowUser||'';
 const all=state.v1036AppFollowups||[];const month=state.v1037AppFollowMonth||'';const year=String(state.v1037AppFollowYear||new Date().getFullYear());
 const scoped=all.filter(x=>{const bucket=v1037AppFollowBucket(x);if(state.v1037AppFollowBucket!=='all'&&bucket!==state.v1037AppFollowBucket)return false;if(state.v1037AppFollowType&&x.category!==state.v1037AppFollowType)return false;if(state.v1037AppFollowUser&&String(x.assigned_user_id)!==String(state.v1037AppFollowUser))return false;const key=v1018_monthKey(x.follow_date);if(month&&key!==`${year}-${month}`)return false;if(!month&&year&&key&&!key.startsWith(`${year}-`))return false;return true;});
 const users=v1037LoginLeadVisibleUsers();
 const todayCount=all.filter(x=>v1037AppFollowBucket(x)==='today').length,overdueCount=all.filter(x=>v1037AppFollowBucket(x)==='overdue').length,upcomingCount=all.filter(x=>v1037AppFollowBucket(x)==='upcoming').length;
 const labels={REJECTED:'Hồ sơ bị từ chối',CALLBACK:'Khách hẹn gọi lại',DOCUMENT:'Bổ sung hồ sơ',RELOGIN:'Đăng nhập App lại'};
 main.innerHTML=`<div class="premium-page"><div class="premium-page-head"><div class="premium-page-title"><h1>Follow-up Login App</h1><p>Khách bị từ chối hồ sơ cần chăm sóc, bổ sung hồ sơ hoặc hẹn Login App lại.</p></div><div class="premium-page-actions"><button class="btn primary" id="v1037-appfu-add">+ Tạo lịch</button><button class="btn" id="v1037-appfu-refresh">↻ Làm mới</button></div></div>
   <section class="followup-summary-grid"><article class="followup-summary-card ${state.v1037AppFollowBucket==='today'?'active':''}" data-v1037-bucket="today"><span>Hôm nay</span><strong>${todayCount}</strong><small>Không có lịch hôm nay</small></article><article class="followup-summary-card ${state.v1037AppFollowBucket==='overdue'?'active':''}" data-v1037-bucket="overdue"><span>Quá hạn</span><strong>${overdueCount}</strong><small>Cần xử lý ngay</small></article><article class="followup-summary-card ${state.v1037AppFollowBucket==='upcoming'?'active':''}" data-v1037-bucket="upcoming"><span>Sắp tới</span><strong>${upcomingCount}</strong><small>Từ ngày mai</small></article></section>
   <section class="crm-panel followup-panel"><div class="lead-toolbar-simple"><div class="team-tabs"><button class="${state.v1037AppFollowBucket==='all'?'active':''}" data-v1037-bucket="all">Tất cả ${all.length}</button><button class="${state.v1037AppFollowBucket==='today'?'active':''}" data-v1037-bucket="today">Hôm nay ${todayCount}</button><button class="${state.v1037AppFollowBucket==='overdue'?'active':''}" data-v1037-bucket="overdue">Quá hạn ${overdueCount}</button><button class="${state.v1037AppFollowBucket==='upcoming'?'active':''}" data-v1037-bucket="upcoming">Sắp tới ${upcomingCount}</button></div><div class="v1037-inline-filters"><select id="v1037-fu-month"><option value="">Tất cả tháng</option>${Array.from({length:12},(_,i)=>{const v=String(i+1).padStart(2,'0');return `<option value="${v}" ${month===v?'selected':''}>Tháng ${i+1}</option>`}).join('')}</select><select id="v1037-fu-year">${Array.from({length:6},(_,i)=>{const y=String(new Date().getFullYear()-2+i);return `<option value="${y}" ${year===y?'selected':''}>${y}</option>`}).join('')}</select><select id="v1037-fu-type"><option value="">Tất cả loại</option>${Object.entries(labels).map(([k,v])=>`<option value="${k}" ${state.v1037AppFollowType===k?'selected':''}>${v}</option>`).join('')}</select><select id="v1037-fu-user"><option value="">Mọi nhân viên</option>${users.map(u=>`<option value="${u.id}" ${String(state.v1037AppFollowUser||'')===String(u.id)?'selected':''}>${esc(u.display_name)}</option>`).join('')}</select></div></div>
   <div class="table-wrap"><table class="data-table"><thead><tr><th>Lịch hẹn</th><th>Khách hàng</th><th>SĐT</th><th>Nhân viên</th><th>Team</th><th>Tình trạng</th><th>Ghi chú</th><th>Thao tác</th></tr></thead><tbody>${scoped.map(x=>`<tr><td>${shortDate(x.follow_date)}</td><td><strong>${esc(x.customer_name||'')}</strong></td><td>${esc(x.phone||'')}</td><td>${esc(x.owner||'—')}</td><td>${esc(x.team||'—')}</td><td>${x.status==='DONE'?'<span class="status-pill success">Đã chăm sóc</span>':v1037AppFollowBucket(x)==='overdue'?'<span class="status-pill danger">Quá hạn</span>':v1037AppFollowBucket(x)==='today'?'<span class="status-pill warn">Hôm nay</span>':'<span class="status-pill primary">Sắp tới</span>'}<small>${esc(labels[x.category]||x.category)}</small></td><td>${esc(x.note||'')}</td><td>${x.status==='PENDING'?`<button class="btn small primary" data-v1037-fu-done="${x.id}">Đã chăm sóc</button>`:'—'}</td></tr>`).join('')||'<tr><td colspan="8"><div class="empty">Không có lịch hẹn trong nhóm đang chọn.</div></td></tr>'}</tbody></table></div></section></div>`;
 const refresh=()=>v1037LoadAppFollowups(main);
 main.querySelector('#v1037-appfu-refresh').onclick=refresh;
 main.querySelector('#v1037-appfu-add').onclick=async()=>{let apps=state.loginApps||[];if(!apps.length){try{const r=await API.request('/login-apps');apps=r.items||[];}catch(e){toast(e.message,'bad');return;}}openAdminModal('Tạo lịch Follow-up Login App',`<div class="v1035-target-form"><label>Khách Login App<select id="v1037-fu-app">${apps.map(a=>`<option value="${a.id}">${esc(a.customer_name||'')} · ${esc(a.phone||'')}</option>`).join('')}</select></label><label>Nội dung chăm sóc<select id="v1037-fu-kind">${Object.entries(labels).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></label><label>Ngày chăm sóc<input id="v1037-fu-date" type="date" value="${todayISO()}"></label><label>Ghi chú<input id="v1037-fu-note" placeholder="Nội dung cần chăm sóc"></label><div class="call-actions"><button class="btn" id="v1037-fu-cancel">Hủy</button><button class="btn primary" id="v1037-fu-save">Lưu lịch</button></div></div>`);document.querySelector('#v1037-fu-cancel').onclick=closeAdminModal;document.querySelector('#v1037-fu-save').onclick=async()=>{try{await API.request('/app-followups',{method:'POST',body:JSON.stringify({login_app_id:Number(document.querySelector('#v1037-fu-app').value),category:document.querySelector('#v1037-fu-kind').value,follow_date:document.querySelector('#v1037-fu-date').value,note:document.querySelector('#v1037-fu-note').value})});closeAdminModal();refresh();toast('Đã thêm lịch Follow-up Login App.');}catch(e){toast(e.message,'bad')}}};
 main.querySelectorAll('[data-v1037-bucket]').forEach(b=>b.onclick=()=>{state.v1037AppFollowBucket=b.dataset.v1037Bucket;v1037RenderAppFollowups(main)});
 main.querySelector('#v1037-fu-month').onchange=e=>{state.v1037AppFollowMonth=e.target.value;v1037RenderAppFollowups(main)};
 main.querySelector('#v1037-fu-year').onchange=e=>{state.v1037AppFollowYear=e.target.value;v1037RenderAppFollowups(main)};
 main.querySelector('#v1037-fu-type').onchange=e=>{state.v1037AppFollowType=e.target.value;v1037RenderAppFollowups(main)};
 main.querySelector('#v1037-fu-user').onchange=e=>{state.v1037AppFollowUser=e.target.value;v1037RenderAppFollowups(main)};
 main.querySelectorAll('[data-v1037-fu-done]').forEach(b=>b.onclick=async()=>{try{await API.request(`/app-followups/${Number(b.dataset.v1037FuDone)}/complete`,{method:'POST',body:'{}'});refresh();toast('Đã ghi nhận chăm sóc.');}catch(e){toast(e.message,'bad')}});
}
async function v1037LoadAppFollowups(main){try{const result=await API.request('/app-followups');state.v1036AppFollowups=result.items||[];if(state.page==='appFollowup')v1037RenderAppFollowups(main||document.querySelector('#main'));}catch(e){if(main)main.innerHTML=`<div class="empty">${esc(e.message)}</div>`;}}
const v1036PrevRender=render;
render=function(){
 if(state.page==='loginLead'){v1037LoadLoginLeads(document.querySelector('#main'));ensureFloatingChat();return;}
 if(state.page==='appFollowup'){v1037LoadAppFollowups(document.querySelector('#main'));ensureFloatingChat();return;}
 return v1036PrevRender();
};
V1032_AUDIT_LABELS.USER_LOCK='Khóa tài khoản';
V1032_AUDIT_LABELS.USER_UNLOCK='Mở khóa tài khoản';
V1032_AUDIT_LABELS.REVENUE_KPI_BULK='Đặt KPI doanh số hàng loạt';
V1032_AUDIT_LABELS.APP_FOLLOWUP_CREATE='Tạo lịch Login App';
V1032_AUDIT_LABELS.APP_FOLLOWUP_COMPLETE='Chăm sóc Login App';
V1032_AUDIT_LABELS.LOGIN_LEAD_SOURCE='Cập nhật nguồn Lead';
V1032_AUDIT_LABELS.LOGIN_LEAD_CREATE='Tạo Lead Login App';
V1032_AUDIT_LABELS.LOGIN_LEAD_CONVERT='Chuyển Lead sang Login App';
V1032_AUDIT_LABELS.LOGIN_LEAD_NOLOGIN='Ghi nhận không Login App';
