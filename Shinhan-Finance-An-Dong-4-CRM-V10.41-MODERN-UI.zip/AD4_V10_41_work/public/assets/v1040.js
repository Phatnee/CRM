/* An Đông 4 CRM V10.40 — Team Leader staff drill-down and navigable KPI details.
   UI-only: backend and D1 permission checks from V10.39 remain authoritative. */
(() => {
  const manager = role => role === 'admin' || role === 'sup';
  const leader = role => role === 'teamlead';
  const number = n => Number(n || 0).toLocaleString('vi-VN');
  const money = n => number(n) + ' đ';
  const staffRole = u => String(u.staff_type || '').toLowerCase() === 'freelancer' ? 'Freelancer' : 'Sales';
  const initials = name => String(name || 'NV').trim().split(/\s+/).slice(-2).map(s=>s.charAt(0)).join('').toUpperCase();
  const mainEl = () => document.getElementById('main');
  const userRole = () => state.session?.user?.role || 'sale';

  // Rows come only from the existing role-scoped /api/login-performance endpoint.
  // No client-side filtering can increase the user's server-authorized scope.
  function staffTable(panel, staff, main) {
    const rows = staff.slice().sort((a,b)=>Number(b.volume||0)-Number(a.volume||0)||String(a.display_name||'').localeCompare(String(b.display_name||''),'vi'));
    const title = leader(userRole()) ? 'Hiệu suất nhân viên trong Team' : 'Hiệu suất nhân viên';
    panel.classList.add('v1040-staff-panel');
    panel.innerHTML = `<div class="v1039-panel-head"><div><div class="v1039-head-icon">${uiIcon('users')}</div><div><h2>${title}</h2><p>Chọn Xem Dashboard để xem APP, Loan và doanh số riêng của nhân viên</p></div></div><small>${rows.length} nhân viên</small></div>
    <div class="v1039-table-scroller"><table class="v1039-table v1040-staff-table"><thead><tr><th>NHÂN VIÊN</th><th>VAI TRÒ</th><th>APP</th><th>LOAN</th><th>DOANH SỐ</th><th>CHI TIẾT</th></tr></thead><tbody>${rows.map(u=>`<tr><td><div class="v1040-staff-name"><span class="v1039-employee-avatar">${esc(initials(u.display_name))}</span><strong>${esc(u.display_name||'—')}</strong></div></td><td><span class="v1039-role-chip ${staffRole(u)==='Freelancer'?'freelancer':'sales'}">${staffRole(u)}</span></td><td>${number(u.apps)}</td><td>${number(u.loans)}</td><td class="v1039-money-cell">${money(u.volume)}</td><td><button class="v1039-view-team" type="button" data-v1040-staff="${Number(u.id)}">Xem Dashboard <span aria-hidden="true">→</span></button></td></tr>`).join('')||'<tr><td colspan="6" class="v1039-empty">Team chưa có nhân viên.</td></tr>'}</tbody></table></div>`;
    panel.querySelectorAll('[data-v1040-staff]').forEach(btn=>btn.onclick=()=>{
      const id = Number(btn.dataset.v1040Staff);
      if(!rows.some(u=>Number(u.id)===id) || userRole()==='sale')return;
      state.v1040DashboardTrail = { team:String(state.v1035RevenueTeam||''), user:String(state.v1035RevenueUser||'') };
      state.v1035RevenueUser = String(id);
      v1035RenderPerformance(main,false);
    });
  }

  function backHeader(root,main,data) {
    const role = userRole();
    const selectedUser=String(state.v1035RevenueUser||'');
    const team=String(state.v1035RevenueTeam||'');
    const target=selectedUser?((data?.items||[]).find(x=>String(x.id)===selectedUser)|| (state.users||[]).find(x=>String(x.id)===selectedUser)):null;
    if(role==='sale' || (!selectedUser && !team))return;
    const prev=state.v1040DashboardTrail||{team:'',user:''};
    const hasPrev=Boolean(selectedUser)||manager(role)&&Boolean(team);
    if(!hasPrev)return;
    const label=selectedUser?`Dashboard cá nhân · ${target?.display_name||'Nhân viên'}`:`Dashboard Team · ${(state.teamObjects||[]).find(x=>String(x.id)===team)?.name||'Team'}`;
    const bar=document.createElement('div');bar.className='v1040-back-bar';
    bar.innerHTML=`<button type="button" class="v1040-back-button" aria-label="Quay lại Dashboard trước">← Trở về Dashboard trước</button><strong>${esc(label)}</strong>`;
    const head=root.querySelector('.v1035-perf-head');if(head)head.after(bar);else root.prepend(bar);
    bar.querySelector('button').onclick=()=>{
      // Step out from employee to Team, then from Team to company overview.
      if(selectedUser){state.v1035RevenueUser=prev.user||'';state.v1035RevenueTeam=prev.team||team||'';state.v1040DashboardTrail=null;}
      else if(manager(role)){state.v1035RevenueTeam='';state.v1035RevenueUser='';state.v1040DashboardTrail=null;}
      v1035RenderPerformance(main,false);
    };
  }

  function clickMetric(card,type,main,data){
    if(!card)return;
    card.classList.add('v1040-clickable-metric');
    card.setAttribute('role','button');card.tabIndex=0;
    const scope = {
      month:state.v1035RevenueMonth,
      team:manager(userRole())?String(state.v1035RevenueTeam||''):leader(userRole())?String(state.session.user.team_id||''):'',
      user:userRole()==='sale'?String(state.session.user.id):String(state.v1035RevenueUser||'')
    };
    card.setAttribute('aria-label',type==='app'?'Xem danh sách hồ sơ APP':type==='loan'?'Xem danh sách khoản vay giải ngân':'Xem chi tiết tổng doanh số giải ngân');
    card.setAttribute('title',type==='app'?'Bấm để xem toàn bộ APP trong tháng':'Bấm để xem các khoản vay đã giải ngân trong tháng');
    const go=()=>{
      // Invalidate the target page's cached list so its server-side role filter is applied.
      state.v1040DetailReturn={month:scope.month,team:scope.team,user:scope.user,type,total:data?.total||{}};
      if(type==='app'){
        state.loginAppsMonth=scope.month;
        state.loginAppsTab='all';state.loginAppsSearch='';
        state.loginAppsTeam=scope.team;state.loginAppsUser=scope.user;
        state.loginAppsLoadedAt=0;
        navigate('loginApp');
      }else{
        state.loanCareMonth=scope.month;state._v1035LoanMonthInit=true;
        state.loanCareTab='all';state.loanCareSearch='';
        state.loanCareTeam=scope.team;state.loanCareUser=scope.user;
        state.loanCareLoadedAt=0;
        navigate('loanCare');
      }
    };
    card.onclick=go;
    card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};
    if(!card.querySelector('.v1040-metric-open')){
      const c=document.createElement('span');c.className='v1040-metric-open';c.innerHTML='Xem chi tiết <span aria-hidden="true">↗</span>';card.appendChild(c);
    }
  }

  // Apply AFTER V10.39 decorates the Dashboard to avoid changing caching or its KPI query.
  const previousPerformance = v1035RenderPerformance;
  v1035RenderPerformance=function(main,kpi=false){
    previousPerformance(main,kpi);
    if(kpi || state.page!=='loginDashboard' || !main)return;
    const root=main.querySelector('.v1039-dashboard');if(!root)return;
    const data=state.v1035Performance?.get?.(v1035PerfKey())?.data;
    const role=userRole(), drill=Boolean(state.v1035RevenueUser);
    backHeader(root,main,data);
    if(!data)return;
    const cards=root.querySelectorAll('.v1039-metrics > .v1039-metric');
    clickMetric(cards[0],'volume',main,data);clickMetric(cards[1],'app',main,data);clickMetric(cards[2],'loan',main,data);
    const teamPanel=root.querySelector('.v1039-team-panel');
    const ranking=root.querySelector('.v1039-ranking-panel');
    if(drill){
      teamPanel?.remove();ranking?.remove();
      const p=root.querySelector('.v1039-header p');if(p)p.textContent='Dashboard cá nhân · APP, Loan và doanh số riêng của nhân viên đã chọn.';
    } else if(role!=='sale' && (leader(role)||manager(role)&&Boolean(state.v1035RevenueTeam))){
      if(teamPanel)staffTable(teamPanel,data.items||[],main);
    }
    // Preserve manager/company Team drill from V10.39: it still opens a Team-specific Dashboard.
  };

  // Add an ALL status in App Login. This is the list shown when opening the APP KPI.
  const oldLoginList=renderLoginApps;
  renderLoginApps=function(main,...args){
    oldLoginList(main,...args);
    if(state.page!=='loginApp'||!main)return;
    const tabs=main.querySelector('.loginapp-tabs');
    if(tabs&&!tabs.querySelector('[data-loginapp-tab="all"]')){
      const all=document.createElement('button');all.type='button';all.dataset.loginappTab='all';
      all.innerHTML=`Tất cả <span>${number((state.loginApps||[]).length)}</span>`;
      tabs.prepend(all);
      all.onclick=()=>{state.loginAppsTab='all';state._v1031PageloginApp=1;renderLoginApps(main);};
    }
    if(tabs)tabs.querySelectorAll('[data-loginapp-tab]').forEach(b=>b.classList.toggle('active',b.dataset.loginappTab===(state.loginAppsTab||'active')));
    renderDetailBanner(main,'app');
  };

  function renderDetailBanner(main,pageType){
    const d=state.v1040DetailReturn;if(!d||state.page!==(pageType==='app'?'loginApp':'loanCare'))return;
    if(main.querySelector('.v1040-detail-banner'))return;
    const root=main.querySelector('.premium-page');if(!root)return;
    const c=document.createElement('div');c.className='v1040-detail-banner';
    const isApp=pageType==='app';
    c.innerHTML=`<button class="v1040-back-button" type="button">← Trở lại Dashboard</button><div><strong>${isApp?'Danh sách APP':'Chi tiết khoản giải ngân'} · Tháng ${esc(d.month.slice(5))}/${esc(d.month.slice(0,4))}</strong><small>${isApp?`${number(d.total.apps)} hồ sơ APP`:`${number(d.total.loans)} Loan · ${money(d.total.volume)}`} trong phạm vi Dashboard đã chọn</small></div>`;
    const head=root.querySelector('.premium-page-head');if(head)head.after(c);else root.prepend(c);
    c.querySelector('button').onclick=()=>{state.v1040DetailReturn=null;navigate('loginDashboard');};
  }
  const oldLoanList=renderLoanCare;
  renderLoanCare=function(main,...args){oldLoanList(main,...args);if(state.page==='loanCare')renderDetailBanner(main,'loan');};

  // Customer Management Lead/Follow-up: remove Team chip bar; keep an explicit scope dropdown
  // in the existing filter toolbar for Admin/Sup, mirroring the compact Telesales filter layout.
  function compactTeamFilter(main, kind){
    main.querySelectorAll('.v1038-team-tabs').forEach(n=>n.remove());
    const root=kind==='lead'?main.querySelector('.lead-card'):main.querySelector('.followup-panel');
    if(!root)return;
    const toolbar=root.querySelector('.lead-toolbar-simple');if(!toolbar)return;
    toolbar.classList.add('v1040-filter-bar');
    if(manager(userRole())){
      const dropdown=document.createElement('select');dropdown.className='v1040-team-select';
      dropdown.setAttribute('aria-label','Lọc dữ liệu theo Team');dropdown.innerHTML=`<option value="">Tất cả Team</option>${(state.teamObjects||[]).map(t=>`<option value="${Number(t.id)}" ${String(state.v1038CustomerTeam||'')===String(t.id)?'selected':''}>${esc(t.name)}</option>`).join('')}`;
      toolbar.appendChild(dropdown);
      dropdown.onchange=()=>{state.v1038CustomerTeam=dropdown.value; if(kind==='lead')v1037RenderLoginLeads(main);else v1037RenderAppFollowups(main);};
    }
    // Team Leader and Sales already have a server-restricted, single-scope response.
  }
  const oldCustomerLead=v1037RenderLoginLeads;
  v1037RenderLoginLeads=function(main){
    const original=state.v1036LoginLeads||[];
    const from=state.v1040LeadFrom||'',to=state.v1040LeadTo||'';
    if(from||to)state.v1036LoginLeads=original.filter(u=>{
      const created=dateKey(u.created_at||'');
      return created&&(!from||created>=from)&&(!to||created<=to);
    });
    try{oldCustomerLead(main);}finally{state.v1036LoginLeads=original;}
    if(state.page!=='loginLead')return;
    compactTeamFilter(main,'lead');
    const root=main.querySelector('.premium-page'),summary=root?.querySelector('.loginapp-summary');
    if(summary){
      const controls=document.createElement('div');controls.className='v1040-lead-dates';
      controls.innerHTML=`<label>Từ ngày<input type="date" id="v1040-lead-from" value="${esc(from)}"></label><span class="v1040-date-arrow">→</span><label>Đến ngày<input type="date" id="v1040-lead-to" value="${esc(to)}"></label><button class="v1040-date-clear" type="button" ${from||to?'':'disabled'}>Xóa lọc</button>`;
      summary.before(controls);
      controls.querySelector('#v1040-lead-from').onchange=e=>{state.v1040LeadFrom=e.target.value;v1037RenderLoginLeads(main);};
      controls.querySelector('#v1040-lead-to').onchange=e=>{state.v1040LeadTo=e.target.value;v1037RenderLoginLeads(main);};
      controls.querySelector('.v1040-date-clear').onclick=()=>{state.v1040LeadFrom='';state.v1040LeadTo='';v1037RenderLoginLeads(main);};
    }
  };
  const oldAppFollow=v1037RenderAppFollowups;
  v1037RenderAppFollowups=function(main){oldAppFollow(main);if(state.page==='appFollowup')compactTeamFilter(main,'followup');};
})();
