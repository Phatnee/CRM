/* An Đông 4 CRM V10.39 — dashboard and Follow-up presentation.
   No database mutations: reuses the V10.38 role-scoped API responses. */
(() => {
  const previousPerformanceRender = v1035RenderPerformance;
  const isManager = role => role === 'admin' || role === 'sup';
  const isLeader = role => role === 'teamlead';
  const metric = n => Number(n || 0).toLocaleString('vi-VN');
  const money = n => Number(n || 0).toLocaleString('vi-VN') + ' đ';
  const roleName = user => String(user.staff_type || '').toLowerCase() === 'freelancer' ? 'Freelancer' : 'Sales';
  const roleClass = user => String(user.staff_type || '').toLowerCase() === 'freelancer' ? 'freelancer' : 'sales';
  const nameLetters = name => String(name || 'NV').trim().split(/\s+/).slice(-2).map(x => x[0] || '').join('').toUpperCase();

  function dashboardCards(cards, total, role){
    cards.classList.remove('v1038-revenue-top');
    cards.classList.add('v1039-metrics');
    const subject = role === 'sale' ? 'của bạn' : isLeader(role) ? 'của Team' : 'trong phạm vi đang xem';
    cards.innerHTML = `
      <article class="v1039-metric v1039-metric-primary">
        <div class="v1039-metric-content"><div class="v1039-metric-kicker"><span class="v1039-metric-icon">${uiIcon('warehouse')}</span><span>TỔNG DOANH SỐ GIẢI NGÂN</span></div>
        <strong class="v1039-total-money">${money(total.volume)}</strong>
        <small>Tổng giá trị giải ngân ${subject} trong tháng đang chọn</small></div>
        <div class="v1039-metric-emblem" aria-hidden="true">${uiIcon('kpi')}</div>
      </article>
      <article class="v1039-metric v1039-metric-secondary">
        <div class="v1039-small-icon apps-metric">${uiIcon('apps')}</div>
        <div><span>Số lượng APP</span><strong>${metric(total.apps)}</strong><small>Hồ sơ phát sinh trong tháng</small></div>
      </article>
      <article class="v1039-metric v1039-metric-secondary">
        <div class="v1039-small-icon loan">${uiIcon('kpi')}</div>
        <div><span>Số lượng Loan</span><strong>${metric(total.loans)}</strong><small>Khoản vay đã giải ngân</small></div>
      </article>`;
  }
  function teamRows(items){
    const map=new Map();
    items.forEach(u=>{
      const k=String(u.team_id ?? '');
      let t=map.get(k);
      if(!t){t={id:k,name:u.team||'Chưa có Team',staff:0,apps:0,loans:0,volume:0};map.set(k,t);}
      t.staff++;t.apps+=Number(u.apps||0);t.loans+=Number(u.loans||0);t.volume+=Number(u.volume||0);
    });
    return [...map.values()].sort((a,b)=>b.volume-a.volume||a.name.localeCompare(b.name,'vi'));
  }
  function dashboardTeams(block, items, role, main){
    const teams=teamRows(items);
    const canDrill=isManager(role);
    block.classList.add('v1039-team-panel');
    block.innerHTML=`<div class="v1039-panel-head"><div><div class="v1039-head-icon">${uiIcon('users')}</div><div><h2>Hiệu suất đội ngũ</h2><p>${isLeader(role)?'Thống kê nhân viên trong Team của bạn':'Tổng hợp doanh số theo từng Team'}</p></div></div><small>Tháng ${esc(state.v1035RevenueMonth.slice(5))}/${esc(state.v1035RevenueMonth.slice(0,4))}</small></div>
    <div class="v1039-table-scroller"><table class="v1039-table v1039-team-table"><thead><tr><th>TEAM</th><th>NHÂN VIÊN</th><th>APP</th><th>LOAN</th><th>DOANH SỐ</th><th>CHI TIẾT</th></tr></thead>
    <tbody>${teams.map(t=>`<tr><td><div class="v1039-team-identity"><span class="v1039-team-monogram">${esc((t.name.match(/\d+/)||['T'])[0])}</span><strong>${esc(t.name)}</strong></div></td><td>${metric(t.staff)}</td><td>${metric(t.apps)}</td><td>${metric(t.loans)}</td><td class="v1039-money-cell">${money(t.volume)}</td><td>${canDrill?`<button type="button" class="v1039-view-team" data-v1039-view-team="${esc(t.id)}">Xem Team <span aria-hidden="true">→</span></button>`:'<span class="v1039-subtle-label">Team của bạn</span>'}</td></tr>`).join('')||'<tr><td colspan="6" class="v1039-empty">Chưa có dữ liệu trong phạm vi này.</td></tr>'}</tbody></table></div>`;
    block.querySelectorAll('[data-v1039-view-team]').forEach(b=>b.onclick=()=>{
      const id=b.dataset.v1039ViewTeam;
      // Manager can drill into the selected Team; the API remains responsible for scope.
      if(!canDrill||!(state.teamObjects||[]).some(t=>String(t.id)===id))return;
      state.v1035RevenueTeam=id;
      state.v1035RevenueUser='';
      v1035RenderPerformance(main,false);
    });
  }
  function dashboardRanking(block, items){
    const rows=items.slice().sort((a,b)=> Number(b.volume||0)-Number(a.volume||0)||Number(b.loans||0)-Number(a.loans||0)||Number(b.apps||0)-Number(a.apps||0)||String(a.display_name||'').localeCompare(String(b.display_name||''),'vi'));
    const max=Math.max(...rows.map(r=>Number(r.volume||0)),0);
    block.classList.add('v1039-ranking-panel');
    block.innerHTML=`<div class="v1039-panel-head"><div><div class="v1039-head-icon trophy">${uiIcon('target')}</div><div><h2>Bảng xếp hạng doanh số</h2><p>Sales & Freelancer · Xếp theo Volume giải ngân</p></div></div><span class="v1039-ranking-count">${metric(rows.length)} nhân viên</span></div>
    <div class="v1039-table-scroller v1039-ranking-scroll"><table class="v1039-table v1039-ranking-table"><thead><tr><th>HẠNG</th><th>NHÂN VIÊN</th><th>VAI TRÒ</th><th>TEAM</th><th>APP</th><th>LOAN</th><th>DOANH SỐ GIẢI NGÂN</th></tr></thead><tbody>
    ${rows.map((u,i)=>{const n=Number(u.volume||0),winner=i<3&&n>0;const pct=max?Math.max(0,Math.min(100,n/max*100)):0;return `<tr class="${winner?'v1039-ranked-top v1039-ranked-'+(i+1):''}"><td><span class="v1039-rank-number ${winner?'top-'+(i+1):''}">${winner?['①','②','③'][i]:'#'+(i+1)}</span></td><td><div class="v1039-employee"><span class="v1039-employee-avatar">${esc(nameLetters(u.display_name))}</span><strong title="${esc(u.display_name||'')}">${esc(u.display_name||'—')}</strong></div></td><td><span class="v1039-role-chip ${roleClass(u)}">${roleName(u)}</span></td><td class="v1039-soft">${esc(u.team||'—')}</td><td class="v1039-nums">${metric(u.apps)}</td><td class="v1039-nums">${metric(u.loans)}</td><td><div class="v1039-rank-revenue"><strong>${money(n)}</strong><span class="v1039-rank-track"><i style="width:${pct.toFixed(2)}%"></i></span></div></td></tr>`}).join('')||'<tr><td colspan="7" class="v1039-empty">Chưa có nhân viên trong phạm vi này.</td></tr>'}
    </tbody></table></div>`;
  }
  v1035RenderPerformance=function(main,kpi=false){
    previousPerformanceRender(main,kpi);
    if(kpi||state.page!=='loginDashboard'||!main)return;
    const root=main.querySelector('.v1035-perf-page');if(!root)return;
    root.classList.add('v1039-dashboard');
    // Dashboard: remove the duplicate horizontal Team selection bar.
    root.querySelectorAll('.v1038-team-tabs').forEach(n=>n.remove());
    const role=state.session?.user?.role||'sale';
    const data=state.v1035Performance?.get?.(v1035PerfKey())?.data;
    // Preserve the loading state and the existing comparison request.
    if(!data)return;
    dashboardCards(root.querySelector('.v1035-perf-cards'),data.total||{},role);
    // The V10.38 per-employee raw table duplicates the sales leaderboard.
    root.querySelectorAll('.v1035-perf-list').forEach(n=>n.remove());
    const team=root.querySelector('.v1038-team-performance');
    const ranking=root.querySelector('.v1038-sales-ranking');
    const compare=root.querySelector('.v1036-compare-months');
    if(role==='sale'){
      team?.remove();ranking?.remove();
    }else{
      if(team)dashboardTeams(team,data.items||[],role,main);
      if(ranking)dashboardRanking(ranking,data.items||[]);
      // Visual reading order: hero -> team performance -> comparison -> ranking.
      if(team&&compare&&team.parentNode===root&&compare.parentNode===root)team.after(compare);
      if(ranking&&compare&&compare.parentNode===root)compare.after(ranking);
    }
    // Improve header text without changing the role-scoped filters.
    const head=root.querySelector('.v1035-perf-head');
    if(head){
      head.classList.add('v1039-header');
      const h=head.querySelector('h1');if(h)h.textContent='Dashboard Quản lý khách hàng';
      const p=head.querySelector('p');if(p)p.textContent=role==='sale'?'Kết quả APP, Loan và doanh số của bạn theo tháng.':isLeader(role)?'Kết quả kinh doanh của Team và các thành viên.':'Tổng quan APP, Loan và doanh số giải ngân toàn hệ thống.';
    }
  };
})();
