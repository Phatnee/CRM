/* An Đông 4 CRM V10.41 — Modern SaaS CRM UI layer.
   UI-only: keeps existing Cloudflare Worker APIs, D1 schema, authentication and role scope intact. */
(() => {
  const VERSION='10.41';
  const qs=(s,r=document)=>r.querySelector(s);
  const qsa=(s,r=document)=>[...r.querySelectorAll(s)];
  const currentRole=()=>state.session?.user?.role||'sale';
  const isManager=()=>['admin','sup'].includes(currentRole());
  const isLeader=()=>currentRole()==='teamlead';
  const isSale=()=>currentRole()==='sale';

  const ROUTES={
    dashboard:['dashboard','Dashboard Telesales'],
    loginDashboard:['dashboard','Dashboard khách hàng'],
    customerdb:['customers','Chi tiết cuộc gọi'],
    followup:['calendar','Follow-up Telesales'],
    lead:['lead','Lead Telesales'],
    kpi:['kpi','KPI cuộc gọi'],
    loginApp:['apps','App Login'],
    loginLead:['lead','Lead'],
    appFollowup:['calendar','Follow-up'],
    loanCare:['customers','Chăm sóc khách hàng'],
    revenueKpi:['kpi','KPI doanh số'],
    teamManagement:['users','Nhân viên & nhóm'],
    warehouseAdmin:['warehouse','Kho dữ liệu'],
    io:['import','Nhập / Xuất dữ liệu'],
    audit:['settings','Nhật ký thao tác']
  };
  const GROUPS=[
    {key:'overview',title:'Tổng quan',icon:'dashboard',items:['dashboard','loginDashboard']},
    {key:'customers',title:'Khách hàng',icon:'customers',items:['loginApp','loginLead','appFollowup','loanCare','revenueKpi']},
    {key:'telesales',title:'Telesales',icon:'call',items:['customerdb','followup','lead','kpi']},
    {key:'team',title:'Quản lý đội ngũ',icon:'users',items:['teamManagement','warehouseAdmin','io']},
    {key:'system',title:'Hệ thống',icon:'settings',items:['audit']}
  ];

  function groupForPage(page){return GROUPS.find(g=>g.items.includes(page))?.key||'overview';}
  function loadOpenGroups(){
    let saved={};
    try{saved=JSON.parse(localStorage.getItem('a4_nav_groups')||'{}')||{};}catch(_e){}
    return Object.assign({overview:true,customers:true,telesales:true,team:true,system:true},saved);
  }
  state.v1041NavOpen=state.v1041NavOpen||loadOpenGroups();
  state.v1041SidebarCollapsed=state.v1041SidebarCollapsed ?? (localStorage.getItem('a4_sidebar_collapsed')==='1');

  function persistNav(){
    try{localStorage.setItem('a4_nav_groups',JSON.stringify(state.v1041NavOpen));}catch(_e){}
  }
  function applySidebarCollapsed(){
    document.body.classList.toggle('v1041-sidebar-collapsed',!!state.v1041SidebarCollapsed);
    const btn=qs('[data-v1041-collapse]');
    if(btn){btn.setAttribute('aria-label',state.v1041SidebarCollapsed?'Mở rộng menu':'Thu gọn menu');btn.title=state.v1041SidebarCollapsed?'Mở rộng menu':'Thu gọn menu';}
  }

  const previousSidebar=renderSidebar;
  renderSidebar=function(active){
    // Let the prior version preserve any state/permission side effects, then replace only the visual navigation.
    previousSidebar(active);
    const menu=qs('#sidebar-menu'),user=state.session?.user;
    if(!menu||!user)return;
    const allowed=allowedPagesForRole(user.role);
    const currentGroup=groupForPage(active);
    if(state.v1041NavOpen[currentGroup]===undefined)state.v1041NavOpen[currentGroup]=true;
    const previousScroll=menu.querySelector('.sidebar-nav-scroll')?.scrollTop||0;
    const itemHtml=id=>{
      if(!allowed.has(id)||!ROUTES[id])return '';
      const [icon,label]=ROUTES[id];
      const activeClass=id===active?'active':'';
      return `<button type="button" class="menu-item v1041-nav-item ${activeClass}" data-nav="${id}" title="${esc(label)}" ${id===active?'aria-current="page"':''}><span class="menu-item-icon">${uiIcon(icon)}</span><span class="menu-item-label">${esc(label)}</span></button>`;
    };
    const groups=GROUPS.map(g=>{
      const items=g.items.map(itemHtml).filter(Boolean).join('');
      if(!items)return '';
      const open=!!state.v1041NavOpen[g.key];
      return `<section class="v1041-nav-group ${open?'is-open':''}" data-v1041-group="${g.key}">
        <button type="button" class="v1041-group-toggle" data-v1041-toggle="${g.key}" aria-expanded="${open}">
          <span class="v1041-group-icon">${uiIcon(g.icon)}</span><span class="v1041-group-title">${esc(g.title)}</span><span class="v1041-group-chevron">⌄</span>
        </button>
        <div class="v1041-group-items">${items}</div>
      </section>`;
    }).filter(Boolean).join('');
    menu.innerHTML=`<div class="sidebar-brand v1041-sidebar-brand">
      <div class="sidebar-brand-mark">A4</div>
      <div class="v1041-brand-copy"><strong>An Đông 4</strong><span>SHINHAN FINANCE</span></div>
      <button type="button" class="v1041-sidebar-collapse" data-v1041-collapse aria-label="Thu gọn menu" title="Thu gọn menu">‹</button>
    </div>
    <div class="sidebar-nav-scroll v1041-sidebar-scroll">${groups}</div>`;
    qsa('[data-nav]',menu).forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
    qsa('[data-v1041-toggle]',menu).forEach(b=>b.onclick=()=>{
      const key=b.dataset.v1041Toggle;
      state.v1041NavOpen[key]=!state.v1041NavOpen[key];persistNav();
      const g=b.closest('.v1041-nav-group');g?.classList.toggle('is-open',state.v1041NavOpen[key]);
      b.setAttribute('aria-expanded',String(!!state.v1041NavOpen[key]));
    });
    qs('[data-v1041-collapse]',menu)?.addEventListener('click',()=>{
      state.v1041SidebarCollapsed=!state.v1041SidebarCollapsed;
      try{localStorage.setItem('a4_sidebar_collapsed',state.v1041SidebarCollapsed?'1':'0');}catch(_e){}
      applySidebarCollapsed();
    });
    const scroller=qs('.sidebar-nav-scroll',menu);if(scroller)scroller.scrollTop=previousScroll;
    applySidebarCollapsed();
  };

  function semanticPageName(page){
    if(['dashboard','customerdb','followup','lead','kpi'].includes(page))return 'Telesales';
    if(['loginDashboard','loginApp','loginLead','appFollowup','loanCare','revenueKpi'].includes(page))return 'Khách hàng';
    if(['teamManagement','warehouseAdmin','io'].includes(page))return 'Đội ngũ';
    if(page==='audit')return 'Hệ thống';
    return 'CRM';
  }

  function enhancePage(main){
    if(!main)return;
    main.classList.add('v1041-main');
    const pageRoot=main.firstElementChild;
    pageRoot?.classList.add('v1041-page');
    const head=main.querySelector('.premium-page-head,.page-head,.v1035-perf-head,.v1036-page-head');
    if(head&&!head.querySelector('.v1041-page-kicker')){
      const titleBox=head.querySelector('.premium-page-title')||head.querySelector(':scope > div')||head;
      const h=titleBox.querySelector?.('h1');
      if(h){const k=document.createElement('span');k.className='v1041-page-kicker';k.textContent=semanticPageName(state.page);h.before(k);}
    }
    qsa('.crm-panel,.card,.lead-card,.table-wrap,.toolbar,.loginapp-summary article,.care-summary-top article,.care-summary-bottom article,.kpi,.v1039-metric',main).forEach(el=>el.classList.add('v1041-surface'));
    qsa('.data-table,.v1039-table,.followup-table,.care-v97-table,.loan-table,.loginapp-table',main).forEach(t=>t.classList.add('v1041-table'));
    qsa('.empty',main).forEach(el=>{if(!el.querySelector('.v1041-empty-icon')){const icon=document.createElement('span');icon.className='v1041-empty-icon';icon.textContent='○';el.prepend(icon);}});
  }

  const previousRender=render;
  render=function(...args){
    const result=previousRender(...args);
    queueMicrotask(()=>enhancePage(qs('#main')));
    return result;
  };
  const previousNavigate=navigate;
  navigate=function(page){
    const result=previousNavigate(page);
    queueMicrotask(()=>enhancePage(qs('#main')));
    return result;
  };

  // Keep dynamic content styled without changing business logic.
  const main=qs('#main');
  if(main){
    const observer=new MutationObserver(()=>enhancePage(main));
    observer.observe(main,{subtree:true,childList:true});
  }

  // Make the topbar feel like an application shell, without removing existing actions.
  qs('.premium-topbar')?.classList.add('v1041-topbar');
  qs('.global-search-wrap')?.classList.add('v1041-global-search');
  qs('#user-menu-button')?.classList.add('v1041-user-button');
  document.documentElement.dataset.crmVersion=VERSION;
  applySidebarCollapsed();
})();
