@echo off
setlocal
cd /d "%~dp0"
echo KIEM TRA D1 PRODUCTION - CHI DOC, KHONG SUA DU LIEU
call npx.cmd wrangler d1 execute an-dong-4-crm --remote --command "SELECT name FROM d1_migrations ORDER BY name;"
if errorlevel 1 goto ERROR
call npx.cmd wrangler d1 execute an-dong-4-crm --remote --command "PRAGMA table_info(login_app_cases);"
if errorlevel 1 goto ERROR
call npx.cmd wrangler d1 execute an-dong-4-crm --remote --command "PRAGMA table_info(loan_profiles);"
if errorlevel 1 goto ERROR
call npx.cmd wrangler d1 execute an-dong-4-crm --remote --command "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('lead_status_history','audit_undo','revenue_kpi_targets','user_access_rules');"
if errorlevel 1 goto ERROR
echo Ket thuc kiem tra chi doc.
pause
exit /b 0
:ERROR
echo Co lenh doc that bai, khong co thay doi du lieu.
pause
exit /b 1
