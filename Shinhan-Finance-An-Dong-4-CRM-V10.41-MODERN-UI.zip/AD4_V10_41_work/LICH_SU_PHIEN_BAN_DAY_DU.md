# LỊCH SỬ TOÀN BỘ PHIÊN BẢN AN ĐÔNG 4

Tài liệu lưu toàn bộ nội dung gốc của 109 file README các phiên bản V2 đến V10.33, theo thứ tự phiên bản. Phần thân mỗi mục là nội dung nguyên vẹn (đúng số byte và SHA-256) của file nguồn.


---

## README_V2.md

- Số byte gốc: 2489
- SHA-256: `8dd5a2bde797c284c66cc755e2f27b8bd36ae78a4168ae555370b408837f7f71`

# AN ĐÔNG 4 CRM – Cloudflare V2

V2 bổ sung các chức năng quản trị dùng trực tiếp trên website:

- Import Excel/CSV trực tiếp vào Cloudflare D1.
- Tự nhận các cột từ Dashboard, CRM Teamlead và file gọi nhân viên.
- Chống trùng theo số điện thoại hoặc Mã KH: dữ liệu trùng sẽ cập nhật thay vì tạo dòng mới.
- Thêm nhân viên.
- Sửa họ tên, tên đăng nhập, Team, vai trò, email.
- Đổi/reset mật khẩu nhân viên.
- Xoá nhân viên theo kiểu vô hiệu hoá; Data đang giao sẽ trả về trạng thái chưa gán Sale.
- Hỗ trợ Mobility 1 / 3 / 5 / 6 (M1/M3/M5/M6).
- Admin có thể quản lý toàn bộ nhân sự; Teamlead xem nhân sự trong Team.
- Mật khẩu mới dùng PBKDF2; tài khoản demo cũ sẽ tự nâng cấp hash sau lần đăng nhập thành công tiếp theo.

## Nâng cấp từ V1 đang chạy

V2 dùng đúng database D1 hiện tại:

`637d02d5-68e7-461f-be92-bc362fb7ed9c`

Không cần xoá database và không cần import lại dữ liệu demo.

Từ thư mục V2:

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau khi deploy xong, mở lại URL Workers cũ.

## Import Data

1. Đăng nhập Admin.
2. Vào **Dữ liệu**.
3. Chọn Team mặc định nếu file không có cột Team.
4. Chọn `.xlsx`, `.xls` hoặc `.csv`.
5. Bấm **Đọc & kiểm tra file**.
6. Xem mẫu dữ liệu nhận diện.
7. Bấm **Đẩy vào D1**.

Các cột được tự nhận diện gồm:
- Mã KH
- Họ tên KH
- Số điện thoại
- Nguồn Data
- Team
- Phân bổ cho
- Tên NV
- Trạng thái cuộc gọi
- Ngày nhận Data / Ngày gọi
- Lịch hẹn gọi lại
- Ghi chú chi tiết

## Quản lý nhân viên

Vào **Nhân sự**:
- `+ Thêm nhân viên`: tạo tài khoản mới.
- `Sửa`: đổi tên đăng nhập, tên hiển thị, Team, vai trò hoặc mật khẩu.
- `Xoá`: vô hiệu hoá tài khoản và trả Data đang gán cho người đó về chưa gán Sale.

Team:
- M1 = Mobility 1
- M3 = Mobility 3
- M5 = Mobility 5
- M6 = Mobility 6


## V2.1 hotfix (Cloudflare PBKDF2)
- Giảm PBKDF2 từ 120.000 xuống 100.000 iterations để phù hợp giới hạn WebCrypto của Cloudflare Workers.
- Sửa lỗi khi Admin thêm nhân viên / reset mật khẩu: `Pbkdf2 failed: iteration counts above 100000 are not supported`.
- Không cần chạy migration và không làm mất dữ liệu D1 hiện có.



---

## README_V3.1.md

- Số byte gốc: 2693
- SHA-256: `81b0a4dabfad059057185836c85c463a4f9982743173f6ba27c6ee44cdf68de7`

# AN ĐÔNG 4 CRM – V3.1

Bản V3.1 nâng cấp theo yêu cầu vận hành Telesale thực tế.

## Tính năng mới

### 1) Nhận Data và phân nhân viên ngay khi import
Tại **Dữ liệu**:
1. Chọn Team (Mobility 1 / 3 / 5 / 6).
2. Chọn cách phân:
   - **Chia đều các thành viên trong Team** (round-robin).
   - **Chưa gán nhân viên** để chia sau.
   - **Giữ tên nhân viên trong file Excel**.
   - **Gán toàn bộ cho một nhân viên cụ thể** trong Team.
3. Chọn `.xlsx`, `.xls` hoặc `.csv`.
4. Bấm **Đọc & kiểm tra file** để xem trước Team/Nhân viên.
5. Bấm **Đẩy vào D1**.

Nếu file không có `Ngày nhận Data`, hệ thống tự dùng ngày import để Dashboard theo ngày vẫn hoạt động.

### 2) Dashboard theo từng ngày
Dashboard có ô chọn ngày, nút hôm nay, ngày trước/sau và bảng 7 ngày gần nhất.
Các chỉ số theo ngày gồm:
- Data nhận
- Calls
- Khách đã xử lý
- Tỷ lệ kết nối
- Y01
- Follow-up

### 3) Xóa Data cũ / tạo đợt Data mới
Tại **Dữ liệu** có vùng màu đỏ **Xoá Data cũ / Bắt đầu đợt mới**.
- Admin có thể xóa toàn bộ hoặc chọn một Team.
- Teamlead chỉ xóa Data của Team mình.
- Phải nhập đúng `XOA DATA` và xác nhận lần nữa.
- Chỉ xóa khách hàng + lịch sử cuộc gọi trong phạm vi chọn.
- Giữ nguyên Team, nhân viên, tài khoản và KPI.

Khuyến nghị bấm **Xuất CSV hiện tại** trước khi xóa.

### 4) KPI riêng cho từng nhân viên
Vào **KPI** → chọn ngày → bấm **Đặt KPI** ở nhân viên.
Có 4 KPI/ngày:
- Calls/ngày
- Khách xử lý/ngày
- Tỷ lệ kết nối mục tiêu (%)
- Y01/ngày

Admin đặt KPI cho mọi Sale. Teamlead đặt KPI cho Sale trong Team mình.

## Cập nhật lên website hiện tại

Bản này dùng đúng D1 hiện tại:
- Database: `an-dong-4-crm`
- ID: `637d02d5-68e7-461f-be92-bc362fb7ed9c`

Không tạo database mới.

Mở PowerShell trong thư mục V3.1 và chạy:

```powershell
npm.cmd install
```

V3.1 có migration mới để tạo bảng KPI. Chạy **một lần**:

```powershell
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
```

Nếu hỏi xác nhận, nhập `y`.

Sau đó deploy:

```powershell
npx.cmd wrangler deploy
```

Cuối cùng tải lại website bằng `Ctrl + F5` để tránh trình duyệt dùng file JavaScript cũ.

## Lưu ý
- Không chạy lại `d1 create`.
- Migration `0002_kpi_targets.sql` không xóa dữ liệu hiện tại.
- Nút xóa Data trên website mới là thao tác không hoàn tác; hãy xuất CSV trước.



---

## README_V3.2.md

- Số byte gốc: 1090
- SHA-256: `8910ff1c24e026e3fcde120c5777dd65740bbf86a0724664b96a15a4fb82157e`

# AN ĐÔNG 4 CRM – V3.2

## Thay đổi chính

- Dashboard Sale chỉ còn 4 chỉ số theo ngày: **Số cuộc gọi, Tỷ lệ kết nối, Y01, Y02**.
- Bỏ hoàn toàn bảng **Việc cần làm** khỏi Dashboard.
- **Hiệu suất theo Team** chỉ hiển thị cho Teamlead và Admin; Sale không thấy phần này.
- Bảng 7 ngày gần nhất được rút gọn còn Calls, Kết nối, Tỷ lệ, Y01, Y02.
- Bàn gọi có thêm chế độ **Gọi lại Data cũ**. Khách đã từng xử lý/trạng thái khác NEW có thể được chọn và ghi nhận thêm nhiều lần gọi mà không mất lịch sử cũ.
- Khi mở một khách cũ từ CRM và bấm **Ghi nhận cuộc gọi**, hệ thống tự chuyển sang chế độ gọi lại Data cũ nếu khách không còn ở hàng đợi thông thường.

## Cập nhật Cloudflare

Bản này **không có migration mới**. Không cần tạo lại D1 và không xóa dữ liệu.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau khi deploy, mở lại website và nhấn `Ctrl + F5`.



---

## README_V3.3.md

- Số byte gốc: 2263
- SHA-256: `655ccb820c06d49fa9e965d480ff6feb5409ed45b2472d9681f6c20e81316d0d`

# AN ĐÔNG 4 CRM – V3.3

Bản V3.3 bổ sung luồng quản lý Data theo kho trung tâm và Team động.

## Tính năng mới

- Admin tạo Team mới ngay tại **Nhân sự**.
- Bấm chip Team ở trang **Nhân sự** để chỉ hiện thành viên của Team đó.
- **Kho dữ liệu trung tâm** với 3 trạng thái:
  - Kho chờ phân (`POOL`)
  - Đang giao (`ASSIGNED`)
  - Đã gọi / lưu trữ (`ARCHIVED`)
- File Excel/CSV được đưa vào Kho trước, sau đó mới chia Data.
- Chia Data từ Kho theo 3 cách:
  - Chia đều toàn bộ Sale đang hoạt động.
  - Chia đều cho một Team.
  - Gán cho một nhân viên cụ thể.
- Khi nhân viên lưu kết quả cuộc gọi, khách tự chuyển sang **Đã gọi / lưu trữ**.
- Nhân viên vẫn có thể vào **Gọi lại Data cũ** để gọi lại khách đã lưu trữ.
- Dashboard cho phép chọn **Từ ngày – Đến ngày** thay vì cố định 7 ngày gần nhất.
- Dashboard Sale chỉ hiển thị Calls, tỷ lệ kết nối, Y01, Y02.
- Dashboard Teamlead/Admin giữ thêm hiệu suất theo Team.
- Bàn gọi của Admin đổi thành **màn hình theo dõi**: tab từng Team + chọn ngày + log cuộc gọi.

## Nâng cấp từ V3.2 / V3.1

Không tạo D1 mới. Vẫn dùng database hiện tại.

Mở PowerShell trong thư mục V3.3:

```powershell
npm.cmd install
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
npx.cmd wrangler deploy
```

Migration mới là `0003_data_warehouse.sql`, chỉ thêm trạng thái Kho vào bảng khách hàng. Không xóa nhân viên, Team, KPI hay lịch sử hiện có.

Sau deploy, mở website và nhấn **Ctrl + F5**.

## Luồng Data mới

```text
Excel / CSV
   ↓
KHO CHỜ PHÂN
   ↓
Chia toàn bộ / theo Team / 1 nhân viên
   ↓
ĐANG GIAO
   ↓
Nhân viên gọi và lưu kết quả
   ↓
ĐÃ GỌI / LƯU TRỮ
   ↓
Có thể Gọi lại Data cũ
```

## Ghi chú

- `Số lượng = 0` khi chia Data nghĩa là chia toàn bộ Data đang có trong Kho.
- Khi chọn **Chia đều toàn bộ nhân viên**, khách tự nhận Team theo Sale được phân.
- Team mới tạo sẽ tự xuất hiện trong form nhân viên, Kho Data và bộ lọc.



---

## README_V3.4.md

- Số byte gốc: 1226
- SHA-256: `dbae333923160a330e0e51fb57b8e2f3b07407831036c7d827a0172bd7ac1a86`

# AN ĐÔNG 4 CRM – V3.4

## Thay đổi chính

### 1. Đã gọi / lưu trữ
- Tab **Đã gọi / lưu trữ** trong Kho dữ liệu có bộ lọc theo **Team**.
- Có bộ lọc theo **trạng thái cuộc gọi**: Y01–Y06 và N01–N04.
- Bảng hiển thị riêng **Kho** và **Trạng thái cuộc gọi** để không nhầm trạng thái lưu trữ với kết quả telesale.

### 2. Xoá Team an toàn
- Trang **Nhân sự** có nút **Xoá Team** khi chọn một Team.
- CRM chỉ cho xoá Team khi Team không còn nhân viên hoạt động và không còn Data.
- Việc xoá Team là vô hiệu hoá Team để giữ an toàn lịch sử hệ thống.

### 3. Dashboard theo một ngày
- Chọn **một ngày** cần theo dõi.
- Sale vẫn chỉ thấy 4 chỉ số: Số cuộc gọi, Tỷ lệ kết nối, Y01, Y02.
- Admin/Teamlead thấy thêm bảng tổng hợp theo **Team → từng nhân viên**.
- Bảng có đầy đủ trạng thái: Y01, Y02, Y03, Y04, Y05, Y06, N01, N02, N03, N04.

## Cập nhật Cloudflare
V3.4 **không có migration mới**. Dùng lại D1 hiện tại.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau khi deploy, mở web và nhấn `Ctrl + F5`.



---

## README_V3.5.md

- Số byte gốc: 1085
- SHA-256: `774499340f3f96ec492949479f7b66c9c87a6b93fbd8d28892b3ea485a1a024a`

# AN ĐÔNG 4 CRM — V3.5

## Thay đổi Dashboard

- Chọn khoảng **Từ ngày → Đến ngày** thay vì chỉ chọn một ngày.
- Nút nhanh: **Hôm nay**, **7 ngày**, **Tháng này**.
- 4 KPI đầu trang tính theo đúng khoảng ngày đang chọn: Calls, tỷ lệ kết nối, Y01, Y02.
- Thêm 2 khối đo lường cố định:
  - **Tuần hiện tại** (từ thứ Hai đến hôm nay)
  - **Tháng hiện tại** (từ ngày 01 đến hôm nay)
- Admin/Teamlead không còn xổ tất cả Team dài xuống trang.
  - Tab **Tổng hợp**: mỗi Team chỉ một dòng tổng.
  - Bấm tab **Mobility 1 / Mobility 3 / ...**: mới mở chi tiết từng nhân viên của Team đó.
  - Vẫn thống kê đủ Y01–Y06 và N01–N04.
- Sale vẫn chỉ thấy KPI cá nhân và đo lường tuần/tháng; không thấy bảng Team.

## Cập nhật Cloudflare

V3.5 không thay đổi cấu trúc D1, vì vậy **không cần chạy migration**.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy, mở website và nhấn `Ctrl + F5`.



---

## README_V3.6.md

- Số byte gốc: 680
- SHA-256: `553c0738cb8378c758bfe5b05163e75a3545a6bdaccd33736f768a3a3b93ac7f`

# AN ĐÔNG 4 CRM – V3.6

## Thay đổi
- Tuần và tháng được thu gọn thành các cột nhỏ ngay dưới KPI chính.
- Thêm biểu đồ cột theo ngày cho Calls, Y01 và Y02 trong khoảng ngày đang chọn.
- Sale khi hết Data được giao sẽ thấy trạng thái **Đã gọi hết Data** ở Dashboard và Bàn gọi.
- Admin có chuông thông báo khi nhân viên Sale có 0 Data đang giao nhưng đã có Data đã gọi/lưu trữ. Thông báo tự làm mới khoảng 30 giây/lần.
- Không cần migration mới. Dùng nguyên D1 hiện tại.

## Deploy
```powershell
npm.cmd install
npx.cmd wrangler deploy
```
Sau deploy nhấn `Ctrl + F5`.



---

## README_V3.7.md

- Số byte gốc: 915
- SHA-256: `422af5865ca563d621a400135be7b6f81ce953f1a383fc1716a007c728207220`

# AN ĐÔNG 4 CRM – V3.7

## Thay đổi

- Bỏ hoàn toàn khung `Tài khoản demo` ở màn hình đăng nhập.
- Không còn điền sẵn username/password trên form đăng nhập.
- Dashboard bỏ 2 khối Tuần/Tháng luôn hiển thị.
- Thêm 3 tab: `Khoảng ngày`, `Tuần`, `Tháng`.
- Tab Khoảng ngày: biểu đồ cột theo từng ngày trong khoảng Từ ngày → Đến ngày.
- Tab Tuần: chỉ khi bấm mới hiện thống kê tuần hiện tại + biểu đồ cột theo từng ngày trong tuần.
- Tab Tháng: chỉ khi bấm mới hiện thống kê tháng hiện tại + biểu đồ cột tổng hợp theo Tuần 1, Tuần 2... trong tháng.
- Các bảng Team/nhân viên và thông báo hết Data giữ nguyên.

## Deploy

Không cần migration D1 mới.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy, bấm `Ctrl + F5` trên trình duyệt.



---

## README_V3.8.md

- Số byte gốc: 851
- SHA-256: `b6928102a1a0913475618c1b9ba1a0299c61955a43e8b3f416fcae8c044bcb8f`

# AN ĐÔNG 4 CRM – V3.8

## Thay đổi

- Đổi tên tab Dashboard từ `Khoảng ngày` thành `Ngày`.
- Chuông thông báo Admin có trạng thái `chưa đọc / đã đọc`.
- Thêm nút `Đọc tất cả` trong bảng thông báo.
- Khi bấm `Đọc tất cả`, badge đỏ và hiệu ứng nháy/rung của chuông được tắt.
- Khi có thông báo mới (nhân viên mới gọi hết Data hoặc dữ liệu cảnh báo thay đổi), chuông sẽ báo lại.
- Bấm vào từng thông báo cũng tự đánh dấu riêng thông báo đó là đã đọc.
- Trạng thái đã đọc được lưu theo tài khoản Admin trên trình duyệt, không cần migration D1.

## Deploy

Không cần migration D1 mới.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy, bấm `Ctrl + F5` trên trình duyệt.



---

## README_V3.9.md

- Số byte gốc: 2582
- SHA-256: `3a59306a0e76f649dabb0c3120354cc5394bfea207868e2612471307f1e02d10`

# AN ĐÔNG 4 CRM – V3.9

## Nâng cấp Kho quản trị

V3.9 bổ sung một mục **Kho** riêng trong nhóm **Quản trị** (chỉ Admin).

### 1. Phân loại Data

- Có sẵn `Data loại 1`, `Data loại 2`.
- Admin có thể tạo thêm phân loại.
- Có thể đổi tên hoặc xoá phân loại.
- Xoá phân loại không xoá khách hàng; Data sẽ chuyển về `Chưa phân loại`.
- Chọn nhiều Data rồi:
  - `Thêm vào phân loại`.
  - `Bỏ khỏi phân loại`.

### 2. Random lại Data đã gọi

Trong Kho quản trị:

- Chọn phân loại Data muốn tái gọi.
- Chọn toàn bộ Sale hoặc 1 Team.
- Chọn số lượng.
- Chọn số ngày được phép gọi.
- Bấm `Random lại cho nhân viên khác`.

Hệ thống ưu tiên không giao lại khách cho đúng nhân viên vừa gọi ở vòng trước (nếu còn nhân viên khác phù hợp).

Mỗi lần tái phân phối sẽ tăng `Vòng gọi` để đo hiệu quả vòng 1, vòng 2, vòng 3...

### 3. Deadline

Khi chia Data từ **Dữ liệu** hoặc random lại từ **Kho**, Admin đặt `Thời hạn gọi (ngày)`.

- Trong thời hạn: Data nằm trong tài khoản Sale.
- Sale gọi xong: Data chuyển sang `Đã gọi / lưu trữ`.
- Quá deadline mà chưa gọi: Data tự rời khỏi tài khoản Sale và quay về `Kho chờ phân`.
- Cron Cloudflare chạy mỗi giờ để thu hồi tự động.
- Admin cũng có nút `Thu hồi Data hết hạn` để chạy ngay.

### 4. Đo lường chất lượng Data

Kho quản trị có 2 bảng:

- **Đo lường chất lượng Data**: tổng Data, đang giao, đã gọi, Calls, tỷ lệ kết nối, Y01, Y02, vòng gọi cao nhất.
- **Hiệu quả theo vòng gọi**: so sánh từng phân loại theo Vòng 1 / Vòng 2 / Vòng 3..., số Data đã giao, Calls, tỷ lệ kết nối, Y01, Y02 và số Data hết hạn trả Kho.

## Cập nhật Cloudflare

V3.9 có migration mới nên cần chạy **1 lần**:

```powershell
npm.cmd install
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
npx.cmd wrangler deploy
```

Nếu Cloudflare API timeout, chạy lại sau hoặc đổi mạng như các lần trước.

Sau deploy, mở website và nhấn `Ctrl + F5`.

## Migration mới

`migrations/0004_data_categories_deadlines.sql`

Migration chỉ bổ sung:

- bảng `data_categories`
- bảng `assignment_history`
- các trường phân loại / deadline / vòng gọi trong `customers`

Không xoá Data, user, Team, KPI hay lịch sử cuộc gọi hiện có.



---

## README_V4.0.md

- Số byte gốc: 1259
- SHA-256: `41faba47e42577c2cb6af7c7009a8ac08466a03a9d0ccec6b4ed5e397fb6b5b7`

# AN ĐÔNG 4 CRM V4.0 — Mobile UX

Bản V4.0 tối ưu giao diện mobile nhưng giữ nguyên dữ liệu và backend V3.9.

## Thay đổi mobile
- Menu trái thành drawer trượt, có nút ☰ và lớp nền đóng menu.
- Thanh điều hướng nhanh cố định dưới màn hình.
- KPI tự xếp 2 cột; nút và form đạt kích thước chạm dễ dùng.
- Input/select/textarea dùng font 16px để tránh trình duyệt mobile tự zoom.
- Bảng lớn cuộn ngang mượt và có gợi ý “Vuốt ngang để xem thêm”.
- Bàn gọi chuyển 1 cột, hàng đợi gọn, nút lưu kết quả bám gần đáy màn hình.
- Popup/hồ sơ khách chuyển dạng gần full-screen trên điện thoại.
- Team tabs, category tabs, dashboard tabs cuộn ngang thay vì xuống nhiều dòng.
- Kho Data hiển thị 3 KPI trên một hàng để giảm chiều dài màn hình.
- Notification panel và toast vừa chiều rộng điện thoại.
- Hỗ trợ safe-area cho iPhone.

## Cập nhật Cloudflare
Không cần migration mới.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy: `Ctrl + F5` trên desktop; trên mobile đóng tab/mở lại hoặc refresh mạnh nếu trình duyệt còn cache.



---

## README_V4.1.md

- Số byte gốc: 1788
- SHA-256: `65c5d468717956f3ad78a35d820e0f4c27ec6ce8644402cc6766a1bfbe55e794`

# AN ĐÔNG 4 CRM – V4.1

## Phân quyền giao diện và dữ liệu theo vai trò

### Sale
- CRM Data chỉ hiển thị Data/cuộc gọi của chính tài khoản đang đăng nhập.
- Không có bộ lọc Team hoặc Nhân viên.
- Không có nút Chia Data / Import / Kho / Nhân sự / Cài đặt.
- Bàn gọi chỉ dành cho Data được giao cho chính Sale.
- Có thể xem hồ sơ, lịch sử và ghi nhận cuộc gọi của chính mình.

### Teamlead
- CRM Data chỉ hiển thị khách/cuộc gọi thuộc Team của Teamlead.
- Không có mục Dữ liệu, Kho hoặc Cài đặt.
- Bàn gọi chuyển thành màn hình theo dõi cuộc gọi của Team theo ngày, không phải bàn gọi cá nhân.
- Nhân sự chỉ hiển thị thành viên Team của mình.
- Teamlead chỉ được thêm Sale mới vào Team mình và xoá Sale thuộc Team mình.
- Teamlead không được tạo/xoá Team, đổi Team, tạo Admin/Teamlead khác hoặc sửa tài khoản nhân viên.
- Khi Teamlead xoá Sale, Data đang giao cho Sale đó được trả về Kho chờ phân và giữ Team cũ để Admin chia lại.

### Admin
- Giữ toàn bộ quyền hiện tại: Dữ liệu, Kho, chia Data, quản lý Team, nhân sự, cài đặt và theo dõi tất cả Team.

## Backend
Quyền được kiểm tra ở cả giao diện và API. Teamlead/Sale không thể gọi trực tiếp API quản trị để Import, chia Kho, xoá Data hoặc sửa khách ngoài quyền của mình.

## Deploy
V4.1 không thay đổi schema D1, nên không cần chạy migration.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau khi deploy, nhấn `Ctrl + F5` trên máy tính hoặc đóng/mở lại tab trên điện thoại để tải JS/CSS mới.



---

## README_V4.2.md

- Số byte gốc: 1409
- SHA-256: `70ca95de93dea7a3278e511846ea747c65d43e952cf462084d12d0606eac87b2`

# AN ĐÔNG 4 CRM – V4.2

## Thay đổi theo yêu cầu

### 1. Bỏ Mã KH khỏi giao diện
- Không còn hiển thị cột **Mã KH** tại CRM Data, Kho dữ liệu, Kho quản trị, màn hình theo dõi cuộc gọi, bàn gọi và bản xem trước import.
- Tìm kiếm không còn dựa trên Mã KH.
- File CSV xuất ra cũng bỏ cột Mã KH.
- Cột `customer_code` trong D1 vẫn được giữ nội bộ để tương thích dữ liệu cũ; không cần migration và không hiển thị cho người dùng.

### 2. Đặt tên Nguồn khi đẩy Data vào Kho
Trong **Dữ liệu → Nhập Data vào Kho** có thêm ô **Tên nguồn Data**.

Quy trình mới:
1. Nhập tên nguồn, ví dụ `FLC 06/10`, `CTV Facebook`, `LNL Tháng 10`.
2. Chọn file Excel/CSV.
3. Bấm **Đọc & kiểm tra**.
4. Bản xem trước hiển thị nguồn vừa đặt cho toàn bộ Data.
5. Bấm **Đẩy vào Kho**.

Toàn bộ khách của lần import được gắn cùng tên nguồn. Nguồn trong file Excel/CSV (nếu có) không ghi đè tên nguồn đã nhập ở màn hình Kho.

Backend cũng kiểm tra `source_name`, nên import vào Kho không thể thiếu tên nguồn.

## Deploy
V4.2 không thay đổi schema D1, không cần chạy migration.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau khi deploy, nhấn `Ctrl + F5` để tải lại JS/CSS mới.



---

## README_V4.3.md

- Số byte gốc: 569
- SHA-256: `b108fa4c42861c41206b6dc3a7300423d4394e0a7e0ef4ddbdc8011c6b14bf91`

# AN ĐÔNG 4 CRM – V4.3

## Sửa lỗi import Excel

- Nhận diện thêm cột tên: `Tên`, `Họ tên`, `Họ và tên`, `Tên KH`, `Tên khách hàng`, `Khách hàng`, `Full Name`, `Customer Name`.
- Nhận diện thêm cột SĐT: `SĐT`, `Số ĐT`, `SĐT KH`, `Phone`, `Mobile`...
- Tự khôi phục số 0 đầu của số di động Việt Nam khi Excel lưu cột SĐT dạng Number.
- Chuẩn hóa SĐT cũ khi đối chiếu import để hạn chế tạo trùng nếu trước đó dữ liệu bị mất số 0 đầu.
- Không cần migration D1.



---

## README_V4.4.md

- Số byte gốc: 969
- SHA-256: `88c36a9bd0f7afb2804167de3944dbcfaa53c9239119a7b050bbec87f51900c5`

# An Đông 4 CRM V4.4

## Phân Data cho Teamlead

- Teamlead có thêm mục **Dữ liệu** để chia Data thuộc Team của mình.
- Teamlead chỉ thấy Data có `team_id` trùng Team đang đăng nhập.
- Có thể **chia đều toàn bộ Sale trong Team** hoặc **gán Data cho một Sale cụ thể**.
- Có thể chọn số lượng Data và thời hạn gọi.
- Backend kiểm tra quyền độc lập: Teamlead không thể giao Data cho nhân viên Team khác, kể cả khi sửa request thủ công.
- Hiển thị tải Data hiện tại theo từng thành viên: số Data đang giao và đã gọi/lưu trữ.
- Trong CRM của Teamlead có nút **Chia Data Team** để mở nhanh trang phân Data.

## Luồng đề xuất

1. Admin nhập Data vào Kho.
2. Admin dùng **Chia Data về Team** trong CRM để đưa Data chưa phân về các Team.
3. Teamlead đăng nhập → **Dữ liệu** → chia Data cho Sale trong Team của mình.



---

## README_V4.5.md

- Số byte gốc: 1244
- SHA-256: `99720cc00b78cf8cea82a11875888886b7961ea170890ce5427a404be19b54da`

# An Đông 4 CRM V4.5

## Chi tiết cuộc gọi cho Admin và Teamlead

- Đổi mục **CRM Data** thành **Chi tiết cuộc gọi** đối với tài khoản Admin và Teamlead.
- Tài khoản Sale vẫn giữ trang **CRM Data** như trước.
- Admin có thể xem tất cả Team hoặc lọc từng Team.
- Teamlead chỉ xem được Team của mình.
- Có bộ chọn ngày, nút ngày trước / ngày sau / hôm nay.
- Thêm bảng **Tổng hợp theo nhân viên** gồm:
  - Tổng số cuộc gọi.
  - Tỷ lệ kết nối.
  - Số lượng từng trạng thái Y01, Y02, Y03, Y04, Y05, Y06.
  - Số lượng từng trạng thái N01, N02, N03, N04.
- Nhân viên chưa phát sinh cuộc gọi vẫn được hiển thị với số 0 để Teamlead/Admin dễ theo dõi.
- Bấm vào tên/dòng nhân viên để lọc phần **Chi tiết từng cuộc gọi** bên dưới.
- Chi tiết cuộc gọi hiển thị thời gian, Team, nhân viên, khách hàng, SĐT, trạng thái và ghi chú.
- Không thay đổi database và không cần chạy migration mới.

## Deploy

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau khi deploy, nhấn Ctrl + F5 để trình duyệt tải lại giao diện mới.



---

## README_V4.6.md

- Số byte gốc: 664
- SHA-256: `a4358d8c905c98750a85062bcea1100115bbf2014cd934c43ce17cc4058aa3ee`

# An Đông 4 CRM V4.6

## Thay đổi
- Ẩn mục **Bàn gọi** đối với Admin và Teamlead; tài khoản Sale vẫn giữ Bàn gọi để thao tác gọi.
- Thêm KPI **Y02** kế bên Y01 trong trang **Chi tiết cuộc gọi**.
- Cho phép Admin/Teamlead bấm trực tiếp vào số trạng thái (Y01, Y02, Y03, ... N01, N02, ...) của từng nhân viên để lọc đúng các cuộc gọi đó.
- Sau khi bấm trạng thái, giao diện tự cuộn xuống danh sách chi tiết cuộc gọi tương ứng.
- Có nút **Bỏ lọc trạng thái** và **Xem tất cả nhân viên**.
- Không thay đổi schema D1, không cần migration mới.



---

## README_V4.7.md

- Số byte gốc: 851
- SHA-256: `3a8d47cce68c2607ca004cf959739a7bfd7fee093de509e2fdf39adaa6a29007`

# An Đông 4 CRM — V4.7

## KPI
- Bỏ mục KPI “Khách xử lý / ngày”. KPI còn 3 mục: Calls/ngày, Tỷ lệ kết nối mục tiêu, Y01/ngày.
- Admin và Teamlead có nút **Đặt KPI hàng loạt**, chọn nhiều Sale và áp cùng một bộ KPI. Teamlead chỉ áp được cho Sale trong Team của mình.
- Sale được cảnh báo bằng chuông nếu **ngày đã kết thúc (ngày hôm trước)** mà không đạt một hoặc nhiều mục KPI. Bấm cảnh báo sẽ mở đúng ngày KPI.
- Khi Sale xem một ngày đã kết thúc và chưa đạt KPI, trang KPI hiển thị banner cảnh báo cùng các mục còn thiếu.

## Database
Không có migration mới. Cột `processed_daily` cũ vẫn được giữ trong D1 để tương thích dữ liệu cũ nhưng không còn được dùng để chấm KPI.



---

## README_V4.8.md

- Số byte gốc: 1230
- SHA-256: `7b477c125a2b076de7727d3439f43c6cc00a9a18f26efaaee6a090c059cf7bc4`

# An Đông 4 CRM — V4.8

## KHTN tích hợp trực tiếp vào CRM

- Sale: chỉ thấy biểu mẫu nhập KHTN. Nhân viên/Team được lấy tự động từ tài khoản đăng nhập.
- Admin: xem toàn bộ KHTN, lọc, sửa, xuất Excel.
- Teamlead: chỉ xem/sửa/xuất KHTN của Team mình.
- Admin/Teamlead: có thể cấu hình biểu mẫu KHTN (đổi nhãn, bật/tắt trường, bắt buộc/không bắt buộc và danh sách Nguồn KHTN).
- Dữ liệu KHTN lưu riêng trong D1, không ảnh hưởng CRM/call logs hiện có.

### Trường mặc định
1. Họ và tên khách hàng (bắt buộc)
2. Số điện thoại (bắt buộc)
3. Năm sinh
4. Khu vực sinh sống
5. Nghề nghiệp
6. Thu nhập trung bình
7. CCCD
8. Nguồn KHTN (bắt buộc)
9. Ghi chú
10. Dự kiến login

Nhân viên được ghi tự động theo tài khoản đăng nhập.

## Nâng cấp database

V4.8 có migration mới `0005_khtn.sql`. Chạy một lần trước/sau deploy:

```powershell
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
```

Migration chỉ **tạo bảng mới**, không xóa/chỉnh sửa khách hàng, nhân viên, KPI hay lịch sử cuộc gọi hiện tại.



---

## README_V4.9.md

- Số byte gốc: 1000
- SHA-256: `13fb4631d3a743a5c5daa9b250f0bad2a27c68c04b82ad09ca581c3a904f5d26`

# An Đông 4 CRM V4.9

## Sửa lỗi / cải tiến
- Sửa lỗi ô tìm kiếm CRM mất focus sau khi gõ ký tự đầu tiên.
- Bàn gọi: khung thông tin khách bên phải bám theo khi cuộn danh sách khách trên desktop.
- Dashboard/KPI/Chi tiết cuộc gọi: Y01, Y02, Y03… được tính theo trạng thái mới nhất của mỗi KH trong ngày, vì vậy KH đã chuyển Y01 sang Y03 sẽ không còn nằm ở Y01.
- Sửa nhanh trạng thái cuộc gọi: nếu nhân viên vừa lưu một khách rồi vào Data cũ đổi trạng thái trong vòng 5 phút, hệ thống cập nhật lại call log gần nhất thay vì tạo thêm một call mới. Điều này tránh tình trạng vừa sửa Y01 sang Y03 nhưng Y01 vẫn còn bị tính.
- Sau 5 phút, thao tác trên Data cũ được tính là một lần gọi lại mới để giữ đúng lịch sử thực tế.

## Database
Không có migration mới. Không xóa hoặc reset dữ liệu hiện tại.



---

## README_V5.0.md

- Số byte gốc: 1467
- SHA-256: `72663e53c3b42329cd649982ca3b8f4fd11e83402ef7ff8ae3651e82e73c16c7`

# An Đông 4 CRM V5.0

## KHTN Form Builder

- Sửa lỗi `D1_ERROR: no such table: khtn_form_config` bằng cơ chế tự kiểm tra/tự tạo bảng KHTN khi API KHTN được gọi.
- Admin và Teamlead có thể thêm trường KHTN mới, đổi tên, chọn kiểu dữ liệu, đặt bắt buộc và xóa trường.
- 3 trường cốt lõi (Họ tên khách hàng, SĐT, Nguồn KHTN) không thể xóa.
- Kiểu trường tự tạo: chữ ngắn, số, ngày, nội dung dài, danh sách chọn.
- Trường dạng danh sách chọn cho phép cấu hình các lựa chọn.
- Dữ liệu của trường tự tạo được lưu dưới dạng JSON trong `khtn_entries.custom_json` để không cần tạo cột D1 mới mỗi khi thêm trường.
- Khi xóa trường tự tạo, dữ liệu lịch sử không bị xóa; trường chỉ không còn hiển thị trên form/báo cáo hiện tại.
- Xuất Excel và bảng quản trị tự động bao gồm các trường KHTN đang hoạt động.
- Tìm kiếm KHTN cũng tìm trong dữ liệu của trường tự tạo.

## Deploy

V5.0 có thể tự sửa schema KHTN khi chạy. Chỉ cần:

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Nếu muốn đồng bộ migration chính thức trên D1, có thể chạy trước deploy:

```powershell
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
```

Các lệnh trên không xóa dữ liệu CRM/KHTN hiện có.



---

## README_V5.1.md

- Số byte gốc: 1419
- SHA-256: `366f2bc4ac43cd0484f94b7ec8a187b5fa2855fcd6efd03ca344b34eba628369`

# An Đông 4 CRM – V5.1

## Thay đổi
- KHTN: Admin xóa mọi báo cáo; Teamlead chỉ xóa KHTN thuộc Team của mình. Xóa có hộp xác nhận và ghi audit log. Sale không có quyền xóa.
- Báo cáo đầu ngày: Sale nhập danh sách khách dự kiến login app (Tên KH, CCCD/CMND) và danh sách khách hẹn ký (Tên KH, giờ hẹn ký, số tiền dự kiến VNĐ); có nút thêm/xóa dòng, tự đếm số khách.
- Mỗi nhân viên lưu 1 báo cáo/ngày, có thể cập nhật trong cùng ngày, không trùng báo cáo. Giờ tính ngày theo giờ Việt Nam (UTC+7).
- Admin xem toàn bộ, Teamlead chỉ xem báo cáo Team mình; bộ lọc ngày/Team/nhân viên/tên KH, bảng tổng hợp và xuất Excel 3 sheet (Tổng hợp, Khách login, Khách hẹn ký).

## Deploy AN TOÀN
1. Backup D1 trên account đang sử dụng: `npx.cmd wrangler d1 export an-dong-4-crm --remote --output=backup-truoc-v5.1.sql`
2. Kiểm tra `wrangler.jsonc` dùng ĐÚNG `database_id` của D1 đang chứa Data nhân viên thực tế.
3. Chạy `npm.cmd install`.
4. **Bắt buộc chạy migration mới**: `npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote` (có `0007_daily_reports.sql` tạo bảng mới, không xóa bảng cũ).
5. Chạy `npx.cmd wrangler deploy`, rồi Ctrl + F5.

Không chạy `db reset`, không xóa database, không tạo D1 khác khi nâng cấp.



---

## README_V5.2.md

- Số byte gốc: 1805
- SHA-256: `76a4663a5271440f4c96b99604ea6c482b88bd9e39b3ed7ddaf7e16fdb0e5844`

# An Đông 4 CRM V5.2 — Kho Random thuận tiện & xuất Excel lịch sử gọi

## Thay đổi
- Kho (Admin): khung **Random lại Data đã gọi** và **Đo lường chất lượng Data** nằm phía trên danh sách Data dài. Có nút **🎲 Random lại Data** ở đầu trang để di chuyển trực tiếp tới khu vực.
- Chi tiết cuộc gọi (Admin/Teamlead): thêm **Xuất Excel** ở thanh công cụ và bảng chi tiết, thêm nút **⬇ Excel** trong từng dòng nhân viên.
- Hộp thoại xuất: chọn từ ngày/đến ngày, nhân viên (hoặc tất cả trong Team), trạng thái gọi.
- Xuất `.xlsx` gồm sheet **Tổng hợp** và sheet **riêng từng nhân viên** nếu chọn tất cả; lưu đầy đủ từng lượt gọi, tên khách, SĐT dạng text (giữ số 0), nguồn, kết quả, ghi chú, lịch hẹn.
- API xuất riêng `/api/calls/export`: chỉ Admin/Teamlead, kiểm tra Team ở server, phân trang để không bị giới hạn 10.000 lượt gọi của dashboard.

## Nâng cấp

1. Sao lưu D1 trước khi deploy (dùng đúng `database_id` của hệ thống đang chạy).
2. `npm.cmd install`
3. `npx.cmd wrangler deploy`
4. Ctrl+F5 trình duyệt.

**Không có migration mới.** Không xóa lịch sử, nhân viên hay dữ liệu hiện có. Thư viện SheetJS vẫn tải từ CDN (yêu cầu máy có Internet để xuất `.xlsx`).

**Lưu ý:** File xuất theo lịch sử *lượt gọi*. Nếu một khách được gọi nhiều lần, các lần gọi sẽ là các dòng riêng; thống kê trạng thái trong sheet Tổng hợp cũng tính số lượt, không phải số khách ở trạng thái mới nhất. Nếu trên 50.000 cuộc gọi trong một lần xuất, hãy thu hẹp khoảng ngày.



---

## README_V5.3.md

- Số byte gốc: 1703
- SHA-256: `6820b74c28db993bf9f7a3d0da25468a1277b7372a1d6ad13b8344e168e40343`

# CRM An Đông 4 – V5.3

1. **Thu hồi Data đã giao** trong trang Dữ liệu: trả về Kho, giữ nguyên khách hàng, thông tin nguồn, trạng thái, phân loại và toàn bộ lịch sử cuộc gọi; chỉ gỡ người phụ trách và deadline, ghi nhận lịch sử phân công. Không xóa dữ liệu thật.
2. **Lọc trùng Data trước khi import:** chọn Excel, bấm Đọc & kiểm tra để đối chiếu SĐT chuẩn hóa (84/0 và thiếu 0) với toàn bộ Kho, Data đã giao, Data đã gọi và các dòng ngay trong file. Hiển thị số mới / trùng / thiếu SĐT và có nút xuất Excel các dòng bị lọc. Chỉ import các dòng mới, backend cũng tự bỏ qua trùng nên không ghi đè khách cũ.
3. **Giờ cuộc gọi:** chuyển chính xác timestamp SQLite UTC sang giờ Việt Nam UTC+7 trong lịch sử, Dashboard, báo cáo Excel, lọc theo ngày; khi Sale sửa trạng thái trong 5 phút, thời điểm của dòng ghi nhận được cập nhật theo lần sửa đó.

## Deploy
Trước khi deploy **sao lưu D1** và kiểm tra `database_id` trong wrangler.jsonc trùng database đang dùng.
```powershell
npm.cmd install
npx.cmd wrangler d1 export an-dong-4-crm --remote --output=backup-truoc-v5.3.sql
npx.cmd wrangler deploy
```
Không cần migration mới.
**Lưu ý:** Việc trả Data về Kho sẽ khiến Sale không còn truy cập được những khách đó cho tới khi Admin/Teamlead chia lại. Các lượt gọi trước vẫn nằm trong call_logs để Admin theo dõi. Không thể phục hồi timestamp đúng của các cuộc gọi lịch sử nếu nguồn timestamp ban đầu đã ghi sai.



---

## README_V5.4.md

- Số byte gốc: 3300
- SHA-256: `424e2d86c21b098d9359bc935f24e9f702d7ce61528f33f57a5eff2b47c35808`

# CRM An Đông 4 V5.4 — Tối ưu D1 (Rows read/Rows written)

Giữ các tính năng của V5.3. Thay đổi chính:

- Thêm migration `0008_d1_read_optimization.sql`: chỉ tạo 5 chỉ mục, **không thay đổi/xóa** khách hàng, cuộc gọi, KPI, nhân viên, KHTN.
- Khi Sale lưu một cuộc gọi, API trả về chính bản ghi đã lưu và trạng thái khách để giao diện cập nhật tức thì, thay vì tải lại toàn bộ D1 sau mỗi cuộc gọi.
- Khi sửa thông tin khách, trang Sale chỉ đồng bộ khách và cuộc gọi. Không chạy lại các truy vấn KHTN, KPI, nhân sự, báo cáo đầu ngày và thống kê Kho mỗi lần lưu.
- Nhân viên được đồng bộ nhẹ mỗi khoảng 10 phút khi đang dùng web để nhận dữ liệu mới do Admin phân; tránh làm mất dữ liệu đang gõ trong form bàn gọi.
- Thông báo hết Data của Admin đổi từ kiểm tra mỗi 30 giây sang mỗi 5 phút; không gọi nền nếu tab bị ẩn, cập nhật khi quay lại tab nếu dữ liệu cũ.
- Báo cáo thống kê Kho chỉ tải ở lần đồng bộ đầu hoặc khi đang ở mục Kho; không tính lại ở mỗi lần thay đổi cuộc gọi ở các trang khác.
- Truy vấn đối chiếu số điện thoại và import Excel kiểm tra bằng chỉ mục theo từng nhóm nhỏ, thay vì quét toàn bộ khách trong mỗi batch.
- Truy vấn trả Data hết hạn không bọc hàm `date()` quanh cột đã có chỉ mục.

## Cách triển khai

1. Sao lưu D1 từ **đúng tài khoản Cloudflare** và kiểm tra `database_id` trong `wrangler.jsonc`. Nếu ID không trùng với database CRM đang sử dụng, sửa trước khi tiếp tục.
2. `npm.cmd install`
3. `npx.cmd wrangler d1 export an-dong-4-crm --remote --output=backup-truoc-v5.4.sql`
4. `npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote` (sẽ chạy migration 0008 một lần)
5. `npx.cmd wrangler deploy`
6. Ctrl + F5.

**Chú ý**: Tạo chỉ mục ban đầu tốn một lượng rows written để xây index; lượng ghi khi cập nhật các cột có index cũng tăng nhẹ. Không bảo đảm không bao giờ chạm quota nếu dữ liệu và người dùng tăng nhiều. Nếu bị chặn bởi quota hiện tại, chờ reset hoặc cân nhắc Paid; không sử dụng D1 ở chế độ demo để ghi dữ liệu thật.

## Kiểm tra sau deploy

Trong Cloudflare D1 > Metrics, xem Rows read / Rows written theo ngày và so sánh trong các khoảng thời gian có số nhân viên / cuộc gọi tương tự nhau. Đừng so sánh ngày có số lượng hoạt động khác nhau.

D1 Console (SELECT chỉ đọc):

```sql
EXPLAIN QUERY PLAN SELECT id FROM customers WHERE data_state='ASSIGNED' AND assignment_deadline < date('now');
EXPLAIN QUERY PLAN SELECT id FROM call_logs WHERE customer_id=1 AND user_id=1 ORDER BY created_at DESC LIMIT 1;
```

Các kế hoạch nên cho biết `USING INDEX idx_customers_state_deadline` và `USING ... idx_calls_customer_user_created` thay vì `SCAN ...`.

Cloudflare Free vẫn có hạn mức cứng; V5.4 tối ưu nhưng không thể bảo đảm ở dưới 5M/100K nếu lượng người dùng hoặc dữ liệu vượt dự báo.



---

## README_V5.5.md

- Số byte gốc: 2041
- SHA-256: `53c1522764df4f59f17718c279d26d3cb02f9b74398d0973f650d4d6994e8980`

# An Đông 4 CRM V5.5 — KPI 2 mục tiêu và lọc trạng thái trong Kho

Nâng cấp từ V5.4, giữ các tính năng và phân quyền khác.

## KPI
- Bỏ chỉ tiêu Kết nối khỏi riêng KPI (không ảnh hưởng tỷ lệ kết nối trong Dashboard hoặc các thống kê cuộc gọi khác).
- KPI còn 2 mục tiêu: số Calls/ngày và số khách Y01/ngày.
- Admin/Teamlead đặt KPI đơn lẻ hoặc hàng loạt chỉ bằng hai ô; cảnh báo nhân viên hôm trước chỉ liệt kê hai mục này. Kết quả đổi thành 0/2, 1/2, 2/2.
- Database vẫn giữ cột `connect_rate_target` cũ vì lý do tương thích, nhưng KPI không còn đọc hoặc xét chỉ tiêu này. Không cần migration mới.

## Kho quản trị
- Trong **Thêm / xoá Data khỏi phân loại** thêm dropdown **Trạng thái cuộc gọi** (NEW, Y01–Y06, N01–N04) và các nút lọc nhanh với số lượng hiện có.
- Lọc theo trạng thái **mới nhất** của khách; kết hợp với phân loại, trạng thái kho, tên/SĐT/nguồn/nhân viên.
- Có thể chọn từng khách hoặc chọn tất cả kết quả đang lọc (tối đa 2.000 mỗi lần), sau đó đưa vào phân loại mới hoặc hiện có. Có hộp xác nhận trước khi phân loại.
- Đổi phân loại không thu hồi khách đang được giao, không đổi trạng thái gọi và không xóa khách/lịch sử.
- Thay bộ lọc sẽ xóa danh sách checkbox đã chọn để tránh vô tình phân loại khách ngoài kết quả.
- Chỉ Admin được quản lý phân loại như quyền trước đây.

## Triển khai
1. Đối chiếu đúng account Cloudflare, Worker và `database_id` trong wrangler.jsonc với D1 đang dùng. Sao lưu D1 trước khi cập nhật.
2. npm.cmd install
3. npx.cmd wrangler deploy
4. Ctrl+F5

Không có migration mới so với V5.4. Nếu bạn vẫn chưa áp dụng migration 0008 của V5.4, nên kiểm tra và áp dụng trước khi triển khai V5.5.



---

## README_V5.6.md

- Số byte gốc: 1941
- SHA-256: `557f10b06da946ffd83f78ac36824649cfb715e42035bdb738450704f15c75ff`

# CRM An Đông 4 V5.6 — Chuyển Data giữa nhân viên

- **Admin:** Kho → Chuyển Data giữa nhân viên. Chọn nhân viên nguồn, trạng thái Y01–N04/NEW, nhân viên nhận, số lượng (0 = toàn bộ, tối đa 500), hạn gọi. Chỉ chuyển giữa nhân viên trong cùng Team để tránh đổi số liệu Team của lịch sử cuộc gọi.
- **Teamlead:** Dữ liệu → Chuyển Data giữa nhân viên. Chỉ chuyển giữa nhân viên thuộc chính Team mình; kiểm tra phân quyền ở server.
- Data `ASSIGNED` hoặc `ARCHIVED` của nhân viên nguồn mới đủ điều kiện chuyển. Server luôn kiểm tra trạng thái thật của từng Data; khách thay đổi trạng thái hoặc đã bị chuyển không được đưa vào.
- Giữ nguyên **status** (VD N02), `call_logs`, tên/SĐT, nguồn, phân loại, ghi chú và Data trong Kho. Gán nhân viên nhận, `data_state='ASSIGNED'` để vào **Hàng đợi**, bắt đầu vòng giao mới, đặt hạn gọi mới.
- Chỉ ghi lại lịch sử **phân công** (`assignment_history`, `audit_logs`); lịch sử cuộc gọi của Quỳnh vẫn thuộc Quỳnh và cuộc gọi sau được ghi cho người nhận.
- Không thêm bảng / migration; kế thừa indexes & tối ưu D1 của V5.4/V5.5.

## Nâng cấp

1. Sao lưu D1 của website đang dùng. Kiểm tra `wrangler.jsonc` → `database_id` trùng database đang có data trước khi deploy.
2. `npm.cmd install`
3. `npx.cmd wrangler deploy`
4. `Ctrl + F5` sau deploy. Nếu chưa chạy migration 0008 của V5.4, hãy áp dụng migrations trước.

**Lưu ý:** số lượng tối đa 500 khách mỗi thao tác để tránh tạo quá nhiều hàng ghi D1. Với khách N02 đã được gọi, trạng thái vẫn là N02 trong hồ sơ, nhưng có mặt trong hàng đợi người nhận để gọi lại. Không xóa dữ liệu khi chuyển.



---

## README_V5.7.md

- Số byte gốc: 3995
- SHA-256: `13f06ace697aa511641e2c08fee9861c54060d866368ed858fca1638ae4c1583`

# CRM An Đông 4 V5.7 — Kho dễ theo dõi, Data chưa gọi theo nhân viên

## Cải tiến giao diện Kho (Admin)

Thay trang Kho dài và khó tìm chức năng bằng 4 tab:

1. **Tổng quan**: tổng Data còn phải gọi, Data `NEW`, Data được chuyển để gọi lại (`Yxx/Nxx`), số nhân viên còn Data; bảng tổng hợp theo nhân viên; tìm tên và lọc Team; bấm **Xem khách** để xem chi tiết Data đang chờ gọi theo từng nhân viên (100 dòng/trang).
2. **Chuyển Data**: giữ nguyên chuyển trực tiếp giữa nhân viên cùng Team; không mất lịch sử gọi.
3. **Phân loại & danh sách**: nhóm phân loại, lọc Y01–N04, chọn hàng loạt và cập nhật phân loại. Danh sách tối đa 500 dòng hiển thị; không nằm trên các chức năng khác.
4. **Random & thống kê**: random lại Data đã gọi, đo chất lượng Data và hiệu quả theo vòng.

Tài khoản Teamlead có thêm bảng **Data chưa gọi theo nhân viên** trong mục **Dữ liệu**, chỉ trong Team của mình. Sale không có quyền xem các thống kê này.

## Quy ước đếm đúng Data còn phải gọi

Chỉ tính Data đang được giao (`customers.data_state='ASSIGNED'`) — tức vẫn đang chờ xử lý trong lần giao hiện tại:

- **Data mới (NEW)**: trạng thái hiện tại là `NEW`, chưa ghi cuộc gọi trong lần giao này.
- **Được giao gọi lại**: đang `ASSIGNED` nhưng trạng thái trước đó là Yxx hoặc Nxx, ví dụ khách N02 của Quỳnh đã chuyển sang nhân viên khác.
- **Còn phải gọi**: tổng của hai nhóm trên. Khách đã gọi và lưu trữ (`ARCHIVED`) không bị tính là chưa gọi. Data chưa chia (`POOL`) không tính cho nhân viên.

Dữ liệu lấy từ D1 với API `/api/warehouse/staff-pending` (phân quyền Admin / Teamlead), chi tiết `/api/warehouse/staff-pending/:userId` có phân trang và lọc nhóm. Thống kê được lưu tạm ở trình duyệt tối đa 2 phút; nhấn **Làm mới** khi cần số liệu mới ngay.

## Hiệu suất / D1

- Không tạo bảng và không có migration mới so với V5.6.
- Báo cáo chờ gọi dùng một truy vấn `GROUP BY` và chỉ mục `idx_customers_owner` sẵn có.
- Không tải toàn bộ lịch sử gọi để tính số Data chưa gọi.
- Thống kê nặng (đo chất lượng/vòng gọi) chỉ truy vấn khi vào tab **Random & thống kê**, cache 2 phút; có xử lý lỗi để không lặp vô hạn.
- Giữ các tối ưu từ V5.4–V5.6.

## Cập nhật Cloudflare

> **Quan trọng:** Trước khi deploy, kiểm tra `wrangler.jsonc` có đúng `database_id` của D1 đang lưu Data và đúng Worker/account Cloudflare hiện tại. Tuyệt đối không tạo database mới nếu muốn giữ dữ liệu đang sử dụng.

PowerShell tại thư mục V5.7:

```powershell
npm.cmd install
npx.cmd wrangler d1 export an-dong-4-crm --remote --output=backup-truoc-v5.7.sql
npx.cmd wrangler deploy
```

Không cần chạy migration thêm **nếu database đang ở V5.6 và các migration trước đã áp dụng**. Sau khi deploy nhấn `Ctrl + F5`.

## Kiểm tra sau deploy

1. Đăng nhập Admin → **Kho**. Mặc định mở tab **Tổng quan**.
2. Thử tìm một Sale có Data đang giao. Xem số **Data mới**, **Gọi lại**, **Còn phải gọi**.
3. Bấm **Xem khách**, thử lọc Data mới/gọi lại, qua trang tiếp theo nếu có hơn 100 khách.
4. Thử chuyển 1 khách N02 sang một Sale khác cùng Team: thống kê người nhận tăng 1, người giao giảm 1; lịch sử cuộc gọi cũ vẫn giữ.
5. Đăng nhập Teamlead → **Dữ liệu**, kiểm tra chỉ xem được nhân viên trong Team.

Đây là bản xây dựng/kiểm tra với database mẫu và trình duyệt thử nghiệm; chưa deploy hoặc đọc dữ liệu thật trên Cloudflare của bạn.



---

## README_V5.8.md

- Số byte gốc: 963
- SHA-256: `3d17634e54498dd9dd69640bfa33e47c5c7531e60ae7af97f1a88508bad35722`

# V5.8 — Dashboard Tổng Modern SaaS

- Thiết kế lại Dashboard Tổng theo phong cách SaaS/CRM sáng, thoáng và dễ đọc.
- Sidebar 240px với thương hiệu An Đông 4, nền plum trên desktop Dashboard.
- 6 KPI cards: Calls, tỷ lệ kết nối, Y01, Y02, không liên hệ được, Y03.
- Hiển thị xu hướng so với kỳ trước cùng độ dài.
- Biểu đồ kết hợp: Calls dạng cột; Kết nối/Y01/Y02 dạng đường, có tooltip native.
- Chuyển chế độ Ngày / Tuần / Tháng ngay trên Dashboard.
- Team summary cards và tab Team.
- Bảng nhân viên có tìm kiếm, sắp xếp Calls/Kết nối/Tỷ lệ/Tên và chip trạng thái.
- Nút Xuất Excel gọi lại module xuất lịch sử cuộc gọi hiện có, tự điền khoảng ngày của Dashboard.
- Responsive cho tablet/mobile.
- Không thay đổi D1 schema; không cần migration mới.
- Giữ các tối ưu D1 từ V5.4–V5.7.



---

## README_V5.9.md

- Số byte gốc: 613
- SHA-256: `60a8b1c9c22b280f00344d13274a491984429372cd6ae4d0a19bd40dceea9ba2`

# An Đông 4 CRM V5.9

## Dashboard tinh gọn
- Bỏ hoàn toàn bộ chọn Ngày / Tuần / Tháng trên Dashboard.
- Bỏ Toàn bộ / Theo team / Theo nhân viên ở khu vực trên biểu đồ.
- Bỏ đánh giá tăng/giảm màu xanh/đỏ trên KPI cards.
- Khoảng ngày + Hôm nay / 7 ngày / 30 ngày / Tháng này là bộ điều khiển thời gian duy nhất.
- Biểu đồ hiển thị theo từng ngày trong chính khoảng thời gian đang chọn.
- Giữ nguyên Team cards, bảng nhân viên, xuất Excel và toàn bộ chức năng V5.8/V5.7.
- Không có migration database mới.



---

## README_V6.0.md

- Số byte gốc: 2598
- SHA-256: `9fa1cf460d0cea6bc877b381793edeb16be2c4d0a349674f2e0328048e99d769`

# An Đông 4 CRM V6.0

## Thay đổi chính

### 1. TeamLead tự đẩy Data vào Team
- TeamLead có thể tải Excel/CSV ở mục **Dữ liệu**.
- Data mới tự khóa vào Team của TeamLead, không thể đẩy sang Team khác.
- Kiểm tra trùng SĐT trước khi nhập.
- Sau khi nhập có thể chia đều hoặc gán cho một Sale trong Team.
- Giữ chức năng chuyển Data theo trạng thái giữa nhân viên cùng Team.

### 2. Dashboard dễ đọc hơn
- Biểu đồ đổi sang **grouped bar chart**.
- Mỗi ngày có 4 cột: Calls, Kết nối, Y01, Y02.
- Giữ bộ lọc khoảng ngày, Hôm nay, 7 ngày, 30 ngày, Tháng này.

### 3. Lịch sử cuộc gọi không ghi đè
- Mỗi lần Sale bấm Lưu tạo **một call_logs mới**.
- Ví dụ 12/10 Y03 và 13/10 Y02 sẽ giữ đủ cả hai dòng lịch sử.
- `customers.status` chỉ lưu trạng thái mới nhất để lọc nhanh.
- Mở hồ sơ khách sẽ tải lịch sử riêng của khách (tối đa 500 lượt) thay vì bắt toàn hệ thống đọc toàn bộ lịch sử.

## Tối ưu Cloudflare D1
- Chỉ tải lịch sử cuộc gọi 45 ngày gần nhất khi đăng nhập/full sync.
- Khi chọn khoảng Dashboard cũ hơn, chỉ tải đúng khoảng ngày cần xem.
- Mở hồ sơ khách chỉ đọc lịch sử của đúng khách đó.
- Sau import/chia/chuyển Data chỉ refresh bảng khách hàng, không tải lại Calls/KHTN/Báo cáo/KPI.
- Import Kho không còn quét danh sách Team/User khi không cần.
- Không ghi `audit_logs` cho từng lượt gọi; `call_logs` là lịch sử chính, giảm 1 Row written/lượt gọi.
- Migration `0009_v60_hotpath_indexes.sql` thêm chỉ mục cho các truy vấn nóng.

## Nâng cấp

Khuyến nghị backup trước:

```powershell
npx.cmd wrangler d1 export an-dong-4-crm --remote --output=backup-truoc-v6.0.sql
```

Cài package và chạy migration:

```powershell
npm.cmd install
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
npx.cmd wrangler deploy
```

Sau deploy, nhấn `Ctrl + F5`.

> Kiểm tra `database_id` trong `wrangler.jsonc` phải đúng D1 đang dùng trước khi chạy migration/deploy.

## Lưu ý Rows read / Rows written
Migration tạo index sẽ phát sinh một lượng Rows written **một lần** khi xây index. Sau đó các truy vấn lọc Team/trạng thái/lịch sử khách sẽ quét ít dòng hơn. Không thể cam kết một con số giảm cố định vì còn phụ thuộc số nhân viên, số Data và cách sử dụng thực tế.



---

## README_V6.1.md

- Số byte gốc: 873
- SHA-256: `8c20996c509e3a9218c4501f4d0cac5e8c4910f03fab7fe0e48d63a564c12576`

# An Đông 4 CRM V6.1

## Tự đổi mật khẩu
- Teamlead và Sale có thể tự đổi mật khẩu từ menu tài khoản góc phải.
- Admin cũng có thể dùng cùng chức năng cho chính tài khoản của mình.
- Bắt buộc nhập mật khẩu hiện tại.
- Mật khẩu mới tối thiểu 6 ký tự và phải nhập lại để xác nhận.
- Không thể đổi mật khẩu của tài khoản khác qua chức năng này.
- Sau khi đổi, phiên hiện tại được giữ lại; các phiên đăng nhập khác của cùng tài khoản bị thu hồi.

## D1 / triển khai
- Không có migration mới.
- Mỗi lần đổi mật khẩu chỉ phát sinh thao tác ghi khi người dùng thực sự đổi mật khẩu, không tạo polling hay truy vấn nền mới.
- Kế thừa toàn bộ tối ưu Rows read / Rows written của V6.0.



---

## README_V6.2.md

- Số byte gốc: 2073
- SHA-256: `60904d4c37ab1a75cc3354a2dbeb473c5a3b12eb2c92837b9553b1bd67d565f3`

# AN ĐÔNG 4 CRM — V6.2

Nâng cấp từ V6.1. Không cần migration mới.

## Thay đổi chính

### 1. Admin tạo thêm tài khoản Admin
- Trang **Nhân sự** có nút **+ Tạo Admin** riêng.
- Admin mới không thuộc Team và có quyền quản trị toàn hệ thống.
- Teamlead vẫn chỉ được tạo Sale trong Team của mình.
- Danh sách tài khoản Admin được hiển thị riêng cho Admin; Teamlead không nhìn thấy danh sách Admin.

### 2. Kho Data riêng theo Team
- Teamlead dùng trang **Kho Data Team** thay cho Dữ liệu chung.
- Mọi Data Teamlead upload được khóa vào `team_id` của Teamlead ở backend.
- Teamlead chỉ xem/chia/chuyển Data trong chính Team của mình.
- Admin xem tổng toàn hệ thống và có thể upload vào **Kho chung Admin** hoặc chọn thẳng **Kho của một Team**.
- Khi Admin chia toàn hệ thống, hệ thống chỉ lấy Data từ Kho chung Admin; không tự hút Data khỏi Kho riêng của Teamlead.
- Khi Admin gán cho một Team/nhân viên, chỉ dùng Kho chung + đúng Kho Team đích.

### 3. Tên nguồn = Phân loại Data
- Khi upload, trường **Tên nguồn / Phân loại Data** được dùng đồng thời cho `source` và `data_category_id`.
- Nếu phân loại chưa có, hệ thống chỉ tạo **1 lần cho cả batch**, không tạo theo từng khách.
- Ví dụ nhập `CTV Facebook T10` thì Data có Nguồn `CTV Facebook T10` và Phân loại `CTV Facebook T10`.

### 4. Tối ưu D1
- Không thêm polling/truy vấn nền mới.
- Upload chỉ đọc/tạo phân loại một lần cho mỗi batch.
- Sau upload/chia/thu hồi Data ở trang Admin chỉ refresh danh sách khách (`customers`), không tải lại Call logs, KPI, KHTN và Báo cáo đầu ngày.
- Dùng lại các index tối ưu đã có từ V5.4/V6.0.

## Deploy

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Nếu database hiện tại đã chạy đầy đủ migration đến V6.0/V6.1 thì **V6.2 không cần chạy migration mới**.



---

## README_V6.3.md

- Số byte gốc: 1899
- SHA-256: `4a023f14272f9d0bd81a2a1b6fa1bc3d0005d8699959bf7742a88333f53cbbad`

# AN ĐÔNG 4 CRM — V6.3

## Thay đổi chính

- Bỏ KHTN và Báo cáo đầu ngày khỏi menu và luồng tải dữ liệu. Các bảng cũ được giữ nguyên để không phá dữ liệu lịch sử.
- Thêm tab **Lead**. Khách được đưa vào Lead khi lần đầu phát sinh cuộc gọi **Y01 hoặc Y02**.
- Teamlead chỉ xem Lead trong Team; Sale chỉ xem Lead đang thuộc chính mình; Admin xem tổng.
- Tiến trình Lead: Khách hàng đã login app -> Khách hàng ký; hoặc KH dư nợ cao / KH nợ xấu / KH mới phát sinh dư nợ / Lý do khác.
- Mỗi lần đổi tiến trình Lead tạo một dòng lịch sử riêng, có thời gian và người cập nhật. Không ghi đè lịch sử.
- Lý do khác bắt buộc nhập nội dung.
- Xuất lịch sử cuộc gọi tiếp tục hỗ trợ chọn **Từ ngày / Đến ngày**, Team, nhân viên và trạng thái; Teamlead bị khóa server-side trong Team của mình.

## Tối ưu D1

- Không còn đọc KHTN config, KHTN entries và daily_reports khi đăng nhập/sync CRM.
- Lead chỉ được đọc khi người dùng mở tab Lead và cache 60 giây ở trình duyệt.
- Lịch sử Lead chỉ đọc khi bấm **Lịch sử** của một khách.
- Một khách chỉ tạo `lead_cases` một lần (INSERT OR IGNORE) khi đạt Y01/Y02.
- Mỗi lần đổi tiến trình Lead chỉ ghi đúng 1 dòng `lead_status_history`; không tạo audit log riêng.
- Chỉ thêm 1 index cần thiết cho truy vấn lịch sử Lead để hạn chế write amplification.

## Migration

V6.3 có migration mới: `migrations/0010_leads.sql`.

Triển khai:

```powershell
npm.cmd install
npx.cmd wrangler d1 export an-dong-4-crm --remote --output=backup-truoc-v6.3.sql
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
npx.cmd wrangler deploy
```

Sau deploy nhấn Ctrl + F5.



---

## README_V6.4.md

- Số byte gốc: 1488
- SHA-256: `5c5da1257c018479baeb7dd901cd1d78bd5a8781b80e537ebabc2736b5be8bc7`

# An Đông 4 CRM V6.4

## Thay đổi chính

- Lead được khóa theo phạm vi: Sale chỉ thấy Lead của mình, Teamlead chỉ thấy Lead thuộc Team của mình, Admin xem toàn hệ thống.
- Teamlead có bộ lọc nhân viên chỉ chứa các nhân viên trong Team đang có Lead. Admin có thể lọc Team rồi lọc nhân viên.
- Danh sách Lead được chia nhóm theo **ngày đầu tiên phát sinh Y01/Y02** để dễ theo dõi.
- Chi tiết cuộc gọi đổi từ 1 ngày sang **Từ ngày → Đến ngày**. KPI, bảng nhân viên, danh sách cuộc gọi và Excel đều dùng đúng khoảng đã chọn.
- Có nút nhanh Hôm nay / 7 ngày / 30 ngày.
- Xuất Excel từng nhân viên cũng tự nhận đúng khoảng ngày đang xem.

## Tối ưu D1

- Không có migration mới, không thêm index nên không phát sinh Rows written do nâng cấp V6.4.
- Cache call range được sửa thành danh sách khoảng đã tải; không còn đánh dấu nhầm một khoảng chưa đọc là đã tải. Điều này tránh đọc D1 không cần thiết khi xem ngày cũ.
- Lead vẫn lazy-load chỉ khi mở tab Lead và cache 60 giây.
- Server tiếp tục bắt buộc scope Teamlead theo team_id; danh sách Lead còn kiểm tra nhân viên được gán thuộc đúng Team.

## Deploy

Không cần chạy migration nếu database đã ở V6.3.

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy nhấn Ctrl+F5.



---

## README_V6.5.md

- Số byte gốc: 2133
- SHA-256: `4d5c1c7fcc3ec05015fd457d89fc109a087630c78e32c522ae2f732bca7ba364`

# An Đông 4 CRM V6.5

## Thay đổi chính

### Dashboard
- Thêm KPI **Tổng số chưa gọi**: chỉ tính Data đang giao (`ASSIGNED`) có trạng thái `NEW`.
- **Tỷ lệ kết nối** nay tính theo **số khách đã gọi duy nhất** trong khoảng ngày: số khách có kết quả Y01–Y06 / số khách đã gọi. Một khách được gọi nhiều lần không làm mẫu số tăng nhiều lần.
- `Số lượt gọi` vẫn giữ tổng số lần gọi thực tế để theo dõi khối lượng công việc.

### Lead
- Thêm thẻ **Tổng Lead phát sinh** rõ ràng.
- Giữ chia Lead theo ngày đầu tiên khách phát sinh Y01/Y02.
- Bỏ **Lý do khác** khỏi danh sách trạng thái có thể chọn. Dữ liệu OTHER cũ vẫn được giữ để không mất lịch sử.
- Thêm **Ghi chú Lead** riêng: Sale, Teamlead và Admin có quyền trong phạm vi của mình có thể ghi chú mà không đổi trạng thái.
- Lịch sử Lead hiển thị chung cả thay đổi trạng thái và ghi chú.
- Ghi chú chỉ được đọc khi mở Lead cụ thể, tránh tăng Rows read ở màn danh sách.
- Mỗi lần lưu ghi chú chỉ ghi 1 dòng `lead_notes`, không tạo audit phụ.

### Kho Data Teamlead
- Thêm bảng **Phân loại Data của Team**: Tổng / Còn trong Kho / Đang giao / Chưa gọi / Đã gọi.
- Có nút **Chia loại này** để chọn nhanh đúng phân loại còn Data.
- Khi phân Data, Teamlead có thể chọn **Phân loại Data** trước khi chia cho Team hoặc một nhân viên.
- Thống kê phân loại được tính từ danh sách khách đã tải sẵn ở frontend, không phát sinh truy vấn D1 riêng.

## D1 / Migration
V6.5 có migration mới `0011_lead_notes.sql` để tạo bảng ghi chú Lead và một index phục vụ đọc ghi chú theo từng khách.

Triển khai:

```powershell
npm.cmd install
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
npx.cmd wrangler deploy
```

Trước khi chạy migration, kiểm tra `database_id` trong `wrangler.jsonc` đúng với D1 production hiện tại.



---

## README_V6.6.md

- Số byte gốc: 3472
- SHA-256: `b5181ba2d43c18ba0d30c14c81506785ce243a2f57cacf4f1a46ccba74870189`

# An Đông 4 CRM V6.6

V6.6 tập trung vào 3 phần: Lead theo lịch sử gọi thật, Kho Data dễ đọc hơn và giảm thao tác D1 thừa.

## Lead: giữ nguyên Lead sau Y01/Y02, tự thấy các lần gọi sau

- Khách được tạo Lead ở lần đầu phát sinh **Y01 hoặc Y02**.
- Nếu các lần gọi sau đổi sang Y03, N02... Lead **không bị xoá**.
- Trong danh sách Lead có cột **Cuộc gọi mới nhất** gồm trạng thái mới nhất, ghi chú cuộc gọi và thời gian gọi.
- Nút **Lịch sử** gộp ba loại sự kiện theo thời gian:
  - lịch sử cuộc gọi từ `call_logs`;
  - ghi chú Lead thủ công;
  - thay đổi tiến trình Lead.
- Lịch sử cuộc gọi được **đọc trực tiếp từ `call_logs`**, không copy sang bảng Lead, vì vậy không phát sinh thêm Rows written khi nhân viên gọi lại.

## Kho Data V6.6

Kho Admin được chia thành 4 khu rõ ràng:

1. **Tổng quan Kho**: Tổng Data đã nhập, Trong Kho, Đang giao, Đã gọi và bảng theo từng phân loại.
2. **Chuyển Data**: chọn nhân viên nguồn, chuyển **Tất cả trạng thái** hoặc từng trạng thái Y01/Y02/Y03...; hiển thị số lượng trước khi chuyển.
3. **Data & phân loại**: lọc, xem và chỉnh phân loại.
4. **Random & chất lượng**: random vòng mới và so sánh hiệu quả các vòng gọi.

### Phân loại khi nhập

- Mỗi lần upload phải nhập/chọn **Tên nguồn / Phân loại Data**.
- Có thể chọn phân loại cũ hoặc gõ tên mới.
- Tên này đồng thời là Nguồn và Phân loại Data.

### Random vòng mới

- Admin chọn **một phân loại đã gọi xong** để random.
- Teamlead cũng có nút **Random vòng mới** khi toàn bộ Data của một phân loại trong Team đã gọi xong.
- Backend kiểm tra lại điều kiện này, không chỉ khoá ở giao diện.
- Lead từng đạt **KH ký hồ sơ / giải ngân** được tự động loại khỏi random.
- Random giữ nguyên lịch sử gọi cũ và mở `assignment_round` mới.

### So sánh chất lượng

Bảng theo vòng hiển thị Calls, tỷ lệ kết nối, Y01, Y02 và mức tăng/giảm so với vòng trước.

## Dashboard

Dashboard dùng cùng giao diện điều hướng với các tab khác:

- top bar màu plum;
- sidebar nền trắng;
- Dashboard active bằng nền tím nhạt;
- không còn sidebar nâu riêng chỉ ở Dashboard.

## D1 / quota

- Không có migration mới trong V6.6 nếu đã ở V6.5.
- Call sau khi Lead phát sinh được đọc từ `call_logs`, không nhân đôi dữ liệu vào bảng Lead.
- Tổng quan Kho và số lượng trạng thái chuyển Data chủ yếu tính từ dữ liệu khách đã tải sẵn ở frontend.
- Analytics Kho chỉ được gọi khi mở tab **Random & chất lượng** và cache 2 phút trên trình duyệt.
- Sau chuyển/random chỉ refresh danh sách khách cần thiết, không đồng bộ lại toàn bộ KPI/KHTN/báo cáo.

## Nâng cấp từ V6.5

Nếu database đã chạy migration tới `0011_lead_notes.sql`, V6.6 **không cần chạy migration mới**:

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy nhấn `Ctrl + F5`.

> Trước khi deploy, kiểm tra `database_id` trong `wrangler.jsonc` đúng với D1 production hiện tại. V6.6 không tự thay UUID database.



---

## README_V6.7.md

- Số byte gốc: 1342
- SHA-256: `393f08c459d2d1aa56560e06c3103655b77362a868f435913329b0ee3a2404db`

# An Đông 4 CRM V6.7

## Lead dễ đọc hơn

- Ghi chú Lead mới nhất hiển thị trực tiếp thành một dòng ngay dưới khách hàng trong danh sách Lead.
- Không cần bấm **Ghi chú** để xem ghi chú gần nhất; nút **+ Ghi chú** chỉ dùng để thêm ghi chú mới.
- Dòng ghi chú hiển thị nội dung, người ghi và thời gian.
- Bấm **Lịch sử** để xem toàn bộ lịch sử cuộc gọi, tiến trình Lead và tất cả ghi chú.
- Khoảng cách bảng Lead được thu gọn để tên khách, trạng thái gọi, nguồn, Team, nhân viên và thao tác dễ quét hơn.

## Tối ưu D1

- Danh sách Lead chỉ lấy **1 ghi chú mới nhất** cho mỗi Lead bằng index `idx_lead_notes_customer_time`; không tải toàn bộ lịch sử ghi chú.
- Mở hộp Ghi chú không gọi API lịch sử; ghi chú mới nhất đã có sẵn từ danh sách Lead.
- Sau khi lưu ghi chú, frontend cập nhật ngay dòng Lead hiện tại, không reload toàn bộ CRM và không đọc lại lịch sử.
- Không có migration mới và không thêm Rows written ngoài thao tác lưu ghi chú thực tế.

## Triển khai

Nếu database đã chạy đủ migration đến `0011_lead_notes.sql`:

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau đó Ctrl+F5.



---

## README_V6.8.md

- Số byte gốc: 741
- SHA-256: `47446d55bef8ed12d7d313db5d9191892d7e40ed86d5cd5cff3d223614f2e9fd`

# An Đông 4 CRM V6.8

## Thay đổi
- Lead có bộ lọc theo ngày phát sinh: Tất cả / Hôm nay / Hôm qua / chọn ngày cụ thể.
- Các card Tổng Lead, Chưa xử lý, Đã login app, Đã ký / giải ngân, Không login / vướng điều kiện thay đổi theo ngày đang chọn.
- Khi chọn Tất cả, danh sách vẫn chia nhóm theo từng ngày. Khi chọn một ngày, chỉ hiển thị Lead của ngày đó.
- Teamlead vẫn chỉ thấy Lead thuộc Team mình; Sale chỉ thấy Lead của chính mình; Admin xem toàn bộ theo quyền hiện có.
- Bộ lọc ngày thực hiện trên dữ liệu Lead đã tải/cached nên không tạo thêm request D1 khi đổi ngày.
- Không có migration mới.



---

## README_V6.9.md

- Số byte gốc: 1871
- SHA-256: `965d62f64ffe9b56ffa9cde3ff3006cbdaf78261b0f7583869ea4626a0e29cf4`

# An Đông 4 CRM — V6.9

## Thay đổi chính

### Lead: lọc theo khoảng ngày
- Bỏ các nút Tất cả / Hôm nay / Hôm qua ở phần Lead.
- Chỉ giữ `Từ ngày` và `Đến ngày`.
- Toàn bộ KPI Lead và danh sách Lead dùng đúng khoảng ngày đang chọn.
- Danh sách trong khoảng vẫn chia nhóm theo từng ngày phát sinh để dễ theo dõi.
- Việc đổi khoảng ngày lọc trên danh sách Lead đã tải/cache, không tự tạo thêm query D1 cho mỗi lần đổi ngày.

### Kho Data Teamlead giống Kho Admin nhưng khóa theo Team
- Teamlead có `Kho Data Team` với 4 khu giống Admin:
  1. Tổng quan Kho
  2. Chuyển Data
  3. Data & phân loại
  4. Random & chất lượng
- `Đẩy Data mới` mở trang nhập Data riêng của Teamlead như trước.
- Tổng Data, Data trong Kho, đang giao, đã gọi, thống kê theo nhân viên, phân loại, chuyển Data, random và analytics đều chỉ tính đúng `team_id` của Teamlead.
- Teamlead không thể đọc, phân loại, chuyển, random hoặc thu hồi Data của Team khác ở backend.
- Admin vẫn xem và thao tác toàn hệ thống.

### Tối ưu D1
- Truy vấn analytics Teamlead thêm điều kiện `team_id=?` trực tiếp thay vì điều kiện OR, giúp D1 có cơ hội dùng index theo Team tốt hơn.
- Analytics / round analytics chỉ tải khi mở tab `Random & chất lượng` và vẫn cache 2 phút.
- Không có migration mới, không tạo thêm index/bảng trong V6.9.

## Cập nhật
Nếu database đã chạy đầy đủ đến V6.8/V6.7 trước đó thì không cần chạy migration mới:

```powershell
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy nhấn `Ctrl + F5`.

> Kiểm tra `database_id` trong `wrangler.jsonc` phải đúng D1 production hiện tại trước khi deploy.



---

## README_V7.0.md

- Số byte gốc: 971
- SHA-256: `b0eb9460a0dc87421fbedbe870c157b2b0bd07ce6724b9017fa2c294a3625ece`

# An Đông 4 CRM V7.0

## Thay đổi chính
- Lead mặc định mở với **Từ ngày = hôm nay** và **Đến ngày = hôm nay**. Người dùng có thể đổi khoảng ngày sau.
- Kho Teamlead chuyển sang luồng dễ hiểu: **Đẩy Data -> Phân Data -> Data đã gọi -> Chia lại -> Chuyển nhân viên**.
- Tên nguồn khi upload đồng thời là **Phân loại Data**.
- Có khu riêng **Data đã gọi**; chỉ phân loại đã hoàn tất toàn bộ mới được mở vòng gọi mới/chia lại để tránh trộn vòng.
- Khách Lead đã ký / giải ngân tiếp tục tự động bị loại khỏi vòng chia lại.
- Chuyển Data giữa nhân viên đặt ở cuối trang và giữ nguyên lịch sử cuộc gọi.
- Teamlead chỉ thao tác trên Data của chính Team ở cả frontend và backend hiện có.
- Không có migration mới so với V6.9.

## Deploy
```powershell
npm.cmd install
npx.cmd wrangler deploy
```



---

## README_V7.1.md

- Số byte gốc: 981
- SHA-256: `b2c4db4196d032b1c5b48d487075be86d7d824f0d09acf0c24be61592442afc8`

# An Đông 4 CRM V7.1

## Thay đổi chính

- Bỏ tab **Tổng quan Kho** ở Kho quản trị.
- Kho quản trị mở mặc định ở **Data & phân loại**.
- Thứ tự tab: **Data & phân loại → Random & chất lượng → Chuyển Data**.
- **Chuyển Data** nằm ở tab cuối.
- Data & phân loại có chọn nhanh toàn bộ **Tất cả Data / Data chưa gọi / Data đã gọi** để gán hoặc bỏ phân loại hàng loạt.
- Data chưa gọi = Data chưa hoàn tất lượt gọi hiện tại (Trong Kho + Đang giao). Data đã gọi = ARCHIVED.
- Bulk phân loại dùng 1 UPDATE có scope ở backend thay vì gửi hàng nghìn lệnh update riêng; chỉ update dòng thực sự đổi phân loại để giảm Rows written.
- Checkbox trong bảng vẫn hỗ trợ chọn từng khách / tối đa 500 dòng đang hiển thị.
- Teamlead nếu gọi API bulk scope vẫn bị khóa theo team_id ở backend.
- Không có migration mới.



---

## README_V7.2.md

- Số byte gốc: 454
- SHA-256: `acc8f22a30115c65653a7bf62f19723fd07985cd20d04c359e0b16d73a60dcce`

# An Đông 4 CRM V7.2

## Thay đổi
- Kho > Data & phân loại có thêm mục **Tổng Data theo nhân viên**.
- Mỗi nhân viên hiển thị: Tổng Data, Chưa gọi, Đã gọi và tỷ lệ đã gọi.
- Admin xem toàn bộ Sale; Teamlead xem nhân viên trong Team của mình.
- Số liệu được nhóm trực tiếp từ danh sách khách hàng đã tải vào trang Kho, không tạo thêm API/query D1.
- Không có migration mới.



---

## README_V7.3.md

- Số byte gốc: 535
- SHA-256: `b0c549abe0867cb113d9532df6d3537f0f31181075c0e5b4e0e0106ad1fc120c`

# An Đông 4 CRM V7.3

## Thay đổi
- Lead bỏ dropdown **Tất cả Team** và **Tất cả nhân viên có Lead**.
- Admin lọc Lead bằng tab Team nằm ngang: Tất cả Team / từng Team.
- Teamlead chỉ hiển thị một tab Team của chính mình; Sale vẫn chỉ thấy Lead cá nhân.
- Card thống kê và danh sách Lead cập nhật theo Team đang chọn và khoảng ngày hiện tại.
- Không có migration mới; đổi Team chỉ lọc dữ liệu Lead đã tải/cache, không tạo thêm Rows written.



---

## README_V7.4.md

- Số byte gốc: 790
- SHA-256: `1b9e75184d851c7b6abc72733e7322300e714e176c696a9c8525a45a6bf6fc3d`

# An Đông 4 CRM V7.4

## Lọc trùng Data theo từng Team

- Teamlead khi Đọc & kiểm tra file chỉ đối chiếu SĐT với Data thuộc chính Team của mình.
- Cùng một SĐT tồn tại ở Team khác không còn bị xem là trùng đối với Team hiện tại.
- Admin khi chọn Kho của một Team cũng lọc trùng trong đúng Team đó.
- Admin chọn Kho chung vẫn giữ đối chiếu toàn CRM như trước.
- Backend `/api/customers/import/check` và `/api/customers/import` dùng cùng phạm vi `team_id`, tránh lệch giữa preview và lúc ghi D1.
- Đổi Kho nhận Data ở màn Admin sẽ xoá preview cũ và bắt buộc kiểm tra lại.
- Không có migration mới.
- Không thêm index mới, tránh phát sinh Rows written do migration.



---

## README_V7.5.md

- Số byte gốc: 1452
- SHA-256: `a7e105718b577c306bc2f130adc71608f58ed2bd6fe088704da9463854b6a633`

# An Đông 4 CRM V7.5

## Thay đổi chính

### 1. Tổng Data theo nhân viên thành tab riêng
- Kho Admin có tab **Data nhân viên** riêng.
- Kho Teamlead có tab **Data nhân viên** riêng và chỉ tính Sale trong Team.
- Bảng gồm Tổng Data, Chưa gọi, Đã gọi và tiến độ.
- Số liệu tính từ Data Kho đã tải sẵn ở frontend, không tạo API D1 riêng.

### 2. Chat nội bộ
- **Admin** có thể chat với mọi tài khoản đang hoạt động.
- **Teamlead** có thể chat với Sale thuộc chính Team và Admin.
- **Sale** có thể chat với Teamlead thuộc chính Team và Admin.
- Phân quyền được kiểm tra ở backend.
- Tin nhắn là chat 1:1, có lịch sử gần nhất và nút tải tin cũ hơn.
- Khi đang mở một cuộc chat, hệ thống chỉ kiểm tra tin mới theo `id` sau mỗi 30 giây; khi rời tab Chat sẽ dừng polling.

## Tối ưu D1
- Mỗi lần gửi chat = 1 dòng `chat_messages`.
- Không ghi read-receipt và không tạo audit row lặp cho từng tin nhắn.
- Tin nhắn được đọc theo `conversation_key + id`, không quét toàn bộ bảng.
- Chỉ có một index phục vụ lịch sử hội thoại.

## Migration mới
Có migration `0012_internal_chat.sql`. Cần chạy migration trước khi deploy V7.5.

```powershell
npm.cmd install
npx.cmd wrangler d1 migrations apply an-dong-4-crm --remote
npx.cmd wrangler deploy
```



---

## README_V7.6.md

- Số byte gốc: 793
- SHA-256: `98ef4a25d8b2b5eff44c4fdb4e711a3326e5e7df7b0ca3321a549b14a5ce8f2f`

# An Đông 4 CRM V7.6

## Nhắc cập nhật Lead theo từng nhân viên

- Admin và Teamlead có thêm khu **Nhắc cập nhật Lead theo nhân viên** trong tab Lead.
- Mỗi nhân viên hiển thị tổng Lead và số Lead chưa xử lý trong đúng khoảng ngày/Team đang xem.
- Bấm **Nhắc cập nhật** sẽ gửi một tin nhắn qua Chat nội bộ đến đúng nhân viên.
- Nội dung nhắc có số Lead, số chưa xử lý và khoảng ngày hiện tại.
- Teamlead chỉ nhắc được Sale cùng Team; Admin nhắc được mọi nhân viên. Backend Chat tiếp tục kiểm tra quyền.
- Mỗi lần nhắc = 1 row ghi vào `chat_messages`; không tạo bảng/audit riêng.
- Không có migration mới nếu database đã có migration 0012 của V7.5.



---

## README_V7.7.md

- Số byte gốc: 569
- SHA-256: `53c1940da43633ae20869a47a318d063fabbc050d07398d0831a364540b20774`

# An Đông 4 CRM V7.7

## Thay đổi
- Sửa ô tìm kiếm Chat nội bộ: gõ liên tục, không mất focus sau mỗi ký tự.
- Admin có nút Xóa Lead. Backend chặn Teamlead/Sale; xóa Lead không xóa khách hàng và không xóa call_logs.
- Tin nhắn mới tạo thông báo trong CRM cho người nhận, dùng chuông thông báo + toast.
- Thông báo chat được kiểm tra theo recipient_user_id + id, không có read-receipt write.
- Migration mới 0013 chỉ thêm index idx_chat_recipient_id để giảm Rows read khi kiểm tra tin mới.



---

## README_V7.8.md

- Số byte gốc: 580
- SHA-256: `2501bdb524b6b72589647137a163d049e4c92c02a51d9ba7b5043a569facb168`

# An Đông 4 CRM V7.8

## Bàn gọi - bắt buộc chọn trạng thái

- Kết quả cuộc gọi mặc định là `-- Chọn trạng thái cuộc gọi --`.
- Không kế thừa trạng thái hiện tại của khách vào lượt gọi mới.
- Nút lưu bị khóa cho tới khi Sale chọn một trạng thái Y01-Y06/N01-N04.
- `saveCall()` kiểm tra lại trạng thái trước khi gửi API; backend vẫn chặn trạng thái rỗng/NEW.
- Mỗi khách tiếp theo lại trở về trạng thái chưa chọn, giúp tránh lưu nhầm.

Không có migration mới.



---

## README_V7.9.md

- Số byte gốc: 1307
- SHA-256: `56f7b8b078fa2070175d0c0b37148a837800e3ee65e880352cf38a280bbbe438`

# An Đông 4 CRM V7.9

## 1. Thanh tiến độ Data theo nhân viên

- Thanh `Tiến độ` trong `Kho Data Team > Data nhân viên` hiển thị phần đã gọi bằng màu xanh lá.
- Chiều dài phần màu xanh bám đúng phần trăm `Đã gọi / Tổng Data`.
- Ví dụ: 58% sẽ tô xanh 58% thanh, 100% sẽ tô xanh toàn bộ thanh.

## 2. Lead - Xuất Excel

- Thêm nút `⬇ Xuất Excel` ngay tại danh sách Lead.
- File `.xlsx` xuất đúng danh sách đang hiển thị sau các bộ lọc ngày, Team, tiến trình và ô tìm kiếm.
- Bao gồm: khách hàng, SĐT, ngày/giờ phát sinh Lead, trạng thái tạo Lead Y01/Y02, cuộc gọi mới nhất, nguồn Data, Team, nhân viên, tiến trình Lead, ghi chú mới nhất, thời gian/người cập nhật.
- SĐT được ép kiểu Text để giữ số 0 ở đầu.

## 3. Dashboard - Cuộc gọi cuối

- Bỏ cột `Trạng thái` (Đang hoạt động/Tạm dừng) ở bảng hiệu suất nhân viên.
- Thay bằng cột `Cuộc gọi cuối`.
- Hiển thị giờ `HH:mm` và ngày của cuộc gọi gần nhất trong khoảng thời gian Dashboard đang xem.
- Nếu nhân viên chưa có cuộc gọi trong khoảng đó sẽ hiển thị `Chưa có cuộc gọi`.

Không có migration D1 mới.



---

## README_V7.10.md

- Số byte gốc: 827
- SHA-256: `7cb444037303c5f758939c2c1c900d9bc9123d52b49402e0ab508391b80a9aaf`

# An Đông 4 CRM V7.10

## Sửa lỗi dùng lại tên đăng nhập sau khi xoá tài khoản

- Khi xoá nhân viên, hệ thống vẫn giữ bản ghi user cũ để bảo toàn lịch sử cuộc gọi và audit, nhưng username cũ sẽ được đổi sang tên lưu trữ nội bộ.
- Vì vậy username vừa xoá có thể được tạo lại ngay cho một tài khoản mới.
- Với các tài khoản đã xoá từ phiên bản cũ (ví dụ `locphuoc`), khi tạo lại username đó lần đầu ở V7.10, hệ thống sẽ tự giải phóng username cũ rồi tạo tài khoản mới.
- Username của tài khoản đang hoạt động vẫn không được trùng, kể cả khác chữ hoa/chữ thường.
- Không cần migration D1 mới.

Tất cả tính năng của V7.9 được giữ nguyên.



---

## README_V7.11.md

- Số byte gốc: 1160
- SHA-256: `c6066118b12602e6674f897e9ff61ef160525d0261fa96837248a9526998e9c5`

# An Đông 4 CRM V7.11

## Dashboard mới 3 cấp

- **Admin – Dashboard Tổng:** 4 KPI theo ngày: Tổng cuộc gọi, Y01, Y02, Tỷ lệ kết nối. Bên dưới là từng Team theo tháng với 4 ô: Tổng cuộc gọi, Y01/Y02, Y03, Tỷ lệ kết nối.
- **Drill-down Team:** Admin bấm ô đầu tiên của Team để mở Dashboard Team. Dashboard Team hiển thị 4 KPI theo ngày và từng nhân viên theo tháng.
- **Teamlead:** mặc định vào Dashboard Team của mình; bấm tên nhân viên để mở Dashboard cá nhân.
- **Nhân viên:** 4 KPI theo ngày: Số lượng gọi, Y01, Y02, Y03. Bên dưới là 2 ô lớn cân đối Follow up và Lead theo tháng.
- Có bộ chọn **Ngày báo cáo**; dữ liệu theo tháng tự lấy tháng chứa ngày đã chọn.
- Lead trên Dashboard cá nhân được tính theo người tạo Lead (`lead_cases.created_by`) để không bị sai khi khách được chuyển nhân viên sau đó.
- Toàn bộ chức năng khác của V7.10 được giữ nguyên, bao gồm sửa lỗi tái sử dụng username sau khi xoá tài khoản.
- Không cần migration D1 mới.



---

## README_V7.12.md

- Số byte gốc: 995
- SHA-256: `790487699c63640ea4154fb20c44082bbdeafde59275f47cbeaaf8388149f3b1`

# An Đông 4 CRM — V7.12

## Thay đổi giao diện
- Thiết kế lại template toàn hệ thống theo phong cách doanh nghiệp xanh dương - trắng, lấy cảm hứng từ ngôn ngữ thị giác Shinhan Finance.
- Thay màu tím Odoo cũ bằng hệ màu xanh doanh nghiệp đồng nhất.
- Làm mới: màn hình đăng nhập, topbar, sidebar, menu, nút bấm, form, bảng dữ liệu, card, modal, notification, Chat, Lead, Kho Data, Nhân sự, Telesale và Dashboard.
- Dashboard V7.11 được giữ nguyên logic Admin → Team → Nhân viên nhưng restyle theo giao diện mới.
- Icon điều hướng được giản lược sang ký hiệu đơn sắc để giao diện gọn và chuyên nghiệp hơn.
- Tối ưu lại responsive trên mobile.

## Không thay đổi
- Không thay đổi API, D1 schema, migration, phân quyền hoặc logic nghiệp vụ.
- Không cần chạy migration D1 mới.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```



---

## README_V7.13.md

- Số byte gốc: 824
- SHA-256: `7568870e783e488b6b8c193e9ced56aff067f0396fa783f882f7c83d0f54cf2e`

# An Đông 4 CRM V7.13 — Enterprise Redesign

V7.13 là bản redesign giao diện tổng thể, không chỉ đổi màu.

## Thay đổi chính
- Thiết kế lại App Shell: topbar, sidebar, workspace context và trạng thái hệ thống.
- Thiết kế lại màn hình đăng nhập theo phong cách doanh nghiệp xanh dương/trắng.
- Trang Ứng dụng mới có hero, phân cấp nội dung và module card rõ ràng.
- Dashboard Admin / Teamlead / Sale được làm lại về bố cục, KPI card và danh sách Team/nhân viên.
- Chuẩn hóa card, bảng, input, filter, button, modal, toast, chat và các trang nghiệp vụ.
- Giữ nguyên API, D1, phân quyền và logic nghiệp vụ của V7.12.
- Không cần migration D1 mới.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```



---

## README_V7.14.md

- Số byte gốc: 2087
- SHA-256: `cf56c4c360c50a62fcef3418dc059a47c2561e726f9bda3feca397a9201dcf36`

# CALL CENTER CRM V7.14 — SaaS CRM Redesign

V7.14 thiết kế lại giao diện theo hướng SaaS CRM cho đội telesales tài chính, đồng thời giữ nguyên dữ liệu và logic nghiệp vụ hiện có.

## Thiết kế mới
- Đổi product shell thành **CALL CENTER CRM**: navy / trắng / xanh dương nhấn.
- Đăng nhập đi thẳng vào Dashboard thay vì màn hình launcher.
- Sidebar cố định, phân nhóm Tổng quan / Vận hành / Quản trị.
- Topbar có **tìm nhanh chức năng hoặc khách hàng trong đúng phạm vi tài khoản**; hỗ trợ `Ctrl + K`.
- Dashboard mới gồm KPI cards, biểu đồ 7 ngày, phân bổ kết quả và danh sách Team / nhân viên có drill-down.
- Chuẩn hóa typography, khoảng trắng, button, filter, bảng, modal, form, chat, kho dữ liệu và responsive tablet.
- Các icon giao diện chuyển sang SVG line icon đồng nhất thay vì ký tự rời rạc.

## Chức năng bổ sung không làm thay đổi dữ liệu
- Xuất Data khách hàng sang **Excel .xlsx** thay cho CSV ở các vị trí dùng hàm export chung.
- Thêm trang **Nhật ký thao tác** cho Admin, đọc trực tiếp bảng `audit_logs` đã tồn tại trong D1. Không tạo audit giả ở Demo Local.

## Dữ liệu và bảo mật
- Không đổi database ID, Worker name, bảng dữ liệu hay dữ liệu hiện có.
- Không có migration D1 mới.
- Phân quyền backend hiện tại vẫn là `admin / teamlead / sale`; giao diện hiển thị tương ứng **Admin / Team Leader / Agent**.
- Không thêm role Supervisor giả vì backend hiện tại chưa có mô hình phạm vi Supervisor. Nếu cần Supervisor thật, nên làm thành một nâng cấp phân quyền riêng có scope dữ liệu rõ ràng.
- Tìm khách hàng trên topbar chỉ dùng dữ liệu mà tài khoản hiện tại đã được phép tải/xem.
- Nhật ký thao tác chỉ Admin đọc được ở backend.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```

Không cần chạy migration D1.



---

## README_V8.0.md

- Số byte gốc: 1399
- SHA-256: `2bdf1938f53a77c2fad757f181ab1581ea2e04a6fd4388b1e968206c051dc23a`

# CALL CENTER CRM V8.0 — Premium SaaS Redesign

## Mục tiêu
V8.0 xây lại lớp giao diện theo phong cách CRM Admin Dashboard doanh nghiệp: sidebar navy cố định, topbar trắng, dashboard phân tích, bảng dữ liệu gọn và workspace Call Center 3 cột.

## Giữ nguyên dữ liệu và backend
- Giữ nguyên Cloudflare Worker, D1 binding và database_id từ V7.14.
- Không có migration D1 mới.
- Giữ nguyên API đăng nhập, phân quyền backend, khách hàng, call logs, Lead, Follow-up, KPI, nhân sự, Kho Data, chat và audit logs.
- Giao diện chỉ hiển thị dữ liệu theo phạm vi API/backend hiện tại.

## Các màn hình redesign chính
- Dashboard CRM: KPI cards, xu hướng 7 ngày, phân bổ kết quả, hiệu suất đội ngũ, Follow-up và hoạt động gần đây.
- Cơ sở dữ liệu khách hàng: bộ lọc, bảng enterprise, xuất Excel, điều hướng nhập Excel.
- Call Center: layout 3 cột Queue / Hồ sơ khách / Cập nhật kết quả.
- Quản lý nhóm & nhân viên: summary cards, filters, bảng nhân sự, KPI progress.
- KPI & Hiệu suất: filters, 5 KPI cards, biểu đồ target/actual, so sánh Team, ranking.
- Sidebar/topbar/layout mới đồng nhất trên toàn hệ thống.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```

Không cần chạy migration D1 cho V8.0.



---

## README_V8.1.md

- Số byte gốc: 2795
- SHA-256: `6c754b0976a0fc339f21b3f39dfb78f7ade14b531960e98595e030a39c1ccbc1`

# CALL CENTER CRM V8.1 — Operations Control Update

V8.1 giữ nguyên D1/database và dữ liệu hiện tại, đồng thời chỉnh lại luồng vận hành theo yêu cầu quản trị Call Center.

## Thay đổi chính

- Bỏ menu **Báo cáo & Phân tích** và **Call Center**.
- **Cơ sở dữ liệu khách hàng** đổi thành **Chi tiết cuộc gọi**.
  - Admin: xem toàn hệ thống, lọc theo Team và khoảng Từ ngày → Đến ngày.
  - Team Leader: chỉ xem Team của mình.
  - Agent: chỉ làm việc trong phạm vi dữ liệu được cấp.
- Dashboard dùng **Từ ngày / Đến ngày**.
  - KPI chính: Tổng khách hàng, Tổng cuộc gọi, Tỷ lệ kết nối, Lead phát sinh.
  - Admin thấy hiệu suất theo Team và bấm Team để drill-down.
  - Team Leader thấy nhân viên trong Team và bấm nhân viên để xem Dashboard cá nhân.
  - Lead tồn được hiển thị ngay trên Dashboard.
- **Lịch sử cuộc gọi** được đưa lên trước **Quản lý Lead** trong sidebar.
- **Quản lý Lead** chuyển sang pipeline kiểm soát dài hạn:
  - Lead → Login App → Giải ngân.
  - Lead chưa xác định hoặc Login App chưa có kết quả giải ngân tiếp tục nằm trong danh sách tồn dù đã qua ngày phát sinh.
  - Có trạng thái không chuyển App / Login App nhưng không giải ngân và lưu lý do.
  - Bỏ khu vực nhắc cập nhật Lead cũ.
  - Bộ chọn Từ ngày / Đến ngày nằm trên đầu trang.
- Gộp **Quản lý nhóm** + **Quản lý nhân viên** thành **Quản lý nhóm và nhân viên**.
  - Chuyển Team bằng tab.
  - Tìm kiếm nhân viên trong Team đang chọn.
- **KPI & Hiệu suất** dùng khoảng Từ ngày / Đến ngày; bộ chọn Team và Nhân viên được làm rõ hơn.
- **Kho dữ liệu**:
  - Admin có Kho dữ liệu toàn hệ thống.
  - Team Leader chỉ có Kho Data Team của mình.
  - Khi Team Leader nhập Data vào Kho Team, kiểm tra trùng SĐT chỉ trong chính Team đó (logic backend hiện có được giữ nguyên).
- Bỏ tab Chat khỏi sidebar. Chat chuyển thành **bong bóng Chat nội bộ** ở góc phải:
  - Admin ↔ tất cả tài khoản.
  - Team Leader ↔ Admin + Agent trong Team.
  - Agent ↔ Admin + Team Leader + Agent cùng Team.
  - Quyền chat được kiểm tra ở backend, không chỉ ẩn giao diện.

## Database / migration

Không có migration D1 mới cho V8.1. Bản này dùng các bảng hiện có, bao gồm `lead_cases`, `lead_status_history`, `lead_notes`, `chat_messages`, kho dữ liệu và audit logs.

## Xem thử local

```bat
npm.cmd install
npx.cmd wrangler dev
```

## Deploy

```bat
npm.cmd install
npx.cmd wrangler deploy
```



---

## README_V8.2.md

- Số byte gốc: 896
- SHA-256: `3c24e1eff9b13cd3937a6549e1add417ea4aafc240a1e5740f8de0842d0f7b62`

# CALL CENTER CRM V8.2

Bản tinh chỉnh giao diện và luồng vận hành từ V8.1.

## Thay đổi
- Sửa Dashboard để KPI card và chú giải biểu đồ donut không bị dính chữ.
- Bỏ mục **Lịch sử cuộc gọi** khỏi điều hướng; lịch sử vẫn nằm trong dữ liệu cuộc gọi/khách hàng.
- Quản lý Lead trở về bố cục cũ, chỉ loại bỏ khối **Nhắc cập nhật Lead**.
- Bộ lọc KPI **Từ ngày / Đến ngày / Nhóm / Nhân viên** được làm gọn, bỏ chữ “Có thể chọn”.
- Trang Chi tiết cuộc gọi của Agent đổi **Data chưa gọi** và **Data cũ / đã gọi** thành 2 tab.
- Giữ nguyên D1, API, dữ liệu và các chức năng khác của V8.1.

## Chạy thử
```bat
npm.cmd install
npx.cmd wrangler dev
```

## Deploy
```bat
npx.cmd wrangler deploy
```

Không có migration D1 mới.



---

## README_V8.3.md

- Số byte gốc: 504
- SHA-256: `792f2f3e8a30bab081d5fb6d00fc987b444673a3e304d2348c4e8736a5b2b3b8`

# CALL-CENTER-CRM-Cloudflare-V8.3

## Cập nhật
- Đổi branding thành **Shinhan Finance - An Đông 4** và rút gọn phần giới thiệu trang đăng nhập.
- Sidebar đổi tên thương hiệu thành **An Đông 4**.
- Sửa bộ lọc **KPI** để ô chọn **Từ ngày / Đến ngày** hiển thị ngày đúng và gọn hơn.
- Trang **Chi tiết cuộc gọi** bỏ dropdown **Ưu tiên hiện tại**.
- Giữ dạng tab **Data chưa gọi / Data cũ / đã gọi** cho nhân viên.



---

## README_V8.4.md

- Số byte gốc: 1104
- SHA-256: `26d9d06bc3b61d40ed4064618fe823b5d3a1db8a110819568d7187469a1e785d`

# Shinhan Finance - An Đông 4 CRM V8.4

## Thay đổi chính
- Giữ toàn bộ giao diện và chức năng của V8.3.
- Không còn tự động rơi sang **Demo Local** khi D1/API chập chờn. Demo chỉ mở khi chủ động thêm `?demo=1`.
- Tự xoá session Demo cũ lưu trong trình duyệt khi truy cập bản thật, tránh tình trạng một trình duyệt bị kẹt Demo còn trình duyệt khác dùng D1 bình thường.
- API health tự thử lại trước khi báo mất kết nối.
- Tối ưu dữ liệu khởi động: chỉ tải dữ liệu cốt lõi + 14 ngày cuộc gọi trước; dữ liệu 30 ngày, Lead, cảnh báo và phân loại được prefetch sau khi Dashboard đã hiển thị.
- Dashboard không còn chặn toàn trang để chờ Lead tải xong.
- Cache tính toán cuộc gọi dùng chung cho Dashboard/KPI.
- Quản lý nhóm & nhân viên dùng bộ đếm Map thay vì quét toàn bộ khách hàng/cuộc gọi cho từng nhân viên.
- Tinh gọn màu sắc/text theo **Shinhan Finance - An Đông 4**.
- Không có migration D1 mới.



---

## README_V8.5.md

- Số byte gốc: 605
- SHA-256: `782203922d8c008a7ee03a92b8aea4a242776259271c3cf747341bcf2efef08a`

# Shinhan Finance - An Đông 4 CRM V8.5

## Cập nhật
- Chi tiết cuộc gọi của Agent có thêm bộ lọc **Trạng thái cuộc gọi** ngay dưới tab Data.
- Khi chuyển tab **Data chưa gọi / Data cũ / đã gọi**, bộ lọc trạng thái tự đặt lại để tránh danh sách trống gây nhầm lẫn.
- Tăng cỡ chữ ở danh sách khách hàng, thông tin khách hàng, lịch sử xử lý và form cập nhật cuộc gọi.
- Giữ nguyên khung 3 cột và kích thước tổng thể hiện tại.
- Giữ toàn bộ tối ưu và sửa lỗi kết nối của V8.4.



---

## README_V8.6.md

- Số byte gốc: 1062
- SHA-256: `8da2960cf4c071fc8d69178939a1b0539f297f42ff8999fd21a741c4b471e792`

# Shinhan Finance - An Đông 4 CRM V8.6

## Sửa lỗi chia / chuyển Data bị "Kết nối máy chủ quá thời gian"

- Chia Data từ Kho theo từng batch 100 khách thay vì xử lý hàng trăm / hàng nghìn khách trong một request.
- Giao diện tự chạy nhiều batch liên tiếp, hiển thị tiến độ `Đang phân ...` và chỉ render lại trang một lần khi hoàn tất.
- Request chia / chuyển Data dùng timeout riêng 30 giây cho mỗi batch.
- Sau khi chia Data, client cập nhật trực tiếp các khách vừa thay đổi thay vì tải lại toàn bộ `/customers` (có thể tới 20.000 dòng).
- Chuyển Data giữa nhân viên cũng tự chia batch 100 khách và giữ nguyên lịch sử cuộc gọi.
- Teamlead chỉ quét Data hết hạn trong Team của mình trước khi phân Data.
- Tối ưu thu hồi Data hết hạn bằng UPDATE theo batch SQL thay vì 2 câu lệnh cho từng khách.
- Giữ cân bằng chia vòng tròn giữa nhân viên qua nhiều batch.

Không có migration D1 mới.



---

## README_V8.7.md

- Số byte gốc: 1358
- SHA-256: `0f92e2a00fed6d2cfd3f34a99f36227cecc53c97dbe73e8a1fb6c5001b44ab93`

# Shinhan Finance - An Đông 4 CRM V8.7

## Nâng cấp xử lý Data lớn

- Thêm job chia Data có checkpoint lưu trong D1.
- Hỗ trợ chia đến 100.000 Data cho một job.
- Khi trình duyệt còn mở: client liên tục xử lý job theo batch nhỏ để chạy nhanh.
- Nếu refresh, đổi trang hoặc đóng trình duyệt: tiến độ không mất.
- Cron Cloudflare chạy mỗi phút và tiếp tục các job đang RUNNING ở nền.
- Khi đăng nhập lại bằng đúng tài khoản, CRM tự tìm job đang chạy và tiếp tục tăng tốc ở phía trình duyệt.
- Tránh tạo nhiều job chia Data trùng nhau cho cùng tài khoản khi job trước vẫn đang chạy.
- Import/lọc trùng vẫn chia batch 250 và tự retry tối đa 4 lần nếu mạng/API chập chờn.
- Nếu import bị dừng giữa chừng, có thể chọn lại file và kiểm tra lại: các SĐT đã nhập sẽ được nhận diện là trùng nên không tạo bản ghi trùng.

## Không cần chạy migration thủ công

V8.7 tự tạo bảng `bulk_jobs` khi cần. File `migrations/0014_bulk_jobs.sql` vẫn được kèm theo để đồng bộ cấu trúc dự án.

## Cloudflare Cron

Cron được đổi sang mỗi phút để các job phân Data lớn có thể tiếp tục ngay cả khi trình duyệt đã đóng.



---

## README_V8.8.md

- Số byte gốc: 1358
- SHA-256: `ef487aebbd1cf3c94d9dcf2895635311780331ddaf95eeda3105c2f40e4777cb`

# Shinhan Finance - An Đông 4 CRM V8.8

## Nâng cấp xử lý Data lớn

- Thêm job chia Data có checkpoint lưu trong D1.
- Hỗ trợ chia đến 100.000 Data cho một job.
- Khi trình duyệt còn mở: client liên tục xử lý job theo batch nhỏ để chạy nhanh.
- Nếu refresh, đổi trang hoặc đóng trình duyệt: tiến độ không mất.
- Cron Cloudflare chạy mỗi phút và tiếp tục các job đang RUNNING ở nền.
- Khi đăng nhập lại bằng đúng tài khoản, CRM tự tìm job đang chạy và tiếp tục tăng tốc ở phía trình duyệt.
- Tránh tạo nhiều job chia Data trùng nhau cho cùng tài khoản khi job trước vẫn đang chạy.
- Import/lọc trùng vẫn chia batch 250 và tự retry tối đa 4 lần nếu mạng/API chập chờn.
- Nếu import bị dừng giữa chừng, có thể chọn lại file và kiểm tra lại: các SĐT đã nhập sẽ được nhận diện là trùng nên không tạo bản ghi trùng.

## Không cần chạy migration thủ công

V8.8 tự tạo bảng `bulk_jobs` khi cần. File `migrations/0014_bulk_jobs.sql` vẫn được kèm theo để đồng bộ cấu trúc dự án.

## Cloudflare Cron

Cron được đổi sang mỗi phút để các job phân Data lớn có thể tiếp tục ngay cả khi trình duyệt đã đóng.



---

## README_V8.8.1.md

- Số byte gốc: 147
- SHA-256: `71a7ec5dab9e40ef1207f31ec357aa419ea8c34bb219952178f6306fbcfa994a`

V8.8.1
- Fix cache-busting for app.css/app.js
- Includes call detail change: remove Thông tin liên hệ and replace Nhóm with Ngày nhận Data



---

## README_V8.9.md

- Số byte gốc: 610
- SHA-256: `a642ee5fa5b7f659e8741da45429325a97cbd7828c5a25b44e0d395078973b54`

# Shinhan Finance - An Đông 4 CRM V8.9

- Kế thừa toàn bộ V8.8.1 và cơ chế bulk job/resume của V8.7.
- Chi tiết cuộc gọi: tăng font thêm một mức, tăng độ rõ các nhãn và giá trị.
- Cân lại khoảng cách 3 cột để dễ đọc nhưng vẫn giữ nguyên bố cục.
- Khu cập nhật kết quả gọn hơn: input/select rõ hơn, ghi chú thấp hơn, nhóm gợi ý trạng thái dễ nhìn.
- Giữ bỏ Thông tin liên hệ và giữ Ngày nhận Data thay cho Nhóm.
- Cache-busting app.css/app.js lên v=8.9 để tránh trình duyệt giữ giao diện cũ.



---

## README_V9.0.md

- Số byte gốc: 1090
- SHA-256: `62ba36212b21b0d0ddad048984ef12edc9712b6d3b4be1cbb6643bbb635246c4`

# Shinhan Finance - An Đông 4 CRM V9.0

## Nâng cấp Chat nội bộ
- Admin có nút **Thông báo tất cả** trong bong bóng Chat.
- Một thông báo Admin gửi sẽ được tạo cho toàn bộ tài khoản đang hoạt động và xuất hiện như tin nhắn từ Admin.
- Trạng thái chưa đọc được lưu trong D1 theo từng người gửi.
- Danh sách liên hệ hiển thị badge đỏ nhấp nháy ở đúng người vừa nhắn.
- Khi mở đúng cuộc trò chuyện, badge chưa đọc được xóa và trạng thái đọc được lưu trên backend.
- Thông báo chưa đọc vẫn còn sau khi reload/đổi trình duyệt (sau lần khởi tạo V9.0).
- Giữ nguyên phân quyền Chat: Admin ↔ tất cả; Team Leader ↔ Admin + Agent cùng Team; Agent ↔ Admin + Team Leader + Agent cùng Team.

## Database
V9.0 tự tạo bảng `chat_read_state` khi Chat được sử dụng. Có kèm migration `0015_chat_unread_state.sql` để đồng bộ cấu trúc dự án. Không bắt buộc chạy migration thủ công trước khi deploy.



---

## README_V9.1.md

- Số byte gốc: 724
- SHA-256: `b8092a7bed4be21b830c4398a572acd4258620bde4d8185ccbf205498d4a791c`

# Shinhan Finance - An Đông 4 CRM V9.1

## Chat V9.1
- Nút Thông báo Admin được thiết kế lại gọn bằng icon + nhãn.
- Không còn mở modal chồng lên cửa sổ Chat. Màn hình gửi thông báo hiển thị trực tiếp ở khung bên phải.
- Có nút Quay lại Chat, sau khi gửi thành công tự trở về Chat.
- Admin có bộ lọc Team và danh sách liên hệ được chia thành từng nhóm Team.
- Mỗi Team hiển thị số người và tổng tin chưa đọc trong Team (nếu có).
- Giữ badge nhấp nháy theo từng người gửi từ V9.0.
- Giữ nguyên backend, quyền chat và chức năng gửi thông báo toàn hệ thống.

Không cần migration D1 mới.



---

## README_V9.2.md

- Số byte gốc: 881
- SHA-256: `a839a13cfa59397d217d3b5d329431520d525aac0e2186a13b6363be12e0c610`

# Shinhan Finance - An Đông 4 CRM V9.2

## Cập nhật chính

### 1) Lịch gọi lại
- Làm lại giao diện theo layout mới.
- Thêm 3 thẻ tổng quan: Hôm nay / Quá hạn / Sắp tới.
- Thêm bộ lọc theo nhân viên phụ trách.
- Thêm tab chuyển nhanh Hôm nay / Quá hạn / Sắp tới.
- Bảng hiển thị: Giờ hẹn, Khách hàng, SĐT, Sản phẩm, Phụ trách, Tình trạng, nút Gọi.

### 2) KPI & Hiệu suất
- Làm lại phần KPI theo bố cục mới.
- Top KPI gồm: Mục tiêu cuộc gọi, Thực đạt cuộc gọi, Tỷ lệ kết nối, Lead.
- Bỏ bảng xu hướng ở giữa.
- Giữ 2 khối chính:
  - KPI mục tiêu vs Thực đạt
  - So sánh các nhóm
- Bổ sung phần Chi tiết theo Nhóm / Nhân viên với số liệu rõ ràng.
- Thêm số liệu vào các cột KPI mục tiêu và thực đạt.



---

## README_V9.3.md

- Số byte gốc: 971
- SHA-256: `0845747947ba541489f6968dda9590323e89a955f7e0c1e0556aee60c606c54f`

# Shinhan Finance - An Đông 4 CRM V9.3

## Chat V9.3
- Admin: danh sách liên hệ chia theo từng Team, có lọc Team và nhóm Quản trị riêng.
- Badge chưa đọc vẫn nằm đúng người gửi và nhấp nháy cho tới khi mở cuộc trò chuyện.
- Nút **Thông báo chung** được thiết kế lại, không còn bị chật/tràn chữ.
- Khi bấm Thông báo chung, phần bên phải của cửa sổ Chat chuyển trực tiếp sang màn hình soạn thông báo; không mở modal chồng lên Chat.
- Có nút quay lại Chat ngay trong màn hình thông báo.
- Bấm một nhân viên ở cột trái khi đang soạn thông báo sẽ trở lại cuộc chat với người đó ngay.
- Giao diện Chat rộng và thoáng hơn trên desktop; vẫn responsive trên mobile.

## Giữ nguyên V9.2
- Lịch gọi lại mới.
- KPI & Hiệu suất mới.
- D1, Lead pipeline, Kho Data, job phân Data lớn và các quyền hiện tại.



---

## README_V9.4.md

- Số byte gốc: 548
- SHA-256: `9322e8bcd897b7fa0f308d63d0ff3d1442cf76d74782304a9dc06debd3fe1759`

# CRM V9.4

- Team Leader có nút **Thông báo Team** trong Chat nội bộ.
- Thông báo Team được gửi một lần tới toàn bộ tài khoản Sale đang hoạt động trong đúng Team của Team Leader.
- Mỗi nhân viên nhận tin dưới dạng tin nhắn từ Team Leader và có badge chưa đọc như chat thường.
- Team Leader không thể gửi thông báo sang Team khác; phạm vi được kiểm tra ở backend.
- Admin vẫn giữ **Thông báo chung** tới toàn hệ thống.
- Không cần migration D1 mới.



---

## README_V9.5.md

- Số byte gốc: 1106
- SHA-256: `bb5681af52e0986298f7714e5a5c7eb1efb74ed5c5c84a561222330c7bfa83b2`

# Shinhan Finance - An Đông 4 CRM V9.5

## Khách hàng sau giải ngân

- Thêm module quản lý khách hàng sau giải ngân đến hết vòng đời khoản vay.
- Phân quyền backend:
  - Admin: xem toàn bộ.
  - Team Leader: chỉ xem khách thuộc Team của mình.
  - Agent: chỉ xem khách do chính mình phụ trách.
- Khi Lead chuyển sang `SIGNED`, hệ thống tự tạo hồ sơ sau giải ngân.
- Tự backfill các Lead đã giải ngân trước V9.5 khi module được mở lần đầu.
- Dashboard module gồm: khách đang vay, dư nợ quản lý, đến kỳ, sắp đến hạn, quá hạn, sắp tất toán, đã tất toán, đủ điều kiện vay lại.
- Có lọc Team / nhân viên theo đúng quyền.
- Hồ sơ khoản vay: mã hợp đồng, ngày giải ngân, số tiền, kỳ hạn, ngày thanh toán, đáo hạn, dư nợ, kỳ tiếp theo, trạng thái, người phụ trách.
- Lịch sử chăm sóc: kết quả, ghi chú, lịch hẹn tiếp theo.
- D1 schema có migration `0016_loan_care.sql`; Worker cũng tự tạo schema khi cần.



---

## README_V9.6.md

- Số byte gốc: 794
- SHA-256: `d8aa955be4043db20b19c3b11292622fdfb037c80c278545f107ac7f659f9c11`

# Shinhan Finance - An Đông 4 CRM V9.6

## Thu hồi Data theo nhân viên
- Admin: chọn bất kỳ Sale, trạng thái và số lượng để thu hồi Data về Kho của Team nhân viên đó.
- Team Leader: chỉ được thu hồi Data của Sale trong Team mình về Kho Team.
- Hỗ trợ Tất cả trạng thái hoặc NEW/Y01-Y06/N01-N04.
- Số lượng 0 = toàn bộ Data phù hợp; client tự chia batch tối đa 500 Data/request để giảm nguy cơ timeout.
- Khi thu hồi chỉ gỡ người phụ trách, deadline/lịch gọi lại hiện tại và đưa Data về POOL.
- Giữ nguyên khách hàng, phân loại, Lead, call_logs và lịch sử cuộc gọi.
- Assignment đang mở được đóng với lý do MANUAL_RECALL.
- Không cần migration D1 mới.



---

## README_V9.7.md

- Số byte gốc: 1898
- SHA-256: `c7f80260f540acdf53eb8b504eb6b5b97cd0c767fa6ed51acafaf979d5aa4e28`

# Shinhan Finance - An Đông 4 CRM V9.7

## 1. Đổi tên module
- `Lịch gọi lại` -> **Follow-up**.
- `Khách hàng sau giải ngân` -> **Chăm sóc khách hàng**.

## 2. Login App
Thêm module **Login App** với phân quyền backend:
- Admin: xem toàn hệ thống.
- Team Leader: xem đúng Team.
- Sale: chỉ xem khách do chính mình phụ trách.

Nhân viên nhập:
- Tên KH
- SĐT
- CCCD
- Nhân viên (tự nhận tài khoản đang đăng nhập)

Trạng thái ban đầu: **Đã Login App**.

### Kết quả Login App
- **Được duyệt / giải ngân**: bắt buộc nhập Số tiền giải ngân, Số tiền đóng hàng tháng, Ngày giải ngân, Kỳ hạn vay. Khách tự chuyển vào **Chăm sóc khách hàng**.
- **Từ chối - Có thể lên lại**: bắt buộc chọn thời gian có thể lên lại. Khách tự tạo lịch trong **Follow-up**.
- **Từ chối - Không lên lại**: đóng hồ sơ và loại khỏi danh sách đang xử lý.

## 3. Chăm sóc khách hàng
Dashboard còn đúng 7 chỉ số:
- Tổng KH
- Tổng Dư nợ
- KH đến ngày TT hôm nay
- KH đến hạn chăm sóc lần 1 (sau 30 ngày)
- KH đến hạn chăm sóc lần 2 (sau 60 ngày)
- KH đủ điều kiện Topup (sau 90 ngày)
- KH sắp kết thúc hợp đồng

Danh sách khách hiển thị:
- Tên KH
- SĐT
- CCCD
- Số tiền giải ngân
- Số tiền đóng hàng tháng
- Thời gian giải ngân
- Kỳ hạn vay

Có ghi nhận chăm sóc theo loại `CARE_30`, `CARE_60`, `TOPUP` để không tính lại khách đã hoàn thành lần chăm sóc tương ứng.

## 4. CSDL
- Thêm bảng `login_app_cases`.
- `loan_profiles` được bổ sung `cccd` và `monthly_payment` bằng cơ chế kiểm tra/tự tạo an toàn lúc chạy.
- Có migration `0017_login_app_customer_care.sql`, nhưng không bắt buộc chạy thủ công.



---

## README_V9.8.md

- Số byte gốc: 1346
- SHA-256: `0c9b2cb3738aed7cb7e0566faba9c06331a4594f3f24d21c008f4832de60bed4`

# Shinhan Finance - An Đông 4 CRM V9.8

## Chăm sóc khách hàng
- Thêm cột **Trạng thái** theo vòng đời sau giải ngân:
  - Mới giải ngân: dưới 30 ngày.
  - Đủ 1 tháng · cần CS: từ 30 đến dưới 60 ngày.
  - Đủ 2 tháng · cần CS: từ 60 đến dưới 90 ngày.
  - Đủ điều kiện Topup: từ 90 ngày trở lên.
- Đổi nút **Chi tiết** thành **Chăm sóc**.
- Popup Chăm sóc hiển thị trạng thái vòng đời hiện tại.
- Popup dùng vùng cuộn riêng nên xem đầy đủ lịch sử và nút thao tác trên màn hình thấp.

## Lịch chăm sóc tiếp theo
- Chỉ chọn **ngày**, không cần nhập giờ.
- Mỗi lịch hẹn tạo tối đa 2 lần nhắc cho nhân viên phụ trách:
  1. **Trước hạn 3 ngày**.
  2. **Đúng ngày đến hạn**.
- Mỗi mốc chỉ tạo 1 thông báo nhờ khóa UNIQUE trong D1.
- Thông báo xuất hiện ở chuông thông báo CRM; bấm vào sẽ mở module **Chăm sóc khách hàng** và tìm đúng khách.
- Nếu nhân viên tạo lịch chăm sóc mới, các nhắc của lịch cũ được xóa để tránh báo sai hạn.

## D1
- Có migration `0018_loan_care_reminders.sql`.
- Worker vẫn tự tạo bảng/index khi module được dùng nên không bắt buộc chạy migration thủ công.



---

## README_V9.9.md

- Số byte gốc: 723
- SHA-256: `9e4104dade6a28b3b74561a20f0283e7ad55dff10d265ff6039ed28c530a24f6`

# Shinhan Finance - An Đông 4 CRM V9.9

## Cập nhật
- Follow-up bỏ cột Sản phẩm; tách Nhân viên và Team thành hai cột riêng.
- Khách có nguồn LOGIN_APP không còn xuất hiện trong bàn gọi/Chi tiết cuộc gọi của Agent.
- Lead rút gọn KPI còn: Tổng Lead phát sinh, Chưa xử lý, Đã Login App.
- Cập nhật Lead chỉ còn hai hướng mới: Đã Login App hoặc Không Login.
- Đã Login App tự động tạo/chuyển hồ sơ sang module Login App.
- Không Login bắt buộc nhập lý do; lý do được lưu trong lịch sử Lead và hiển thị tại danh sách.
- Giữ tương thích các trạng thái Lead cũ để không mất dữ liệu lịch sử.



---

## README_V10.0.md

- Số byte gốc: 343
- SHA-256: `e5010ae0b10242bdef042692bd86aae59373329de7f1dae2650e7ec0b6f6cd44`

# Shinhan Finance - An Đông 4 CRM V10.0

- Sửa popup Chăm sóc khách hàng: chiều cao theo viewport, nội dung cuộn riêng và luôn xem được phần cuối.
- Bỏ ô/cột Kỳ hạn vay riêng.
- Gộp kỳ hạn vay với Số tiền đóng hàng tháng ở bảng danh sách và popup.
- Cache-busting app.js/app.css v10.0.



---

## README_V10.1.md

- Số byte gốc: 450
- SHA-256: `5e0002f9660784131c5e98d423f023b0ed534b8ce53767541e0e207ea4a76dcf`

# CRM V10.1

- Phóng to cụm tab trạng thái Login App.
- Thu gọn Follow-up cho cân đối hơn.
- Login App hẹn lên lại chỉ chọn ngày, không bắt buộc giờ.
- Khi hồ sơ bị từ chối nhưng có thể lên lại, Follow-up hiển thị “Đã từ chối hồ sơ ngày dd/mm/yyyy” và lý do (nếu có).
- Backfill ghi chú ngày từ chối cho các case REJECT_RETRY cũ khi schema Login App được khởi tạo.



---

## README_V10.2.md

- Số byte gốc: 427
- SHA-256: `a04e7f4e0caddd7382498b769d3d0d495dc2ab9502df22c792b0cd405ebd8a73`

# CRM V10.2

- Chăm sóc khách hàng: modal Admin/Team Leader có thanh cuộn dọc rõ ràng, kéo được toàn bộ nội dung đến phần cuối.
- Thêm fallback cuộn ở lớp modal ngoài để tránh bị kẹt trên màn hình thấp.
- Dashboard không còn bật class template riêng `dashboard-redesign`; dùng cùng sidebar/topbar/main shell với các tab khác.
- Cache-busting app.js/app.css -> v10.2.



---

## README_V10.3.md

- Số byte gốc: 1073
- SHA-256: `839530ab826dba8929249f250ff9a807970039c153d0069cd86a993e6e6912c3`

# Shinhan Finance - An Đông 4 CRM V10.3

## Cập nhật V10.3

### Login App
- Phóng to popup **Thêm khách Login App** và tăng kích thước input/nút/chữ.
- Phóng to tab, bộ lọc và bảng quản lý Login App.
- **SĐT bắt buộc đúng 10 chữ số**.
- **CCCD bắt buộc đúng 12 chữ số**.
- Kiểm tra ở cả giao diện và backend.
- Admin có nút **Xóa** khách khỏi Login App.

### Chăm sóc khách hàng
- Admin có nút **Xóa** từng hồ sơ Chăm sóc khách hàng.
- Khi xóa sẽ xóa lịch sử chăm sóc và nhắc lịch của hồ sơ đó, nhưng không xóa bản ghi khách hàng gốc.

### Follow-up
- Admin có nút **Xóa** từng khách khỏi Follow-up.
- Khi khách đến từ Login App trạng thái hẹn lên lại, xóa Follow-up sẽ chuyển hồ sơ Login App tương ứng sang **Đã loại** để tránh trạng thái treo.

### Phân quyền
- Nút Xóa chỉ hiển thị với Admin.
- Backend cũng chặn Team Leader / Agent gọi API xóa trực tiếp.

Không cần migration D1 mới.



---

## README_V10.4.md

- Số byte gốc: 424
- SHA-256: `93f828b53763492ed9fd8b6cb61e1ea2dd5db4fc33744c0a76c65e6a1d8959a4`

# CRM V10.4

Bugfix chính:
- Sửa lỗi popup Chăm sóc không gắn class scroll ở renderer V9.7+.
- Popup Chăm sóc Admin/Teamlead có thanh cuộn dọc thật trong phần nội dung.
- Bỏ hoàn toàn dashboard-only skin (`dashboard-redesign`) để Bảng điều khiển dùng cùng template/menu active xanh như mọi tab khác.
- Cache bust app.js/app.css lên v10.4.
- Giữ toàn bộ chức năng V10.3.



---

## README_V10.5.md

- Số byte gốc: 808
- SHA-256: `aec900646d41fdb010870df834d6ea630a5969bc1894f89a073a2e32b163da44`

# CRM V10.5

- Toast sau khi ghi nhận chăm sóc nằm phía trên nút Chat, không che bong bóng Chat.
- Trạng thái vòng đời đổi ngay sau khi hoàn thành CS lần 1 / CS lần 2.
- KPI "KH đến ngày TT hôm nay" dùng `next_due_date` (kỳ đầu sau 1 tháng), không dùng ngày trong tháng của ngày giải ngân.
- Sửa Thu hồi Data bị `too many SQL variables` bằng batch nhỏ hơn.
- Login App thêm thông tin KH đã từng vay Shinhan hay chưa.
- KH đủ điều kiện Topup có nút Topup: nhập số tiền muốn vay thêm, tự tạo Login App và đổi trạng thái CSKH sang Topup.
- Follow-up bỏ mã APP cạnh tên khách, phân loại Hồ sơ bị từ chối / Khách hẹn gọi lại.
- Follow-up được đưa lên trước Login App ở sidebar.



---

## README_V10.6.md

- Số byte gốc: 221
- SHA-256: `35cdd39d8b6f59b4a805e1228e1d8364588df6942a0e3a427a19d463b78a21de`

# CRM V10.6

- Quản lý nhóm và nhân viên: bỏ cột Mã NV.
- Thay bằng User (Tên đăng nhập), hiển thị username thực của tài khoản.
- Giữ nguyên các chức năng và dữ liệu của V10.5.



---

## README_V10.7.md

- Số byte gốc: 347
- SHA-256: `4e2b9d924f163810c6c203ac1459b335c0fba449caf37c82414b1bfb41f452a0`

# CRM V10.7

- Số tiền giải ngân và số tiền đóng hàng tháng trong Cập nhật Login App dùng định dạng tiền Việt.
- Tự chèn dấu chấm mỗi 3 số.
- Hỗ trợ nhập nhanh theo nghìn: 10000 -> 10.000.000 VNĐ, 2000 -> 2.000.000 VNĐ khi rời ô nhập.
- Backend/API vẫn nhận giá trị số nguyên VNĐ.



---

## README_V10.8.md

- Số byte gốc: 431
- SHA-256: `f7414bffd046fa8570c59e0aaf9868488a96c952432a55823f4e14d2383f4001`

# CRM V10.8

- Phóng to và căn chỉnh bảng thông tin khách hàng trong Chăm sóc khách hàng.
- Tăng kích thước chữ, khoảng cách hàng, trạng thái, nhân viên phụ trách và nút thao tác.
- Bỏ hai dòng hướng dẫn nhỏ dưới Số tiền giải ngân và Số tiền đóng hàng tháng.
- Giữ nguyên định dạng tiền VNĐ tự động của V10.7.
- Cache-busting app.js/app.css v10.8.



---

## README_V10.9.md

- Số byte gốc: 929
- SHA-256: `3dced20465200cee32a1548a878d8118965bd293310bc28fd9c931e032a840ce`

# CRM V10.9

- D1 database ID cập nhật theo DB người dùng cung cấp.
- Bấm các KPI card Chăm sóc khách hàng để mở đúng danh sách lọc: Tất cả, TT hôm nay, CS lần 1, CS lần 2, Topup, Sắp kết thúc.
- Bấm các KPI card Follow-up để mở đúng Hôm nay / Quá hạn / Sắp tới.
- Bấm các KPI card Login App để mở đúng Đang xử lý / Được duyệt / Follow-up / Đã loại.
- Bấm card Lead phát sinh trên Dashboard sẽ chuyển sang Quản lý Lead với cùng khoảng ngày Dashboard.
- Các ô tổng quan trong Lead có thể bấm để lọc Tổng / Chưa xử lý / Đã Login App.
- Admin và Team Leader tại Login App, Follow-up và Chăm sóc khách hàng có nút Nhắc nhân viên. Nhắc được gửi trực tiếp qua Chat nội bộ đến đúng nhân viên phụ trách.
- Agent vẫn giữ thao tác xử lý khách hàng như hiện tại.



---

## README_V10.11.md

- Số byte gốc: 955
- SHA-256: `f753339749a98b57ea31a75cf635ba42f7adadfc4924f8fc5f4b641c5fe0574d`

# Shinhan Finance - An Đông 4 CRM V10.11

## Login App - Nhập từ Excel

- Thêm nút **Nhập Excel** trực tiếp tại trang Login App.
- Thêm nút **File mẫu** để tải workbook mẫu ngay trong CRM.
- File Excel gồm 5 cột:
  1. Tên khách hàng
  2. SĐT
  3. CCCD
  4. Đã từng vay Shinhan?
  5. User nhân viên
- Kiểm tra trước khi nhập:
  - SĐT đúng 10 số.
  - CCCD đúng 12 số.
  - Đã từng vay Shinhan chỉ nhận Có / Chưa.
  - User nhân viên phải tồn tại và đúng phạm vi phân quyền.
  - Lọc trùng SĐT / CCCD trong file và trong Login App hiện tại.
- Agent có thể để trống User nhân viên; hệ thống tự gán cho chính Agent.
- Admin / Team Leader có thể chọn nhân viên mặc định nếu file không điền User nhân viên.
- Import chạy theo batch để tránh request quá lớn.

File mẫu nằm tại `public/templates/Mau_nhap_Login_App.xlsx`.



---

## README_V10.12.md

- Số byte gốc: 485
- SHA-256: `0917b847bc125ac387ca262cf50c1fdf13e4aeecd0b8d1051a704c242e49f5a4`

# Shinhan Finance - An Đông 4 CRM V10.12

## Login App Excel import
- File Excel chỉ còn 4 cột: Tên khách hàng, SĐT, CCCD, Đã từng vay Shinhan?.
- Không còn cột User nhân viên.
- Agent nhập file: CRM tự gán toàn bộ khách cho chính tài khoản Agent đang đăng nhập.
- Admin / Team Leader nhập file: chọn nhân viên phụ trách ngay trên màn hình import, không cần ghi trong Excel.
- SĐT bắt buộc 10 số, CCCD bắt buộc 12 số.



---

## README_V10.13.md

- Số byte gốc: 886
- SHA-256: `dfdc51340d5234bb5779832e1cb5e8f73683dca019903bc331696d17e6e49f5e`

# Shinhan Finance - An Đông 4 CRM V10.12

## Login App Excel import
- File Excel chỉ còn 4 cột: Tên khách hàng, SĐT, CCCD, Đã từng vay Shinhan?.
- Không còn cột User nhân viên.
- Agent nhập file: CRM tự gán toàn bộ khách cho chính tài khoản Agent đang đăng nhập.
- Admin / Team Leader nhập file: chọn nhân viên phụ trách ngay trên màn hình import, không cần ghi trong Excel.
- SĐT bắt buộc 10 số, CCCD bắt buộc 12 số.


## V10.13
- Import Login App: tự bổ sung đúng 1 số 0 đầu nếu SĐT chỉ còn 9 số hoặc CCCD chỉ còn 11 số; dư số hoặc thiếu nhiều hơn 1 số sẽ báo lỗi và bỏ qua dòng.
- Kho Data: Admin có thể chuyển Data giữa mọi Sale của tất cả Team; Team Leader chỉ được chuyển giữa Sale trong Team mình. Quyền được kiểm tra ở backend.



---

## README_V10.14.md

- Số byte gốc: 614
- SHA-256: `019044d3c9552702a3136deaf581eeed017b41b14a3195653a3d147437ddbbfa`

# Shinhan Finance - An Đông 4 CRM V10.14

## Thay đổi Lead
- Admin và Team Leader không còn nút **Cập nhật**, **+ Ghi chú**, **Lịch sử** tại từng dòng Lead.
- Thay bằng nút **🔔 Nhắc cập nhật** để gửi tin nhắn trực tiếp tới nhân viên đang phụ trách khách hàng.
- Nhân viên Sale vẫn giữ **Cập nhật / + Ghi chú / Lịch sử** để tự xử lý Lead của mình.
- Admin vẫn giữ quyền **Xóa** Lead.
- Team Leader chỉ nhắc được nhân viên trong phạm vi Team theo quyền Chat/backend hiện có.
- Không cần migration D1 mới.



---

## README_V10.15.md

- Số byte gốc: 588
- SHA-256: `097fa7eb68d0578bc2f6fb497644c293ead9314e54bc1221ba8648f991f72d6d`

# CRM V10.15

- Import Login App Excel chỉ còn 3 cột: Tên khách hàng, SĐT, CCCD.
- Bỏ trường “Đã từng vay Shinhan?” khỏi luồng import Excel. Khách nhập từ Excel mặc định giá trị này là Chưa.
- Modal import có chiều cao cố định theo màn hình; danh sách xem trước cuộn riêng.
- Nút Hủy / Nhập vào Login App luôn cố định ở cuối modal, không bị đẩy khỏi màn hình khi file có nhiều khách.
- Vẫn giữ tự sửa thiếu đúng 1 số 0 đầu cho SĐT/CCCD và báo lỗi khi dư/thiếu nhiều hơn.



---

## README_V10.16.md

- Số byte gốc: 830
- SHA-256: `58dec23001018796c11109e3b46c72515df42d2ee7b8ccfd51c65775761b21d2`

# CRM V10.16

Sửa lỗi Login App sau V10.15:

- Sửa modal **Nhập Login App từ Excel** chỉ hiện phần tiêu đề. Nội dung import, chọn file, xem trước và nút nhập hiển thị lại đầy đủ.
- Modal import có vùng cuộn hợp lý; danh sách dài không đẩy nút **Nhập vào Login App** ra khỏi màn hình.
- Bỏ hoàn toàn cột **Đã vay Shinhan** khỏi bảng Login App.
- Bỏ trường **Đã từng vay Shinhan?** khỏi form thêm khách và form cập nhật Login App.
- Backend không còn bắt buộc trường này khi thêm Login App thủ công; dữ liệu cũ vẫn giữ nguyên trong D1 để không phá luồng Topup.
- File Excel import vẫn chỉ cần 3 cột: Tên khách hàng, SĐT, CCCD.
- Cache assets tăng lên V10.16.

Không cần migration D1 mới.



---

## README_V10.17.md

- Số byte gốc: 599
- SHA-256: `5e9012ec7956a1a4df7f5aaa2bab59e7684c46c2798408d2a7d76d2b3ba5a97d`

# CRM V10.17

Cập nhật trang Chăm sóc khách hàng:

- Bỏ dòng mô tả dưới tiêu đề trang.
- Bỏ dropdown chọn Team trong thanh lọc.
- Đưa Team thành các tab chọn ngay dưới tiêu đề.
- Admin thấy `Tất cả Team` và toàn bộ Team đang có trong hệ thống.
- Team Leader chỉ thấy đúng tab Team của mình.
- Nhân viên không có bộ lọc Team và chỉ xem phạm vi dữ liệu của chính mình như trước.
- Khi đổi tab Team, bộ lọc nhân viên được reset và tải lại đúng phạm vi Team.

Không có migration D1 mới.



---

## README_V10.18.md

- Số byte gốc: 726
- SHA-256: `1c645357b32fab0a57a6332a351ec8d39f36f73bf34eea26c6abb43c29e9cb19`

# Shinhan Finance - An Đông 4 CRM V10.18

## Thay đổi
- Thêm bộ lọc **theo tháng** cho 3 module:
  - **Chăm sóc khách hàng**: lọc theo **tháng giải ngân**.
  - **Login App**: lọc theo **tháng tạo Login App**.
  - **Follow-up**: lọc theo **tháng lịch hẹn**.
- Mặc định để trống = **Tất cả tháng**, nên dữ liệu cũ không bị ẩn khi vừa mở trang.
- Có nút **Tất cả** để xóa lọc tháng nhanh.
- Các KPI/card và tab trạng thái trong từng module cập nhật theo tháng đang chọn.
- Không cần migration D1 mới.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```
Sau deploy nên Ctrl+F5 một lần để bỏ cache giao diện cũ.



---

## README_V10.19.md

- Số byte gốc: 487
- SHA-256: `17814c0b4482462ecc786740d0ad57cea600a4b826fcca4fbb62f0c16049a88e`

# Shinhan Finance - An Đông 4 CRM V10.19

## Thay đổi
- Thay bộ chọn tháng native của trình duyệt bằng bộ chọn riêng tiếng Việt.
- Tháng hiển thị dạng **Tháng 1, Tháng 2, ... Tháng 12** thay vì Jan/Feb/Mar.
- Năm hiển thị bằng số riêng, ví dụ **2026**.
- Đổi nút `Clear`/hành vi native thành nút **Xóa chọn**.
- Áp dụng đồng bộ cho Chăm sóc khách hàng, Login App và Follow-up.
- Không thay đổi cấu trúc D1.



---

## README_V10.20.md

- Số byte gốc: 602
- SHA-256: `e0d7593130eefedb1ae797a61aeace060a0505d0eba01fc3c22497808be8fe05`

# An Đông 4 CRM V10.20

## Thay đổi
- Ô **Tổng cuộc gọi** trên Dashboard giờ có thể bấm trực tiếp.
- Khi bấm sẽ mở **Chi tiết cuộc gọi**.
- Giữ nguyên **Từ ngày / Đến ngày** đang chọn trên Dashboard.
- Nếu Admin đang drill-down vào một Team, Chi tiết cuộc gọi tự lọc đúng Team đó.
- Nếu Admin/Teamlead đang xem Dashboard một nhân viên, Chi tiết cuộc gọi tự lọc đúng nhân viên đó.
- Teamlead vẫn chỉ xem dữ liệu Team của mình theo phân quyền backend hiện có.

Không cần migration D1 mới.



---

## README_V10.21.md

- Số byte gốc: 809
- SHA-256: `f05852c7ad1d421525baab52ecbf2e6f628dc039d2461359b847912778083aa2`

# An Đông 4 CRM V10.21

## Login App
Khi cập nhật một khách đã Login App sang bất kỳ một trong 3 kết quả:
- Được duyệt / Giải ngân
- Từ chối · Có thể lên lại
- Từ chối · Không lên lại được

nhân viên bắt buộc nhập:
- Thu nhập
- Nguồn KH: Data / TikTok / Facebook / Thị trường / CTV
- Tên Công ty
- MST
- Nơi ở KH

Nơi ở KH dùng danh sách 34 tỉnh/thành sau sắp xếp và hỗ trợ gõ để tìm nhanh.

Backend kiểm tra các trường này để tránh bỏ qua bằng cách gọi API trực tiếp.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```

Worker tự bổ sung các cột mới khi module Login App được sử dụng. Migration 0020 được kèm theo để đồng bộ cấu trúc dự án.



---

## README_V10.22.md

- Số byte gốc: 731
- SHA-256: `0186166484c603c106a05ee0c1de6c49e3e52640746b135df08b9dd0e1020d24`

# CRM V10.22

- Modal cập nhật Login App có thanh cuộn dọc riêng, không bị mất phần cuối khi form dài; vùng nút lưu được giữ dễ thao tác.
- Chăm sóc khách hàng nhận thêm thông tin từ Login App: Thu nhập, Nguồn KH, Tên công ty, MST, Nơi ở KH.
- Bảng CSKH được gom thông tin theo nhóm Liên hệ / Hồ sơ KH / Công việc / Khoản vay, giảm nhẹ cỡ chữ và dùng table-layout cố định để không cần kéo ngang.
- API /loans lấy hồ sơ Login App đã duyệt gần nhất của khách; có index customer/status để truy vấn ổn định hơn.
- Không yêu cầu migration thủ công; schema Login App tự đảm bảo index khi Worker chạy.



---

## README_V10.23.md

- Số byte gốc: 426
- SHA-256: `06f8e7c33478c947b895df44ee0ee0d090cf31d00c348955a01dfb0eccb9b14f`

# CRM V10.23

- Tăng cỡ chữ tại bảng Chăm sóc khách hàng để rõ và dễ đọc hơn.
- Tăng font cho tiêu đề cột, tên khách hàng, thông tin liên hệ/hồ sơ/công việc/khoản vay, trạng thái và nút thao tác.
- Giữ bảng `table-layout: fixed`, tự xuống dòng và `overflow-x: hidden` để không xuất hiện thanh kéo ngang.
- Không thay đổi dữ liệu hoặc schema D1.



---

## README_V10.24.md

- Số byte gốc: 1058
- SHA-256: `818474bbe064704a511f9767766edabf8f7dce95ffd83aedc36f5c17cebcb68d`

# CRM V10.24 — Mobile / PWA

## Thay đổi
- Cài CRM như ứng dụng PWA trên Android/iPhone.
- Icon An Đông 4 và chế độ standalone toàn màn hình.
- Service Worker dùng network-first để hạn chế giữ bản CRM cũ sau khi deploy.
- Thêm mục `Cài ứng dụng trên điện thoại` trong menu tài khoản và banner cài app trên mobile.
- Sidebar mobile dạng drawer + thanh điều hướng dưới màn hình.
- Login App, Follow-up, Lead và Chăm sóc khách hàng chuyển bảng thành card trên màn hình nhỏ, hạn chế kéo ngang.
- Modal/form tối ưu thao tác trên điện thoại và vùng safe-area iPhone.
- Không thay đổi database, không cần migration D1.

## Cài trên điện thoại
### Android / Chrome
Mở website CRM → bấm `Cài app` hoặc menu Chrome → `Cài đặt ứng dụng` / `Thêm vào màn hình chính`.

### iPhone / Safari
Mở website CRM bằng Safari → Chia sẻ → `Thêm vào Màn hình chính`.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```



---

## README_V10.25.md

- Số byte gốc: 1135
- SHA-256: `763c7da16fc956d28463931fbe71345082d9e84ec3d0ad5f00f5a40a1926781c`

# CRM V10.25 — Mobile Pro

Bản V10.25 tập trung làm giao diện điện thoại giống ứng dụng doanh nghiệp hơn, không thay đổi logic dữ liệu/backend.

## Mobile
- Header gọn kiểu app: menu, tên trang, tìm kiếm, thông báo, avatar.
- Ẩn bộ chọn ngày toàn cục trên header để không chật màn hình; bộ lọc ngày trong từng trang vẫn giữ nguyên.
- Thanh điều hướng dưới màn hình được thiết kế lại, active rõ và dễ bấm một tay.
- Sidebar dạng drawer bo góc, khóa cuộn nền khi mở.
- KPI/summary card 2 cột, khoảng cách và font cân đối hơn.
- Lead / Login App / Follow-up / Chăm sóc khách hàng chuyển thành card rõ ràng, hạn chế kéo ngang.
- Toolbar, tab, bộ lọc tháng và form được tối ưu cho cảm ứng.
- Modal trên điện thoại là bottom-sheet, header cố định và nội dung cuộn dọc.
- Chat và banner cài PWA được thu gọn.

## Desktop
Không thay đổi bố cục desktop V10.24.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```
Không cần migration D1 mới.



---

## README_V10.26.md

- Số byte gốc: 1100
- SHA-256: `a610a7c34596ac531405a0af51fb404859858193dfaa991a3e47bfe203d0a691`

# CRM V10.26 — Sup / Sales / Freelancer

## Thay đổi vai trò
- `Admin` hiển thị thành **Sup**. Quyền backend vẫn giữ role lõi `admin` để không phá dữ liệu cũ.
- `Agent` hiển thị thành **Sales**.
- Thêm **Freelancer**. Freelancer dùng cùng quyền nghiệp vụ với Sales.

## Cách lưu tương thích dữ liệu
- Sales và Freelancer đều dùng role lõi `sale` để toàn bộ phân quyền, KPI, Kho Data, Lead, Login App, Follow-up và CSKH tiếp tục hoạt động như trước.
- Hệ thống tự thêm cột `staff_type` vào bảng `users` lần đầu Worker chạy.
- `staff_type = sales` cho Sales; `staff_type = freelancer` cho Freelancer.
- Tài khoản Sales cũ tự được hiểu là `sales`.

## Nhân sự
- Sup có thể tạo/sửa: Sup, Team Leader, Sales, Freelancer.
- Team Leader có thể thêm Sales hoặc Freelancer trong chính Team mình.
- Bộ lọc Vai trò có riêng Sales và Freelancer.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```
Không cần chạy migration thủ công cho thay đổi này.



---

## README_V10.27.md

- Số byte gốc: 1391
- SHA-256: `97342e533264c92db60d3af0d32fe26b012c57a7cf8703b2254d14f4f435b35d`

# CRM V10.27 — Lead thủ công + Mobile tối ưu

## Lead thủ công
- Thêm nút **+ Thêm Lead thủ công** trong Quản lý Lead.
- Dùng cho khách hàng đến từ Facebook, TikTok, CTV, thị trường, Data... không phát sinh từ cuộc gọi CRM.
- Bắt buộc: Tên khách hàng, SĐT 10 số, Nguồn khách hàng.
- Có thể nhập ghi chú ban đầu.
- Sales/Freelancer: tự gán Lead cho chính tài khoản đang đăng nhập.
- Team Leader: chỉ chọn Sales/Freelancer trong Team mình.
- Sup: chọn Sales/Freelancer toàn hệ thống.
- Lead thủ công được đánh dấu **Thủ công**, không tạo lịch sử cuộc gọi giả.
- Sau khi tạo, quy trình xử lý Lead → Login App giữ nguyên.

## Mobile
- Mở rộng breakpoint app mobile đến 1024px để điện thoại xoay ngang vẫn dùng giao diện mobile.
- Sidebar chuyển thành drawer, có menu dưới màn hình.
- Các bảng Lead / Login App / Follow-up / Chăm sóc khách hàng chuyển thành card, không kéo ngang.
- Form/modal dùng dạng bottom-sheet, trường nhập to và dễ bấm hơn.
- Tối ưu riêng bảng Chăm sóc khách hàng trên màn hình nhỏ.

## Database
- Worker tự bổ sung cột `lead_origin` vào `lead_cases` khi cần.
- Không cần chạy migration thủ công.

## Deploy
```bat
npm.cmd install
npx.cmd wrangler deploy
```



---

## README_V10.28.md

- Số byte gốc: 686
- SHA-256: `a5df4205b4a924e03544d634b6084ffe95bf200e80444206e75c599116a0ad19`

# CRM V10.28

## Phân quyền xóa cho Team Leader

- Sup: xóa Lead, Login App và khách trong Chăm sóc khách hàng trên toàn hệ thống.
- Team Leader: được xóa Lead, Login App và khách trong Chăm sóc khách hàng **chỉ trong Team của mình**.
- Sales / Freelancer: không có quyền xóa.
- Backend kiểm tra phạm vi Team, không chỉ ẩn/hiện nút ở giao diện.
- Xóa Lead chỉ xóa tiến trình/ghi chú quản lý Lead, vẫn giữ customer và call_logs gốc.
- Xóa Chăm sóc khách hàng sẽ xóa hồ sơ khoản vay cùng lịch sử/chăm sóc liên quan của hồ sơ đó như logic hiện tại.
- Không cần migration D1 mới.



---

## README_V10.29.md

- Số byte gốc: 1912
- SHA-256: `db6357a02ab457ac2707fecf4f6649dd26688a96ffe1f91e201bc59e3808b035`

# Shinhan Finance – An Đông 4 CRM V10.29

## Phân quyền theo tài khoản

Trong **Quản lý nhóm và nhân viên**, tài khoản Sup mở tab **Phân quyền truy cập**, chọn tài khoản và tab nghiệp vụ. Tick quyền **Xem, Thêm, Sửa/Cập nhật trạng thái, Xóa, Nhắc nhở, Xuất, Phân công** theo các chức năng có hỗ trợ rồi nhấn **Lưu phân quyền**.

- Sup có quyền toàn hệ thống và quyền thiết lập phân quyền.
- Team Leader chỉ xem/sửa/nhắc/xóa khách trong Team mình dù có thêm quyền thao tác.
- Sales/Freelancer chỉ có phạm vi dữ liệu của chính mình, không tự được nâng thành Sup.
- Team Leader được **Sửa trạng thái Lead**, **Cập nhật kết quả Login App**, và **Sửa hồ sơ CSKH** trong Team (mặc định bật; Sup có thể tắt trên từng tài khoản).
- Các nút tương ứng chỉ xuất hiện khi được cấp quyền, và API backend kiểm tra quyền trước khi ghi dữ liệu.
- Thay đổi quyền được lưu trong bảng D1 `user_access_rules`, có audit `ACCESS_POLICY_UPDATE`.

## Quan trọng

Đây là cơ chế phân quyền thao tác *trong phạm vi vai trò*; không trao quyền xem dữ liệu Team khác cho Team Leader hoặc dữ liệu đồng nghiệp cho Sales/Freelancer. Một số chức năng bị khóa theo role cốt lõi (ví dụ cấu hình phân quyền chỉ thuộc Sup).

Dữ liệu nghiệp vụ hiện có không bị xóa hoặc chuyển đổi. Worker tự tạo bảng phân quyền nếu chưa có (không yêu cầu migration thủ công); đồng thời có migration 0021 nếu cần quản trị D1 bằng Wrangler.

## Deploy

```bat
npm.cmd install
npx.cmd wrangler deploy
```

Sau deploy, Ctrl+F5 trên máy tính; đóng/mở lại PWA trên điện thoại. Worker không tự deploy khi giải nén ZIP.



---

## README_V10.30.md

- Số byte gốc: 2348
- SHA-256: `e5d2012b8bb01bcf2d718c6c4c2edc38c50f0e965b2e74f7556535b6f070db58`

# Shinhan Finance – An Đông 4 CRM V10.30

## V10.29 + sửa lỗi cập nhật Lead

- **Quản lý nhóm và nhân viên → Phân quyền truy cập**: chỉ **Sup** có thể chọn tài khoản và cấp/thu hồi quyền theo module: Xem / Thêm / Sửa, cập nhật trạng thái / Xóa / Nhắc / Xuất / Phân công (tùy module).
- **Sup**: toàn hệ thống theo các quyền cho phép. **Team Leader**: chỉ khách của Team mình kể cả khi được cấp thêm quyền sửa/xóa. **Sales/Freelancer**: chỉ dữ liệu của chính mình.
- Theo quyền đã cấp, người quản lý có thêm nút **Sửa trạng thái** ở Lead và Login App, **Sửa hồ sơ** trong Chăm sóc khách hàng. Thu hồi quyền thì nút không còn hiển thị; API D1 vẫn kiểm tra quyền và phạm vi.
- Thay đổi quyền lưu ở bảng **`user_access_rules`** và có nhật ký audit `ACCESS_POLICY_UPDATE`.
- **Sửa `CHECK constraint failed` khi chọn Lead → Không Login**: bản D1 cũ chỉ cho phép `LOGIN_APP`, `SIGNED`, `HIGH_DEBT`, `BAD_DEBT`, `NEW_DEBT`, `OTHER`. V10.30 thêm `NO_LOGIN` và bảo toàn lịch sử Lead trước đó.
- **Không xóa dữ liệu CRM**, giữ nguyên binding D1. Worker có cơ chế cập nhật ràng buộc Lead khi lần đầu cần ghi trạng thái; không phải chạy migration bằng tay trong quy trình deploy thông thường.

## Lưu ý an toàn

1. **Sao lưu D1 trước deploy** vì bản này có cập nhật cấu trúc bảng lịch sử Lead để giải quyết CHECK constraint.
2. Chỉ giải nén và chạy `npm.cmd install`, `npx.cmd wrangler deploy` trong thư mục dự án.
3. Sau deploy nên Ctrl+F5, trên PWA đóng/mở lại.
4. Test với tài khoản Sales: chuyển một Lead thành **Không Login** có lý do, rồi xem lịch sử. Test Team Leader: chỉ sửa/xóa đúng Team. Test Sup: tick/tắt quyền rồi kiểm tra lại giao diện và thao tác.
5. `migrations/0022_lead_no_login_check.sql` được cung cấp cho việc quản lý migration tập trung, **không cần chạy thêm nếu Worker đã tự nâng bảng**.

Chưa có xác nhận chạy thử trực tiếp trên D1 production; bản cập nhật đã qua kiểm tra cú pháp JavaScript và thử cập nhật bảng bằng SQLite cục bộ.



---

## README_V10.31.md

- Số byte gốc: 4295
- SHA-256: `7f543418b32380dd48e5e9dc3290e2bc74815beae158fdc493e9b1ed4026d9db`

# Shinhan Finance – An Đông 4 CRM V10.31

Nâng cấp trực tiếp từ V10.30, **không thay đổi tên binding D1 hoặc xoá dữ liệu đang có**.

## 1. Phân quyền ngay trên tài khoản nhân viên

- Trong **Quản lý nhóm và nhân viên**, **không còn tab Phân quyền truy cập riêng**.
- Admin thấy nút **Quyền** ở cột **Thao tác** của mỗi tài khoản, ngay cạnh nút sửa.
- Bấm **Quyền** để chỉnh các nhóm chức năng bằng các tab nhỏ trong hộp thoại; tick Xem, Thêm, Sửa/cập nhật trạng thái, Xóa, Nhắc nhở, Xuất, Phân công theo từng nhóm hỗ trợ.
- Bấm **Lưu phân quyền** để lưu trực tiếp vào D1. Các chỉnh sửa chưa lưu được giữ lại khi chuyển nhóm chức năng trong hộp thoại.
- **Team Leader chỉ thao tác trong Team được gán; Sales/Freelancer chỉ trong phạm vi dữ liệu cá nhân.** Việc tick quyền không mở rộng phạm vi Team; Worker kiểm tra lại quyền và phạm vi trên API.
- Hiển thị tên **Admin** thay cho **Sup** ở giao diện (menu, bảng nhân viên, tạo tài khoản, form, thông báo). Giá trị vai trò trong DB vẫn là `admin` — không phải đổi dữ liệu tài khoản.

## 2. Tối ưu tốc độ và giảm chờ

- **Bảng điều khiển, KPI:** tạo chỉ mục cuộc gọi trong bộ nhớ theo nhân viên (thay vì quét toàn bộ lịch sử cho mỗi nhân viên/Team); giữ bộ nhớ kết quả và gộp truy vấn cùng khoảng ngày đang thực hiện.
- **Login App, Chăm sóc khách hàng:** chỉ vẽ **80 hồ sơ mỗi trang**, có Trước/Sau; toàn bộ kết quả vẫn được giữ trong dữ liệu đã tải để tìm kiếm, lọc và tính thẻ tổng hợp. Không giới hạn/xóa dữ liệu D1.
- Khi trở lại Login App/CSKH, ưu tiên hiện dữ liệu đã có và làm mới sau nền theo chu kỳ, tránh màn hình trắng trong khi chờ gọi API. Nút Làm mới và cập nhật hồ sơ vẫn gọi API theo thao tác.
- Giảm tải công việc prefetch khi mới vào CRM.
- **Backend D1:** các truy vấn sửa dữ liệu lịch sử của phiên bản cũ (Lead đã ký, ghi chú Login App từ chối) được đánh dấu đã xử lý trong bảng `crm_maintenance_state` để không quét toàn bộ dữ liệu mỗi lần Cloudflare Worker khởi động. Thêm chỉ mục `idx_loan_care_action_v1031` cho truy vấn trạng thái chăm sóc. Worker tự tạo khi sử dụng, không yêu cầu xoá DB.
- Tăng phiên bản tài nguyên JavaScript/CSS và Service Worker lên **10.31** để tránh PWA giữ bản cũ.

## 3. Cách cập nhật Cloudflare

1. **Nên backup D1 trước khi cập nhật production**. Bản này tạo thêm bảng metadata và một chỉ mục mới; không xoá bảng dữ liệu khách.
2. Giải nén ZIP vào thư mục riêng; bảo đảm file `wrangler.jsonc` vẫn dùng binding D1 đúng tài khoản đang chạy.
3. Mở Terminal/CMD trong thư mục dự án và chạy:

```cmd
npm.cmd install
npx.cmd wrangler deploy
```

4. Trên trình duyệt nhấn **Ctrl + F5**. Nếu đang dùng app đã cài vào điện thoại, đóng/mở lại để cập nhật cache.
5. Kiểm tra ở **Admin → Quản lý nhóm và nhân viên → Quyền**. Thử cấp quyền cập nhật Lead/CSKH cho Team Leader, sau đó xác nhận Team Leader không thể sửa khách của Team khác. Thử chuyển nhiều trang trong Login App và CSKH.

## Kiểm tra được thực hiện

- Kiểm tra cú pháp `public/assets/app.js` và `src/index.js` bằng Node.js.
- Chạy thử giao diện Chromium giả lập local; xác nhận nút phân quyền xuất hiện trên từng tài khoản, không có tab phân quyền riêng, tab chỉnh quyền giữ được dữ liệu chưa lưu, nút lưu hoạt động với phản hồi API mô phỏng.
- Thử 165 hồ sơ Login App và 175 hồ sơ CSKH: 80 hồ sơ/trang; các thao tác ở trang 2 liên kết đúng hồ sơ số 81; không có lỗi JavaScript phát sinh.
- **Chưa thử trực tiếp trên D1 production**, nên tốc độ thực tế vẫn phụ thuộc quy mô dữ liệu, D1 và mạng.



---

## README_V10.32.md

- Số byte gốc: 5521
- SHA-256: `bab6f4454965f3d2a8336301b34f1ce3f3c447cb314afbd9620b61e5b18b0b7a`

# Shinhan Finance – An Đông 4 CRM V10.32

Phiên bản nâng cấp **trực tiếp từ V10.31**; giữ nguyên giao diện, các tối ưu Dashboard/KPI/Login App/CSKH và dữ liệu D1 đang chạy.

## 1. Thêm Sup vào hệ thống vai trò

Thứ tự hiển thị trong bảng Nhân sự, bộ lọc và form tài khoản:
**Admin → Sup → Team Leader → Sales → Freelancer**.

- **Admin:** quản trị cao nhất; tạo/sửa tài khoản Admin và Sup, chỉnh quyền truy cập từng tài khoản, xem Nhật ký.
- **Sup:** quyền điều hành toàn bộ Team, thao tác nghiệp vụ và xem Nhật ký; **không thể tạo/sửa/xóa tài khoản Admin/Sup, không thể sửa phân quyền tài khoản hoặc vào Cài đặt**.
- **Team Leader:** chỉ Team được phân công; Sales/Freelancer: chỉ dữ liệu được giao, không đổi các phạm vi đã áp dụng trước đó.
- Không đổi vai trò của nhân viên hiện tại. Admin có thể tạo Sup trong **Thêm nhân viên → Vai trò: Sup**, hoặc chỉnh một tài khoản hiện có thành Sup.
- **Tương thích DB:** để tránh xây lại bảng `users` trên D1 production (có ràng buộc chỉ nhận `admin/teamlead/sale`), Sup được lưu bằng `users.role='admin'` + `users.staff_type='supervisor'`. Worker chuyển thành vai trò API/UI `sup` và **tự áp quyền Sup theo phiên đã xác thực**. Đây là vai trò riêng biệt ở lớp nghiệp vụ, không phải cho Sup sử dụng toàn quyền Admin.

## 2. CSKH – Xuất Excel

- Nút **⬇ Xuất Excel** ở đầu trang Chăm sóc khách hàng.
- Xuất đầy đủ danh sách thuộc **Team/nhân viên/tháng/nhóm chăm sóc/từ khóa đang lọc**, không chỉ 80 dòng đang hiển thị.
- Các cột gồm tên khách, số điện thoại, CCCD, Team, người phụ trách, hợp đồng, giải ngân, dư nợ, số tiền đóng hàng tháng, kỳ hạn, trạng thái, lịch chăm sóc, thông tin khách hàng.
- Giữ **SĐT/CCCD/MST dạng chuỗi Excel** để không mất số 0 đầu.
- Worker kiểm tra `loanCare.export` ở endpoint `/api/loan-care/export` trước khi ghi nhận hành động và xuất file. Admin có thể cấp/tắt quyền **Xuất** riêng trong phần Quyền của tài khoản.
- Dữ liệu xuất dựa trên danh sách Worker đã tải với giới hạn API hiện tại tối đa 5.000 hồ sơ theo phạm vi lọc. Nếu số hồ sơ lớn hơn, cần thực hiện xuất theo từng Team/tháng hoặc nâng cấp API xuất phân trang.

## 3. Nhật ký thao tác – Chỉ Admin / Sup

- Thêm menu **Nhật ký thao tác** cho Admin và Sup. Team Leader/Sales/Freelancer không thấy menu và bị từ chối **403** nếu trực tiếp gọi API.
- Dữ liệu lưu **trong bảng `audit_logs` D1 hiện có** (không có dữ liệu log giả): thời gian, người thao tác, hành động, nội dung, đối tượng, IP nếu sự kiện có ghi IP.
- Có tìm kiếm, lọc hành động, lọc người dùng, từ/đến ngày, phân trang 80 bản ghi/lần. Có nút Làm mới.
- Các hoạt động mới được ghi nhật ký gồm đăng nhập thành công, đổi mật khẩu, thay đổi quyền, truy cập API không có quyền, tạo/sửa/xóa tài khoản, cập nhật trạng thái Lead, ghi nhận CSKH và xuất Excel CSKH. Nhiều nghiệp vụ cũ như phân phối/thu hồi Data, import, KPI, Login App, xóa Lead/CSKH, thông báo cũng dùng `audit_logs` sẵn có.
- Địa chỉ IP chỉ có ở những sự kiện mới đã bổ sung ghi IP; log lịch sử cũ không thể khôi phục IP. Nhật ký **không** sao chép từng cuộc gọi để tránh tăng Rows Written: các lượt gọi đã có bảng lịch sử `call_logs` riêng.
- Không lưu mật khẩu rõ khi sửa tài khoản trong nhật ký; chỉ lưu `password_changed: true/false`.

## 4. Cập nhật hệ thống

1. **Sao lưu D1 production trước khi triển khai.** Không tạo D1 mới, không đổi `database_id` đang chạy.
2. Giải nén ZIP. Kiểm tra `wrangler.jsonc` giữ nguyên binding `DB` và `database_id` của bạn.
3. Từ thư mục chứa `package.json`, chạy:

   ```cmd
   npm.cmd install
   npx.cmd wrangler deploy
   ```

4. Trên trình duyệt nhấn **Ctrl + F5**, đóng/mở lại PWA nếu cần. Đăng xuất và đăng nhập lại tài khoản vừa đổi vai trò để nhận quyền mới.
5. Admin thử tạo tài khoản Sup, rồi đăng nhập bằng Sup để kiểm tra thấy Nhật ký, không thấy phân quyền. Thử xuất CSKH và mở Excel kiểm tra số 0 đầu ở SĐT/CCCD.

### Kiểm thử

- `node --check` cho Worker và frontend: đạt.
- Chromium mô phỏng giao diện: thứ tự vai trò Admin/Sup, tạo Sup, menu Nhật ký Sup, ẩn Cài đặt/nút Quyền với Sup, hiển thị Xuất Excel CSKH (thử 183 hồ sơ), chuyển trang CSKH/Login App: đạt, không có lỗi JS.
- Kiểm tra API bằng môi trường D1 mô phỏng: Sup được xem Nhật ký; Sales bị 403; Sup bị 403 khi đọc/sửa phân quyền và khi tạo Admin/Sup; Admin tạo Sup được; quyền Xuất CSKH bị từ chối 403 khi Sales chưa được cấp: đạt.
- **Chưa triển khai và chưa chạy thử trên D1 production thật.** Hiệu năng, khối lượng log và tương tác dữ liệu thực cần nghiệm thu sau deploy.



---

## README_V10.33.md

- Số byte gốc: 1395
- SHA-256: `748ebd84ba538596f972f942fdfa4806335742a667c7b7b4e1e38f878ebdff26`

# Shinhan Finance – An Đông 4 CRM V10.33

Cập nhật trực tiếp trên bản V10.32, giữ nguyên Cloudflare Worker, D1, Sup và Nhật ký thao tác.

## Thay đổi

- Bỏ mục **Cài đặt** khỏi sidebar của tất cả vai trò. Đồng thời bỏ khỏi danh sách trang truy cập, nên mở Cài đặt từ điều hướng cũ sẽ quay về Dashboard. Không xóa dữ liệu hay bảng D1.
- Bỏ khối **tài khoản và trạng thái online ở chân sidebar trái**; vùng menu tận dụng hết chiều cao còn lại.
- **Giữ nguyên menu tài khoản góc trên bên phải** với chức năng Đổi mật khẩu, Đăng xuất.
- **Giữ nguyên Nhật ký thao tác** và quyền chỉ Admin/Sup được xem.
- Các tính năng Dashboard, KPI, CSKH/Xuất Excel, Sup, phân quyền trực tiếp tài khoản, Login App, Follow-up giữ nguyên.

## Cài đặt

1. Sao lưu D1 (không bắt buộc đổi hoặc tạo database vì phiên bản này chỉ thay giao diện).
2. Giải nén ZIP; đảm bảo `wrangler.jsonc` đúng binding DB hiện tại.
3. Chạy `npm.cmd install` (nếu chưa cài dependencies) và `npx.cmd wrangler deploy`.
4. Sau deploy nhấn Ctrl+F5 hoặc đóng/mở lại PWA để nhận tài nguyên phiên bản 10.33.

Không có migration D1 mới. Chưa triển khai lên hệ thống production thay người dùng.


---

(Het lich su phien ban cu.)
