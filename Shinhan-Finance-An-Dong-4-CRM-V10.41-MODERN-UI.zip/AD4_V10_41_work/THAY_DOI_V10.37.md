# THAY ĐỔI V10.37

## 1) Lead Login App tách riêng khỏi Lead Telesales
- `Lead Login App` giờ là funnel riêng cho nhân viên tự thêm khách ngoài nguồn telesales.
- Có thể thêm lead thủ công, chọn nguồn, chọn nhân viên phụ trách, cập nhật nguồn ngay trên dòng.
- Lead có 3 trạng thái: `Đang chăm sóc`, `Đã Login App`, `Không login`.
- Khi bấm `Đã Login App`, hệ thống tự chuyển Lead này sang `Danh sách Login App`.

## 2) Follow-up Login App độc lập
- Thêm `Follow-up Login App` riêng, không dùng chung dữ liệu Follow-up Telesales.
- Khi hồ sơ Login App bị từ chối nhưng có ngày lên lại, hệ thống tự tạo / cập nhật lịch Follow-up Login App.
- Có thể tạo lịch thủ công, đánh dấu đã chăm sóc, lọc theo hôm nay / quá hạn / sắp tới.

## 3) Login App cũ nhập từ nhiều tháng trước
- Với hồ sơ `APPROVED` cũ, nếu thời gian tạo và ngày giải ngân lệch lớn, hệ thống ưu tiên dùng `ngày giải ngân` để tính tháng và hiển thị thời gian.
- Giao diện có ghi chú `Theo ngày giải ngân` cho trường hợp này.

## 4) Cải tiến sidebar / dropdown
- Làm lại style sidebar tối hơn, gọn hơn, hiệu ứng accordion mượt hơn.
- Mục con active nổi bật hơn, icon nền trong suốt hơn, giảm cảm giác ô trắng.

## 5) Cải thiện trải nghiệm tab
- Giữ vị trí cuộn tốt hơn khi bấm tab / nhóm lọc ở panel bên phải.

## 6) Audit log
- Bổ sung nhãn audit cho Lead Login App / Follow-up Login App.
- Undo vẫn áp dụng cho các thao tác có lưu snapshot hoàn tác trong vòng 7 ngày.
