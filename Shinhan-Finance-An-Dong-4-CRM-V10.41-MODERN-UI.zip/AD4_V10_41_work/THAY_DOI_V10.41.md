# AN ĐÔNG 4 CRM — NÂNG CẤP V10.41

## Mục tiêu
Chuẩn hóa giao diện hiện tại thành Modern SaaS CRM gọn, rõ, nhất quán và dễ vận hành hằng ngày, theo tài liệu UI/UX mới, nhưng không thay đổi framework, API contract, schema D1, authentication hoặc business logic.

## File mới / chỉnh sửa
- `public/assets/v1041.css`: design system và responsive layer mới.
- `public/assets/v1041.js`: sidebar theo nhóm route thật, accordion, collapse, semantic styling hook.
- `public/index.html`: nạp asset V10.41.
- `public/sw.js`: cache V10.41.
- `package.json`: version 10.41.0.
- `CAP_NHAT_WEB_THAT.cmd`, `README.md`: cập nhật hướng dẫn.

## Điều hướng mới (chỉ dùng route đã có)
- Tổng quan: Dashboard Telesales, Dashboard khách hàng.
- Khách hàng: App Login, Lead, Follow-up, Chăm sóc khách hàng, KPI doanh số.
- Telesales: Chi tiết cuộc gọi, Follow-up Telesales, Lead Telesales, KPI cuộc gọi.
- Quản lý đội ngũ: Nhân viên & nhóm, Kho dữ liệu, Nhập/Xuất dữ liệu (theo quyền hiện hữu).
- Hệ thống: Nhật ký thao tác (theo quyền hiện hữu).

## Bảo toàn hệ thống
- Không thay đổi `src/index.js`.
- Không thay đổi `wrangler.jsonc`.
- Không thêm/sửa migration.
- Không tạo số liệu dashboard hardcode trong production.
- Không tạo route giả cho chức năng chưa có backend.

## Giới hạn
Các hạng mục “Công việc hôm nay”, “Đánh giá điều kiện vay” và “Cấu hình” trong tài liệu mục tiêu chưa được tạo vì workspace hiện tại không có route/backend đã xác minh tương ứng. Khi có API/logic nghiệp vụ thật, có thể nối vào design system V10.41 mà không phải làm lại shell.
