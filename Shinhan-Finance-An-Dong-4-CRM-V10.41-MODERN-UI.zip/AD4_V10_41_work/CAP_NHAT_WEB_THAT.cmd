@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title AD4 CRM V10.41 - CLOUDFARE PRODUCTION

echo =====================================================
echo AD4 CRM V10.41 - TRI EN KHAI WEBSITE THAT

echo =====================================================
echo.
echo Database: an-dong-4-crm
echo Database ID: 9f7223db-3f9b-44c7-b059-9b3a2904b2c4
echo SE DUNG CLOUDFARE D1 PRODUCTION - DU LIEU THAT
echo.
echo KHONG CHAY MIGRATIONS APPLY --REMOTE VI COT 0019 DA TON TAI.
echo.
if not exist "wrangler.jsonc" (
  echo LOI: Khong tim thay wrangler.jsonc. Giai nen lai ZIP.
  pause
  exit /b 1
)
if not exist "src\index.js" (
  echo LOI: Khong tim thay src\index.js. Giai nen lai ZIP.
  pause
  exit /b 1
)
set "ANSWER="
set /p ANSWER=Neu D1 nay la DB THAT can cap nhat, go YES de tiep tuc: 
if /I not "%ANSWER%"=="YES" (
  echo Da huy. Khong sua du lieu.
  pause
  exit /b 0
)
echo.
echo [1/3] Cai dat goi can thiet...
call npm.cmd install
if errorlevel 1 goto ERROR
echo.
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "TIMESTAMP=%%i"
if not defined TIMESTAMP set "TIMESTAMP=%RANDOM%"
set "BACKUP=%~dp0BACKUP_D1_V1041_%TIMESTAMP%.sql"
if exist "%BACKUP%" (
  echo LOI: Da ton tai file sao luu trung ten. Dung de khong ghi de.
  pause
  exit /b 1
)
echo [2/3] Tao ban sao luu database (chi xuat, khong thay doi D1)...
call npx.cmd wrangler d1 export an-dong-4-crm --remote --output "%BACKUP%"
if errorlevel 1 goto ERROR
if not exist "%BACKUP%" (
  echo LOI: Khong thay file BACKUP. KHONG DEPLOY.
  pause
  exit /b 1
)
for %%F in ("%BACKUP%") do if %%~zF LEQ 0 (
  echo LOI: File BACKUP rong. KHONG DEPLOY.
  pause
  exit /b 1
)
echo.
echo Da sao luu thanh cong: "%BACKUP%"
echo BAO MAT: File nay chua thong tin khach hang. KHONG GUI CONG KHAI.
echo.
set "CONFIRM="
set /p CONFIRM=Nhap DEPLOY de cap nhat Workers THAT: 
if /I not "%CONFIRM%"=="DEPLOY" (
  echo Da sao luu, NHUNG CHUA DEPLOY.
  pause
  exit /b 0
)
echo.
echo [3/3] Deploy Workers production (khong chay migrations cu)...
call npx.cmd wrangler deploy
if errorlevel 1 goto ERROR
echo.
echo THANH CONG: Da gui code Workers moi. Vao website, nhan Ctrl+F5.
echo Nho kiem tra du lieu va phan quyen tren trinh duyet.
pause
exit /b 0
:ERROR
echo.
echo LOI: Lenh vua chay that bai. Da dung, KHONG chay cac buoc tiep theo.
echo Kiem tra ket noi Cloudflare, luu log de doi soat.
pause
exit /b 1
