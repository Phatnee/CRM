-- V7.5 - Internal 1:1 chat.
-- One message row per send; no read-receipt updates to avoid unnecessary Rows written.
CREATE TABLE IF NOT EXISTS chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversation_key TEXT NOT NULL,
  sender_user_id INTEGER NOT NULL,
  recipient_user_id INTEGER NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(sender_user_id) REFERENCES users(id),
  FOREIGN KEY(recipient_user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_chat_conversation_id
  ON chat_messages(conversation_key, id);
