-- V6.5: Ghi chú Lead độc lập với trạng thái.
-- Mỗi lần lưu ghi chú chỉ tạo 1 row; không tạo audit row phụ.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS lead_notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  note TEXT NOT NULL,
  created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(created_by) REFERENCES users(id)
);

-- Chỉ một index phục vụ đọc ghi chú theo từng Lead; tránh quét toàn bảng khi mở lịch sử.
CREATE INDEX IF NOT EXISTS idx_lead_notes_customer_time
ON lead_notes(customer_id, created_at DESC, id DESC);
