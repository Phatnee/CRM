-- V9.0 persistent chat unread state.
CREATE TABLE IF NOT EXISTS chat_read_state (
  user_id INTEGER NOT NULL,
  other_user_id INTEGER NOT NULL,
  last_read_message_id INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY(user_id, other_user_id)
);
