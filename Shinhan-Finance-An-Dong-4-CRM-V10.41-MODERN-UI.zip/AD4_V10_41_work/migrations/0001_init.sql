PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  email TEXT,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','teamlead','sale')),
  team_id INTEGER,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(team_id) REFERENCES teams(id)
);

CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_code TEXT,
  full_name TEXT NOT NULL,
  phone TEXT,
  phone_normalized TEXT,
  source TEXT,
  team_id INTEGER,
  assigned_user_id INTEGER,
  status TEXT NOT NULL DEFAULT 'NEW',
  received_at TEXT,
  follow_up_at TEXT,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(team_id) REFERENCES teams(id),
  FOREIGN KEY(assigned_user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_customers_team ON customers(team_id);
CREATE INDEX IF NOT EXISTS idx_customers_owner ON customers(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone_normalized);
CREATE INDEX IF NOT EXISTS idx_customers_followup ON customers(follow_up_at);

CREATE TABLE IF NOT EXISTS call_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  status TEXT NOT NULL,
  note TEXT,
  follow_up_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_calls_customer ON call_logs(customer_id);
CREATE INDEX IF NOT EXISTS idx_calls_created ON call_logs(created_at);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id INTEGER,
  detail TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id)
);

INSERT OR IGNORE INTO teams(id,name) VALUES
  (1,'Mobility 1'),(3,'Mobility 3'),(5,'Mobility 5'),(6,'Mobility 6');

-- Demo accounts. Change passwords before production.
-- admin / admin123 ; lead5 / lead123 ; sale5 / sale123
INSERT OR IGNORE INTO users(id,username,display_name,password_hash,role,team_id) VALUES
  (1,'admin','Quản trị An Đông 4','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9','admin',NULL),
  (2,'lead5','Teamlead Mobility 5','5830aa9ba1fd7843c92fd956cb640604e6d3bff683ddeeac778e0af21089a303','teamlead',5),
  (3,'sale5','Phan Thị Đan Vy','eebfdf399da8f2bb47d242749bfba58d45a949e2b1e872de696eb740f00b9a66','sale',5),
  (4,'vy','Nguyễn Thị Tường Vy','eebfdf399da8f2bb47d242749bfba58d45a949e2b1e872de696eb740f00b9a66','sale',5),
  (5,'viet','Lữ Quốc Việt','eebfdf399da8f2bb47d242749bfba58d45a949e2b1e872de696eb740f00b9a66','sale',5),
  (6,'minhanh','Lương Tuệ Minh Anh','eebfdf399da8f2bb47d242749bfba58d45a949e2b1e872de696eb740f00b9a66','sale',5),
  (7,'nhu','Võ Tường Như','eebfdf399da8f2bb47d242749bfba58d45a949e2b1e872de696eb740f00b9a66','sale',5),
  (8,'nha','Hồ Phan Hồng Nhã','eebfdf399da8f2bb47d242749bfba58d45a949e2b1e872de696eb740f00b9a66','sale',5),
  (9,'ly','Đỗ Thị Trúc Ly','eebfdf399da8f2bb47d242749bfba58d45a949e2b1e872de696eb740f00b9a66','sale',5);

INSERT INTO customers(customer_code,full_name,phone,phone_normalized,source,team_id,assigned_user_id,status,received_at,follow_up_at,note)
SELECT 'KH0001','Nguyễn Văn An','0901 23x xxx','090123xxxx','LNL',5,3,'Y01','2026-10-01','2026-10-05T15:30','Khách cần tư vấn khoản vay 100 triệu.'
WHERE NOT EXISTS (SELECT 1 FROM customers);
INSERT INTO customers(customer_code,full_name,phone,phone_normalized,source,team_id,assigned_user_id,status,received_at,follow_up_at,note) VALUES
('KH0002','Trần Thị Bình','0932 41x xxx','093241xxxx','FLC',5,9,'N02','2026-10-01','2026-10-05T16:00','Không nghe máy, gọi lại chiều.'),
('KH0005','Võ Thị Hạnh','0977 12x xxx','097712xxxx','FLC',5,6,'Y01','2026-10-02','2026-10-05T14:45','Đã gửi thông tin hồ sơ.'),
('KH0008','Huỳnh Gia Minh','0888 73x xxx','088873xxxx','FLC',5,5,'NEW','2026-10-03',NULL,''),
('KH0009','Đỗ Ngọc Mai','0923 67x xxx','092367xxxx','LNL',5,8,'Y05','2026-10-04','2026-10-06T13:30','Khách đang bận.'),
('KH0011','Trương Khánh Ngọc','0938 94x xxx','093894xxxx','FLC',5,7,'N02','2026-10-05','2026-10-05T15:10','Gọi lại sau 15h.'),
('KH0012','Nguyễn Hoài Phương','0906 44x xxx','090644xxxx','LNL',5,3,'NEW','2026-10-05',NULL,'');
