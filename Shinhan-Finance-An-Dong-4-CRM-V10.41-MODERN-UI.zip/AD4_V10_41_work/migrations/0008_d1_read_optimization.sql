-- V5.4: targeted indexes for hot read paths. No customer or call records are altered.
-- Applying once incurs index-building writes; future SELECT scans should be much smaller.
CREATE INDEX IF NOT EXISTS idx_calls_user_created ON call_logs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_calls_customer_user_created ON call_logs(customer_id, user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_customers_state_deadline ON customers(data_state, assignment_deadline);
CREATE INDEX IF NOT EXISTS idx_customers_team_state ON customers(team_id, data_state);
-- Keep raw-number duplicates fast for old records which have not been normalized.
CREATE INDEX IF NOT EXISTS idx_customers_phone_raw ON customers(phone);
