-- V8.7 persistent bulk jobs (runtime also ensures this table exists)
CREATE TABLE IF NOT EXISTS bulk_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'RUNNING',
  created_by INTEGER NOT NULL,
  team_id INTEGER,
  total_count INTEGER NOT NULL DEFAULT 0,
  processed_count INTEGER NOT NULL DEFAULT 0,
  payload_json TEXT NOT NULL,
  locked_until TEXT,
  last_error TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at TEXT,
  FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_bulk_jobs_status ON bulk_jobs(status,updated_at);
CREATE INDEX IF NOT EXISTS idx_bulk_jobs_creator ON bulk_jobs(created_by,status,id);
