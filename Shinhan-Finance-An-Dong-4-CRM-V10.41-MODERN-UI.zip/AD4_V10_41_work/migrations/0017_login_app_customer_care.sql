-- V9.7: Login App workflow.
-- cccd/monthly_payment on loan_profiles are added safely by ensureLoanCareSchema at runtime
-- so this migration remains idempotent for databases where the module has already been opened.
CREATE TABLE IF NOT EXISTS login_app_cases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER,
  team_id INTEGER,
  assigned_user_id INTEGER NOT NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  phone_normalized TEXT,
  cccd TEXT,
  status TEXT NOT NULL DEFAULT 'LOGIN_APP',
  retry_at TEXT,
  reject_reason TEXT,
  disbursement_amount REAL NOT NULL DEFAULT 0,
  monthly_payment REAL NOT NULL DEFAULT 0,
  disbursement_date TEXT,
  term_months INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER NOT NULL,
  approved_at TEXT,
  closed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(team_id) REFERENCES teams(id),
  FOREIGN KEY(assigned_user_id) REFERENCES users(id),
  FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_login_app_team ON login_app_cases(team_id,status,updated_at);
CREATE INDEX IF NOT EXISTS idx_login_app_user ON login_app_cases(assigned_user_id,status,updated_at);
CREATE INDEX IF NOT EXISTS idx_login_app_phone ON login_app_cases(phone_normalized);
