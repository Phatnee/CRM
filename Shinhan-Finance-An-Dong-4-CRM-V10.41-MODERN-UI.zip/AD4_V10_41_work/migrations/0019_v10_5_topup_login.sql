-- V10.5: Login App prior Shinhan + Topup workflow
ALTER TABLE login_app_cases ADD COLUMN has_prior_shinhan INTEGER NOT NULL DEFAULT 0;
ALTER TABLE login_app_cases ADD COLUMN topup_requested_amount REAL NOT NULL DEFAULT 0;
ALTER TABLE login_app_cases ADD COLUMN source_loan_id INTEGER;
ALTER TABLE loan_profiles ADD COLUMN topup_requested_amount REAL NOT NULL DEFAULT 0;
ALTER TABLE loan_profiles ADD COLUMN topup_at TEXT;
