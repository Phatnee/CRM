-- V5.0: repair KHTN tables if an earlier KHTN migration was not applied.
-- The V5.0 Worker also self-checks these tables at runtime, so this migration is safe/redundant.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS khtn_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  team_id INTEGER,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  phone_normalized TEXT,
  birth_year TEXT,
  area TEXT,
  occupation TEXT,
  average_income TEXT,
  cccd TEXT,
  source TEXT NOT NULL,
  note TEXT,
  expected_login_date TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(team_id) REFERENCES teams(id)
);

CREATE TABLE IF NOT EXISTS khtn_form_config (
  id INTEGER PRIMARY KEY CHECK(id = 1),
  config_json TEXT NOT NULL,
  updated_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(updated_by) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_khtn_user ON khtn_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_khtn_team ON khtn_entries(team_id);
CREATE INDEX IF NOT EXISTS idx_khtn_created ON khtn_entries(created_at);
CREATE INDEX IF NOT EXISTS idx_khtn_phone ON khtn_entries(phone_normalized);
