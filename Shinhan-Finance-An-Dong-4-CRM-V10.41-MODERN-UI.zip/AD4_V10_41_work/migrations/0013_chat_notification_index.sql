-- V7.7 - Efficient incoming-chat notification polling.
-- This index avoids scanning all chat messages when a user checks for new incoming messages.
CREATE INDEX IF NOT EXISTS idx_chat_recipient_id
  ON chat_messages(recipient_user_id, id);
