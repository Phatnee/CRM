-- V10.34: Seven-day recovery snapshots, separate from immutable audit history.
CREATE TABLE IF NOT EXISTS audit_undo (
 audit_id INTEGER PRIMARY KEY, action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL,
 before_json TEXT NOT NULL, after_json TEXT NOT NULL,
 expires_at TEXT NOT NULL DEFAULT (datetime('now','+7 days')),
 undone_at TEXT, undone_by INTEGER,
 FOREIGN KEY(audit_id) REFERENCES audit_logs(id)
);
CREATE INDEX IF NOT EXISTS idx_audit_undo_expiration ON audit_undo(expires_at);
