PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS data_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT OR IGNORE INTO data_categories(name) VALUES ('Data loại 1'),('Data loại 2');

ALTER TABLE customers ADD COLUMN data_category_id INTEGER;
ALTER TABLE customers ADD COLUMN assignment_deadline TEXT;
ALTER TABLE customers ADD COLUMN assignment_round INTEGER NOT NULL DEFAULT 0;
ALTER TABLE customers ADD COLUMN last_assigned_user_id INTEGER;

CREATE INDEX IF NOT EXISTS idx_customers_category ON customers(data_category_id);
CREATE INDEX IF NOT EXISTS idx_customers_deadline ON customers(assignment_deadline);
CREATE INDEX IF NOT EXISTS idx_customers_round ON customers(assignment_round);

CREATE TABLE IF NOT EXISTS assignment_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  team_id INTEGER,
  category_id INTEGER,
  round_no INTEGER NOT NULL DEFAULT 1,
  assigned_at TEXT NOT NULL DEFAULT (datetime('now')),
  deadline_at TEXT,
  completed_at TEXT,
  returned_at TEXT,
  return_reason TEXT,
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(team_id) REFERENCES teams(id),
  FOREIGN KEY(category_id) REFERENCES data_categories(id)
);

CREATE INDEX IF NOT EXISTS idx_assignment_history_customer ON assignment_history(customer_id);
CREATE INDEX IF NOT EXISTS idx_assignment_history_user ON assignment_history(user_id);
CREATE INDEX IF NOT EXISTS idx_assignment_history_category ON assignment_history(category_id);
CREATE INDEX IF NOT EXISTS idx_assignment_history_deadline ON assignment_history(deadline_at);
