-- V6.3: Lead pipeline replacing KHTN + daily report.
-- A Lead is created only when a customer reaches Y01/Y02. Status changes are immutable history rows.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS lead_cases (
  customer_id INTEGER PRIMARY KEY,
  source_call_status TEXT NOT NULL CHECK(source_call_status IN ('Y01','Y02')),
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(created_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS lead_status_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('LOGIN_APP','SIGNED','HIGH_DEBT','BAD_DEBT','NEW_DEBT','OTHER')),
  reason TEXT,
  changed_by INTEGER NOT NULL,
  changed_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(changed_by) REFERENCES users(id)
);

-- One useful index only: history for a single Lead and latest-status lookup.
CREATE INDEX IF NOT EXISTS idx_lead_history_customer_time
ON lead_status_history(customer_id, changed_at DESC, id DESC);

-- Backfill each historical customer that ever reached Y01/Y02, one Lead row per customer.
-- This scan/write happens once during migration; normal usage is lazy and incremental.
WITH ranked AS (
  SELECT customer_id,status,user_id,created_at,
         ROW_NUMBER() OVER(PARTITION BY customer_id ORDER BY created_at ASC,id ASC) AS rn
  FROM call_logs
  WHERE status IN ('Y01','Y02')
)
INSERT OR IGNORE INTO lead_cases(customer_id,source_call_status,created_by,created_at)
SELECT customer_id,status,user_id,created_at FROM ranked WHERE rn=1;

-- Fallback for old/imported rows whose current status is Y01/Y02 but have no call_log.
INSERT OR IGNORE INTO lead_cases(customer_id,source_call_status,created_by,created_at)
SELECT id,status,assigned_user_id,COALESCE(updated_at,created_at,datetime('now'))
FROM customers
WHERE status IN ('Y01','Y02');
