-- V10.21: bổ sung thông tin khách hàng bắt buộc khi cập nhật Login App.
ALTER TABLE login_app_cases ADD COLUMN income_amount REAL NOT NULL DEFAULT 0;
ALTER TABLE login_app_cases ADD COLUMN customer_source TEXT;
ALTER TABLE login_app_cases ADD COLUMN company_name TEXT;
ALTER TABLE login_app_cases ADD COLUMN company_tax_code TEXT;
ALTER TABLE login_app_cases ADD COLUMN residence_province TEXT;
