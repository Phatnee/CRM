-- V10.29: Quyền module/thao tác theo tài khoản, scope vẫn do role và Team quyết định.
-- Worker cũng tự tạo bảng nếu chưa chạy migration thủ công.
CREATE TABLE IF NOT EXISTS user_access_rules (
  user_id INTEGER NOT NULL,
  module TEXT NOT NULL,
  action TEXT NOT NULL,
  allowed INTEGER NOT NULL CHECK (allowed IN (0,1)),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id,module,action)
);
