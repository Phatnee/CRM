CREATE TABLE IF NOT EXISTS loan_care_reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  loan_id INTEGER NOT NULL,
  recipient_user_id INTEGER NOT NULL,
  due_date TEXT NOT NULL,
  reminder_type TEXT NOT NULL,
  read_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(loan_id, recipient_user_id, due_date, reminder_type),
  FOREIGN KEY(loan_id) REFERENCES loan_profiles(id),
  FOREIGN KEY(recipient_user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_loan_care_reminder_user
  ON loan_care_reminders(recipient_user_id, read_at, id);
CREATE INDEX IF NOT EXISTS idx_loan_care_reminder_due
  ON loan_care_reminders(due_date, reminder_type);
