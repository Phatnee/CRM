PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS kpi_targets (
  user_id INTEGER PRIMARY KEY,
  calls_daily INTEGER NOT NULL DEFAULT 50,
  processed_daily INTEGER NOT NULL DEFAULT 50,
  connect_rate_target REAL NOT NULL DEFAULT 50,
  y01_daily INTEGER NOT NULL DEFAULT 5,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_kpi_targets_user ON kpi_targets(user_id);
