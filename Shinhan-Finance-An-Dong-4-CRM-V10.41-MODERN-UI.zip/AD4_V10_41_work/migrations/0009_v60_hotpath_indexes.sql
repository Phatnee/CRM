-- V6.0: minimal hot-path indexes selected to reduce Rows read without adding excessive index-write overhead.
-- One-time index build may use some Rows written; normal operation keeps only the indexes that materially help new hot paths.
CREATE INDEX IF NOT EXISTS idx_customers_team_owner_status ON customers(team_id, assigned_user_id, status);
CREATE INDEX IF NOT EXISTS idx_calls_customer_created_id ON call_logs(customer_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_assignment_customer_user_open ON assignment_history(customer_id, user_id, completed_at, returned_at, id DESC);
