CREATE TABLE IF NOT EXISTS loan_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL UNIQUE,
  team_id INTEGER,
  assigned_user_id INTEGER,
  contract_code TEXT,
  disbursement_date TEXT,
  disbursement_amount REAL NOT NULL DEFAULT 0,
  original_term_months INTEGER NOT NULL DEFAULT 0,
  monthly_due_day INTEGER,
  maturity_date TEXT,
  current_balance REAL NOT NULL DEFAULT 0,
  next_due_date TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  reloan_eligible INTEGER NOT NULL DEFAULT 0,
  note TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(team_id) REFERENCES teams(id),
  FOREIGN KEY(assigned_user_id) REFERENCES users(id),
  FOREIGN KEY(created_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS loan_care_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  loan_id INTEGER NOT NULL,
  customer_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  action_type TEXT NOT NULL DEFAULT 'CARE',
  result TEXT,
  note TEXT,
  next_follow_up_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(loan_id) REFERENCES loan_profiles(id),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS loan_payment_schedule (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  loan_id INTEGER NOT NULL,
  due_date TEXT NOT NULL,
  amount_due REAL NOT NULL DEFAULT 0,
  amount_paid REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'PENDING',
  paid_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(loan_id,due_date),
  FOREIGN KEY(loan_id) REFERENCES loan_profiles(id)
);
CREATE INDEX IF NOT EXISTS idx_loan_profiles_team ON loan_profiles(team_id);
CREATE INDEX IF NOT EXISTS idx_loan_profiles_user ON loan_profiles(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_loan_profiles_status ON loan_profiles(status);
CREATE INDEX IF NOT EXISTS idx_loan_profiles_next_due ON loan_profiles(next_due_date);
CREATE INDEX IF NOT EXISTS idx_loan_care_loan ON loan_care_logs(loan_id,created_at);
CREATE INDEX IF NOT EXISTS idx_loan_schedule_due ON loan_payment_schedule(loan_id,due_date);
