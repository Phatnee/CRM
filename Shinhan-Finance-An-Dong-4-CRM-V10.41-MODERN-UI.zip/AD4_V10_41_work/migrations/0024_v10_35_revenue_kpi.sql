-- V10.35: Monthly Login App / disbursement KPI; does not modify any existing records.
CREATE TABLE IF NOT EXISTS revenue_kpi_targets (
  user_id INTEGER NOT NULL,
  month TEXT NOT NULL,
  target_volume INTEGER NOT NULL DEFAULT 0,
  target_loans INTEGER NOT NULL DEFAULT 0,
  target_apps INTEGER NOT NULL DEFAULT 0,
  updated_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, month)
);
