PRAGMA foreign_keys = ON;

ALTER TABLE customers ADD COLUMN data_state TEXT NOT NULL DEFAULT 'ASSIGNED';
ALTER TABLE customers ADD COLUMN archived_at TEXT;

UPDATE customers
SET data_state = CASE WHEN assigned_user_id IS NULL THEN 'POOL' ELSE 'ASSIGNED' END
WHERE data_state IS NULL OR data_state = '' OR data_state = 'ASSIGNED';

CREATE INDEX IF NOT EXISTS idx_customers_data_state ON customers(data_state);
CREATE INDEX IF NOT EXISTS idx_customers_archived_at ON customers(archived_at);
