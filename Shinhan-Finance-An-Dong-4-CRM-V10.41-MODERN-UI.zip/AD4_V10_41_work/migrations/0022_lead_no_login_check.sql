-- V10.30: Preserve all Lead history and expand the status CHECK to NO_LOGIN.
-- Existing Workers can also apply this upgrade automatically at first Lead status update.
CREATE TABLE lead_status_history_v1030 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('LOGIN_APP','NO_LOGIN','SIGNED','HIGH_DEBT','BAD_DEBT','NEW_DEBT','OTHER')),
  reason TEXT,
  changed_by INTEGER NOT NULL,
  changed_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES customers(id),
  FOREIGN KEY(changed_by) REFERENCES users(id)
);
INSERT INTO lead_status_history_v1030(id,customer_id,status,reason,changed_by,changed_at)
 SELECT id,customer_id,status,reason,changed_by,changed_at FROM lead_status_history;
DROP TABLE lead_status_history;
ALTER TABLE lead_status_history_v1030 RENAME TO lead_status_history;
CREATE INDEX IF NOT EXISTS idx_lead_history_customer_time
 ON lead_status_history(customer_id, changed_at DESC,id DESC);
