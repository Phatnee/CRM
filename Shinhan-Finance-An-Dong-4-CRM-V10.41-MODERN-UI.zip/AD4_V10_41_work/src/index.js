const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8',...headers}});
const bad = (msg, status=400) => json({error:msg}, status);
const textEncoder = new TextEncoder();
const PBKDF2_ITERATIONS = 100000; // Cloudflare Workers WebCrypto supports up to 100,000 PBKDF2 iterations.

const hex = bytes => [...bytes].map(x=>x.toString(16).padStart(2,'0')).join('');
const randomHex = (n=16) => { const b=new Uint8Array(n); crypto.getRandomValues(b); return hex(b); };
const sha256 = async (s) => {
  const b = await crypto.subtle.digest('SHA-256', textEncoder.encode(s));
  return hex(new Uint8Array(b));
};
async function hashPassword(password){
  const iterations=PBKDF2_ITERATIONS, salt=randomHex(16);
  const key=await crypto.subtle.importKey('raw',textEncoder.encode(password),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:textEncoder.encode(salt),iterations},key,256);
  return `pbkdf2$${iterations}$${salt}$${hex(new Uint8Array(bits))}`;
}
async function verifyPassword(password, stored){
  if(!stored) return false;
  if(/^([0-9a-f]{64})$/i.test(stored)) return (await sha256(password))===stored.toLowerCase();
  const parts=stored.split('$'); if(parts.length!==4||parts[0]!=='pbkdf2') return false;
  const iterations=Number(parts[1]), salt=parts[2], expected=parts[3];
  if(!Number.isInteger(iterations) || iterations < 1 || iterations > PBKDF2_ITERATIONS) return false;
  const key=await crypto.subtle.importKey('raw',textEncoder.encode(password),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:textEncoder.encode(salt),iterations},key,256);
  return hex(new Uint8Array(bits))===expected;
}
const token = () => crypto.randomUUID()+crypto.randomUUID();
const normalizePhone = value => {
  let s=String(value??'').replace(/\D/g,'');
  if(s.startsWith('84') && s.length>=11) s='0'+s.slice(2);
  if(s.length===9 && /^[35789]/.test(s)) s='0'+s;
  return s;
};
const normalizeLoginAppImportPhone = value => {
  let s=String(value??'').replace(/\D/g,'');
  if(s.startsWith('84') && s.length===11) s='0'+s.slice(2);
  if(s.length===9) s='0'+s;
  return s;
};
const normalizeLoginAppImportCccd = value => {
  let s=String(value??'').replace(/\D/g,'');
  if(s.length===11) s='0'+s;
  return s;
};
const normalizeStatus = value => {
  const s=String(value??'').trim().toUpperCase();
  const m=s.match(/^(NEW|Y0[1-6]|N0[1-4])/); return m?m[1]:'NEW';
};
const cleanText = v => String(v??'').trim();
let userStaffSchemaReady=false,userStaffSchemaPromise=null;
async function ensureUserStaffSchema(env){
  if(userStaffSchemaReady) return;
  if(!userStaffSchemaPromise){
    userStaffSchemaPromise=(async()=>{
      const info=await env.DB.prepare('PRAGMA table_info(users)').all();
      if(!(info.results||[]).some(x=>x.name==='staff_type')){
        try{await env.DB.prepare("ALTER TABLE users ADD COLUMN staff_type TEXT NOT NULL DEFAULT 'sales'").run();}
        catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}
      }
      userStaffSchemaReady=true;
    })();
  }
  try{await userStaffSchemaPromise;}finally{if(!userStaffSchemaReady) userStaffSchemaPromise=null;}
}
const effectiveRole = user => user?.role==='admin' && user?.staff_type==='supervisor' ? 'sup' : user?.role;
const isManager = session => session?.role==='admin'||session?.role==='sup';
function normalizeRequestedUserRole(value,staffTypeValue=''){
  const raw=cleanText(value||'sale').toLowerCase();
  if(raw==='sup') return {role:'admin',staff_type:'supervisor'};
  if(raw==='admin') return {role:'admin',staff_type:null};
  if(raw==='teamlead'||raw==='team leader') return {role:'teamlead',staff_type:null};
  const explicitStaff=cleanText(staffTypeValue).toLowerCase();
  if(raw==='freelancer'||explicitStaff==='freelancer') return {role:'sale',staff_type:'freelancer'};
  if(raw==='sale'||raw==='sales'||raw==='agent') return {role:'sale',staff_type:'sales'};
  return null;
}
const LOGIN_APP_CUSTOMER_SOURCES=['Data','TikTok','Facebook','Thị trường','CTV'];
const VIETNAM_PROVINCES_2025=[
  'Hà Nội','Hải Phòng','Huế','Đà Nẵng','Cần Thơ','Thành phố Hồ Chí Minh',
  'Lai Châu','Điện Biên','Sơn La','Lạng Sơn','Cao Bằng','Tuyên Quang','Lào Cai','Thái Nguyên','Phú Thọ','Bắc Ninh','Hưng Yên','Ninh Bình',
  'Quảng Ninh','Thanh Hóa','Nghệ An','Hà Tĩnh','Quảng Trị','Quảng Ngãi','Gia Lai','Khánh Hòa','Lâm Đồng','Đắk Lắk','Đồng Nai','Tây Ninh',
  'Vĩnh Long','Đồng Tháp','Cà Mau','An Giang'
];
const norm = v => cleanText(v).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/\s+/g,' ');
const KHTN_FIELD_KEYS=['customer_name','phone','birth_year','area','occupation','average_income','cccd','source','note','expected_login_date'];
const KHTN_CORE_FIELDS=new Set(['customer_name','phone','source']);
const KHTN_ALLOWED_TYPES=new Set(['text','number','date','textarea','select']);
const KHTN_DEFAULT_CONFIG={
  fields:{
    customer_name:{label:'Họ và tên khách hàng',enabled:true,required:true,type:'text'},
    phone:{label:'Số điện thoại',enabled:true,required:true,type:'text'},
    birth_year:{label:'Năm sinh',enabled:true,required:false,type:'number'},
    area:{label:'Khu vực sinh sống',enabled:true,required:false,type:'text'},
    occupation:{label:'Nghề nghiệp',enabled:true,required:false,type:'text'},
    average_income:{label:'Thu nhập trung bình',enabled:true,required:false,type:'text'},
    cccd:{label:'CCCD',enabled:true,required:false,type:'text'},
    source:{label:'Nguồn KHTN',enabled:true,required:true,type:'select'},
    note:{label:'Ghi chú',enabled:true,required:false,type:'textarea'},
    expected_login_date:{label:'Dự kiến login',enabled:true,required:false,type:'date'}
  },
  field_order:['customer_name','phone','birth_year','area','occupation','average_income','cccd','source','note','expected_login_date'],
  source_options:['Telesale','CTV','Khách giới thiệu','Facebook','TikTok','Khác']
};
const safeJsonObject=(value,fallback={})=>{try{const x=typeof value==='string'?JSON.parse(value):value;return x&&typeof x==='object'&&!Array.isArray(x)?x:fallback}catch{return fallback}};
const safeJsonArray=value=>{try{const x=JSON.parse(value||'[]');return Array.isArray(x)?x:[]}catch{return []}};
function sanitizeKhtnConfig(raw){
  const cfg={fields:{},field_order:[],source_options:[]};
  const input=(raw&&typeof raw==='object')?raw:{};
  for(const key of KHTN_FIELD_KEYS){
    const base=KHTN_DEFAULT_CONFIG.fields[key], src=input.fields?.[key]||{};
    cfg.fields[key]={
      label:cleanText(src.label||base.label).slice(0,80)||base.label,
      enabled:src.enabled===undefined?base.enabled:!!src.enabled,
      required:src.required===undefined?base.required:!!src.required,
      type:base.type
    };
  }
  let customCount=0;
  for(const [key,src0] of Object.entries(input.fields||{})){
    if(KHTN_FIELD_KEYS.includes(key)||!/^custom_[a-z0-9_]{3,50}$/i.test(key)||customCount>=30) continue;
    const src=src0&&typeof src0==='object'?src0:{};
    const type=KHTN_ALLOWED_TYPES.has(src.type)?src.type:'text';
    const options=Array.isArray(src.options)?[...new Set(src.options.map(cleanText).filter(Boolean).map(x=>x.slice(0,100)))].slice(0,100):[];
    cfg.fields[key]={label:cleanText(src.label||'Trường mới').slice(0,80)||'Trường mới',enabled:src.enabled!==false,required:!!src.required,type,options};
    customCount++;
  }
  for(const key of KHTN_CORE_FIELDS){cfg.fields[key].enabled=true;cfg.fields[key].required=true;}
  const requestedOrder=Array.isArray(input.field_order)?input.field_order.map(cleanText):null;
  const fallbackOrder=[...KHTN_FIELD_KEYS,...Object.keys(cfg.fields).filter(k=>!KHTN_FIELD_KEYS.includes(k))].filter(k=>cfg.fields[k]?.enabled!==false);
  const order=requestedOrder||fallbackOrder;
  for(const key of order){if(cfg.fields[key]&&cfg.fields[key].enabled!==false&&!cfg.field_order.includes(key)) cfg.field_order.push(key);}
  for(const key of ['customer_name','phone','source']) if(!cfg.field_order.includes(key)) cfg.field_order.unshift(key);
  const options=Array.isArray(input.source_options)?input.source_options:KHTN_DEFAULT_CONFIG.source_options;
  cfg.source_options=[...new Set(options.map(cleanText).filter(Boolean).map(x=>x.slice(0,80)))].slice(0,50);
  if(!cfg.source_options.length) cfg.source_options=[...KHTN_DEFAULT_CONFIG.source_options];
  return cfg;
}
let khtnSchemaReady=false, khtnSchemaPromise=null;
async function ensureKhtnSchema(env){
  if(khtnSchemaReady) return;
  if(!khtnSchemaPromise){
    khtnSchemaPromise=(async()=>{
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS khtn_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,team_id INTEGER,customer_name TEXT NOT NULL,phone TEXT NOT NULL,phone_normalized TEXT,
        birth_year TEXT,area TEXT,occupation TEXT,average_income TEXT,cccd TEXT,source TEXT NOT NULL,note TEXT,expected_login_date TEXT,
        custom_json TEXT,created_at TEXT NOT NULL DEFAULT (datetime('now')),updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(team_id) REFERENCES teams(id))`).run();
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS khtn_form_config (
        id INTEGER PRIMARY KEY CHECK(id = 1),config_json TEXT NOT NULL,updated_by INTEGER,updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY(updated_by) REFERENCES users(id))`).run();
      const info=await env.DB.prepare('PRAGMA table_info(khtn_entries)').all();
      if(!(info.results||[]).some(x=>x.name==='custom_json')) await env.DB.prepare('ALTER TABLE khtn_entries ADD COLUMN custom_json TEXT').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_khtn_user ON khtn_entries(user_id)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_khtn_team ON khtn_entries(team_id)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_khtn_created ON khtn_entries(created_at)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_khtn_phone ON khtn_entries(phone_normalized)').run();
      khtnSchemaReady=true;
    })();
  }
  try{await khtnSchemaPromise;}finally{if(!khtnSchemaReady) khtnSchemaPromise=null;}
}
async function getKhtnConfig(env){
  await ensureKhtnSchema(env);
  const row=await env.DB.prepare('SELECT config_json FROM khtn_form_config WHERE id=1').first();
  if(!row?.config_json) return sanitizeKhtnConfig(KHTN_DEFAULT_CONFIG);
  try{return sanitizeKhtnConfig(JSON.parse(row.config_json));}catch{return sanitizeKhtnConfig(KHTN_DEFAULT_CONFIG);}
}
function khtnActiveKeys(config){return (config.field_order||[]).filter(k=>config.fields?.[k]?.enabled!==false);}
function cleanKhtnCustom(body,config,current={}){
  const input=safeJsonObject(body?.custom_fields,{}), out={...safeJsonObject(current,{})};
  for(const key of khtnActiveKeys(config)){
    if(KHTN_FIELD_KEYS.includes(key)) continue;
    if(Object.prototype.hasOwnProperty.call(input,key)) out[key]=cleanText(input[key]);
  }
  return out;
}


const LEAD_STATUSES=new Set(['LOGIN_APP','NO_LOGIN','SIGNED','HIGH_DEBT','BAD_DEBT','NEW_DEBT','OTHER']);
// V10.30: The original V6.3 history table predates the NO_LOGIN status.
// SQLite cannot extend a CHECK constraint with ALTER COLUMN, so rebuild the
// small history table atomically, copying its IDs, actors, times, and reasons.
let leadHistorySchemaReady=false,leadHistorySchemaPromise=null;
async function ensureLeadHistoryStatusSchema(env){
  if(leadHistorySchemaReady)return;
  if(!leadHistorySchemaPromise){
    leadHistorySchemaPromise=(async()=>{
      const table=await env.DB.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='lead_status_history'").first();
      if(!table?.sql)throw new Error('Thiếu bảng lịch sử Lead. Hãy chạy các migration D1 hiện có trước.');
      // Match the literal allowed enum in the table DDL, not comments or indexes.
      if(/['\"]NO_LOGIN['\"]/.test(table.sql)){leadHistorySchemaReady=true;return;}
      const statements=[
        env.DB.prepare(`CREATE TABLE lead_status_history_v1030 (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          customer_id INTEGER NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('LOGIN_APP','NO_LOGIN','SIGNED','HIGH_DEBT','BAD_DEBT','NEW_DEBT','OTHER')),
          reason TEXT,
          changed_by INTEGER NOT NULL,
          changed_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY(customer_id) REFERENCES customers(id),
          FOREIGN KEY(changed_by) REFERENCES users(id)
        )`),
        env.DB.prepare(`INSERT INTO lead_status_history_v1030(id,customer_id,status,reason,changed_by,changed_at)
          SELECT id,customer_id,status,reason,changed_by,changed_at FROM lead_status_history`),
        env.DB.prepare('DROP TABLE lead_status_history'),
        env.DB.prepare('ALTER TABLE lead_status_history_v1030 RENAME TO lead_status_history'),
        env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_lead_history_customer_time ON lead_status_history(customer_id,changed_at DESC,id DESC)')
      ];
      try{await env.DB.batch(statements);}
      catch(err){
        // Another isolate may have completed the upgrade concurrently.
        const after=await env.DB.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='lead_status_history'").first();
        if(!/['\"]NO_LOGIN['\"]/.test(after?.sql||''))throw err;
      }
      leadHistorySchemaReady=true;
    })();
  }
  try{await leadHistorySchemaPromise;}catch(err){leadHistorySchemaPromise=null;throw err;}
}
let manualLeadSchemaReady=false,manualLeadSchemaPromise=null;
async function ensureManualLeadSchema(env){
  if(manualLeadSchemaReady)return;
  if(!manualLeadSchemaPromise){
    manualLeadSchemaPromise=(async()=>{
      const info=await env.DB.prepare('PRAGMA table_info(lead_cases)').all();
      if(!(info.results||[]).some(x=>x.name==='lead_origin')){
        try{await env.DB.prepare("ALTER TABLE lead_cases ADD COLUMN lead_origin TEXT NOT NULL DEFAULT 'CALL'").run();}
        catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}
      }
      manualLeadSchemaReady=true;
    })();
  }
  try{await manualLeadSchemaPromise;}finally{if(!manualLeadSchemaReady)manualLeadSchemaPromise=null;}
}
// V10.36+: Login App Lead and Follow-up are separate workflows.
const V1036_LOGIN_LEAD_SOURCES=['Data','TikTok','Facebook','Thị trường','CTV','Giới thiệu','Khác'];
let v1036AuxReady=false,v1036AuxPromise=null;
async function v1036EnsureAux(env){
 if(v1036AuxReady)return;
 if(!v1036AuxPromise)v1036AuxPromise=(async()=>{
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS login_lead_sources (
   customer_id INTEGER PRIMARY KEY, source TEXT NOT NULL, updated_by INTEGER, updated_at TEXT NOT NULL DEFAULT (datetime('now')),
   FOREIGN KEY(customer_id) REFERENCES customers(id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS login_app_leads (
   id INTEGER PRIMARY KEY AUTOINCREMENT,
   team_id INTEGER,
   assigned_user_id INTEGER NOT NULL,
   customer_name TEXT NOT NULL,
   phone TEXT NOT NULL,
   phone_normalized TEXT,
   source TEXT NOT NULL DEFAULT 'Data',
   note TEXT NOT NULL DEFAULT '',
   status TEXT NOT NULL DEFAULT 'PENDING',
   no_login_reason TEXT,
   login_app_id INTEGER,
   created_by INTEGER,
   created_at TEXT NOT NULL DEFAULT (datetime('now')),
   updated_at TEXT NOT NULL DEFAULT (datetime('now')),
   FOREIGN KEY(login_app_id) REFERENCES login_app_cases(id))`).run();
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_login_app_leads_scope ON login_app_leads(team_id,assigned_user_id,status,created_at)').run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS app_followups (
   id INTEGER PRIMARY KEY AUTOINCREMENT,login_app_id INTEGER NOT NULL,
   assigned_user_id INTEGER NOT NULL,team_id INTEGER,follow_date TEXT NOT NULL,category TEXT NOT NULL,
   note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_by INTEGER,
   created_at TEXT NOT NULL DEFAULT (datetime('now')),updated_at TEXT NOT NULL DEFAULT (datetime('now')),
   FOREIGN KEY(login_app_id) REFERENCES login_app_cases(id))`).run();
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_app_followups_scope ON app_followups(team_id,assigned_user_id,follow_date,status)').run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS user_lock_records (user_id INTEGER PRIMARY KEY, locked_by INTEGER, locked_at TEXT NOT NULL DEFAULT (datetime('now')))` ).run();
  v1036AuxReady=true;
 })();
 try{await v1036AuxPromise;}catch(e){v1036AuxPromise=null;throw e;}
}
async function resolveLoginLeadOwner(env,session,requestedId){
  if(session.role==='sale')return env.DB.prepare(`SELECT id,display_name,role,staff_type,team_id,active FROM users WHERE id=? AND active=1`).bind(session.id).first();
  const targetId=Number(requestedId||0);
  if(!Number.isSafeInteger(targetId)||targetId<1)return null;
  const user=await env.DB.prepare(`SELECT id,display_name,role,staff_type,team_id,active FROM users WHERE id=? AND role='sale' AND active=1`).bind(targetId).first();
  if(!user)return null;
  if(session.role==='teamlead'&&Number(user.team_id)!==Number(session.team_id))return null;
  return user;
}
async function v1036MarkOpenAppFollowupsDone(env,loginAppId){
  if(!Number.isSafeInteger(Number(loginAppId))||Number(loginAppId)<1)return;
  await v1036EnsureAux(env);
  await env.DB.prepare(`UPDATE app_followups SET status='DONE',updated_at=datetime('now') WHERE login_app_id=? AND status='PENDING'`).bind(Number(loginAppId)).run();
}
async function v1036UpsertAppFollowup(env,loginAppRow,followDate,category,note,createdBy){
  await v1036EnsureAux(env);
  const existing=await env.DB.prepare(`SELECT id FROM app_followups WHERE login_app_id=? AND status='PENDING' ORDER BY id DESC LIMIT 1`).bind(loginAppRow.id).first();
  if(existing){
    await env.DB.prepare(`UPDATE app_followups SET follow_date=?,category=?,note=?,assigned_user_id=?,team_id=?,updated_at=datetime('now') WHERE id=?`).bind(followDate,category,note||'',Number(loginAppRow.assigned_user_id||0),loginAppRow.team_id||null,existing.id).run();
    return Number(existing.id);
  }
  const r=await env.DB.prepare(`INSERT INTO app_followups(login_app_id,assigned_user_id,team_id,follow_date,category,note,created_by) VALUES(?,?,?,?,?,?,?)`).bind(loginAppRow.id,Number(loginAppRow.assigned_user_id||0),loginAppRow.team_id||null,followDate,category,note||'',createdBy||null).run();
  return Number(r.meta?.last_row_id||0);
}

async function resolveManualLeadOwner(env,session,requestedId){
  if(session.role==='sale'){
    return env.DB.prepare(`SELECT id,display_name,role,staff_type,team_id,active FROM users WHERE id=? AND active=1`).bind(session.id).first();
  }
  const id=Number(requestedId||0);
  if(!id)return null;
  const u=await env.DB.prepare(`SELECT id,display_name,role,staff_type,team_id,active FROM users WHERE id=? AND active=1`).bind(id).first();
  if(!u||u.role!=='sale')return null;
  if(session.role==='teamlead'&&Number(u.team_id)!==Number(session.team_id))return null;
  return u;
}
function leadScopeSql(session, alias='c'){
  if(isManager(session)) return {where:'1=1',bind:[]};
  if(session.role==='teamlead') return {where:`${alias}.team_id=? AND (${alias}.assigned_user_id IS NULL OR EXISTS (SELECT 1 FROM users lead_scope_user WHERE lead_scope_user.id=${alias}.assigned_user_id AND lead_scope_user.team_id=? AND lead_scope_user.active=1))`,bind:[session.team_id,session.team_id]};
  return {where:`${alias}.assigned_user_id=?`,bind:[session.id]};
}
async function getSession(request, env){
  const auth=request.headers.get('authorization')||'';
  if(!auth.startsWith('Bearer ')) return null;
  const t=auth.slice(7);
  const user=await env.DB.prepare(`SELECT s.token,s.expires_at,u.id,u.username,u.display_name,u.role,u.staff_type,u.team_id,t.name team
    FROM sessions s JOIN users u ON u.id=s.user_id LEFT JOIN teams t ON t.id=u.team_id
    WHERE s.token=? AND s.expires_at > datetime('now') AND u.active=1`).bind(t).first();
  if(user)user.role=effectiveRole(user);
  return user;
}
function scopeSql(session, alias='c'){
  if(isManager(session)) return {where:'1=1',bind:[]};
  if(session.role==='teamlead') return {where:`${alias}.team_id=?`,bind:[session.team_id]};
  return {where:`${alias}.assigned_user_id=?`,bind:[session.id]};
}
async function audit(env, userId, action, entityType, entityId, detail={}){
  const result=await env.DB.prepare('INSERT INTO audit_logs(user_id,action,entity_type,entity_id,detail) VALUES(?,?,?,?,?)')
    .bind(userId,action,entityType,entityId??null,JSON.stringify(detail)).run();
  return Number(result.meta?.last_row_id||0);
}
// V10.34: audit logs stay immutable; only separate recovery snapshots expire after seven days.
let auditUndoReady=false, auditUndoPromise=null;
async function ensureAuditUndoSchema(env){
  if(auditUndoReady)return;
  if(!auditUndoPromise)auditUndoPromise=(async()=>{
    await env.DB.prepare(`CREATE TABLE IF NOT EXISTS audit_undo (
      audit_id INTEGER PRIMARY KEY,action TEXT NOT NULL,entity_type TEXT NOT NULL,entity_id INTEGER NOT NULL,
      before_json TEXT NOT NULL,after_json TEXT NOT NULL,
      expires_at TEXT NOT NULL DEFAULT (datetime('now','+7 days')),
      undone_at TEXT,undone_by INTEGER,
      FOREIGN KEY(audit_id) REFERENCES audit_logs(id)
    )`).run();
    await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_audit_undo_expiration ON audit_undo(expires_at)').run();
    auditUndoReady=true;
  })();
  try{await auditUndoPromise;}catch(e){auditUndoPromise=null;throw e;}
}
const AUDIT_UNDO_TARGETS={
  CUSTOMER_UPDATE:{table:'customers',entity:'customer',fields:['status','follow_up_at','note','team_id','assigned_user_id']},
  LOAN_PROFILE_UPDATE:{table:'loan_profiles',entity:'loan',fields:['assigned_user_id','contract_code','cccd','disbursement_date','disbursement_amount','monthly_payment','original_term_months','monthly_due_day','maturity_date','current_balance','next_due_date','status','reloan_eligible','note']},
  KPI_SET:{table:'kpi_targets',entity:'user',fields:['calls_daily','y01_daily']},
  CATEGORY_RENAME:{table:'data_categories',entity:'data_category',fields:['name']},
  LEAD_STATUS_UPDATE:{table:'lead_status_history',entity:'lead',fields:['history_id']}
};
const pickedUndoValues=(row,cols)=>Object.fromEntries(cols.map(k=>[k,row?.[k]??null]));
async function auditWithUndo(env,session,action,entityType,entityId,detail,before,after){
  const rule=AUDIT_UNDO_TARGETS[action];
  if(!rule||rule.entity!==entityType||!Number.isSafeInteger(Number(entityId))||Number(entityId)<1)throw Error('Thao tác hoàn tác không hợp lệ.');
  const fields=Object.keys(before||{});
  if(!fields.length||fields.some(k=>!rule.fields.includes(k)||!Object.prototype.hasOwnProperty.call(after,k)))throw Error('Dữ liệu khôi phục không hợp lệ.');
  await ensureAuditUndoSchema(env);
  const auditId=await audit(env,session.id,action,entityType,entityId,detail);
  await env.DB.prepare(`INSERT INTO audit_undo(audit_id,action,entity_type,entity_id,before_json,after_json)
     VALUES(?,?,?,?,?,?)`).bind(auditId,action,entityType,entityId,JSON.stringify(before),JSON.stringify(after)).run();
  return auditId;
}
async function undoAuditEntry(env,session,id){
  if(!isManager(session))return bad('Chỉ Admin và Sup được hoàn tác nhật ký.',403);
  await ensureAuditUndoSchema(env);
  const record=await env.DB.prepare(`SELECT a.id,a.action,a.entity_type,a.entity_id,u.before_json,u.after_json,u.expires_at,u.undone_at
    FROM audit_logs a LEFT JOIN audit_undo u ON u.audit_id=a.id WHERE a.id=?`).bind(id).first();
  if(!record)return bad('Không tìm thấy nhật ký.',404);
  if(!record.before_json)return bad('Thao tác này không có dữ liệu khôi phục hoặc đã quá thời hạn 7 ngày.',409);
  if(record.undone_at)return bad('Thao tác đã được hoàn tác trước đó.',409);
  const active=await env.DB.prepare("SELECT 1 ok FROM audit_undo WHERE audit_id=? AND expires_at>datetime('now') AND undone_at IS NULL").bind(id).first();
  if(!active)return bad('Đã quá 7 ngày, không thể hoàn tác.',409);
  if(record.action==='CATEGORY_ASSIGN'&&record.entity_type==='customer'){
    let original,after;try{original=JSON.parse(record.before_json);after=JSON.parse(record.after_json);}catch{return bad('Bản lưu khôi phục không hợp lệ.',409);}
    if(!Array.isArray(original)||!original.length||original.length>500||original.some(x=>!Number.isSafeInteger(Number(x.id))))return bad('Danh sách hoàn tác không hợp lệ.',409);
    const ids=original.map(x=>Number(x.id));const category=after.category_id??null;
    // Guard the entire set atomically: if even one customer was changed later, revert none.
    const marks=ids.map(()=>'?').join(',');
    const updates=original.map(()=>"WHEN ? THEN ?").join(' ');
    const sql=`UPDATE customers SET data_category_id=CASE id ${updates} END,updated_at=datetime('now')
      WHERE id IN (${marks}) AND data_category_id IS ?
      AND (SELECT COUNT(*) FROM customers WHERE id IN (${marks}) AND data_category_id IS ?)=?
      AND EXISTS(SELECT 1 FROM audit_undo WHERE audit_id=? AND expires_at>datetime('now') AND undone_at IS NULL)`;
    const args=[...original.flatMap(x=>[Number(x.id),x.data_category_id??null]),...ids,category,...ids,category,original.length,id];
    const updated=await env.DB.prepare(sql).bind(...args).run();
    if(Number(updated.meta?.changes||0)!==original.length)return bad('Một hoặc nhiều khách đã được phân loại lần nữa; hệ thống không hoàn tác để tránh ghi đè.',409);
    await env.DB.prepare("UPDATE audit_undo SET undone_at=datetime('now'),undone_by=? WHERE audit_id=? AND undone_at IS NULL").bind(session.id,id).run();
    await audit(env,session.id,'AUDIT_UNDO','customer',null,{original_action:'CATEGORY_ASSIGN',original_audit_id:id,count:original.length});
    return json({ok:true,message:`Đã khôi phục phân loại của ${original.length} khách hàng.`});
  }
  const rule=AUDIT_UNDO_TARGETS[record.action];
  if(!rule||rule.entity!==record.entity_type)return bad('Thao tác này không hỗ trợ hoàn tác.',409);
  let before,after;
  try{before=JSON.parse(record.before_json);after=JSON.parse(record.after_json);}catch{return bad('Dữ liệu khôi phục bị lỗi.',409);}
  const keys=Object.keys(before||{});
  if(!keys.length||keys.some(k=>!rule.fields.includes(k)||!Object.prototype.hasOwnProperty.call(after,k)))return bad('Dữ liệu khôi phục không hợp lệ.',409);
  // Status-only Lead changes can be reverted by removing precisely the latest status event.
  // Do NOT undo LOGIN_APP/SIGNED transitions here: those also create/modify related records.
  if(record.action==='LEAD_STATUS_UPDATE'){
    const statusId=Number(after.history_id||0);
    if(!Number.isSafeInteger(statusId)||statusId<=0)return bad('Dữ liệu lịch sử Lead không hợp lệ.',409);
    const last=await env.DB.prepare('SELECT id FROM lead_status_history WHERE customer_id=? ORDER BY changed_at DESC,id DESC LIMIT 1').bind(record.entity_id).first();
    if(Number(last?.id)!==statusId)return bad('Lead đã được cập nhật tiếp nên không thể hoàn tác thay đổi cũ.',409);
    const deleted=await env.DB.prepare(`DELETE FROM lead_status_history WHERE id=? AND customer_id=?
      AND NOT EXISTS(SELECT 1 FROM lead_status_history nx WHERE nx.customer_id=? AND (nx.changed_at>(SELECT changed_at FROM lead_status_history WHERE id=?) OR (nx.changed_at=(SELECT changed_at FROM lead_status_history WHERE id=?) AND nx.id>?)))
      AND EXISTS(SELECT 1 FROM audit_undo WHERE audit_id=? AND expires_at>datetime('now') AND undone_at IS NULL)`)
      .bind(statusId,record.entity_id,record.entity_id,statusId,statusId,statusId,id).run();
    if(Number(deleted.meta?.changes||0)!==1)return bad('Lead đã có thay đổi mới hoặc hết thời hạn hoàn tác.',409);
    await env.DB.prepare("UPDATE audit_undo SET undone_at=datetime('now'),undone_by=? WHERE audit_id=? AND undone_at IS NULL").bind(session.id,id).run();
    await audit(env,session.id,'AUDIT_UNDO',record.entity_type,record.entity_id,{original_action:record.action,original_audit_id:id});
    return json({ok:true,message:'Đã khôi phục trạng thái Lead trước đó.'});
  }
  // Compare only fields that the original action modified. Never overwrite newer edits.
  const where=keys.map(k=>`${k} IS ?`).join(' AND ');
  const pk=rule.table==='kpi_targets'?'user_id':'id';
  const current=await env.DB.prepare(`SELECT ${keys.join(',')} FROM ${rule.table} WHERE ${pk}=?`).bind(record.entity_id).first();
  if(!current||keys.some(k=>!(current[k]===after[k]||(current[k]!=null&&after[k]!=null&&String(current[k])===String(after[k])))))
    return bad('Dữ liệu đã được thay đổi sau thao tác này. Không thể hoàn tác để tránh ghi đè thông tin mới.',409);
  // Use a guarded SQL update to reject concurrent changes to the target row.
  const assignments=keys.map(k=>`${k}=?`).join(',');
  const timeCol=['customers','loan_profiles','data_categories','kpi_targets'].includes(rule.table)?",updated_at=datetime('now')":'';
  const result=await env.DB.prepare(`UPDATE ${rule.table} SET ${assignments}${timeCol} WHERE ${pk}=? AND ${where}${rule.table==='data_categories'?' AND active=1':''}
    AND EXISTS(SELECT 1 FROM audit_undo WHERE audit_id=? AND expires_at>datetime('now') AND undone_at IS NULL)`)
    .bind(...keys.map(k=>before[k]),record.entity_id,...keys.map(k=>after[k]),id).run();
  if(Number(result.meta?.changes||0)!==1)return bad('Dữ liệu đã thay đổi hoặc thời hạn hoàn tác đã hết.',409);
  await env.DB.prepare("UPDATE audit_undo SET undone_at=datetime('now'),undone_by=? WHERE audit_id=? AND undone_at IS NULL").bind(session.id,id).run();
  await audit(env,session.id,'AUDIT_UNDO',record.entity_type,record.entity_id,{original_action:record.action,original_audit_id:id});
  return json({ok:true,message:'Đã hoàn tác thành công.'});
}
function requireAdmin(session){ return isManager(session); }

// V10.29 — Account-level access control. Role still defines DATA SCOPE.
// User grants NEVER turn a Team Leader into a cross-team Admin.
const ACCESS_MODULES={
 dashboard:'Bảng điều khiển',calls:'Chi tiết cuộc gọi',lead:'Quản lý Lead',
 loginApp:'Login App',followup:'Follow-up',loanCare:'Chăm sóc khách hàng',
 teamManagement:'Nhóm và nhân viên',kpi:'KPI & Hiệu suất',
 warehouse:'Kho dữ liệu',import:'Nhập / Xuất dữ liệu',chat:'Chat & thông báo'
};
const ACCESS_ACTIONS={view:'Xem',create:'Thêm',update:'Sửa / Cập nhật trạng thái',delete:'Xóa',remind:'Nhắc nhở',export:'Xuất',assign:'Phân công'};
let accessSchemaReady=false,accessSchemaPromise=null;
async function ensureAccessSchema(env){
 if(accessSchemaReady)return;
 if(!accessSchemaPromise)accessSchemaPromise=env.DB.prepare(`CREATE TABLE IF NOT EXISTS user_access_rules (
   user_id INTEGER NOT NULL,module TEXT NOT NULL,action TEXT NOT NULL,allowed INTEGER NOT NULL CHECK(allowed IN (0,1)),
   updated_at TEXT NOT NULL DEFAULT (datetime('now')),
   PRIMARY KEY(user_id,module,action))`).run().then(()=>{accessSchemaReady=true});
 try{await accessSchemaPromise;}catch(e){accessSchemaPromise=null;throw e;}
}
function accessBase(role,module,action){
 if(role==='admin'||role==='sup')return true;
 const isSale=role==='sale';
 if(module==='teamManagement')return !isSale && ['view','create','update','delete'].includes(action) || (isSale&&action==='view');
 if(module==='warehouse')return !isSale && ['view','create','update','delete','assign'].includes(action);
 if(module==='import')return !isSale && ['view','create','export','assign'].includes(action);
 if(module==='kpi')return action==='view'||(!isSale&&['update','create','export'].includes(action));
 if(module==='chat')return ['view','create'].includes(action)||(!isSale&&action==='remind');
 if(module==='dashboard')return action==='view';
 if(module==='calls')return ['view','update','export'].includes(action)||(!isSale&&['create','assign'].includes(action));
 if(module==='lead')return ['view','create'].includes(action)||(isSale&&action==='update')||(!isSale&&['update','delete','remind','export'].includes(action));
 if(module==='loginApp')return ['view','create'].includes(action)||(isSale&&action==='update')||(!isSale&&['update','delete','remind','export'].includes(action));
 if(module==='loanCare')return action==='view'||(isSale&&action==='update')||(!isSale&&['update','delete','remind','export'].includes(action));
 if(module==='followup')return ['view','create','update'].includes(action)||(!isSale&&['delete','remind'].includes(action));
 return false;
}
async function accessMatrix(env,user){
 await ensureAccessSchema(env);
 const matrix={};
 for(const module of Object.keys(ACCESS_MODULES)){
  matrix[module]={};
  for(const action of Object.keys(ACCESS_ACTIONS))matrix[module][action]=accessBase(user.role,module,action);
 }
 const rows=(await env.DB.prepare('SELECT module,action,allowed FROM user_access_rules WHERE user_id=?').bind(user.id).all()).results||[];
 for(const x of rows)if(Object.hasOwn(matrix,x.module)&&Object.hasOwn(matrix[x.module],x.action))matrix[x.module][x.action]=Boolean(x.allowed);
 return matrix;
}
async function hasAccess(env,session,module,action){
 if(!Object.hasOwn(ACCESS_MODULES,module)||!Object.hasOwn(ACCESS_ACTIONS,action))return false;
 await ensureAccessSchema(env);
 const row=await env.DB.prepare('SELECT allowed FROM user_access_rules WHERE user_id=? AND module=? AND action=?').bind(session.id,module,action).first();
 return row?Number(row.allowed)===1:accessBase(session.role,module,action);
}
function accessRequestPolicy(path,method){
 let module=null,action=method==='GET'?'view':method==='DELETE'?'delete':method==='PATCH'||method==='PUT'?'update':'create';
 if(path.startsWith('/api/login-leads')){module='lead';action=method==='GET'?'view':method==='DELETE'?'delete':method==='POST'&&path==='/api/login-leads'?'create':'update';}
 else if(path.startsWith('/api/app-followups')){module='followup';action=method==='GET'?'view':method==='DELETE'?'delete':method==='POST'&&path==='/api/app-followups'?'create':'update';}
 else if(path.startsWith('/api/leads')){
  module='lead';if(/\/notes$|\/status$/.test(path))action=method==='GET'?'view':'update';
 }else if(path.startsWith('/api/login-apps')){
  module='loginApp';if(path.endsWith('/import'))action='create';
 }else if(path.startsWith('/api/loans')){
  module='loanCare';if(/\/(care|topup)$/.test(path)&&method==='POST')action='update';
 }else if(path.startsWith('/api/followups'))module='followup';
 else if(path.startsWith('/api/users')||path.startsWith('/api/teams')){module='teamManagement';if(/\/(lock|unlock)$/.test(path))action='update';}
 else if(path.startsWith('/api/kpi-targets')||path.startsWith('/api/revenue-kpi')){module='kpi';if(method!=='GET')action='update';}
 else if(path.startsWith('/api/login-performance'))module='dashboard';
 else if(path.startsWith('/api/warehouse')||path.startsWith('/api/data-categories')||path.startsWith('/api/bulk-jobs')||path==='/api/distribute'){
  module='warehouse';if(/distribut|transfer|recall|assign|recycle/.test(path)&&method!=='GET')action='assign';
 }else if(path.startsWith('/api/customers/import')||path.startsWith('/api/data/reset'))module='import';
 else if(path.startsWith('/api/calls')){module='calls';if(path.endsWith('/export'))action='export';if(method==='POST')action='update';}
 else if(path.startsWith('/api/chat')){module='chat';if(path.endsWith('/broadcast'))action='remind';}
 else if(path.startsWith('/api/loan-care')){module='loanCare';if(path.includes('/reminders'))action='view';}
 return module?{module,action}:null;
}

function chatConversationKey(a,b){
  const x=Number(a),y=Number(b);
  return x<y?`${x}:${y}`:`${y}:${x}`;
}
function canChatWith(session,target){
  if(!target||Number(target.id)===Number(session.id)||Number(target.active)===0) return false;
  if(isManager(session)) return true;
  if(target.role==='admin'||target.role==='sup') return true;
  if(session.role==='teamlead') return target.role==='sale'&&Number(target.team_id)===Number(session.team_id);
  if(session.role==='sale') return ['admin','sup'].includes(target.role)||((target.role==='teamlead'||target.role==='sale')&&Number(target.team_id)===Number(session.team_id));
  return false;
}
async function getChatTarget(env,session,targetId){
  const target=await env.DB.prepare(`SELECT u.id,u.username,u.display_name,u.role,u.staff_type,u.team_id,u.active,t.name team
    FROM users u LEFT JOIN teams t ON t.id=u.team_id WHERE u.id=? AND u.active=1`).bind(Number(targetId)).first();
  if(target)target.role=effectiveRole(target);
  return canChatWith(session,target)?target:null;
}
async function ensureChatReadState(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS chat_read_state (
    user_id INTEGER NOT NULL,
    other_user_id INTEGER NOT NULL,
    last_read_message_id INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY(user_id, other_user_id)
  )`).run();
}
async function ensureChatBaseline(env,userId){
  await ensureChatReadState(env);
  const row=await env.DB.prepare(`SELECT last_read_message_id FROM chat_read_state WHERE user_id=? AND other_user_id=0`).bind(userId).first();
  if(row) return Number(row.last_read_message_id||0);
  const maxRow=await env.DB.prepare(`SELECT COALESCE(MAX(id),0) max_id FROM chat_messages WHERE recipient_user_id=?`).bind(userId).first();
  const baseline=Number(maxRow?.max_id||0);
  await env.DB.prepare(`INSERT OR IGNORE INTO chat_read_state(user_id,other_user_id,last_read_message_id,updated_at) VALUES(?,0,?,datetime('now'))`).bind(userId,baseline).run();
  return baseline;
}
async function markChatRead(env,userId,otherUserId){
  await ensureChatBaseline(env,userId);
  const row=await env.DB.prepare(`SELECT COALESCE(MAX(id),0) max_id FROM chat_messages WHERE recipient_user_id=? AND sender_user_id=?`).bind(userId,otherUserId).first();
  const maxId=Number(row?.max_id||0);
  await env.DB.prepare(`INSERT INTO chat_read_state(user_id,other_user_id,last_read_message_id,updated_at)
    VALUES(?,?,?,datetime('now'))
    ON CONFLICT(user_id,other_user_id) DO UPDATE SET last_read_message_id=MAX(chat_read_state.last_read_message_id,excluded.last_read_message_id),updated_at=datetime('now')`)
    .bind(userId,otherUserId,maxId).run();
  return maxId;
}
function parseTeamAlias(name){
  const n=norm(name).replace(/mobility\s*/,'m').replace(/\s/g,'');
  const m=n.match(/^m?([1356])$/); return m?`mobility ${m[1]}`:norm(name);
}
function deadlineFromDays(days){
  const n=Math.max(0,Math.min(365,Number(days)||0));
  if(!n) return null;
  const d=new Date(); d.setUTCDate(d.getUTCDate()+n); return d.toISOString().slice(0,10);
}
function randomPick(list){
  if(!list.length) return null;
  const a=new Uint32Array(1); crypto.getRandomValues(a); return list[a[0]%list.length];
}
async function returnExpiredAssignments(env,teamId=null){
  // V8.6: thu hồi Data quá hạn theo batch SQL thay vì 2 câu lệnh cho từng khách.
  // Nhanh hơn đáng kể khi Team có nhiều Data hết hạn và tránh timeout khi chia Data.
  let sql=`SELECT id FROM customers
    WHERE data_state='ASSIGNED' AND assignment_deadline IS NOT NULL AND assignment_deadline < date('now')`;
  const binds=[];
  if(teamId){sql+=' AND team_id=?';binds.push(Number(teamId));}
  sql+=' ORDER BY id LIMIT 5000';
  const {results}=await env.DB.prepare(sql).bind(...binds).all();
  if(!results.length) return 0;
  const ids=results.map(x=>Number(x.id));
  for(let i=0;i<ids.length;i+=100){
    const batch=ids.slice(i,i+100), marks=batch.map(()=>'?').join(',');
    await env.DB.batch([
      env.DB.prepare(`UPDATE customers SET last_assigned_user_id=assigned_user_id,assigned_user_id=NULL,data_state='POOL',status='NEW',follow_up_at=NULL,assignment_deadline=NULL,updated_at=datetime('now') WHERE id IN (${marks})`).bind(...batch),
      env.DB.prepare(`UPDATE assignment_history SET returned_at=datetime('now'),return_reason='DEADLINE'
        WHERE id IN (
          SELECT MAX(id) FROM assignment_history
          WHERE customer_id IN (${marks}) AND returned_at IS NULL AND completed_at IS NULL
          GROUP BY customer_id
        )`).bind(...batch)
    ]);
  }
  return ids.length;
}


// V8.7: persistent, resumable warehouse distribution jobs for large datasets.
let bulkJobSchemaReady=false, bulkJobSchemaPromise=null;
async function ensureBulkJobSchema(env){
  if(bulkJobSchemaReady) return;
  if(!bulkJobSchemaPromise){
    bulkJobSchemaPromise=(async()=>{
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS bulk_jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'RUNNING',
        created_by INTEGER NOT NULL,
        team_id INTEGER,
        total_count INTEGER NOT NULL DEFAULT 0,
        processed_count INTEGER NOT NULL DEFAULT 0,
        payload_json TEXT NOT NULL,
        locked_until TEXT,
        last_error TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        completed_at TEXT,
        FOREIGN KEY(created_by) REFERENCES users(id)
      )`).run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_bulk_jobs_status ON bulk_jobs(status,updated_at)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_bulk_jobs_creator ON bulk_jobs(created_by,status,id)').run();
      bulkJobSchemaReady=true;
    })();
  }
  try{await bulkJobSchemaPromise;}finally{if(!bulkJobSchemaReady) bulkJobSchemaPromise=null;}
}
function bulkJobPayload(row){return safeJsonObject(row?.payload_json,{});}
function bulkJobPublic(row){
  if(!row) return null;
  const p=bulkJobPayload(row), total=Number(row.total_count||0), done=Number(row.processed_count||0);
  return {id:Number(row.id),job_type:row.job_type,status:row.status,total_count:total,processed_count:done,percent:total?Math.min(100,Math.round(done/total*100)):100,last_error:row.last_error||'',created_at:row.created_at,updated_at:row.updated_at,completed_at:row.completed_at,mode:p.mode||'',category_id:p.category_id||null,deadline_days:Number(p.deadline_days||0),team_id:row.team_id||p.scope_team_id||null,recipients_count:Array.isArray(p.recipients)?p.recipients.length:0};
}
async function bulkDistributionRecipients(env, session, body){
  const mode=cleanText(body.mode||'all'); let recipients=[];
  if(mode==='all'){
    let sql="SELECT id,team_id,display_name FROM users WHERE active=1 AND role='sale' AND team_id IS NOT NULL"; const binds=[];
    if(session.role==='teamlead'){sql+=' AND team_id=?';binds.push(session.team_id)}
    sql+=' ORDER BY team_id,id'; recipients=(await env.DB.prepare(sql).bind(...binds).all()).results;
  }else if(mode==='team'){
    let teamId=Number(body.team_id); if(session.role==='teamlead') teamId=session.team_id;
    if(!teamId) throw new Error('Hãy chọn Team.');
    recipients=(await env.DB.prepare("SELECT id,team_id,display_name FROM users WHERE active=1 AND role='sale' AND team_id=? ORDER BY id").bind(teamId).all()).results;
  }else if(mode==='user'){
    const userId=Number(body.user_id); const u=await env.DB.prepare("SELECT id,team_id,display_name FROM users WHERE id=? AND active=1 AND role='sale'").bind(userId).first();
    if(!u) throw new Error('Không tìm thấy nhân viên Sale.');
    if(session.role==='teamlead' && Number(u.team_id)!==Number(session.team_id)) throw new Error('Không thể chia Data cho Team khác.');
    recipients=[u];
  }else throw new Error('Cách chia Data không hợp lệ.');
  if(!recipients.length) throw new Error('Không có nhân viên Sale để nhận Data.');
  return {mode,recipients};
}
function bulkDistributionPoolSql(payload,limit=0){
  let sql="SELECT id,team_id,data_category_id,assignment_round,last_assigned_user_id FROM customers WHERE data_state='POOL'"; const binds=[];
  if(payload.source_team_id!==undefined && payload.source_team_id!==null){
    if(payload.source_team_id==='common'){sql+=' AND team_id IS NULL';}
    else{sql+=' AND team_id=?';binds.push(Number(payload.source_team_id));}
  }
  else if(payload.scope_role==='teamlead'){sql+=' AND team_id=?';binds.push(Number(payload.scope_team_id));}
  else if(payload.mode==='all'){sql+=' AND team_id IS NULL';}
  else if(payload.mode==='team'){sql+=' AND (team_id IS NULL OR team_id=?)';binds.push(Number(payload.team_id));}
  else if(payload.mode==='user'){sql+=' AND (team_id IS NULL OR team_id=?)';binds.push(Number(payload.recipient_team_id));}
  if(payload.category_id){sql+=' AND data_category_id=?';binds.push(Number(payload.category_id));}
  if(payload.max_customer_id){sql+=' AND id<=?';binds.push(Number(payload.max_customer_id));}
  sql+=' ORDER BY id';
  if(limit>0) sql+=` LIMIT ${Number(limit)}`;
  return {sql,binds};
}
async function createBulkDistributionJob(env,session,body){
  await ensureBulkJobSchema(env);
  await returnExpiredAssignments(env,session.role==='teamlead'?Number(session.team_id):null);
  const {mode,recipients}=await bulkDistributionRecipients(env,session,body);
  // Source Team selector is mandatory when supplied; never cross Team boundaries.
  let sourceTeam=null;
  if(body.source_team_id!==undefined){
    const raw=String(body.source_team_id);
    if(raw==='common')sourceTeam='common';
    else if(/^\d+$/.test(raw)&&Number(raw)>0){
      const team=await env.DB.prepare('SELECT id FROM teams WHERE id=? AND active=1').bind(Number(raw)).first();
      if(!team)throw new Error('Kho nguồn không tồn tại hoặc đã ngừng hoạt động.');
      sourceTeam=Number(raw);
    }else throw new Error('Bạn phải chọn Kho nguồn hợp lệ.');
    if(session.role==='teamlead'&&sourceTeam!==Number(session.team_id))throw new Error('Team Leader chỉ được lấy Data từ Kho của Team mình.');
    if(sourceTeam!=='common'&&recipients.some(u=>Number(u.team_id)!==sourceTeam))throw new Error('Data Kho Team chỉ được chia cho nhân viên đúng Team đó.');
  }

  const effectiveTeamId=session.role==='teamlead'?Number(session.team_id||0):(mode==='team'?Number(body.team_id||0):(mode==='user'?Number(recipients[0]?.team_id||0):0));
  const existing=await env.DB.prepare(`SELECT * FROM bulk_jobs WHERE job_type='WAREHOUSE_DISTRIBUTE' AND status='RUNNING' AND created_by=? ORDER BY id DESC LIMIT 1`).bind(session.id).first();
  if(existing){
    const prior=bulkJobPayload(existing);
    if(prior.mode!==mode || String(prior.source_team_id??'legacy')!==String(sourceTeam??'legacy') ||
      (mode==='team'&&Number(prior.team_id)!==Number(body.team_id||session.team_id)) ||
      (mode==='user'&&Number(prior.user_id)!==Number(body.user_id))){
      throw new Error('Bạn đang có một tác vụ chia Data khác chưa hoàn tất. Vui lòng đợi hoặc hủy tác vụ cũ trước khi đổi Team/kho nguồn.');
    }
    return {job:bulkJobPublic(existing),updated:Number(existing.processed_count||0),recipients:bulkJobPublic(existing).recipients_count,resumed:true};
  }
  const categoryId=body.category_id?Number(body.category_id):null;
  const requestedLimit=Math.max(0,Math.min(100000,Number(body.limit)||0));
  const payload={
    mode,category_id:categoryId,deadline_days:Math.max(0,Math.min(365,Number(body.deadline_days)||0)),
    team_id:mode==='team'?Number(body.team_id||session.team_id||0):null,user_id:mode==='user'?Number(body.user_id||0):null,
    scope_role:session.role,scope_team_id:Number(session.team_id||0)||null,
    ...(sourceTeam!==null?{source_team_id:sourceTeam}:{}),
    recipients:recipients.map(x=>({id:Number(x.id),team_id:Number(x.team_id)})),
    recipient_team_id:mode==='user'?Number(recipients[0].team_id):null
  };
  const maxQ=bulkDistributionPoolSql(payload,0);
  const maxRow=await env.DB.prepare(`SELECT MAX(id) max_id FROM (${maxQ.sql})`).bind(...maxQ.binds).first();
  payload.max_customer_id=Number(maxRow?.max_id||0);
  if(!payload.max_customer_id) return {job:null,updated:0,recipients:recipients.length};
  const countQ=bulkDistributionPoolSql(payload,0);
  const countRow=await env.DB.prepare(`SELECT COUNT(*) n FROM (${countQ.sql})`).bind(...countQ.binds).first();
  const available=Number(countRow?.n||0),total=requestedLimit?Math.min(available,requestedLimit):available;
  if(!total) return {job:null,updated:0,recipients:recipients.length};
  const result=await env.DB.prepare(`INSERT INTO bulk_jobs(job_type,status,created_by,team_id,total_count,processed_count,payload_json) VALUES('WAREHOUSE_DISTRIBUTE','RUNNING',?,?,?,?,?)`)
    .bind(session.id,effectiveTeamId||null,total,0,JSON.stringify(payload)).run();
  const id=Number(result.meta?.last_row_id||0);
  const row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=?').bind(id).first();
  await audit(env,session.id,'BULK_JOB_CREATE','bulk_job',id,{job_type:'WAREHOUSE_DISTRIBUTE',total,mode,category_id:categoryId});
  return {job:bulkJobPublic(row),updated:0,recipients:recipients.length};
}
async function processBulkDistributionJob(env,jobId,maxItems=300){
  await ensureBulkJobSchema(env);
  const lock=await env.DB.prepare(`UPDATE bulk_jobs SET locked_until=datetime('now','+55 seconds'),updated_at=datetime('now') WHERE id=? AND job_type='WAREHOUSE_DISTRIBUTE' AND status='RUNNING' AND (locked_until IS NULL OR locked_until<datetime('now'))`).bind(jobId).run();
  if(Number(lock.meta?.changes||0)===0){
    const row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=?').bind(jobId).first();
    return {job:bulkJobPublic(row),locked:true,assignments:[]};
  }
  let row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=?').bind(jobId).first();
  if(!row) return {job:null,locked:false,assignments:[]};
  const payload=bulkJobPayload(row), total=Number(row.total_count||0);
  let processed=Number(row.processed_count||0), remaining=Math.max(0,total-processed);
  const assignments=[];
  try{
    if(!remaining){
      await env.DB.prepare(`UPDATE bulk_jobs SET status='COMPLETED',locked_until=NULL,completed_at=COALESCE(completed_at,datetime('now')),updated_at=datetime('now') WHERE id=?`).bind(jobId).run();
      row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=?').bind(jobId).first(); return {job:bulkJobPublic(row),locked:false,assignments};
    }
    const recipientIds=(payload.recipients||[]).map(x=>Number(x.id)).filter(Boolean);
    if(!recipientIds.length) throw new Error('Job không còn danh sách nhân viên nhận Data.');
    const marks=recipientIds.map(()=>'?').join(',');
    const activeRecipients=(await env.DB.prepare(`SELECT id,team_id FROM users WHERE active=1 AND role='sale' AND id IN (${marks}) ORDER BY team_id,id`).bind(...recipientIds).all()).results;
    if(!activeRecipients.length) throw new Error('Không còn Sale hoạt động để tiếp tục job.');
    // A recipient may have been moved to another Team after job creation.
    if(payload.source_team_id && payload.source_team_id!=='common' && activeRecipients.some(u=>Number(u.team_id)!==Number(payload.source_team_id)))
      throw new Error('Có nhân viên nhận Data đã chuyển sang Team khác. Tác vụ tạm dừng để tránh chia nhầm Data.');
    const max=Math.max(1,Math.min(1000,Number(maxItems)||300));
    let budget=Math.min(max,remaining);
    while(budget>0 && processed<total){
      const take=Math.min(30,budget,total-processed);
      const q=bulkDistributionPoolSql(payload,take);
      const pool=(await env.DB.prepare(q.sql).bind(...q.binds).all()).results;
      if(!pool.length){
        await env.DB.prepare(`UPDATE bulk_jobs SET total_count=processed_count,status='COMPLETED',locked_until=NULL,completed_at=datetime('now'),updated_at=datetime('now') WHERE id=?`).bind(jobId).run();
        break;
      }
      const deadline=deadlineFromDays(payload.deadline_days);
      const stmts=[],chunkAssignments=[];
      for(let i=0;i<pool.length;i++){
        const data=pool[i]; let choices=activeRecipients;
        if(data.last_assigned_user_id&&activeRecipients.length>1) choices=activeRecipients.filter(x=>Number(x.id)!==Number(data.last_assigned_user_id));
        const u=choices[(processed+i)%choices.length]||activeRecipients[(processed+i)%activeRecipients.length]; const round=Number(data.assignment_round||0)+1;
        stmts.push(env.DB.prepare("UPDATE customers SET team_id=?,assigned_user_id=?,last_assigned_user_id=NULL,data_state='ASSIGNED',status='NEW',archived_at=NULL,follow_up_at=NULL,assignment_deadline=?,assignment_round=?,updated_at=datetime('now') WHERE id=? AND data_state='POOL'").bind(u.team_id,u.id,deadline,round,data.id));
        stmts.push(env.DB.prepare(`INSERT INTO assignment_history(customer_id,user_id,team_id,category_id,round_no,deadline_at)
          SELECT id,?,?,data_category_id,assignment_round,? FROM customers
          WHERE id=? AND assigned_user_id=? AND team_id=? AND data_state='ASSIGNED' AND assignment_round=?`)
          .bind(u.id,u.team_id,deadline,data.id,u.id,u.team_id,round));
        chunkAssignments.push({customer_id:Number(data.id),user_id:Number(u.id),team_id:Number(u.team_id),round,deadline});
      }
      stmts.push(env.DB.prepare(`UPDATE bulk_jobs SET processed_count=processed_count+?,last_error=NULL,updated_at=datetime('now') WHERE id=?`).bind(pool.length,jobId));
      await env.DB.batch(stmts);
      assignments.push(...chunkAssignments); processed+=pool.length; budget-=pool.length;
      if(pool.length<take) break;
    }
    row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=?').bind(jobId).first();
    if(row && Number(row.processed_count||0)>=Number(row.total_count||0) && row.status==='RUNNING'){
      await env.DB.prepare(`UPDATE bulk_jobs SET status='COMPLETED',locked_until=NULL,completed_at=datetime('now'),updated_at=datetime('now') WHERE id=?`).bind(jobId).run();
      await audit(env,row.created_by,'BULK_JOB_COMPLETE','bulk_job',jobId,{job_type:'WAREHOUSE_DISTRIBUTE',processed:Number(row.processed_count||0),total:Number(row.total_count||0)});
    }else{await env.DB.prepare(`UPDATE bulk_jobs SET locked_until=NULL,updated_at=datetime('now') WHERE id=?`).bind(jobId).run();}
    row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=?').bind(jobId).first();
    return {job:bulkJobPublic(row),locked:false,assignments};
  }catch(e){
    await env.DB.prepare(`UPDATE bulk_jobs SET locked_until=NULL,last_error=?,updated_at=datetime('now') WHERE id=?`).bind(String(e?.message||e).slice(0,500),jobId).run();
    throw e;
  }
}
async function processPendingBulkJobs(env,maxJobs=3,maxItemsPerJob=1000){
  await ensureBulkJobSchema(env);
  const rows=(await env.DB.prepare(`SELECT id FROM bulk_jobs WHERE status='RUNNING' ORDER BY updated_at ASC,id ASC LIMIT ?`).bind(maxJobs).all()).results;
  for(const r of rows){try{await processBulkDistributionJob(env,Number(r.id),maxItemsPerJob);}catch{}}
}


// V10.31: one-time historical backfills should never rescan the entire
// customer/lead database on each new Cloudflare Worker isolate.
async function v1031RunHistoricalMaintenanceOnce(env,key,work){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS crm_maintenance_state (
    maintenance_key TEXT PRIMARY KEY,
    completed_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`).run();
  const done=await env.DB.prepare('SELECT maintenance_key FROM crm_maintenance_state WHERE maintenance_key=?').bind(key).first();
  if(done)return;
  await work();
  await env.DB.prepare('INSERT OR IGNORE INTO crm_maintenance_state(maintenance_key) VALUES(?)').bind(key).run();
}
let loanCareSchemaReady=false, loanCareSchemaPromise=null;
async function ensureLoanCareSchema(env){
  if(loanCareSchemaReady) return;
  if(!loanCareSchemaPromise){
    loanCareSchemaPromise=(async()=>{
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS loan_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL UNIQUE,
        team_id INTEGER,
        assigned_user_id INTEGER,
        contract_code TEXT,
        disbursement_date TEXT,
        disbursement_amount REAL NOT NULL DEFAULT 0,
        original_term_months INTEGER NOT NULL DEFAULT 0,
        monthly_due_day INTEGER,
        maturity_date TEXT,
        current_balance REAL NOT NULL DEFAULT 0,
        next_due_date TEXT,
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        reloan_eligible INTEGER NOT NULL DEFAULT 0,
        note TEXT,
        created_by INTEGER,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(team_id) REFERENCES teams(id),
        FOREIGN KEY(assigned_user_id) REFERENCES users(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
      )`).run();
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS loan_care_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        action_type TEXT NOT NULL DEFAULT 'CARE',
        result TEXT,
        note TEXT,
        next_follow_up_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY(loan_id) REFERENCES loan_profiles(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
      )`).run();
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS loan_care_reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        recipient_user_id INTEGER NOT NULL,
        due_date TEXT NOT NULL,
        reminder_type TEXT NOT NULL,
        read_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(loan_id,recipient_user_id,due_date,reminder_type),
        FOREIGN KEY(loan_id) REFERENCES loan_profiles(id),
        FOREIGN KEY(recipient_user_id) REFERENCES users(id)
      )`).run();
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS loan_payment_schedule (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        loan_id INTEGER NOT NULL,
        due_date TEXT NOT NULL,
        amount_due REAL NOT NULL DEFAULT 0,
        amount_paid REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'PENDING',
        paid_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(loan_id,due_date),
        FOREIGN KEY(loan_id) REFERENCES loan_profiles(id)
      )`).run();
      const loanCols=(await env.DB.prepare('PRAGMA table_info(loan_profiles)').all()).results||[];
      if(!loanCols.some(x=>x.name==='cccd')){try{await env.DB.prepare('ALTER TABLE loan_profiles ADD COLUMN cccd TEXT').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loanCols.some(x=>x.name==='monthly_payment')){try{await env.DB.prepare('ALTER TABLE loan_profiles ADD COLUMN monthly_payment REAL NOT NULL DEFAULT 0').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loanCols.some(x=>x.name==='topup_requested_amount')){try{await env.DB.prepare('ALTER TABLE loan_profiles ADD COLUMN topup_requested_amount REAL NOT NULL DEFAULT 0').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loanCols.some(x=>x.name==='topup_at')){try{await env.DB.prepare('ALTER TABLE loan_profiles ADD COLUMN topup_at TEXT').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_profiles_team ON loan_profiles(team_id)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_profiles_user ON loan_profiles(assigned_user_id)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_profiles_status ON loan_profiles(status)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_profiles_next_due ON loan_profiles(next_due_date)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_care_loan ON loan_care_logs(loan_id,created_at)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_care_action_v1031 ON loan_care_logs(loan_id,action_type)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_care_reminder_user ON loan_care_reminders(recipient_user_id,read_at,id)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_care_reminder_due ON loan_care_reminders(due_date,reminder_type)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_loan_schedule_due ON loan_payment_schedule(loan_id,due_date)').run();
      // Run the legacy data migration once per D1, not once per isolate.
      await v1031RunHistoricalMaintenanceOnce(env,'loan_signed_backfill_v1031',async()=>{
        await env.DB.prepare(`INSERT OR IGNORE INTO loan_profiles(customer_id,team_id,assigned_user_id,disbursement_date,status,created_by)
          SELECT c.id,c.team_id,c.assigned_user_id,date(MIN(h.changed_at)),'ACTIVE',MIN(h.changed_by)
          FROM lead_status_history h JOIN customers c ON c.id=h.customer_id
          WHERE h.status='SIGNED'
          GROUP BY c.id,c.team_id,c.assigned_user_id`).run();
      });
      loanCareSchemaReady=true;
    })();
  }
  try{await loanCareSchemaPromise;}finally{if(!loanCareSchemaReady)loanCareSchemaPromise=null;}
}
async function processLoanCareReminders(env){
  await ensureLoanCareSchema(env);
  const todayRow=await env.DB.prepare("SELECT date('now','+7 hours') today,date('now','+7 hours','+3 days') d3").first();
  const today=String(todayRow?.today||''),d3=String(todayRow?.d3||'');
  const {results}=await env.DB.prepare(`SELECT lp.id loan_id,lp.assigned_user_id,c.full_name customer_name,c.phone,
      substr(l.next_follow_up_at,1,10) due_date
    FROM loan_profiles lp JOIN customers c ON c.id=lp.customer_id
    JOIN loan_care_logs l ON l.id=(SELECT x.id FROM loan_care_logs x WHERE x.loan_id=lp.id AND x.next_follow_up_at IS NOT NULL AND trim(x.next_follow_up_at)<>'' ORDER BY x.id DESC LIMIT 1)
    WHERE lp.status<>'SETTLED' AND lp.assigned_user_id IS NOT NULL
      AND substr(l.next_follow_up_at,1,10) IN (?,?)`).bind(today,d3).all();
  const stmts=[];
  for(const r of (results||[])){
    const type=String(r.due_date)===today?'DUE':'D3';
    stmts.push(env.DB.prepare(`INSERT OR IGNORE INTO loan_care_reminders(loan_id,recipient_user_id,due_date,reminder_type) VALUES(?,?,?,?)`)
      .bind(r.loan_id,r.assigned_user_id,r.due_date,type));
  }
  if(stmts.length){for(let i=0;i<stmts.length;i+=80)await env.DB.batch(stmts.slice(i,i+80));}
}

let revenueTargetSchemaReady=false,revenueTargetPromise=null;
async function ensureRevenueTargets(env){
  if(revenueTargetSchemaReady)return;
  if(!revenueTargetPromise)revenueTargetPromise=env.DB.prepare(`CREATE TABLE IF NOT EXISTS revenue_kpi_targets (
    user_id INTEGER NOT NULL,month TEXT NOT NULL,target_volume INTEGER NOT NULL DEFAULT 0,
    target_loans INTEGER NOT NULL DEFAULT 0,target_apps INTEGER NOT NULL DEFAULT 0,
    updated_by INTEGER,updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY(user_id,month))`).run().then(()=>{revenueTargetSchemaReady=true;});
  try{await revenueTargetPromise;}catch(e){revenueTargetPromise=null;throw e;}
}
function loanScopeSql(session,alias='lp'){
  if(isManager(session))return {where:'1=1',bind:[]};
  if(session.role==='teamlead')return {where:`${alias}.team_id=?`,bind:[session.team_id]};
  return {where:`${alias}.assigned_user_id=?`,bind:[session.id]};
}
async function getScopedLoan(env,session,id){
  await ensureLoanCareSchema(env);
  await ensureLoginAppSchema(env);
  const sc=loanScopeSql(session,'lp');
  return env.DB.prepare(`SELECT lp.*,c.full_name customer_name,c.phone,c.source,t.name team,u.display_name owner,
    la.income_amount,la.customer_source,la.company_name,la.company_tax_code,la.residence_province
    FROM loan_profiles lp JOIN customers c ON c.id=lp.customer_id
    LEFT JOIN teams t ON t.id=lp.team_id LEFT JOIN users u ON u.id=lp.assigned_user_id
    LEFT JOIN login_app_cases la ON la.id=(SELECT la2.id FROM login_app_cases la2 WHERE la2.customer_id=lp.customer_id AND la2.status='APPROVED' ORDER BY COALESCE(la2.approved_at,la2.updated_at) DESC,la2.id DESC LIMIT 1)
    WHERE lp.id=? AND ${sc.where}`).bind(Number(id),...sc.bind).first();
}


let loginAppSchemaReady=false,loginAppSchemaPromise=null;
async function ensureLoginAppSchema(env){
  if(loginAppSchemaReady)return;
  if(!loginAppSchemaPromise){
    loginAppSchemaPromise=(async()=>{
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS login_app_cases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        team_id INTEGER,
        assigned_user_id INTEGER NOT NULL,
        customer_name TEXT NOT NULL,
        phone TEXT NOT NULL,
        phone_normalized TEXT,
        cccd TEXT,
        income_amount REAL NOT NULL DEFAULT 0,
        customer_source TEXT,
        company_name TEXT,
        company_tax_code TEXT,
        residence_province TEXT,
        status TEXT NOT NULL DEFAULT 'LOGIN_APP',
        retry_at TEXT,
        reject_reason TEXT,
        disbursement_amount REAL NOT NULL DEFAULT 0,
        monthly_payment REAL NOT NULL DEFAULT 0,
        disbursement_date TEXT,
        term_months INTEGER NOT NULL DEFAULT 0,
        created_by INTEGER NOT NULL,
        approved_at TEXT,
        closed_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(team_id) REFERENCES teams(id),
        FOREIGN KEY(assigned_user_id) REFERENCES users(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
      )`).run();
      const loginCols=(await env.DB.prepare('PRAGMA table_info(login_app_cases)').all()).results||[];
      if(!loginCols.some(x=>x.name==='has_prior_shinhan')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN has_prior_shinhan INTEGER NOT NULL DEFAULT 0').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loginCols.some(x=>x.name==='topup_requested_amount')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN topup_requested_amount REAL NOT NULL DEFAULT 0').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loginCols.some(x=>x.name==='source_loan_id')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN source_loan_id INTEGER').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loginCols.some(x=>x.name==='income_amount')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN income_amount REAL NOT NULL DEFAULT 0').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loginCols.some(x=>x.name==='customer_source')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN customer_source TEXT').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loginCols.some(x=>x.name==='company_name')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN company_name TEXT').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loginCols.some(x=>x.name==='company_tax_code')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN company_tax_code TEXT').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      if(!loginCols.some(x=>x.name==='residence_province')){try{await env.DB.prepare('ALTER TABLE login_app_cases ADD COLUMN residence_province TEXT').run();}catch(e){if(!String(e?.message||e).toLowerCase().includes('duplicate column'))throw e;}}
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_login_app_team ON login_app_cases(team_id,status,updated_at)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_login_app_user ON login_app_cases(assigned_user_id,status,updated_at)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_login_app_phone ON login_app_cases(phone_normalized)').run();
      await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_login_app_customer_status ON login_app_cases(customer_id,status,id)').run();
      // V10.1 legacy notes are repaired once. This UPDATE used to scan all
      // customers every cold start, delaying the Login App and CSKH pages.
      try{
        await v1031RunHistoricalMaintenanceOnce(env,'login_retry_note_backfill_v1031',async()=>{
          await env.DB.prepare(`UPDATE customers SET note=(SELECT 'Đã từ chối hồ sơ ngày '||substr(la.updated_at,9,2)||'/'||substr(la.updated_at,6,2)||'/'||substr(la.updated_at,1,4)||CASE WHEN COALESCE(la.reject_reason,'')<>'' THEN ' · Lý do: '||la.reject_reason ELSE '' END FROM login_app_cases la WHERE la.customer_id=customers.id AND la.status='REJECT_RETRY' ORDER BY la.updated_at DESC,la.id DESC LIMIT 1) WHERE EXISTS(SELECT 1 FROM login_app_cases la WHERE la.customer_id=customers.id AND la.status='REJECT_RETRY') AND COALESCE(note,'') NOT LIKE 'Đã từ chối hồ sơ ngày %'`).run();
        });
      }catch(_e){}
      loginAppSchemaReady=true;
    })();
  }
  try{await loginAppSchemaPromise;}finally{if(!loginAppSchemaReady)loginAppSchemaPromise=null;}
}
function loginAppScopeSql(session,alias='la'){
  if(isManager(session))return {where:'1=1',bind:[]};
  if(session.role==='teamlead')return {where:`${alias}.team_id=?`,bind:[session.team_id]};
  return {where:`${alias}.assigned_user_id=?`,bind:[session.id]};
}
function datePlusMonths(dateStr,months){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(String(dateStr||'')))return null;
  const d=new Date(`${dateStr}T12:00:00Z`);if(Number.isNaN(d.getTime()))return null;
  const day=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+Number(months||0));
  const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last));
  return d.toISOString().slice(0,10);
}
async function resolveLoginAppUser(env,session,requestedUserId){
  if(session.role==='sale')return {id:session.id,team_id:session.team_id,display_name:session.display_name};
  const uid=Number(requestedUserId||0);if(!uid)return null;
  const u=await env.DB.prepare("SELECT id,team_id,display_name,role,active FROM users WHERE id=? AND active=1").bind(uid).first();
  if(!u||u.role!=='sale')return null;
  if(session.role==='teamlead'&&Number(u.team_id)!==Number(session.team_id))return null;
  return u;
}
async function ensureCustomerForLoginApp(env,row){
  let c=null;
  if(row.customer_id)c=await env.DB.prepare('SELECT id,team_id,assigned_user_id FROM customers WHERE id=?').bind(row.customer_id).first();
  if(!c&&row.phone_normalized){
    c=await env.DB.prepare('SELECT id,team_id,assigned_user_id FROM customers WHERE team_id=? AND phone_normalized=? ORDER BY id DESC LIMIT 1').bind(row.team_id,row.phone_normalized).first();
  }
  if(!c){
    const code=`APP${String(row.id).padStart(6,'0')}`;
    const r=await env.DB.prepare(`INSERT INTO customers(customer_code,full_name,phone,phone_normalized,source,team_id,assigned_user_id,status,received_at,note,data_state)
      VALUES(?,?,?,?,?,?,?,?,date('now'),?, 'ASSIGNED')`).bind(code,row.customer_name,row.phone,row.phone_normalized||null,row.customer_source||'LOGIN_APP',row.team_id||null,row.assigned_user_id,'Y02','Khách tạo từ module Login App').run();
    c={id:r.meta?.last_row_id,team_id:row.team_id,assigned_user_id:row.assigned_user_id};
    await env.DB.prepare('UPDATE login_app_cases SET customer_id=? WHERE id=?').bind(c.id,row.id).run();
  }else{
    await env.DB.prepare(`UPDATE customers SET full_name=?,phone=?,phone_normalized=?,source=COALESCE(NULLIF(?,''),source),team_id=?,assigned_user_id=?,updated_at=datetime('now') WHERE id=?`)
      .bind(row.customer_name,row.phone,row.phone_normalized||null,row.customer_source||'',row.team_id||c.team_id,row.assigned_user_id||c.assigned_user_id,c.id).run();
    if(!row.customer_id)await env.DB.prepare('UPDATE login_app_cases SET customer_id=? WHERE id=?').bind(c.id,row.id).run();
  }
  return c;
}

export default {
  async fetch(request, env){
    const url=new URL(request.url);
    if(!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    try{
      await ensureUserStaffSchema(env);
      if(url.pathname==='/api/health') return json({ok:true,service:'call-center-crm',version:'10.36'});
      if(url.pathname==='/api/login' && request.method==='POST'){
        const {username,password}=await request.json();
        if(!username||!password) return bad('Thiếu tài khoản hoặc mật khẩu.');
        const u=await env.DB.prepare(`SELECT u.id,u.username,u.display_name,u.role,u.staff_type,u.team_id,t.name team,u.password_hash FROM users u LEFT JOIN teams t ON t.id=u.team_id WHERE lower(u.username)=lower(?) AND u.active=1`).bind(username.trim()).first();
        if(!u||!(await verifyPassword(password,u.password_hash))) return bad('Sai tài khoản hoặc mật khẩu.',401);
        if(/^([0-9a-f]{64})$/i.test(u.password_hash)){
          await env.DB.prepare('UPDATE users SET password_hash=? WHERE id=?').bind(await hashPassword(password),u.id).run();
        }
        const t=token(), expires=new Date(Date.now()+7*24*3600*1000).toISOString();
        await env.DB.prepare('INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)').bind(t,u.id,expires).run();
        delete u.password_hash; u.role=effectiveRole(u); await audit(env,u.id,'LOGIN_SUCCESS','session',null,{ip:request.headers.get('CF-Connecting-IP')||null}); return json({token:t,user:u,access:await accessMatrix(env,u)});
      }
      const session=await getSession(request,env); if(!session) return bad('Phiên đăng nhập không hợp lệ.',401);


      // Admin manages per-account access rules. No client-side-only authorization.
      if(url.pathname==='/api/loan-care/export' && request.method==='POST'){
        if(!(await hasAccess(env,session,'loanCare','export')))return bad('Bạn chưa được cấp quyền xuất Excel Chăm sóc khách hàng.',403);
        const body=await request.json().catch(()=>({}));
        await audit(env,session.id,'LOAN_CARE_EXPORT','loan',null,{filters:{team:String(body.team||'').slice(0,30),month:String(body.month||'').slice(0,10),tab:String(body.tab||'').slice(0,30)},rows:Math.max(0,Math.min(1000000,Number(body.rows)||0)),ip:request.headers.get('CF-Connecting-IP')||null});
        return json({ok:true});
      }
      if(url.pathname==='/api/access/me' && request.method==='GET'){
        return json({modules:ACCESS_MODULES,actions:ACCESS_ACTIONS,rights:await accessMatrix(env,session)});
      }
      const accessUserPath=url.pathname.match(/^\/api\/access\/users\/(\d+)$/);
      if(accessUserPath){
        if(session.role!=='admin')return bad('Chỉ Admin được cấp quyền truy cập.',403);
        const id=Number(accessUserPath[1]);
        const target=await env.DB.prepare('SELECT id,username,display_name,role,staff_type,team_id,active FROM users WHERE id=? AND active=1').bind(id).first();
        if(target)target.role=effectiveRole(target);
        if(!target)return bad('Không tìm thấy tài khoản.',404);
        if(request.method==='GET')return json({user:target,modules:ACCESS_MODULES,actions:ACCESS_ACTIONS,rights:await accessMatrix(env,target)});
        if(request.method==='PUT'){
          const body=await request.json(),overrides=body.overrides;
          if(!Array.isArray(overrides)||overrides.length>100)return bad('Danh sách quyền không hợp lệ.');
          const seen=new Set(),inserts=[];
          for(const x of overrides){
            if(!x||!Object.hasOwn(ACCESS_MODULES,x.module)||!Object.hasOwn(ACCESS_ACTIONS,x.action)||typeof x.allowed!=='boolean')return bad('Có quyền không hợp lệ.');
            const key=x.module+':'+x.action;if(seen.has(key))return bad('Quyền bị lặp.');seen.add(key);
            if((target.role==='admin'||target.role==='sup')&&x.module==='teamManagement'&&x.action==='view'&&!x.allowed)return bad('Không thể khóa quyền xem Nhân sự của tài khoản Admin.');
            // No grants to manage permission policies: /access only ever belongs to a Admin.
            if(x.allowed!==accessBase(target.role,x.module,x.action))inserts.push(env.DB.prepare('INSERT INTO user_access_rules(user_id,module,action,allowed) VALUES(?,?,?,?)').bind(id,x.module,x.action,x.allowed?1:0));
          }
          await ensureAccessSchema(env);
          await env.DB.batch([env.DB.prepare('DELETE FROM user_access_rules WHERE user_id=?').bind(id),...inserts]);
          await audit(env,session.id,'ACCESS_POLICY_UPDATE','user',id,{target_username:target.username,overrides_count:inserts.length,modules:[...new Set(overrides.map(x=>x.module))],ip:request.headers.get('CF-Connecting-IP')||null});
          return json({ok:true,rights:await accessMatrix(env,target)});
        }
        return bad('Phương thức không hợp lệ.',405);
      }
      const policy=accessRequestPolicy(url.pathname,request.method);
      if(policy && !(await hasAccess(env,session,policy.module,policy.action))){
        await audit(env,session.id,'ACCESS_DENIED','api',null,{path:url.pathname,method:request.method,module:policy.module,action:policy.action,ip:request.headers.get('CF-Connecting-IP')||null});
        return bad(`Bạn chưa được cấp quyền ${ACCESS_ACTIONS[policy.action]} ở mục ${ACCESS_MODULES[policy.module]}.`,403);
      }

      if(url.pathname==='/api/logout' && request.method==='POST'){
        const auth=request.headers.get('authorization')||''; if(auth.startsWith('Bearer ')) await env.DB.prepare('DELETE FROM sessions WHERE token=?').bind(auth.slice(7)).run();
        return json({ok:true});
      }
      if(url.pathname==='/api/me/password' && request.method==='POST'){
        const body=await request.json();
        const currentPassword=String(body.current_password||''), newPassword=String(body.new_password||'');
        if(!currentPassword||!newPassword) return bad('Vui lòng nhập mật khẩu hiện tại và mật khẩu mới.');
        if(newPassword.length<6) return bad('Mật khẩu mới tối thiểu 6 ký tự.');
        if(newPassword===currentPassword) return bad('Mật khẩu mới phải khác mật khẩu hiện tại.');
        const u=await env.DB.prepare('SELECT id,password_hash FROM users WHERE id=? AND active=1').bind(session.id).first();
        if(!u||!(await verifyPassword(currentPassword,u.password_hash))) return bad('Mật khẩu hiện tại không đúng.',401);
        await env.DB.prepare('UPDATE users SET password_hash=? WHERE id=?').bind(await hashPassword(newPassword),session.id).run();
        await audit(env,session.id,'PASSWORD_CHANGE','user',session.id,{ip:request.headers.get('CF-Connecting-IP')||null});
        // Giữ phiên hiện tại để người dùng không bị văng khỏi CRM; đăng xuất các thiết bị/phiên khác để an toàn.
        await env.DB.prepare('DELETE FROM sessions WHERE user_id=? AND token<>?').bind(session.id,session.token).run();
        return json({ok:true});
      }



      // V9.7: Login App workflow -> Approved customer care / retry Follow-up / closed.
      if(url.pathname==='/api/login-apps' && request.method==='GET'){
        await ensureLoginAppSchema(env);
        const sc=loginAppScopeSql(session,'la'),clauses=[sc.where],bind=[...sc.bind];
        const teamRaw=cleanText(url.searchParams.get('team_id')),userRaw=cleanText(url.searchParams.get('user_id')),status=cleanText(url.searchParams.get('status')).toUpperCase(),q=cleanText(url.searchParams.get('q')).slice(0,100);
        if(isManager(session)&&teamRaw&&/^\d+$/.test(teamRaw)){clauses.push('la.team_id=?');bind.push(Number(teamRaw));}
        if((isManager(session)||session.role==='teamlead')&&userRaw&&/^\d+$/.test(userRaw)){
          const u=await resolveLoginAppUser(env,session,Number(userRaw));if(!u)return bad('Nhân viên không hợp lệ hoặc ngoài phạm vi.',403);
          clauses.push('la.assigned_user_id=?');bind.push(u.id);
        }
        if(status&&['LOGIN_APP','APPROVED','REJECT_RETRY','REJECT_CLOSED'].includes(status)){clauses.push('la.status=?');bind.push(status);}
        if(q){clauses.push("(lower(la.customer_name) LIKE lower(?) OR la.phone LIKE ? OR la.cccd LIKE ? OR lower(COALESCE(u.display_name,'')) LIKE lower(?))");bind.push(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`);}
        const {results}=await env.DB.prepare(`SELECT la.*,t.name team,u.display_name owner
          FROM login_app_cases la LEFT JOIN teams t ON t.id=la.team_id LEFT JOIN users u ON u.id=la.assigned_user_id
          WHERE ${clauses.join(' AND ')} ORDER BY CASE la.status WHEN 'LOGIN_APP' THEN 0 WHEN 'REJECT_RETRY' THEN 1 WHEN 'APPROVED' THEN 2 ELSE 3 END,la.updated_at DESC,la.id DESC LIMIT 5000`).bind(...bind).all();
        return json({items:results||[],scope:session.role,team_id:session.team_id||null,user_id:session.id});
      }
      if(url.pathname==='/api/login-apps' && request.method==='POST'){
        await ensureLoginAppSchema(env);
        const body=await request.json(),name=cleanText(body.customer_name).slice(0,160),phoneRaw=cleanText(body.phone).slice(0,40),cccdRaw=cleanText(body.cccd).slice(0,30),phoneNorm=normalizePhone(phoneRaw),cccd=cccdRaw.replace(/\D/g,'');
        const hasPrior=Number(body.has_prior_shinhan)===1?1:0;
        if(!name||!phoneRaw||!cccdRaw)return bad('Vui lòng nhập Tên khách hàng, SĐT và CCCD.');
        if(!/^\d{10}$/.test(phoneNorm))return bad('Số điện thoại bắt buộc đúng 10 số.');
        if(!/^\d{12}$/.test(cccd))return bad('CCCD bắt buộc đúng 12 số.');
        const owner=await resolveLoginAppUser(env,session,body.assigned_user_id);if(!owner)return bad('Nhân viên phụ trách không hợp lệ hoặc ngoài phạm vi.',403);
        const r=await env.DB.prepare(`INSERT INTO login_app_cases(team_id,assigned_user_id,customer_name,phone,phone_normalized,cccd,status,created_by,has_prior_shinhan)
          VALUES(?,?,?,?,?,?,'LOGIN_APP',?,?)`).bind(owner.team_id||null,owner.id,name,phoneNorm,phoneNorm,cccd,session.id,hasPrior).run();
        await audit(env,session.id,'LOGIN_APP_CREATE','login_app',r.meta?.last_row_id||null,{assigned_user_id:owner.id,team_id:owner.team_id||null});
        return json({ok:true,id:r.meta?.last_row_id||null});
      }
      if(url.pathname==='/api/login-apps/import' && request.method==='POST'){
        await ensureLoginAppSchema(env);
        const body=await request.json();
        const items=Array.isArray(body.items)?body.items.slice(0,200):[];
        if(!items.length)return bad('File Excel không có dữ liệu hợp lệ để nhập.');

        let userSql="SELECT id,username,display_name,team_id,role FROM users WHERE active=1 AND role='sale'";
        const userBind=[];
        if(session.role==='teamlead'){userSql+=' AND team_id=?';userBind.push(session.team_id);}
        if(session.role==='sale'){userSql+=' AND id=?';userBind.push(session.id);}
        const userStmt=env.DB.prepare(userSql);
        const userRows=(userBind.length?await userStmt.bind(...userBind).all():await userStmt.all()).results||[];
        const byId=new Map(userRows.map(u=>[Number(u.id),u]));
        const defaultOwner=session.role==='sale'?byId.get(Number(session.id)):(body.default_assigned_user_id?byId.get(Number(body.default_assigned_user_id)):null);

        const sc=loginAppScopeSql(session,'la');
        const phoneCandidates=[...new Set(items.map(x=>normalizeLoginAppImportPhone(cleanText(x.phone))).filter(x=>/^\d{10}$/.test(x)))];
        const cccdCandidates=[...new Set(items.map(x=>normalizeLoginAppImportCccd(cleanText(x.cccd))).filter(x=>/^\d{12}$/.test(x)))];
        const existingPhones=new Set(),existingCccds=new Set();
        for(let i=0;i<phoneCandidates.length;i+=30){
          const chunk=phoneCandidates.slice(i,i+30),marks=chunk.map(()=>'?').join(',');
          const q=await env.DB.prepare(`SELECT phone_normalized FROM login_app_cases la WHERE ${sc.where} AND phone_normalized IN (${marks})`).bind(...sc.bind,...chunk).all();
          for(const r of (q.results||[]))if(r.phone_normalized)existingPhones.add(String(r.phone_normalized));
        }
        for(let i=0;i<cccdCandidates.length;i+=30){
          const chunk=cccdCandidates.slice(i,i+30),marks=chunk.map(()=>'?').join(',');
          const q=await env.DB.prepare(`SELECT cccd FROM login_app_cases la WHERE ${sc.where} AND cccd IN (${marks})`).bind(...sc.bind,...chunk).all();
          for(const r of (q.results||[]))if(r.cccd)existingCccds.add(String(r.cccd));
        }

        const seenPhone=new Set(),seenCccd=new Set(),valid=[],skipped=[];
        for(let idx=0;idx<items.length;idx++){
          const x=items[idx]||{},row=Number(x.row_number||idx+2),name=cleanText(x.customer_name).slice(0,160),phone=normalizeLoginAppImportPhone(cleanText(x.phone)),cccd=normalizeLoginAppImportCccd(cleanText(x.cccd));
          const prior=0;
          const owner=defaultOwner;
          let reason='';
          if(!name)reason='Thiếu tên khách hàng';
          else if(!/^\d{10}$/.test(phone))reason=phone.length>10?`SĐT dư ${phone.length-10} số`:`SĐT thiếu ${10-phone.length} số`;
          else if(!/^\d{12}$/.test(cccd))reason=cccd.length>12?`CCCD dư ${cccd.length-12} số`:`CCCD thiếu ${12-cccd.length} số`;
          else if(!owner)reason=session.role==='sale'?'Không xác định được tài khoản nhân viên':'Chưa chọn nhân viên phụ trách hoặc nhân viên ngoài phạm vi';
          else if(existingPhones.has(phone)||existingCccds.has(cccd))reason='Khách đã có trong Login App';
          else if(seenPhone.has(phone)||seenCccd.has(cccd))reason='Trùng trong file Excel';
          if(reason){skipped.push({row,customer_name:name,phone,cccd,reason});continue;}
          seenPhone.add(phone);seenCccd.add(cccd);
          valid.push({row,name,phone,cccd,prior,owner});
        }

        let inserted=0;
        for(let i=0;i<valid.length;i+=80){
          const chunk=valid.slice(i,i+80);
          const stmts=chunk.map(x=>env.DB.prepare(`INSERT INTO login_app_cases(team_id,assigned_user_id,customer_name,phone,phone_normalized,cccd,status,created_by,has_prior_shinhan) VALUES(?,?,?,?,?,?,'LOGIN_APP',?,?)`).bind(x.owner.team_id||null,x.owner.id,x.name,x.phone,x.phone,x.cccd,session.id,x.prior));
          if(stmts.length){await env.DB.batch(stmts);inserted+=stmts.length;}
        }
        if(inserted)await audit(env,session.id,'LOGIN_APP_IMPORT','login_app',null,{inserted,skipped:skipped.length});
        return json({ok:true,inserted,skipped_count:skipped.length,skipped});
      }
      const loginAppMatch=url.pathname.match(/^\/api\/login-apps\/(\d+)$/);
      if(loginAppMatch && request.method==='DELETE'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Chỉ Admin hoặc Team Leader được xóa khách Login App.',403);
        await ensureLoginAppSchema(env);
        const id=Number(loginAppMatch[1]),sc=loginAppScopeSql(session,'la');
        const row=await env.DB.prepare(`SELECT la.id,la.customer_id,la.customer_name,la.status,la.team_id,la.assigned_user_id FROM login_app_cases la WHERE la.id=? AND ${sc.where}`).bind(id,...sc.bind).first();
        if(!row)return bad('Không tìm thấy khách Login App hoặc khách không thuộc phạm vi Team của bạn.',404);
        await env.DB.prepare('DELETE FROM login_app_cases WHERE id=?').bind(id).run();
        await audit(env,session.id,'LOGIN_APP_DELETE','login_app',id,{customer_id:row.customer_id||null,customer_name:row.customer_name||'',status:row.status||'',team_id:row.team_id||null,assigned_user_id:row.assigned_user_id||null});
        return json({ok:true});
      }
      if(loginAppMatch && request.method==='PATCH'){
        await ensureLoginAppSchema(env);await ensureLoanCareSchema(env);
        const id=Number(loginAppMatch[1]),sc=loginAppScopeSql(session,'la');
        const row=await env.DB.prepare(`SELECT la.* FROM login_app_cases la WHERE la.id=? AND ${sc.where}`).bind(id,...sc.bind).first();
        if(!row)return bad('Không tìm thấy khách Login App hoặc bạn không có quyền.',404);
        const body=await request.json(),next=cleanText(body.status).toUpperCase();
        if(!['LOGIN_APP','APPROVED','REJECT_RETRY','REJECT_CLOSED'].includes(next))return bad('Trạng thái Login App không hợp lệ.');
        if(body.has_prior_shinhan!==undefined)await env.DB.prepare("UPDATE login_app_cases SET has_prior_shinhan=?,updated_at=datetime('now') WHERE id=?").bind(Number(body.has_prior_shinhan)===1?1:0,id).run();
        const reason=cleanText(body.reject_reason).slice(0,500),now=new Date().toISOString().slice(0,19).replace('T',' ');
        const incomeAmount=Number(body.income_amount||0);
        const customerSource=cleanText(body.customer_source).slice(0,40);
        const companyName=cleanText(body.company_name).slice(0,180);
        const companyTaxCode=cleanText(body.company_tax_code).slice(0,30);
        const residenceProvince=cleanText(body.residence_province).slice(0,100);
        if(next!=='LOGIN_APP'){
          if(!(incomeAmount>0))return bad('Vui lòng nhập Thu nhập của khách hàng.');
          if(!LOGIN_APP_CUSTOMER_SOURCES.includes(customerSource))return bad('Vui lòng chọn Nguồn KH hợp lệ.');
          if(!companyName)return bad('Vui lòng nhập Tên Công ty.');
          if(!companyTaxCode)return bad('Vui lòng nhập MST.');
          if(!VIETNAM_PROVINCES_2025.includes(residenceProvince))return bad('Vui lòng chọn Nơi ở KH trong danh sách tỉnh/thành sau sáp nhập.');
          await env.DB.prepare(`UPDATE login_app_cases SET income_amount=?,customer_source=?,company_name=?,company_tax_code=?,residence_province=?,updated_at=datetime('now') WHERE id=?`)
            .bind(incomeAmount,customerSource,companyName,companyTaxCode,residenceProvince,id).run();
          row.income_amount=incomeAmount;row.customer_source=customerSource;row.company_name=companyName;row.company_tax_code=companyTaxCode;row.residence_province=residenceProvince;
        }
        if(next==='LOGIN_APP'){
          await env.DB.prepare(`UPDATE login_app_cases SET status='LOGIN_APP',retry_at=NULL,reject_reason=NULL,closed_at=NULL,updated_at=datetime('now') WHERE id=?`).bind(id).run();
          await v1036MarkOpenAppFollowupsDone(env,id);
          return json({ok:true});
        }
        if(next==='REJECT_RETRY'){
          const retryAt=cleanText(body.retry_at);if(!retryAt)return bad('Vui lòng chọn ngày khách có thể lên lại.');
          const customer=await ensureCustomerForLoginApp(env,row);
          const rejectDate=now.slice(0,10).split('-').reverse().join('/');
          const retryNote=`Đã từ chối hồ sơ ngày ${rejectDate}${reason?` · Lý do: ${reason}`:''}`;
          await env.DB.prepare(`UPDATE customers SET follow_up_at=?,note=?,updated_at=datetime('now') WHERE id=?`).bind(retryAt,retryNote,customer.id).run();
          await env.DB.prepare(`UPDATE login_app_cases SET status='REJECT_RETRY',retry_at=?,reject_reason=?,closed_at=NULL,updated_at=datetime('now') WHERE id=?`).bind(retryAt,reason||null,id).run();
          const followupId=await v1036UpsertAppFollowup(env,{id,team_id:row.team_id,assigned_user_id:row.assigned_user_id},retryAt,'RELOGIN',retryNote,session.id);
          await audit(env,session.id,'LOGIN_APP_RETRY','login_app',id,{retry_at:retryAt,rejected_on:now.slice(0,10),customer_id:customer.id,app_followup_id:followupId});
          return json({ok:true,customer_id:customer.id,followup_id:followupId});
        }
        if(next==='REJECT_CLOSED'){
          await env.DB.prepare(`UPDATE login_app_cases SET status='REJECT_CLOSED',retry_at=NULL,reject_reason=?,closed_at=?,updated_at=datetime('now') WHERE id=?`).bind(reason||null,now,id).run();
          await v1036MarkOpenAppFollowupsDone(env,id);
          await audit(env,session.id,'LOGIN_APP_CLOSED','login_app',id,{reason:reason||null});
          return json({ok:true});
        }
        const amount=Number(body.disbursement_amount||0),monthly=Number(body.monthly_payment||0),date=cleanText(body.disbursement_date),term=Number(body.term_months||0);
        if(!(amount>0)||!(monthly>0)||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!(term>0))return bad('Vui lòng nhập đủ Số tiền giải ngân, Số tiền đóng hàng tháng, Ngày giải ngân và Kỳ hạn vay.');
        const customer=await ensureCustomerForLoginApp(env,row),maturity=datePlusMonths(date,term),nextDue=datePlusMonths(date,1),dueDay=Number(date.slice(8,10));
        const existing=await env.DB.prepare('SELECT id FROM loan_profiles WHERE customer_id=?').bind(customer.id).first();
        if(existing){
          await env.DB.prepare(`UPDATE loan_profiles SET team_id=?,assigned_user_id=?,cccd=?,disbursement_date=?,disbursement_amount=?,monthly_payment=?,original_term_months=?,monthly_due_day=?,maturity_date=?,current_balance=?,next_due_date=?,status='ACTIVE',reloan_eligible=0,updated_at=datetime('now') WHERE id=?`)
            .bind(row.team_id||null,row.assigned_user_id,row.cccd||null,date,amount,monthly,term,dueDay,maturity,amount,nextDue,existing.id).run();
        }else{
          await env.DB.prepare(`INSERT INTO loan_profiles(customer_id,team_id,assigned_user_id,contract_code,cccd,disbursement_date,disbursement_amount,monthly_payment,original_term_months,monthly_due_day,maturity_date,current_balance,next_due_date,status,reloan_eligible,created_by)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'ACTIVE',0,?)`).bind(customer.id,row.team_id||null,row.assigned_user_id,`HD${String(id).padStart(6,'0')}`,row.cccd||null,date,amount,monthly,term,dueDay,maturity,amount,nextDue,session.id).run();
        }
        await env.DB.prepare(`UPDATE login_app_cases SET status='APPROVED',disbursement_amount=?,monthly_payment=?,disbursement_date=?,term_months=?,approved_at=?,retry_at=NULL,reject_reason=NULL,closed_at=NULL,updated_at=datetime('now') WHERE id=?`)
          .bind(amount,monthly,date,term,now,id).run();
        await v1036MarkOpenAppFollowupsDone(env,id);
        await env.DB.prepare(`UPDATE customers SET follow_up_at=NULL,note=COALESCE(note,'')||CASE WHEN COALESCE(note,'')='' THEN '' ELSE '
' END||'Đã giải ngân từ Login App',updated_at=datetime('now') WHERE id=?`).bind(customer.id).run();
        await audit(env,session.id,'LOGIN_APP_APPROVED','login_app',id,{customer_id:customer.id,amount,term_months:term});
        return json({ok:true,customer_id:customer.id});
      }

      // V9.5: Post-disbursement customer lifecycle management.
      // V10.35: Login App + giải ngân reporting, scoped on the SERVER (not only filtered in the UI).
      if(url.pathname==='/api/login-performance' && request.method==='GET'){
        await ensureLoginAppSchema(env);await ensureLoanCareSchema(env);
        const month=cleanText(url.searchParams.get('month'));
        if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))return bad('Tháng phải có dạng YYYY-MM.');
        const requestedTeam=Number(url.searchParams.get('team_id')||0),requestedUser=Number(url.searchParams.get('user_id')||0);
        const teamId=isManager(session)?requestedTeam:(session.role==='teamlead'?Number(session.team_id||0):0);
        const userId=session.role==='sale'?Number(session.id):requestedUser;
        if(session.role==='teamlead'&&!session.team_id)return bad('Tài khoản chưa thuộc Team.',403);
        if(userId){const check=await env.DB.prepare("SELECT team_id,role,active FROM users WHERE id=?").bind(userId).first();
          if(!check||check.role!=='sale'||!Number(check.active))return bad('Nhân viên không hợp lệ.',400);
          if(!isManager(session)&&session.role==='teamlead'&&Number(check.team_id)!==Number(session.team_id))return bad('Không có quyền xem Team khác.',403);
          if(teamId&&Number(check.team_id)!==teamId)return bad('Nhân viên không thuộc Team đã chọn.',400);
        }
        const where=[],bindings=[];
        if(teamId){where.push('u.team_id=?');bindings.push(teamId);}
        if(userId){where.push('u.id=?');bindings.push(userId);}
        const users=(await env.DB.prepare(`SELECT u.id,u.display_name,u.username,u.team_id,u.staff_type,t.name team FROM users u LEFT JOIN teams t ON t.id=u.team_id WHERE u.active=1 AND u.role='sale' ${where.length?'AND '+where.join(' AND '):''} ORDER BY t.name,u.display_name`).bind(...bindings).all()).results||[];
        // Aggregates are grouped by assigned employee rather than multiplying app and loan counts in a join.
        const appScope=loginAppScopeSql(session,'la'),loanScope=loanScopeSql(session,'lp');
        const appMonthExpr=`CASE WHEN la.status='APPROVED' AND la.disbursement_date IS NOT NULL AND julianday(substr(la.created_at,1,10)) - julianday(la.disbursement_date) > 45 THEN substr(la.disbursement_date,1,7) ELSE substr(la.created_at,1,7) END`;
        const appWhere=[appScope.where,`${appMonthExpr}=?`],appBindings=[...appScope.bind,month];
        const loanWhere=[loanScope.where,"substr(lp.disbursement_date,1,7)=?"],loanBindings=[...loanScope.bind,month];
        if(teamId){appWhere.push('la.team_id=?');appBindings.push(teamId);loanWhere.push('lp.team_id=?');loanBindings.push(teamId);}
        if(userId){appWhere.push('la.assigned_user_id=?');appBindings.push(userId);loanWhere.push('lp.assigned_user_id=?');loanBindings.push(userId);}
        const appRows=(await env.DB.prepare(`SELECT la.assigned_user_id user_id,COUNT(*) count FROM login_app_cases la WHERE ${appWhere.join(' AND ')} GROUP BY la.assigned_user_id`).bind(...appBindings).all()).results||[];
        const loanRows=(await env.DB.prepare(`SELECT lp.assigned_user_id user_id,COUNT(*) count,COALESCE(SUM(lp.disbursement_amount),0) volume FROM loan_profiles lp WHERE ${loanWhere.join(' AND ')} GROUP BY lp.assigned_user_id`).bind(...loanBindings).all()).results||[];
        await ensureRevenueTargets(env);
        const userIds=users.map(u=>Number(u.id));let targetRows=[];
        if(userIds.length){const marks=userIds.map(()=>'?').join(',');targetRows=(await env.DB.prepare(`SELECT user_id,target_volume,target_loans,target_apps FROM revenue_kpi_targets WHERE month=? AND user_id IN (${marks})`).bind(month,...userIds).all()).results||[];}
        const appMap=new Map(appRows.map(r=>[Number(r.user_id),Number(r.count)])),loanMap=new Map(loanRows.map(r=>[Number(r.user_id),r])),targetMap=new Map(targetRows.map(r=>[Number(r.user_id),r]));
        const items=users.map(u=>{const id=Number(u.id),loans=loanMap.get(id)||{},kpi=targetMap.get(id)||{};return {...u,apps:appMap.get(id)||0,loans:Number(loans.count||0),volume:Number(loans.volume||0),target_volume:Number(kpi.target_volume||0),target_loans:Number(kpi.target_loans||0),target_apps:Number(kpi.target_apps||0)};});
        const total={apps:appRows.reduce((n,r)=>n+Number(r.count||0),0),loans:loanRows.reduce((n,r)=>n+Number(r.count||0),0),volume:loanRows.reduce((n,r)=>n+Number(r.volume||0),0)};
        return json({month,items,total,scope:session.role,team_id:teamId||null,user_id:userId||null});
      }
      if(url.pathname==='/api/revenue-kpi/bulk' && request.method==='PUT'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Bạn không có quyền giao KPI.',403);
        await ensureRevenueTargets(env);
        const body=await request.json();const month=cleanText(body.month);
        if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))return bad('Tháng KPI không hợp lệ.');
        const ids=[...new Set((Array.isArray(body.user_ids)?body.user_ids:[]).map(Number))];
        if(ids.length<1||ids.length>100||ids.some(x=>!Number.isSafeInteger(x)||x<1))return bad('Chọn từ 1 đến 100 nhân viên.',400);
        const nums=['target_volume','target_loans','target_apps'].map(k=>Number(body[k]));
        if(nums.some(n=>!Number.isSafeInteger(n)||n<0||n>1000000000000))return bad('Chỉ tiêu phải là số nguyên không âm.',400);
        const marks=ids.map(()=>'?').join(',');
        const eligible=(await env.DB.prepare(`SELECT id,team_id FROM users WHERE active=1 AND role='sale' AND id IN (${marks})`).bind(...ids).all()).results||[];
        if(eligible.length!==ids.length)return bad('Có nhân viên không còn hoạt động.',409);
        if(session.role==='teamlead'&&eligible.some(u=>Number(u.team_id)!==Number(session.team_id)))return bad('Chỉ đặt KPI cho Team của bạn.',403);
        const stmts=ids.map(id=>env.DB.prepare(`INSERT INTO revenue_kpi_targets(user_id,month,target_volume,target_loans,target_apps,updated_by,updated_at)
          VALUES(?,?,?,?,?,?,datetime('now')) ON CONFLICT(user_id,month) DO UPDATE SET
          target_volume=excluded.target_volume,target_loans=excluded.target_loans,target_apps=excluded.target_apps,
          updated_by=excluded.updated_by,updated_at=datetime('now')`).bind(id,month,...nums,session.id));
        await env.DB.batch(stmts);
        await audit(env,session.id,'REVENUE_KPI_BULK','kpi',null,{month,count:ids.length,target_volume:nums[0],target_loans:nums[1],target_apps:nums[2]});
        return json({ok:true,updated:ids.length});
      }
      if(url.pathname==='/api/revenue-kpi' && request.method==='PUT'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Không có quyền đặt KPI doanh số.',403);
        await ensureRevenueTargets(env);
        const body=await request.json();const month=cleanText(body.month),userId=Number(body.user_id);
        if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))return bad('Tháng không hợp lệ.');
        const user=await env.DB.prepare("SELECT id,team_id FROM users WHERE id=? AND role='sale' AND active=1").bind(userId).first();
        if(!user)return bad('Không tìm thấy Sales/Freelancer đang hoạt động.',404);
        if(session.role==='teamlead'&&Number(user.team_id)!==Number(session.team_id))return bad('Bạn chỉ được đặt KPI cho Team mình.',403);
        const nums=['target_volume','target_loans','target_apps'].map(k=>Number(body[k]));
        if(nums.some(n=>!Number.isSafeInteger(n)||n<0||n>1000000000000))return bad('KPI phải là số nguyên không âm và hợp lệ.');
        await env.DB.prepare(`INSERT INTO revenue_kpi_targets(user_id,month,target_volume,target_loans,target_apps,updated_by,updated_at) VALUES(?,?,?,?,?,?,datetime('now')) ON CONFLICT(user_id,month) DO UPDATE SET target_volume=excluded.target_volume,target_loans=excluded.target_loans,target_apps=excluded.target_apps,updated_by=excluded.updated_by,updated_at=datetime('now')`).bind(userId,month,...nums,session.id).run();
        await audit(env,session.id,'REVENUE_KPI_SET','user',userId,{month,target_volume:nums[0],target_loans:nums[1],target_apps:nums[2]});
        return json({ok:true});
      }
      if(url.pathname==='/api/loans' && request.method==='GET'){
        await ensureLoanCareSchema(env);
        await ensureLoginAppSchema(env);
        const sc=loanScopeSql(session,'lp');
        const teamRaw=cleanText(url.searchParams.get('team_id'));
        const userRaw=cleanText(url.searchParams.get('user_id'));
        const status=cleanText(url.searchParams.get('status')).toUpperCase();
        const q=cleanText(url.searchParams.get('q')).slice(0,100);
        const clauses=[sc.where],bind=[...sc.bind];
        if(isManager(session)&&teamRaw&&/^\d+$/.test(teamRaw)){clauses.push('lp.team_id=?');bind.push(Number(teamRaw));}
        if((isManager(session)||session.role==='teamlead')&&userRaw&&/^\d+$/.test(userRaw)){
          const target=await env.DB.prepare("SELECT id,team_id,role FROM users WHERE id=? AND active=1").bind(Number(userRaw)).first();
          if(!target||target.role!=='sale')return bad('Nhân viên không hợp lệ.');
          if(session.role==='teamlead'&&Number(target.team_id)!==Number(session.team_id))return bad('Không có quyền xem nhân viên Team khác.',403);
          clauses.push('lp.assigned_user_id=?');bind.push(Number(userRaw));
        }
        if(status&&['ACTIVE','DUE','OVERDUE','NEAR_MATURITY','SETTLED','CARE_REQUIRED','TOPUP'].includes(status)){clauses.push('lp.status=?');bind.push(status);}
        if(q){clauses.push("(lower(c.full_name) LIKE lower(?) OR c.phone LIKE ? OR lower(COALESCE(lp.contract_code,'')) LIKE lower(?))");bind.push(`%${q}%`,`%${q}%`,`%${q}%`);}
        const {results}=await env.DB.prepare(`SELECT lp.id,lp.customer_id,lp.team_id,lp.assigned_user_id,lp.contract_code,lp.cccd,lp.disbursement_date,lp.disbursement_amount,lp.monthly_payment,
          lp.original_term_months,lp.monthly_due_day,lp.maturity_date,lp.current_balance,lp.next_due_date,lp.status,lp.reloan_eligible,lp.topup_requested_amount,lp.topup_at,lp.note,lp.created_at,lp.updated_at,
          c.full_name customer_name,c.phone,c.source,t.name team,u.display_name owner,
          la.income_amount,la.customer_source,la.company_name,la.company_tax_code,la.residence_province,
          (SELECT MAX(l.created_at) FROM loan_care_logs l WHERE l.loan_id=lp.id) last_care_at,
          (SELECT MAX(l.next_follow_up_at) FROM loan_care_logs l WHERE l.loan_id=lp.id AND l.next_follow_up_at IS NOT NULL) next_care_at,
          EXISTS(SELECT 1 FROM loan_care_logs l WHERE l.loan_id=lp.id AND l.action_type='CARE_30') care30_done,
          EXISTS(SELECT 1 FROM loan_care_logs l WHERE l.loan_id=lp.id AND l.action_type='CARE_60') care60_done,
          EXISTS(SELECT 1 FROM loan_care_logs l WHERE l.loan_id=lp.id AND l.action_type='TOPUP') topup_done
          FROM loan_profiles lp JOIN customers c ON c.id=lp.customer_id
          LEFT JOIN teams t ON t.id=lp.team_id LEFT JOIN users u ON u.id=lp.assigned_user_id
          LEFT JOIN login_app_cases la ON la.id=(SELECT la2.id FROM login_app_cases la2 WHERE la2.customer_id=lp.customer_id AND la2.status='APPROVED' ORDER BY COALESCE(la2.approved_at,la2.updated_at) DESC,la2.id DESC LIMIT 1)
          WHERE ${clauses.join(' AND ')} ORDER BY CASE WHEN lp.status='OVERDUE' THEN 0 WHEN lp.status='DUE' THEN 1 WHEN lp.status='NEAR_MATURITY' THEN 2 ELSE 3 END,
          COALESCE(lp.next_due_date,'9999-12-31'),lp.id DESC LIMIT 5000`).bind(...bind).all();
        return json({items:results||[],scope:session.role,team_id:session.team_id||null,user_id:session.id});
      }
      if(url.pathname==='/api/loans' && request.method==='POST'){
        if(session.role==='sale')return bad('Nhân viên không được tự tạo hồ sơ khoản vay.',403);
        await ensureLoanCareSchema(env);
        const body=await request.json();
        const customerId=Number(body.customer_id);
        if(!Number.isSafeInteger(customerId)||customerId<1)return bad('Khách hàng không hợp lệ.');
        const sc=scopeSql(session,'c');
        const c=await env.DB.prepare(`SELECT c.id,c.team_id,c.assigned_user_id FROM customers c WHERE c.id=? AND ${sc.where}`).bind(customerId,...sc.bind).first();
        if(!c)return bad('Không tìm thấy khách hoặc bạn không có quyền.',404);
        const r=await env.DB.prepare(`INSERT OR IGNORE INTO loan_profiles(customer_id,team_id,assigned_user_id,contract_code,cccd,disbursement_date,disbursement_amount,monthly_payment,original_term_months,monthly_due_day,maturity_date,current_balance,next_due_date,status,reloan_eligible,note,created_by)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(customerId,c.team_id||null,c.assigned_user_id||null,cleanText(body.contract_code)||null,cleanText(body.cccd)||null,cleanText(body.disbursement_date)||null,Number(body.disbursement_amount||0),Number(body.monthly_payment||0),Number(body.original_term_months||0),Number(body.monthly_due_day||0)||null,cleanText(body.maturity_date)||null,Number(body.current_balance||0),cleanText(body.next_due_date)||null,cleanText(body.status||'ACTIVE').toUpperCase(),body.reloan_eligible?1:0,cleanText(body.note).slice(0,1000)||null,session.id).run();
        const row=await env.DB.prepare('SELECT id FROM loan_profiles WHERE customer_id=?').bind(customerId).first();
        await audit(env,session.id,'LOAN_PROFILE_CREATE','loan',row?.id||null,{customer_id:customerId});
        return json({ok:true,id:row?.id||r.meta?.last_row_id||null});
      }
      const loanMatch=url.pathname.match(/^\/api\/loans\/(\d+)$/);
      if(loanMatch && request.method==='DELETE'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Chỉ Admin hoặc Team Leader được xóa khách trong Chăm sóc khách hàng.',403);
        await ensureLoanCareSchema(env);
        const id=Number(loanMatch[1]);
        const loan=await getScopedLoan(env,session,id);
        if(!loan)return bad('Không tìm thấy hồ sơ chăm sóc khách hàng hoặc khách không thuộc phạm vi Team của bạn.',404);
        await env.DB.batch([
          env.DB.prepare('DELETE FROM loan_care_reminders WHERE loan_id=?').bind(id),
          env.DB.prepare('DELETE FROM loan_care_logs WHERE loan_id=?').bind(id),
          env.DB.prepare('DELETE FROM loan_profiles WHERE id=?').bind(id)
        ]);
        await audit(env,session.id,'LOAN_PROFILE_DELETE','loan',id,{customer_id:loan.customer_id||null,team_id:loan.team_id||null,assigned_user_id:loan.assigned_user_id||null});
        return json({ok:true});
      }
      if(loanMatch && request.method==='PATCH'){
        const id=Number(loanMatch[1]),loan=await getScopedLoan(env,session,id);
        if(!loan)return bad('Không tìm thấy hồ sơ khoản vay hoặc bạn không có quyền.',404);
        const body=await request.json();
        const allowedStatus=new Set(['ACTIVE','DUE','OVERDUE','NEAR_MATURITY','SETTLED','CARE_REQUIRED','TOPUP']);
        let assignedUserId=loan.assigned_user_id;
        if(body.assigned_user_id!==undefined&&session.role!=='sale'){
          const uid=Number(body.assigned_user_id);
          const u=await env.DB.prepare("SELECT id,team_id,role FROM users WHERE id=? AND active=1").bind(uid).first();
          if(!u||u.role!=='sale')return bad('Nhân viên phụ trách không hợp lệ.');
          if(session.role==='teamlead'&&Number(u.team_id)!==Number(session.team_id))return bad('Không thể giao khách sang Team khác.',403);
          assignedUserId=uid;
        }
        const status=body.status!==undefined?cleanText(body.status).toUpperCase():loan.status;
        if(!allowedStatus.has(status))return bad('Trạng thái khoản vay không hợp lệ.');
        await env.DB.prepare(`UPDATE loan_profiles SET assigned_user_id=?,contract_code=?,cccd=?,disbursement_date=?,disbursement_amount=?,monthly_payment=?,original_term_months=?,monthly_due_day=?,maturity_date=?,current_balance=?,next_due_date=?,status=?,reloan_eligible=?,note=?,updated_at=datetime('now') WHERE id=?`)
          .bind(assignedUserId,body.contract_code!==undefined?cleanText(body.contract_code)||null:loan.contract_code,body.cccd!==undefined?cleanText(body.cccd)||null:loan.cccd,body.disbursement_date!==undefined?cleanText(body.disbursement_date)||null:loan.disbursement_date,body.disbursement_amount!==undefined?Number(body.disbursement_amount||0):loan.disbursement_amount,body.monthly_payment!==undefined?Number(body.monthly_payment||0):loan.monthly_payment,body.original_term_months!==undefined?Number(body.original_term_months||0):loan.original_term_months,body.monthly_due_day!==undefined?(Number(body.monthly_due_day||0)||null):loan.monthly_due_day,body.maturity_date!==undefined?cleanText(body.maturity_date)||null:loan.maturity_date,body.current_balance!==undefined?Number(body.current_balance||0):loan.current_balance,body.next_due_date!==undefined?cleanText(body.next_due_date)||null:loan.next_due_date,status,body.reloan_eligible!==undefined?(body.reloan_eligible?1:0):loan.reloan_eligible,body.note!==undefined?cleanText(body.note).slice(0,1000)||null:loan.note,id).run();
        const cols=AUDIT_UNDO_TARGETS.LOAN_PROFILE_UPDATE.fields;
        const updatedLoan=await env.DB.prepare(`SELECT ${cols.join(',')} FROM loan_profiles WHERE id=?`).bind(id).first();
        const beforeLoan=pickedUndoValues(loan,cols),afterLoan=pickedUndoValues(updatedLoan,cols);
        const changedCols=cols.filter(k=>beforeLoan[k]!==afterLoan[k]);
        if(changedCols.length){
          await auditWithUndo(env,session,'LOAN_PROFILE_UPDATE','loan',id,{status,assigned_user_id:assignedUserId},pickedUndoValues(beforeLoan,changedCols),pickedUndoValues(afterLoan,changedCols));
        }else{
          await audit(env,session.id,'LOAN_PROFILE_UPDATE','loan',id,{status,assigned_user_id:assignedUserId,unchanged:true});
        }
        return json({ok:true});
      }
      const loanHistoryMatch=url.pathname.match(/^\/api\/loans\/(\d+)\/history$/);
      if(loanHistoryMatch && request.method==='GET'){
        const id=Number(loanHistoryMatch[1]),loan=await getScopedLoan(env,session,id);
        if(!loan)return bad('Không tìm thấy hồ sơ khoản vay hoặc bạn không có quyền.',404);
        const {results}=await env.DB.prepare(`SELECT l.id,l.action_type,l.result,l.note,l.next_follow_up_at,l.created_at,u.display_name actor
          FROM loan_care_logs l LEFT JOIN users u ON u.id=l.user_id WHERE l.loan_id=? ORDER BY l.id DESC LIMIT 300`).bind(id).all();
        return json({loan,items:results||[]});
      }
      const loanCareMatch=url.pathname.match(/^\/api\/loans\/(\d+)\/care$/);
      if(loanCareMatch && request.method==='POST'){
        const id=Number(loanCareMatch[1]),loan=await getScopedLoan(env,session,id);
        if(!loan)return bad('Không tìm thấy hồ sơ khoản vay hoặc bạn không có quyền.',404);
        const body=await request.json(),note=cleanText(body.note).slice(0,1500),result=cleanText(body.result).slice(0,200),action=cleanText(body.action_type||'CARE').slice(0,40).toUpperCase();
        let next=cleanText(body.next_follow_up_at)||null;
        if(next){next=next.slice(0,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(next))return bad('Ngày chăm sóc tiếp theo không hợp lệ.');}
        if(!note&&!result)return bad('Vui lòng nhập kết quả hoặc ghi chú chăm sóc.');
        const r=await env.DB.prepare('INSERT INTO loan_care_logs(loan_id,customer_id,user_id,action_type,result,note,next_follow_up_at) VALUES(?,?,?,?,?,?,?)').bind(id,loan.customer_id,session.id,action,result||null,note||null,next).run();
        await env.DB.prepare('DELETE FROM loan_care_reminders WHERE loan_id=?').bind(id).run();
        if(next)await env.DB.prepare("UPDATE loan_profiles SET updated_at=datetime('now') WHERE id=?").bind(id).run();
        await audit(env,session.id,'LOAN_CARE_RECORDED','loan',id,{action,result:result||null,next_follow_up_at:next});
        return json({ok:true,id:r.meta?.last_row_id||null});
      }

      const loanTopupMatch=url.pathname.match(/^\/api\/loans\/(\d+)\/topup$/);
      if(loanTopupMatch && request.method==='POST'){
        await ensureLoginAppSchema(env);
        const id=Number(loanTopupMatch[1]),loan=await getScopedLoan(env,session,id);
        if(!loan)return bad('Không tìm thấy hồ sơ khoản vay hoặc bạn không có quyền.',404);
        const body=await request.json(),amount=Number(body.requested_amount||0),note=cleanText(body.note).slice(0,500);
        if(!(amount>0))return bad('Vui lòng nhập số tiền khách muốn vay thêm.');
        const phoneNorm=normalizePhone(loan.phone||'');
        const existing=await env.DB.prepare("SELECT id FROM login_app_cases WHERE source_loan_id=? AND status IN ('LOGIN_APP','REJECT_RETRY') ORDER BY id DESC LIMIT 1").bind(id).first();
        let loginId=existing?.id||null;
        if(existing){
          await env.DB.prepare(`UPDATE login_app_cases SET customer_name=?,phone=?,phone_normalized=?,cccd=?,team_id=?,assigned_user_id=?,status='LOGIN_APP',retry_at=NULL,reject_reason=NULL,closed_at=NULL,has_prior_shinhan=1,topup_requested_amount=?,updated_at=datetime('now') WHERE id=?`)
            .bind(loan.customer_name||'',loan.phone||'',phoneNorm||null,loan.cccd||'',loan.team_id||null,loan.assigned_user_id,amount,existing.id).run();
        }else{
          const r=await env.DB.prepare(`INSERT INTO login_app_cases(customer_id,team_id,assigned_user_id,customer_name,phone,phone_normalized,cccd,status,created_by,has_prior_shinhan,topup_requested_amount,source_loan_id) VALUES(?,?,?,?,?,?,?,'LOGIN_APP',?,1,?,?)`)
            .bind(loan.customer_id,loan.team_id||null,loan.assigned_user_id,loan.customer_name||'',loan.phone||'',phoneNorm||null,loan.cccd||'',session.id,amount,id).run();
          loginId=r.meta?.last_row_id||null;
        }
        await env.DB.prepare(`UPDATE loan_profiles SET status='TOPUP',reloan_eligible=1,topup_requested_amount=?,topup_at=datetime('now'),updated_at=datetime('now') WHERE id=?`).bind(amount,id).run();
        await env.DB.prepare(`INSERT INTO loan_care_logs(loan_id,customer_id,user_id,action_type,result,note) VALUES(?,?,?,'TOPUP','Có nhu cầu Topup',?)`).bind(id,loan.customer_id,session.id,note||`Khách có nhu cầu vay thêm ${amount}`).run();
        await audit(env,session.id,'LOAN_TOPUP_TO_LOGIN_APP','loan',id,{login_app_id:loginId,requested_amount:amount,customer_id:loan.customer_id});
        return json({ok:true,login_app_id:loginId,requested_amount:amount});
      }

      if(url.pathname==='/api/loan-care/reminders' && request.method==='GET'){
        await processLoanCareReminders(env);
        const {results}=await env.DB.prepare(`SELECT r.id,r.loan_id,r.due_date,r.reminder_type,r.created_at,c.full_name customer_name,c.phone
          FROM loan_care_reminders r JOIN loan_profiles lp ON lp.id=r.loan_id JOIN customers c ON c.id=lp.customer_id
          WHERE r.recipient_user_id=? AND r.read_at IS NULL ORDER BY r.id DESC LIMIT 100`).bind(session.id).all();
        return json({items:results||[]});
      }
      const careReminderRead=url.pathname.match(/^\/api\/loan-care\/reminders\/(\d+)\/read$/);
      if(careReminderRead && request.method==='POST'){
        await ensureLoanCareSchema(env);
        await env.DB.prepare("UPDATE loan_care_reminders SET read_at=datetime('now') WHERE id=? AND recipient_user_id=?").bind(Number(careReminderRead[1]),session.id).run();
        return json({ok:true});
      }
      if(url.pathname==='/api/loan-care/reminders/read-all' && request.method==='POST'){
        await ensureLoanCareSchema(env);
        await env.DB.prepare("UPDATE loan_care_reminders SET read_at=datetime('now') WHERE recipient_user_id=? AND read_at IS NULL").bind(session.id).run();
        return json({ok:true});
      }

      const followupDeleteMatch=url.pathname.match(/^\/api\/followups\/(\d+)$/);
      if(followupDeleteMatch && request.method==='DELETE'){
        if(!isManager(session))return bad('Chỉ Admin được xóa khách khỏi Follow-up.',403);
        const customerId=Number(followupDeleteMatch[1]);
        const customer=await env.DB.prepare('SELECT id,full_name,follow_up_at FROM customers WHERE id=?').bind(customerId).first();
        if(!customer)return bad('Không tìm thấy khách hàng.',404);
        await ensureLoginAppSchema(env);
        const now=new Date().toISOString().slice(0,19).replace('T',' ');
        await env.DB.batch([
          env.DB.prepare("UPDATE customers SET follow_up_at=NULL,updated_at=datetime('now') WHERE id=?").bind(customerId),
          env.DB.prepare("UPDATE login_app_cases SET status='REJECT_CLOSED',retry_at=NULL,closed_at=?,updated_at=datetime('now') WHERE customer_id=? AND status='REJECT_RETRY'").bind(now,customerId)
        ]);
        await audit(env,session.id,'FOLLOWUP_DELETE','customer',customerId,{customer_name:customer.full_name||'',follow_up_at:customer.follow_up_at||null});
        return json({ok:true});
      }

      // V10.32 — persisted, server-side scoped activity log. No demo records.
      if(url.pathname==='/api/audit-logs' && request.method==='GET'){
        if(!isManager(session)) return bad('Chỉ Admin và Sup được xem nhật ký thao tác.',403);
        const limit=Math.min(200,Math.max(10,Number(url.searchParams.get('limit')||80)));
        const offset=Math.max(0,Math.min(1000000,Number(url.searchParams.get('offset')||0)));
        const action=cleanText(url.searchParams.get('action')).slice(0,60);
        const userId=Number(url.searchParams.get('user_id')||0);
        const q=cleanText(url.searchParams.get('q')).slice(0,120).toLowerCase();
        const from=cleanText(url.searchParams.get('from'));
        const to=cleanText(url.searchParams.get('to'));
        const where=[],bind=[];
        if(action){where.push('a.action=?');bind.push(action);}
        if(q){const pattern='%'+q.replace(/[\\%_]/g,'\\$&')+'%';where.push("(lower(a.action) LIKE ? ESCAPE '\\' OR lower(a.detail) LIKE ? ESCAPE '\\' OR EXISTS(SELECT 1 FROM users aq WHERE aq.id=a.user_id AND (lower(aq.display_name) LIKE ? ESCAPE '\\' OR lower(aq.username) LIKE ? ESCAPE '\\')))");bind.push(pattern,pattern,pattern,pattern);}
        if(Number.isSafeInteger(userId)&&userId>0){where.push('a.user_id=?');bind.push(userId);}
        if(/^\d{4}-\d{2}-\d{2}$/.test(from)){where.push('a.created_at>=?');bind.push(from+' 00:00:00');}
        if(/^\d{4}-\d{2}-\d{2}$/.test(to)){where.push('a.created_at<=?');bind.push(to+' 23:59:59');}
        const filter=where.length?' WHERE '+where.join(' AND '):'';
        await ensureAuditUndoSchema(env);
        const count=await env.DB.prepare('SELECT COUNT(*) n FROM audit_logs a'+filter).bind(...bind).first();
        const {results}=await env.DB.prepare(`SELECT a.id,a.user_id,a.action,a.entity_type,a.entity_id,a.detail,a.created_at,
          COALESCE(u.display_name,'Tài khoản đã xóa') display_name,u.username,
          CASE WHEN au.undone_at IS NOT NULL THEN 'undone'
            WHEN au.audit_id IS NOT NULL AND au.expires_at>datetime('now') THEN 'available'
            WHEN au.audit_id IS NOT NULL THEN 'expired' ELSE 'unavailable' END undo_state,
          au.expires_at undo_expires_at
          FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
          LEFT JOIN audit_undo au ON au.audit_id=a.id ${filter}
          ORDER BY a.id DESC LIMIT ? OFFSET ?`).bind(...bind,limit,offset).all();
        return json({items:results||[],total:Number(count?.n||0),limit,offset});
      }


      const undoMatch=url.pathname.match(/^\/api\/audit-logs\/(\d+)\/undo$/);
      if(undoMatch && request.method==='POST'){
        return await undoAuditEntry(env,session,Number(undoMatch[1]));
      }

      // V7.5: lightweight internal 1:1 chat. Contacts are role-scoped server-side.
      if(url.pathname==='/api/chat/contacts' && request.method==='GET'){
        let sql=`SELECT u.id,u.username,u.display_name,u.role,u.staff_type,u.team_id,u.active,t.name team
          FROM users u LEFT JOIN teams t ON t.id=u.team_id WHERE u.active=1 AND u.id<>?`,bind=[session.id];
        if(session.role==='teamlead'){
          sql+=` AND (u.role='admin' OR (u.role='sale' AND u.team_id=?))`;bind.push(session.team_id);
        }else if(session.role==='sale'){
          sql+=` AND (u.role='admin' OR ((u.role='teamlead' OR u.role='sale') AND u.team_id=?))`;bind.push(session.team_id);
        }
        sql+=` ORDER BY CASE u.role WHEN 'admin' THEN 0 WHEN 'teamlead' THEN 1 ELSE 2 END,COALESCE(t.name,''),u.display_name`;
        const {results}=await env.DB.prepare(sql).bind(...bind).all();
        return json({items:(results||[]).map(u=>({...u,role:effectiveRole(u)}))});
      }
      if(url.pathname==='/api/chat/notifications' && request.method==='GET'){
        const baseline=await ensureChatBaseline(env,session.id);
        const {results}=await env.DB.prepare(`SELECT m.id,m.sender_user_id,m.recipient_user_id,m.message,m.created_at,u.display_name sender_name
          FROM chat_messages m
          LEFT JOIN users u ON u.id=m.sender_user_id
          LEFT JOIN chat_read_state r ON r.user_id=? AND r.other_user_id=m.sender_user_id
          WHERE m.recipient_user_id=?
            AND m.id > MAX(?,COALESCE(r.last_read_message_id,0))
          ORDER BY m.id ASC LIMIT 100`).bind(session.id,session.id,baseline).all();
        const items=results||[];
        const maxRow=await env.DB.prepare('SELECT COALESCE(MAX(id),0) last_id FROM chat_messages WHERE recipient_user_id=?').bind(session.id).first();
        return json({items,last_id:Number(maxRow?.last_id||0),initialized:true});
      }
      if(url.pathname==='/api/chat/read' && request.method==='POST'){
        const body=await request.json();
        const otherId=Number(body.user_id);
        if(!Number.isSafeInteger(otherId)||otherId<1) return bad('Người gửi không hợp lệ.');
        const target=await getChatTarget(env,session,otherId);
        if(!target) return bad('Bạn không có quyền chat với tài khoản này.',403);
        const lastRead=await markChatRead(env,session.id,otherId);
        return json({ok:true,last_read_message_id:lastRead});
      }
      if(url.pathname==='/api/chat/broadcast' && request.method==='POST'){
        if(!isManager(session) && session.role!=='teamlead') return bad('Bạn không có quyền gửi thông báo hàng loạt.',403);
        const body=await request.json();
        const raw=cleanText(body.message);
        if(!raw) return bad('Vui lòng nhập nội dung thông báo.');
        if(raw.length>1800) return bad('Thông báo tối đa 1.800 ký tự.');
        const isAdmin=isManager(session);
        const message=isAdmin?`📢 THÔNG BÁO: ${raw}`:`📢 THÔNG BÁO TEAM: ${raw}`;
        let results=[];
        if(isAdmin){
          const r=await env.DB.prepare(`SELECT id,display_name FROM users WHERE active=1 AND id<>? ORDER BY id`).bind(session.id).all();
          results=r.results||[];
        }else{
          if(!session.team_id) return bad('Team Leader chưa được gán Team.',400);
          const r=await env.DB.prepare(`SELECT id,display_name FROM users WHERE active=1 AND role='sale' AND team_id=? ORDER BY display_name`).bind(session.team_id).all();
          results=r.results||[];
        }
        const targets=results||[];
        if(!targets.length) return bad(isAdmin?'Không có tài khoản đang hoạt động để nhận thông báo.':'Team hiện chưa có nhân viên đang hoạt động.',400);
        const now=new Date().toISOString().slice(0,19).replace('T',' ');
        let sent=0;
        for(let i=0;i<targets.length;i+=50){
          const chunk=targets.slice(i,i+50);
          if(!chunk.length) continue;
          const stmts=chunk.map(t=>env.DB.prepare(`INSERT INTO chat_messages(conversation_key,sender_user_id,recipient_user_id,message,created_at) VALUES(?,?,?,?,?)`)
            .bind(chatConversationKey(session.id,t.id),session.id,t.id,message,now));
          await env.DB.batch(stmts);
          sent+=chunk.length;
        }
        await audit(env,session.id,isAdmin?'CHAT_BROADCAST':'CHAT_TEAM_BROADCAST','chat',null,{team_id:session.team_id||null,recipients:sent,message_preview:raw.slice(0,120)});
        return json({ok:true,sent,message,created_at:now,scope:isAdmin?'all':'team'});
      }
      if(url.pathname==='/api/chat/messages' && request.method==='GET'){
        const rawTarget=cleanText(url.searchParams.get('user_id'));
        if(!/^\d+$/.test(rawTarget)) return bad('Người nhận không hợp lệ.');
        const target=await getChatTarget(env,session,Number(rawTarget));
        if(!target) return bad('Bạn không có quyền chat với tài khoản này.',403);
        const key=chatConversationKey(session.id,target.id);
        const afterId=Math.max(0,Number(url.searchParams.get('after_id')||0));
        const beforeId=Math.max(0,Number(url.searchParams.get('before_id')||0));
        const limit=Math.min(100,Math.max(1,Number(url.searchParams.get('limit')||60)));
        if(!Number.isSafeInteger(afterId)||!Number.isSafeInteger(beforeId)) return bad('Mốc tin nhắn không hợp lệ.');
        let results=[];
        if(afterId>0){
          const r=await env.DB.prepare(`SELECT m.id,m.sender_user_id,m.recipient_user_id,m.message,m.created_at,
            su.display_name sender_name,ru.display_name recipient_name
            FROM chat_messages m LEFT JOIN users su ON su.id=m.sender_user_id LEFT JOIN users ru ON ru.id=m.recipient_user_id
            WHERE m.conversation_key=? AND m.id>? ORDER BY m.id ASC LIMIT ?`).bind(key,afterId,limit+1).all();
          results=r.results||[];
          return json({items:results.slice(0,limit),has_more:results.length>limit,direction:'newer'});
        }
        if(beforeId>0){
          const r=await env.DB.prepare(`SELECT m.id,m.sender_user_id,m.recipient_user_id,m.message,m.created_at,
            su.display_name sender_name,ru.display_name recipient_name
            FROM chat_messages m LEFT JOIN users su ON su.id=m.sender_user_id LEFT JOIN users ru ON ru.id=m.recipient_user_id
            WHERE m.conversation_key=? AND m.id<? ORDER BY m.id DESC LIMIT ?`).bind(key,beforeId,limit+1).all();
          results=r.results||[];
          const hasMore=results.length>limit;
          return json({items:results.slice(0,limit).reverse(),has_more:hasMore,direction:'older'});
        }
        const r=await env.DB.prepare(`SELECT m.id,m.sender_user_id,m.recipient_user_id,m.message,m.created_at,
          su.display_name sender_name,ru.display_name recipient_name
          FROM chat_messages m LEFT JOIN users su ON su.id=m.sender_user_id LEFT JOIN users ru ON ru.id=m.recipient_user_id
          WHERE m.conversation_key=? ORDER BY m.id DESC LIMIT ?`).bind(key,limit+1).all();
        results=r.results||[];
        const hasMore=results.length>limit;
        return json({items:results.slice(0,limit).reverse(),has_more:hasMore,direction:'initial'});
      }
      if(url.pathname==='/api/chat/messages' && request.method==='POST'){
        const body=await request.json();
        const targetId=Number(body.recipient_user_id),message=cleanText(body.message);
        if(!Number.isSafeInteger(targetId)||targetId<1) return bad('Người nhận không hợp lệ.');
        if(!message) return bad('Vui lòng nhập nội dung tin nhắn.');
        if(message.length>2000) return bad('Tin nhắn tối đa 2.000 ký tự.');
        const target=await getChatTarget(env,session,targetId);
        if(!target) return bad('Bạn không có quyền chat với tài khoản này.',403);
        const key=chatConversationKey(session.id,target.id);
        const now=new Date().toISOString().slice(0,19).replace('T',' ');
        // One send = one D1 row write. No read-receipt writes or duplicate audit rows.
        const r=await env.DB.prepare(`INSERT INTO chat_messages(conversation_key,sender_user_id,recipient_user_id,message,created_at)
          VALUES(?,?,?,?,?)`).bind(key,session.id,target.id,message,now).run();
        return json({ok:true,item:{id:r.meta?.last_row_id||null,sender_user_id:session.id,recipient_user_id:target.id,message,created_at:now,sender_name:session.display_name,recipient_name:target.display_name}});
      }

      if(url.pathname==='/api/teams' && request.method==='GET'){
        if(isManager(session)){
          const {results}=await env.DB.prepare('SELECT id,name,active FROM teams WHERE active=1 ORDER BY id').all(); return json({items:results});
        }
        const {results}=await env.DB.prepare('SELECT id,name,active FROM teams WHERE active=1 AND id=? ORDER BY id').bind(session.team_id||0).all(); return json({items:results});
      }
      if(url.pathname==='/api/teams' && request.method==='POST'){
        if(!requireAdmin(session)) return bad('Chỉ Admin được thêm Team.',403);
        const {name}=await request.json(); if(!cleanText(name)) return bad('Thiếu tên Team.');
        try{const r=await env.DB.prepare('INSERT INTO teams(name) VALUES(?)').bind(cleanText(name)).run(); await audit(env,session.id,'TEAM_CREATE','team',r.meta?.last_row_id,{name}); return json({ok:true,id:r.meta?.last_row_id});}
        catch(e){return bad('Tên Team đã tồn tại hoặc không hợp lệ.');}
      }
      const teamMatch=url.pathname.match(/^\/api\/teams\/(\d+)$/);
      if(teamMatch && request.method==='DELETE'){
        if(!requireAdmin(session)) return bad('Chỉ Admin được xoá Team.',403);
        const id=Number(teamMatch[1]);
        const team=await env.DB.prepare('SELECT id,name,active FROM teams WHERE id=? AND active=1').bind(id).first();
        if(!team) return bad('Không tìm thấy Team.',404);
        const usersCount=await env.DB.prepare('SELECT COUNT(*) n FROM users WHERE team_id=? AND active=1').bind(id).first();
        const dataCount=await env.DB.prepare('SELECT COUNT(*) n FROM customers WHERE team_id=?').bind(id).first();
        if(Number(usersCount?.n||0)>0) return bad(`Team ${team.name} vẫn còn ${usersCount.n} nhân viên hoạt động. Hãy chuyển hoặc xoá nhân viên khỏi Team trước.`);
        if(Number(dataCount?.n||0)>0) return bad(`Team ${team.name} vẫn còn ${dataCount.n} Data. Hãy chuyển/xoá Data của Team trước.`);
        await env.DB.prepare('UPDATE teams SET active=0 WHERE id=?').bind(id).run();
        await audit(env,session.id,'TEAM_DELETE','team',id,{name:team.name});
        return json({ok:true,id,name:team.name});
      }

      if(url.pathname==='/api/data-categories' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xem phân loại Kho.',403);
        if(session.role==='teamlead'){
          const {results}=await env.DB.prepare(`SELECT dc.id,dc.name,dc.active,dc.created_at,dc.updated_at
            FROM data_categories dc WHERE dc.active=1 AND EXISTS(
              SELECT 1 FROM customers c WHERE c.data_category_id=dc.id AND c.team_id=?
            ) ORDER BY dc.id`).bind(session.team_id).all();
          return json({items:results});
        }
        const {results}=await env.DB.prepare(`SELECT id,name,active,created_at,updated_at FROM data_categories WHERE active=1 ORDER BY id`).all();
        return json({items:results});
      }
      if(url.pathname==='/api/data-categories' && request.method==='POST'){
        if(!requireAdmin(session)) return bad('Chỉ Admin được tạo phân loại Data.',403);
        const body=await request.json(); const name=cleanText(body.name); if(!name) return bad('Thiếu tên phân loại.');
        try{const r=await env.DB.prepare('INSERT INTO data_categories(name) VALUES(?)').bind(name).run(); await audit(env,session.id,'CATEGORY_CREATE','data_category',r.meta?.last_row_id,{name}); return json({ok:true,id:r.meta?.last_row_id,name});}
        catch(e){return bad('Tên phân loại đã tồn tại hoặc không hợp lệ.');}
      }
      const categoryMatch=url.pathname.match(/^\/api\/data-categories\/(\d+)$/);
      if(categoryMatch && request.method==='PATCH'){
        if(!requireAdmin(session)) return bad('Chỉ Admin được đổi tên phân loại.',403);
        const id=Number(categoryMatch[1]), body=await request.json(), name=cleanText(body.name); if(!name) return bad('Thiếu tên phân loại.');
        try{
          const previous=await env.DB.prepare('SELECT name FROM data_categories WHERE id=? AND active=1').bind(id).first();
          if(!previous)return bad('Không tìm thấy phân loại.',404);
          await env.DB.prepare(`UPDATE data_categories SET name=?,updated_at=datetime('now') WHERE id=? AND active=1`).bind(name,id).run();
          if(previous.name!==name)await auditWithUndo(env,session,'CATEGORY_RENAME','data_category',id,{name,previous_name:previous.name},{name:previous.name},{name});
          else await audit(env,session.id,'CATEGORY_RENAME','data_category',id,{name,unchanged:true});
          return json({ok:true,id,name});
        }
        catch(e){return bad('Tên phân loại đã tồn tại hoặc không hợp lệ.');}
      }
      if(categoryMatch && request.method==='DELETE'){
        if(!requireAdmin(session)) return bad('Chỉ Admin được xoá phân loại.',403);
        const id=Number(categoryMatch[1]);
        const c=await env.DB.prepare('SELECT id,name FROM data_categories WHERE id=? AND active=1').bind(id).first(); if(!c) return bad('Không tìm thấy phân loại.',404);
        await env.DB.batch([
          env.DB.prepare('UPDATE customers SET data_category_id=NULL,updated_at=datetime(\'now\') WHERE data_category_id=?').bind(id),
          env.DB.prepare('UPDATE data_categories SET active=0,updated_at=datetime(\'now\') WHERE id=?').bind(id)
        ]);
        await audit(env,session.id,'CATEGORY_DELETE','data_category',id,{name:c.name}); return json({ok:true,id});
      }
      if(url.pathname==='/api/warehouse/categories/assign' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền phân loại Data.',403);
        const body=await request.json(); const ids=[...new Set((Array.isArray(body.customer_ids)?body.customer_ids:[]).map(Number).filter(Boolean))];
        if(!ids.length) return bad('Hãy chọn ít nhất 1 Data.'); if(ids.length>2000) return bad('Mỗi lần tối đa 2.000 Data.');
        const categoryId=body.category_id===null||body.category_id===''?null:Number(body.category_id);
        if(categoryId){const c=await env.DB.prepare('SELECT id FROM data_categories WHERE id=? AND active=1').bind(categoryId).first();if(!c)return bad('Phân loại không tồn tại.');}
        if(session.role==='teamlead'){
          const marks=ids.map(()=>'?').join(',');
          const chk=await env.DB.prepare(`SELECT COUNT(*) n FROM customers WHERE team_id=? AND id IN (${marks})`).bind(session.team_id,...ids).first();
          if(Number(chk?.n||0)!==ids.length) return bad('Teamlead chỉ được phân loại Data thuộc Team mình.',403);
        }
        // Undo snapshots for new <=500-row categorizations. Historical logs did not capture old values.
        let oldCategoryRows=[];
        if(ids.length<=500){
          await ensureAuditUndoSchema(env);
          const marks=ids.map(()=>'?').join(',');
          oldCategoryRows=(await env.DB.prepare(`SELECT id,data_category_id FROM customers WHERE id IN (${marks}) ORDER BY id`).bind(...ids).all()).results||[];
          if(oldCategoryRows.length!==ids.length)return bad('Có khách hàng không tồn tại.',409);
        }
        const stmts=ids.map(id=>session.role==='teamlead'
          ? env.DB.prepare("UPDATE customers SET data_category_id=?,updated_at=datetime('now') WHERE id=? AND team_id=?").bind(categoryId,id,session.team_id)
          : env.DB.prepare("UPDATE customers SET data_category_id=?,updated_at=datetime('now') WHERE id=?").bind(categoryId,id));
        for(let i=0;i<stmts.length;i+=80) await env.DB.batch(stmts.slice(i,i+80));
        const entryId=await audit(env,session.id,'CATEGORY_ASSIGN','customer',null,{count:ids.length,category_id:categoryId,team_id:session.role==='teamlead'?session.team_id:null});
        if(oldCategoryRows.length){
          try{await env.DB.prepare(`INSERT INTO audit_undo(audit_id,action,entity_type,entity_id,before_json,after_json)
              VALUES(?,?,?,?,?,?)`).bind(entryId,'CATEGORY_ASSIGN','customer',0,JSON.stringify(oldCategoryRows),JSON.stringify({category_id:categoryId})).run();}
          catch(e){console.warn('Undo snapshot unavailable for category batch:',String(e));}
        }
        return json({ok:true,updated:ids.length,undo_available:oldCategoryRows.length===ids.length});
      }
      // V10.35: removed one-click categorization of the entire warehouse.
      if(url.pathname==='/api/warehouse/categories/assign-scope' && request.method==='POST')return bad('Chức năng phân loại toàn bộ Kho đã được gỡ bỏ. Hãy chọn khách hàng cụ thể để phân loại.',410);
      if(url.pathname==='/api/warehouse/categories/assign-scope' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền phân loại Data.',403);
        const body=await request.json();
        const scope=String(body.scope||'').toLowerCase();
        if(!['all','called','uncalled'].includes(scope)) return bad('Phạm vi Data không hợp lệ.');
        const categoryId=body.category_id===null||body.category_id===''?null:Number(body.category_id);
        if(categoryId){const c=await env.DB.prepare('SELECT id FROM data_categories WHERE id=? AND active=1').bind(categoryId).first();if(!c)return bad('Phân loại không tồn tại.');}
        const where=[],bind=[];
        if(session.role==='teamlead'){where.push('team_id=?');bind.push(Number(session.team_id));}
        if(scope==='called') where.push("data_state='ARCHIVED'");
        else if(scope==='uncalled') where.push("data_state<>'ARCHIVED'");
        // Chỉ ghi các dòng thực sự đổi phân loại để giảm Rows written.
        if(categoryId===null) where.push('data_category_id IS NOT NULL');
        else {where.push('(data_category_id IS NULL OR data_category_id<>?)');bind.push(categoryId);}
        const sql=`UPDATE customers SET data_category_id=?,updated_at=datetime('now') WHERE ${where.join(' AND ')}`;
        const r=await env.DB.prepare(sql).bind(categoryId,...bind).run();
        const updated=Number(r.meta?.changes||0);
        if(updated>0) await audit(env,session.id,'CATEGORY_ASSIGN_SCOPE','customer',null,{scope,count:updated,category_id:categoryId,team_id:session.role==='teamlead'?session.team_id:null});
        return json({ok:true,updated,scope});
      }
      if(url.pathname==='/api/warehouse/analytics' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xem đo lường Kho.',403);
        const teamId=session.role==='teamlead'?Number(session.team_id):null;
        await returnExpiredAssignments(env,teamId);
        // V7.1: Teamlead dùng cùng thống kê với Admin nhưng SQL thêm team_id trực tiếp,
        // tránh điều kiện OR để D1 có thể dùng index team_id/data_state hiệu quả hơn.
        const teamWhere=teamId?' WHERE c.team_id=?':'';
        const sql=`WITH
          signed_leads AS (SELECT DISTINCT customer_id FROM lead_status_history WHERE status='SIGNED'),
          customer_stats AS (
            SELECT c.data_category_id,
              COUNT(*) total_data,
              SUM(CASE WHEN c.data_state='POOL' THEN 1 ELSE 0 END) pool_count,
              SUM(CASE WHEN c.data_state='ASSIGNED' THEN 1 ELSE 0 END) assigned_count,
              SUM(CASE WHEN c.data_state='ARCHIVED' THEN 1 ELSE 0 END) archived_count,
              SUM(CASE WHEN lc.customer_id IS NOT NULL THEN 1 ELSE 0 END) lead_count,
              SUM(CASE WHEN sl.customer_id IS NOT NULL THEN 1 ELSE 0 END) signed_leads,
              SUM(CASE WHEN c.data_state='ARCHIVED' AND sl.customer_id IS NULL THEN 1 ELSE 0 END) recyclable_count,
              COALESCE(MAX(c.assignment_round),0) max_round
            FROM customers c
            LEFT JOIN lead_cases lc ON lc.customer_id=c.id
            LEFT JOIN signed_leads sl ON sl.customer_id=c.id
            ${teamWhere}
            GROUP BY c.data_category_id
          ),
          call_stats AS (
            SELECT c.data_category_id,COUNT(l.id) calls,
              SUM(CASE WHEN l.status LIKE 'Y%' THEN 1 ELSE 0 END) connected,
              SUM(CASE WHEN l.status='Y01' THEN 1 ELSE 0 END) y01,
              SUM(CASE WHEN l.status='Y02' THEN 1 ELSE 0 END) y02
            FROM call_logs l JOIN customers c ON c.id=l.customer_id
            ${teamWhere}
            GROUP BY c.data_category_id
          )
          SELECT dc.id,dc.name,
            COALESCE(cs.total_data,0) total_data,COALESCE(cs.pool_count,0) pool_count,
            COALESCE(cs.assigned_count,0) assigned_count,COALESCE(cs.archived_count,0) archived_count,
            COALESCE(cs.lead_count,0) lead_count,COALESCE(cs.signed_leads,0) signed_leads,
            COALESCE(cs.recyclable_count,0) recyclable_count,COALESCE(cs.max_round,0) max_round,
            COALESCE(ca.calls,0) calls,COALESCE(ca.connected,0) connected,
            COALESCE(ca.y01,0) y01,COALESCE(ca.y02,0) y02
          FROM data_categories dc
          LEFT JOIN customer_stats cs ON cs.data_category_id=dc.id
          LEFT JOIN call_stats ca ON ca.data_category_id=dc.id
          WHERE dc.active=1 ${teamId?'AND COALESCE(cs.total_data,0)>0':''}
          ORDER BY dc.id`;
        const binds=teamId?[teamId,teamId]:[];
        const {results}=await env.DB.prepare(sql).bind(...binds).all();
        return json({items:results.map(x=>({...x,connect_rate:Number(x.calls||0)?Math.round(Number(x.connected||0)/Number(x.calls)*100):0}))});
      }
      if(url.pathname==='/api/warehouse/round-analytics' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xem đo lường vòng gọi.',403);
        const teamId=session.role==='teamlead'?Number(session.team_id):null;
        const where=teamId?'WHERE ah.team_id=?':'';
        const sql=`SELECT ah.category_id,dc.name category_name,ah.round_no,
          COUNT(DISTINCT ah.customer_id) assigned_data,COUNT(l.id) calls,
          SUM(CASE WHEN l.status LIKE 'Y%' THEN 1 ELSE 0 END) connected,
          SUM(CASE WHEN l.status='Y01' THEN 1 ELSE 0 END) y01,
          SUM(CASE WHEN l.status='Y02' THEN 1 ELSE 0 END) y02,
          SUM(CASE WHEN ah.return_reason='DEADLINE' THEN 1 ELSE 0 END) expired_returns
          FROM assignment_history ah LEFT JOIN data_categories dc ON dc.id=ah.category_id
          LEFT JOIN call_logs l ON l.customer_id=ah.customer_id AND l.user_id=ah.user_id
            AND datetime(l.created_at)>=datetime(ah.assigned_at)
            AND datetime(l.created_at)<=datetime(COALESCE(ah.completed_at,ah.returned_at,datetime('now')))
          ${where}
          GROUP BY ah.category_id,dc.name,ah.round_no ORDER BY COALESCE(dc.name,'Chưa phân loại'),ah.round_no`;
        const {results}=await env.DB.prepare(sql).bind(...(teamId?[teamId]:[])).all();
        return json({items:results.map(x=>({...x,connect_rate:Number(x.calls||0)?Math.round(Number(x.connected||0)/Number(x.calls)*100):0}))});
      }
      if(url.pathname==='/api/warehouse/expire-now' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền thu hồi Data hết hạn.',403);
        const teamId=session.role==='teamlead'?Number(session.team_id):null;
        const returned=await returnExpiredAssignments(env,teamId); await audit(env,session.id,'DEADLINE_SWEEP','customer',null,{returned,team_id:teamId}); return json({ok:true,returned});
      }
      // V5.7: overview of pending assignments, scoped to Admin or the Teamlead's team.
      if(url.pathname==='/api/warehouse/staff-pending' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xem số Data của nhân viên.',403);
        // ASSIGNED = còn phải gọi trong lần giao hiện tại; transferred N02/Y03 stay ASSIGNED.
        let sql=`SELECT u.id user_id,u.display_name,u.team_id,t.name team,
          COUNT(c.id) pending_count,
          SUM(CASE WHEN c.status='NEW' THEN 1 ELSE 0 END) new_count,
          SUM(CASE WHEN c.status<>'NEW' THEN 1 ELSE 0 END) recall_count
          FROM users u LEFT JOIN teams t ON t.id=u.team_id
          LEFT JOIN customers c ON c.assigned_user_id=u.id AND c.data_state='ASSIGNED'
          WHERE u.active=1 AND u.role='sale'`;
        const bind=[];
        if(session.role==='teamlead'){sql+=' AND u.team_id=?';bind.push(session.team_id)}
        sql+=' GROUP BY u.id,u.display_name,u.team_id,t.name ORDER BY t.name,u.display_name';
        const {results}=await env.DB.prepare(sql).bind(...bind).all();
        return json({items:results});
      }
      const pendingDetailMatch=url.pathname.match(/^\/api\/warehouse\/staff-pending\/(\d+)$/);
      if(pendingDetailMatch && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xem Data của nhân viên.',403);
        const employeeId=Number(pendingDetailMatch[1]);
        const employee=await env.DB.prepare("SELECT id,display_name,team_id FROM users WHERE id=? AND active=1 AND role='sale'").bind(employeeId).first();
        if(!employee) return bad('Không tìm thấy nhân viên Sale.',404);
        if(session.role==='teamlead' && Number(employee.team_id)!==Number(session.team_id)) return bad('Chỉ xem được nhân viên trong Team.',403);
        const kind=url.searchParams.get('kind')||'all';
        if(!['all','new','recall'].includes(kind)) return bad('Bộ lọc Data chưa hợp lệ.');
        const offset=Math.min(100000,Math.max(0,Number.parseInt(url.searchParams.get('offset')||'0',10)||0));
        const statusClause=kind==='new'?" AND c.status='NEW'":kind==='recall'?" AND c.status<>'NEW'":'';
        const {results}=await env.DB.prepare(`SELECT c.id,c.full_name name,c.phone,c.status,c.source,
          c.assignment_deadline,c.assignment_round,c.received_at
          FROM customers c WHERE c.assigned_user_id=? AND c.data_state='ASSIGNED'${statusClause}
          ORDER BY c.assignment_deadline IS NULL,c.assignment_deadline ASC,c.id DESC LIMIT 101 OFFSET ?`)
          .bind(employeeId,offset).all();
        return json({items:results.slice(0,100),has_more:results.length>100,offset,employee:employee.display_name});
      }
      if(url.pathname==='/api/data-completion' && request.method==='GET'){
        if(!isManager(session)) return bad('Chỉ Admin hoặc Sup được xem thông báo hết Data.',403);
        const {results}=await env.DB.prepare(`SELECT u.id user_id,u.display_name,u.username,u.team_id,t.name team,
          (SELECT COUNT(*) FROM customers c WHERE c.assigned_user_id=u.id AND c.data_state='ASSIGNED') remaining_count,
          (SELECT COUNT(*) FROM customers c WHERE c.assigned_user_id=u.id AND c.data_state='ARCHIVED') archived_count,
          (SELECT MAX(l.created_at) FROM call_logs l WHERE l.user_id=u.id) last_call_at
          FROM users u LEFT JOIN teams t ON t.id=u.team_id
          WHERE u.active=1 AND u.role='sale' ORDER BY t.name,u.display_name`).all();
        return json({items:results.filter(x=>Number(x.remaining_count||0)===0&&Number(x.archived_count||0)>0)});
      }
      // V10.36 - Disable employee login without erasing their history or customers.
      const lockPath=url.pathname.match(/^\/api\/users\/(\d+)\/lock$/);
      if(lockPath && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Không có quyền khóa nhân viên.',403);
        const id=Number(lockPath[1]);if(id===session.id)return bad('Không thể tự khóa tài khoản của mình.',403);
        const user=await env.DB.prepare('SELECT id,username,display_name,role,staff_type,team_id,active FROM users WHERE id=?').bind(id).first();
        if(!user)return bad('Tài khoản không tồn tại.',404);
        if(user.role!=='sale')return bad('Chỉ được khóa Sales/Freelancer tại đây. Tài khoản quản trị không bị tác động.',403);
        if(session.role==='teamlead'&&Number(user.team_id)!==Number(session.team_id))return bad('Không thể khóa người ngoài Team.',403);
        await v1036EnsureAux(env);
        if(Number(user.active)===0)return bad('Tài khoản đã ngừng hoạt động; không thể khóa lại.',409);
        await env.DB.batch([
          env.DB.prepare('UPDATE users SET active=0 WHERE id=? AND active=1').bind(id),
          env.DB.prepare('DELETE FROM sessions WHERE user_id=?').bind(id),
          env.DB.prepare("INSERT INTO user_lock_records(user_id,locked_by) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET locked_by=excluded.locked_by,locked_at=datetime('now')").bind(id,session.id)
        ]);
        const count=await env.DB.prepare('SELECT COUNT(*) n FROM customers WHERE assigned_user_id=?').bind(id).first();
        await audit(env,session.id,'USER_LOCK','user',id,{name:user.display_name,assigned_customers:Number(count?.n||0)});
        return json({ok:true,assigned_customers:Number(count?.n||0)});
      }
      if(url.pathname==='/api/users/locked' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Không có quyền xem nhân viên đã khóa.',403);
        await v1036EnsureAux(env);
        const sql="SELECT u.id,u.username,u.display_name,u.staff_type,u.team_id,t.name team, (SELECT COUNT(*) FROM customers c WHERE c.assigned_user_id=u.id) assigned_count FROM users u JOIN user_lock_records r ON r.user_id=u.id LEFT JOIN teams t ON t.id=u.team_id WHERE u.role='sale' AND u.active=0";
        const team=session.role==='teamlead'?' AND u.team_id=?':'';
        const rows=(await env.DB.prepare(sql+team+' ORDER BY u.display_name LIMIT 200').bind(...(team?[session.team_id]:[])).all()).results||[];
        return json({items:rows});
      }
      const unlockPath=url.pathname.match(/^\/api\/users\/(\d+)\/unlock$/);
      if(unlockPath && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Không có quyền mở khóa nhân viên.',403);
        const id=Number(unlockPath[1]);
        const user=await env.DB.prepare('SELECT id,role,team_id,active,username FROM users WHERE id=?').bind(id).first();
        if(!user||user.role!=='sale')return bad('Chỉ mở khóa tài khoản Sales/Freelancer.',403);
        if(session.role==='teamlead'&&Number(user.team_id)!==Number(session.team_id))return bad('Không thuộc Team bạn.',403);
        await v1036EnsureAux(env);
        const marker=await env.DB.prepare('SELECT user_id FROM user_lock_records WHERE user_id=?').bind(id).first();
        if(!marker)return bad('Tài khoản này không được khóa bằng chức năng Nghỉ việc; không thể mở khóa tự động.',409);
        await env.DB.batch([env.DB.prepare('UPDATE users SET active=1 WHERE id=?').bind(id),env.DB.prepare('DELETE FROM user_lock_records WHERE user_id=?').bind(id)]);
        await audit(env,session.id,'USER_UNLOCK','user',id,{username:user.username});return json({ok:true});
      }
      if(url.pathname==='/api/users' && request.method==='GET'){
        let sql=`SELECT u.id,u.username,u.display_name,u.email,u.role,u.staff_type,u.team_id,t.name team,u.active FROM users u LEFT JOIN teams t ON t.id=u.team_id WHERE u.active=1`, binds=[];
        if(session.role==='teamlead'){sql+=' AND u.team_id=?';binds.push(session.team_id)}
        if(session.role==='sale'){sql+=' AND u.id=?';binds.push(session.id)}
        sql+=' ORDER BY COALESCE(t.id,0),u.role,u.display_name'; const {results}=await env.DB.prepare(sql).bind(...binds).all(); const items=(results||[]).map(u=>({...u,role:effectiveRole(u)})).sort((a,b)=>({admin:0,sup:1,teamlead:2,sale:a.staff_type==='freelancer'?4:3}[a.role]??9)-({admin:0,sup:1,teamlead:2,sale:b.staff_type==='freelancer'?4:3}[b.role]??9)||String(a.display_name).localeCompare(String(b.display_name),'vi')); return json({items});
      }
      if(url.pathname==='/api/users' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Bạn không có quyền thêm nhân viên.',403);
        const body=await request.json();
        const username=cleanText(body.username), display=cleanText(body.display_name), password=String(body.password||'');
        const normalizedRole=normalizeRequestedUserRole(body.role,body.staff_type);
        if(!normalizedRole) return bad('Vai trò không hợp lệ.');
        let role=normalizedRole.role, staffType=normalizedRole.staff_type, teamId=body.team_id?Number(body.team_id):null;
        if(session.role==='teamlead'){
          if(role!=='sale') return bad('Team Leader chỉ được tạo Sales hoặc Freelancer trong Team mình.',403);
          teamId=Number(session.team_id);
        }
        if(!username||!display||!password) return bad('Cần nhập họ tên, tên đăng nhập và mật khẩu.');
        if(role==='admin'&&session.role!=='admin') return bad('Chỉ Admin được tạo tài khoản Admin hoặc Sup.',403);
        if(role!=='admin'&&!teamId) return bad('Team Leader, Sales và Freelancer phải thuộc một Team.');
        if(password.length<6) return bad('Mật khẩu tối thiểu 6 ký tự.');
        // V7.10: username của tài khoản đang hoạt động vẫn phải là duy nhất (không phân biệt hoa/thường).
        // Nếu username chỉ còn nằm ở một tài khoản đã xoá (active=0), giải phóng username cũ
        // trước khi tạo bản ghi mới. Cách này giữ nguyên lịch sử call_logs/audit của user đã xoá
        // nhưng không làm user mới kế thừa dữ liệu lịch sử của user cũ.
        const activeUsername=await env.DB.prepare('SELECT id FROM users WHERE lower(username)=lower(?) AND active=1 LIMIT 1').bind(username).first();
        if(activeUsername) return bad('Tên đăng nhập đã tồn tại.');
        await v1036EnsureAux(env);
        const lockedUsername=await env.DB.prepare('SELECT u.id FROM users u JOIN user_lock_records r ON r.user_id=u.id WHERE lower(u.username)=lower(?) LIMIT 1').bind(username).first();
        if(lockedUsername)return bad('Tên đăng nhập đang được giữ cho tài khoản đã khóa, không thể sử dụng lại.',409);
        const archivedExact=await env.DB.prepare('SELECT id FROM users WHERE username=? AND active=0 AND NOT EXISTS(SELECT 1 FROM user_lock_records r WHERE r.user_id=users.id) LIMIT 1').bind(username).first();
        if(archivedExact){
          const archivedUsername=`__deleted_${archivedExact.id}_${Date.now()}`;
          await env.DB.prepare('UPDATE users SET username=? WHERE id=? AND active=0').bind(archivedUsername,archivedExact.id).run();
        }
        try{
          const r=await env.DB.prepare('INSERT INTO users(username,display_name,email,password_hash,role,staff_type,team_id) VALUES(?,?,?,?,?,?,?)')
            .bind(username,display,cleanText(body.email)||null,await hashPassword(password),role,staffType||'sales',role==='admin'?null:teamId).run();
          await audit(env,session.id,'USER_CREATE','user',r.meta?.last_row_id,{username,display_name:display,role:effectiveRole({role,staff_type:staffType}),team_id:teamId,created_by_role:session.role,ip:request.headers.get('CF-Connecting-IP')||null});
          return json({ok:true,id:r.meta?.last_row_id});
        }catch(e){ if(String(e.message).toLowerCase().includes('unique')) return bad('Tên đăng nhập đã tồn tại.'); throw e; }
      }
      const userMatch=url.pathname.match(/^\/api\/users\/(\d+)$/);
      if(userMatch && request.method==='PATCH'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Team Leader được sửa nhân viên.',403);
        const id=Number(userMatch[1]), body=await request.json();
        const u=await env.DB.prepare('SELECT * FROM users WHERE id=? AND active=1').bind(id).first(); if(!u) return bad('Không tìm thấy nhân viên.',404);
        if(session.role==='sup'&&(u.role==='admin'||(body.role!==undefined&&['admin','sup'].includes(cleanText(body.role).toLowerCase()))))return bad('Sup không thể sửa hoặc cấp quyền tài khoản Admin/Sup.',403);
        if(session.role==='admin'&&id===session.id&&body.role!==undefined&&cleanText(body.role).toLowerCase()!=='admin')return bad('Không thể tự hạ quyền tài khoản Admin đang đăng nhập.',403);
        if(session.role==='teamlead'){
          if(u.role!=='sale'||Number(u.team_id)!==Number(session.team_id))return bad('Team Leader chỉ được sửa Sales/Freelancer thuộc Team mình.',403);
          if(body.role!==undefined&&normalizeRequestedUserRole(body.role,body.staff_type)?.role!=='sale')return bad('Team Leader không được cấp vai trò quản trị.',403);
          if(body.team_id!==undefined&&Number(body.team_id)!==Number(session.team_id))return bad('Không được chuyển nhân viên sang Team khác.',403);
        }
        const fields=[], values=[];
        let archivedUsernameId=null;
        if(body.username!==undefined){
          const v=cleanText(body.username);
          if(!v)return bad('Tên đăng nhập không được trống.');
          const activeConflict=await env.DB.prepare('SELECT id FROM users WHERE lower(username)=lower(?) AND active=1 AND id<>? LIMIT 1').bind(v,id).first();
          if(activeConflict) return bad('Tên đăng nhập đã tồn tại.');
          const archivedConflict=await env.DB.prepare('SELECT id FROM users WHERE username=? AND active=0 LIMIT 1').bind(v).first();
          if(archivedConflict) archivedUsernameId=Number(archivedConflict.id);
          fields.push('username=?');values.push(v);
        }
        if(body.display_name!==undefined){const v=cleanText(body.display_name);if(!v)return bad('Tên nhân viên không được trống.');fields.push('display_name=?');values.push(v)}
        if(body.email!==undefined){fields.push('email=?');values.push(cleanText(body.email)||null)}
        let patchCoreRole=null;
        if(body.role!==undefined){
          const mapped=normalizeRequestedUserRole(body.role,body.staff_type);if(!mapped)return bad('Vai trò không hợp lệ.');
          patchCoreRole=mapped.role;fields.push('role=?');values.push(mapped.role);fields.push('staff_type=?');values.push(mapped.staff_type||'sales');
          if(mapped.role==='admin'){fields.push('team_id=?');values.push(null)}
        }
        if(body.team_id!==undefined && patchCoreRole!=='admin'){fields.push('team_id=?');values.push(body.team_id?Number(body.team_id):null)}
        if(body.password){if(String(body.password).length<6)return bad('Mật khẩu tối thiểu 6 ký tự.');fields.push('password_hash=?');values.push(await hashPassword(String(body.password)))}
        if(!fields.length) return bad('Không có thông tin cần cập nhật.');
        if(archivedUsernameId){
          const archivedUsername=`__deleted_${archivedUsernameId}_${Date.now()}`;
          await env.DB.prepare('UPDATE users SET username=? WHERE id=? AND active=0').bind(archivedUsername,archivedUsernameId).run();
        }
        try{await env.DB.prepare(`UPDATE users SET ${fields.join(',')} WHERE id=?`).bind(...values,id).run(); await env.DB.prepare('DELETE FROM sessions WHERE user_id=?').bind(id).run(); await audit(env,session.id,'USER_UPDATE','user',id,{username:body.username,display_name:body.display_name,role:body.role,team_id:body.team_id,password_changed:!!body.password,ip:request.headers.get('CF-Connecting-IP')||null}); return json({ok:true});}
        catch(e){ if(String(e.message).toLowerCase().includes('unique')) return bad('Tên đăng nhập đã tồn tại.'); throw e; }
      }
      if(userMatch && request.method==='DELETE'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Bạn không có quyền xoá nhân viên.',403);
        const id=Number(userMatch[1]); if(id===session.id) return bad('Không thể xoá chính tài khoản đang đăng nhập.');
        const u=await env.DB.prepare('SELECT id,username,display_name,role,staff_type,team_id FROM users WHERE id=? AND active=1').bind(id).first(); if(!u) return bad('Không tìm thấy nhân viên.',404);
        if(session.role==='sup'&&u.role==='admin')return bad('Sup không thể xóa Admin/Sup.',403);
        if(u.role==='admin' && session.role!=='admin')return bad('Chỉ Admin được xóa tài khoản Sup.',403);
        if(u.role==='admin'&&u.staff_type!=='supervisor')return bad('Không thể xóa tài khoản Admin tại đây.',403);
        if(session.role==='teamlead'){
          if(u.role!=='sale'||Number(u.team_id)!==Number(session.team_id)) return bad('Teamlead chỉ được xoá Sale thuộc Team của mình.',403);
        }
        // V7.10: đổi username của tài khoản bị xoá sang tên lưu trữ để username cũ
        // có thể được dùng lại ngay cho tài khoản mới, trong khi bản ghi cũ vẫn được giữ
        // để bảo toàn lịch sử cuộc gọi/audit.
        const archivedUsername=`__deleted_${id}_${Date.now()}`;
        await env.DB.batch([
          env.DB.prepare("UPDATE customers SET last_assigned_user_id=assigned_user_id,assigned_user_id=NULL,data_state='POOL',status='NEW',follow_up_at=NULL,assignment_deadline=NULL,updated_at=datetime('now') WHERE assigned_user_id=?").bind(id),
          env.DB.prepare('DELETE FROM sessions WHERE user_id=?').bind(id),
          env.DB.prepare('UPDATE users SET username=?,active=0 WHERE id=?').bind(archivedUsername,id)
        ]);
        await audit(env,session.id,'USER_DELETE','user',id,{username:u.username,display_name:u.display_name,deleted_by_role:session.role,ip:request.headers.get('CF-Connecting-IP')||null});
        return json({ok:true});
      }

      if(url.pathname==='/api/customers' && request.method==='GET'){
        await returnExpiredAssignments(env);
        const s=scopeSql(session,'c');
        const {results}=await env.DB.prepare(`SELECT c.id,c.customer_code code,c.full_name name,c.phone,c.source,c.team_id,t.name team,c.assigned_user_id,u.display_name owner,u.username owner_username,c.status,c.received_at received,c.follow_up_at follow_up,c.note,c.data_state,c.archived_at,c.data_category_id,dc.name data_category,c.assignment_deadline,c.assignment_round,c.last_assigned_user_id
          FROM customers c LEFT JOIN teams t ON t.id=c.team_id LEFT JOIN users u ON u.id=c.assigned_user_id LEFT JOIN data_categories dc ON dc.id=c.data_category_id AND dc.active=1 WHERE ${s.where} ORDER BY c.updated_at DESC,c.id DESC LIMIT 20000`).bind(...s.bind).all();
        return json({items:results});
      }
      if(url.pathname==='/api/customers/import/check' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được kiểm tra Data trùng.',403);
        const body=await request.json();
        const phones=[...new Set((Array.isArray(body.phones)?body.phones:[]).map(normalizePhone).filter(Boolean))];
        if(phones.length>300) return bad('Mỗi lần kiểm tra tối đa 300 SĐT.');
        if(!phones.length) return json({existing_phones:[]});
        // V7.4: Kho Team chỉ lọc trùng trong chính Team đó. Admin chọn Kho Team cũng dùng cùng phạm vi;
        // chỉ Kho chung Admin mới giữ cách đối chiếu toàn CRM như trước.
        const requestedCheckTeam=session.role==='teamlead'?Number(session.team_id||0):(body.target_team_id?Number(body.target_team_id):null);
        const duplicateTeamId=Number.isFinite(requestedCheckTeam)&&requestedCheckTeam>0?requestedCheckTeam:null;
        const teamClause=duplicateTeamId?' AND team_id=?':'';
        const all=new Set();
        for(let i=0;i<phones.length;i+=80){
          const batch=phones.slice(i,i+80), marks=batch.map(()=>'?').join(','), bind=duplicateTeamId?[...batch,duplicateTeamId]:batch;
          const [normalized,raw]=await Promise.all([
            env.DB.prepare(`SELECT phone_normalized FROM customers WHERE phone_normalized IN (${marks})${teamClause}`).bind(...bind).all(),
            env.DB.prepare(`SELECT phone FROM customers WHERE phone IN (${marks})${teamClause}`).bind(...bind).all()
          ]);
          normalized.results.forEach(x=>all.add(normalizePhone(x.phone_normalized)));
          raw.results.forEach(x=>all.add(normalizePhone(x.phone)));
        }
        // Legacy rows without phone_normalized are also scoped to the Team when importing into a Team warehouse.
        const legacySql=`SELECT phone FROM customers WHERE (phone_normalized IS NULL OR phone_normalized='') AND phone IS NOT NULL${teamClause}`;
        const legacy=duplicateTeamId
          ? (await env.DB.prepare(legacySql).bind(duplicateTeamId).all()).results
          : (await env.DB.prepare(legacySql).all()).results;
        legacy.forEach(x=>all.add(normalizePhone(x.phone)));
        return json({existing_phones:phones.filter(p=>all.has(p)),scope:duplicateTeamId?'team':'all',team_id:duplicateTeamId});
      }
      if(url.pathname==='/api/customers/import' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được import dữ liệu.',403);
        const body=await request.json(); const items=Array.isArray(body.items)?body.items:[];
        if(!items.length) return bad('Không có dữ liệu để import.'); if(items.length>300) return bad('Mỗi lần import tối đa 300 dòng.');
        const toWarehouse=!!body.to_warehouse, importSource=cleanText(body.source_name||'');
        const requestedWarehouseTeam=isManager(session)&&body.target_team_id?Number(body.target_team_id):null;
        if(requestedWarehouseTeam){
          const targetTeam=await env.DB.prepare('SELECT id FROM teams WHERE id=? AND active=1').bind(requestedWarehouseTeam).first();
          if(!targetTeam) return bad('Kho Team nhận Data không hợp lệ.');
        }
        if(session.role==='teamlead' && !toWarehouse) return bad('Teamlead chỉ được đẩy Data mới vào Kho của chính Team mình.',403);
        if(toWarehouse&&!importSource) return bad('Hãy nhập tên nguồn Data trước khi đẩy vào Kho.');
        // V6.2: Tên nguồn của mỗi đợt upload đồng thời là Phân loại Data.
        // Chỉ 1 lần đọc (và tối đa 1 lần ghi nếu phân loại chưa tồn tại) cho cả batch, không ghi theo từng khách.
        let importCategoryId=null;
        if(toWarehouse&&importSource){
          let category=await env.DB.prepare('SELECT id,name,active FROM data_categories WHERE lower(name)=lower(?) ORDER BY id LIMIT 1').bind(importSource).first();
          if(category){
            importCategoryId=Number(category.id);
            if(Number(category.active)!==1){
              await env.DB.prepare("UPDATE data_categories SET active=1,name=?,updated_at=datetime('now') WHERE id=?").bind(importSource,importCategoryId).run();
            }
          }else{
            const created=await env.DB.prepare('INSERT INTO data_categories(name) VALUES(?)').bind(importSource).run();
            importCategoryId=Number(created.meta?.last_row_id||0)||null;
          }
        }
        // Kho import không cần quét teams/users: Teamlead luôn bị khóa vào Team của mình, Admin đưa vào Kho chung.
        const teams=toWarehouse?[]:(await env.DB.prepare('SELECT id,name FROM teams WHERE active=1').all()).results;
        const users=toWarehouse?[]:(await env.DB.prepare('SELECT id,username,display_name,team_id,role FROM users WHERE active=1').all()).results;
        const inputPhones=[...new Set(items.map(x=>normalizePhone(x.phone)).filter(Boolean))];
        const inputCodes=[...new Set(items.map(x=>cleanText(x.code||x.customer_code)).filter(Boolean))];
        const existing=[], existingIds=new Set();
        // V7.4: khi đẩy vào Kho Team, chỉ đối chiếu với Data đang thuộc Team đó.
        // Kho chung Admin vẫn đối chiếu toàn CRM như trước.
        const duplicateTeamId=toWarehouse?(session.role==='teamlead'?Number(session.team_id||0):(requestedWarehouseTeam||null)):null;
        const duplicateTeamClause=duplicateTeamId?' AND team_id=?':'';
        // Indexed phone/code lookups; team filter is applied in SQL so Data cùng SĐT ở Team khác không chặn import.
        for(const [column,keys] of [['phone_normalized',inputPhones],['phone',inputPhones],['customer_code',inputCodes]]){
          for(let i=0;i<keys.length;i+=80){
            const batch=keys.slice(i,i+80),marks=batch.map(()=>'?').join(','),bind=duplicateTeamId?[...batch,duplicateTeamId]:batch;
            const {results}=await env.DB.prepare(`SELECT id,customer_code,phone_normalized,phone FROM customers WHERE ${column} IN (${marks})${duplicateTeamClause}`).bind(...bind).all();
            for(const row of results) if(!existingIds.has(row.id)){existing.push(row);existingIds.add(row.id)}
          }
        }
        // Preserve legacy duplicate detection where old rows lack phone_normalized, scoped to Team when applicable.
        if(inputPhones.length){
          const legacySql=`SELECT id,customer_code,phone_normalized,phone FROM customers WHERE (phone_normalized IS NULL OR phone_normalized='') AND phone IS NOT NULL${duplicateTeamClause}`;
          const {results}=duplicateTeamId?await env.DB.prepare(legacySql).bind(duplicateTeamId).all():await env.DB.prepare(legacySql).all();
          const targets=new Set(inputPhones);
          for(const row of results) if(targets.has(normalizePhone(row.phone))&&!existingIds.has(row.id)){
            existing.push(row);existingIds.add(row.id);
          }
        }
        if(inputCodes.length && !toWarehouse){
          const {results}=await env.DB.prepare('SELECT id,customer_code,phone_normalized,phone FROM customers WHERE customer_code IS NOT NULL').all();
          const codes=new Set(inputCodes.map(norm));
          for(const row of results) if(codes.has(norm(row.customer_code))&&!existingIds.has(row.id)){
            existing.push(row);existingIds.add(row.id);
          }
        }
        const teamMap=new Map(); teams.forEach(t=>{teamMap.set(norm(t.name),t.id);teamMap.set(parseTeamAlias(t.name),t.id);teamMap.set(`m${String(t.name).match(/\d+/)?.[0]||''}`,t.id)});
        const userMap=new Map(); users.forEach(u=>{userMap.set(norm(u.username),u);userMap.set(norm(u.display_name),u)});
        const phoneMap=new Map(existing.filter(x=>x.phone_normalized||x.phone).map(x=>[normalizePhone(x.phone_normalized||x.phone),x.id]));
        const codeMap=new Map(existing.filter(x=>x.customer_code).map(x=>[norm(x.customer_code),x.id]));
        const stmts=[]; let inserted=0,updated=0,skipped=0; const seenBatchPhones=new Set();
        for(const raw of items){
          const name=cleanText(raw.name||raw.full_name), phone=cleanText(raw.phone), phoneNorm=normalizePhone(phone), code=cleanText(raw.code||raw.customer_code), source=toWarehouse?importSource:cleanText(raw.source);
          const rowCategoryId=(toWarehouse||!!raw.to_warehouse)?importCategoryId:(raw.data_category_id?Number(raw.data_category_id):null);
          if(!name&&!phoneNorm){skipped++;continue;}
          let teamId=raw.team_id?Number(raw.team_id):null;
          if(!teamId&&raw.team) teamId=teamMap.get(parseTeamAlias(raw.team))||teamMap.get(norm(raw.team))||null;
            let owner=null;
          if(raw.assigned_user_id){ owner=users.find(u=>u.id===Number(raw.assigned_user_id))||null; }
          if(!owner){ const ownerKey=norm(raw.owner_username||raw.owner||raw.assigned_to||''); if(ownerKey) owner=userMap.get(ownerKey)||null; }
          if(owner && owner.role!=='sale') owner=null;
          if(owner && teamId && owner.team_id!==teamId) owner=null;
          if(session.role==='teamlead' && owner && owner.team_id!==session.team_id) owner=null;
          let ownerId=owner?.id||null, status=raw.status?normalizeStatus(raw.status):'NEW';
          let dataState=cleanText(raw.data_state||'')||((ownerId)?'ASSIGNED':'POOL');
          let archivedAt=raw.archived_at?cleanText(raw.archived_at):null;
          let forceTeam=raw.force_team?1:0, forceOwner=raw.force_owner?1:0;
          const rowToWarehouse=toWarehouse||!!raw.to_warehouse;
          if(rowToWarehouse){
            ownerId=null; forceOwner=1; status='NEW'; dataState='POOL'; archivedAt=null;
            if(session.role==='teamlead'){teamId=session.team_id;forceTeam=1;}else{teamId=requestedWarehouseTeam||null;forceTeam=1;}
          }
          if(!['POOL','ASSIGNED','ARCHIVED'].includes(dataState)) dataState=ownerId?'ASSIGNED':'POOL';
          if(rowToWarehouse){
            // Lọc SĐT trùng ngay trên server, tránh làm mất Data đã gọi, lịch sử hoặc người đang được giao.
            if(!phoneNorm || seenBatchPhones.has(phoneNorm) || phoneMap.has(phoneNorm) || (code && codeMap.has(norm(code)))){skipped++;continue;}
            seenBatchPhones.add(phoneNorm);
          }
          const id=(phoneNorm&&phoneMap.get(phoneNorm))||(code&&codeMap.get(norm(code)))||null;
          if(id){
            stmts.push(env.DB.prepare(`UPDATE customers SET
              customer_code=COALESCE(NULLIF(?,''),customer_code),full_name=COALESCE(NULLIF(?,''),full_name),phone=COALESCE(NULLIF(?,''),phone),phone_normalized=COALESCE(NULLIF(?,''),phone_normalized),source=COALESCE(NULLIF(?,''),source),data_category_id=CASE WHEN ? IS NOT NULL THEN ? ELSE data_category_id END,team_id=CASE WHEN ?=1 THEN ? ELSE COALESCE(?,team_id) END,assigned_user_id=CASE WHEN ?=1 THEN ? ELSE COALESCE(?,assigned_user_id) END,status=?,received_at=COALESCE(NULLIF(?,''),received_at),follow_up_at=?,note=COALESCE(NULLIF(?,''),note),data_state=?,archived_at=?,updated_at=datetime('now') WHERE id=?`)
              .bind(code,name,phone,phoneNorm,source,rowCategoryId,rowCategoryId,forceTeam,teamId,teamId,forceOwner,ownerId,ownerId,status,cleanText(raw.received),rowToWarehouse?null:(cleanText(raw.follow_up)||null),cleanText(raw.note),dataState,archivedAt,id)); updated++;
          }else{
            stmts.push(env.DB.prepare(`INSERT INTO customers(customer_code,full_name,phone,phone_normalized,source,data_category_id,team_id,assigned_user_id,status,received_at,follow_up_at,note,data_state,archived_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
              .bind(code||null,name||'Chưa rõ',phone||null,phoneNorm||null,source||null,rowCategoryId,teamId,ownerId,status||'NEW',cleanText(raw.received)||null,rowToWarehouse?null:(cleanText(raw.follow_up)||null),cleanText(raw.note)||null,dataState,archivedAt)); inserted++;
            if(phoneNorm) phoneMap.set(phoneNorm, -1);
            if(code) codeMap.set(norm(code), -1);
          }
        }
        for(let i=0;i<stmts.length;i+=80) await env.DB.batch(stmts.slice(i,i+80));
        const warehouseTeamId=session.role==='teamlead'?session.team_id:(requestedWarehouseTeam||null);
        await audit(env,session.id,'CUSTOMER_IMPORT','customer',null,{inserted,updated,skipped,total:items.length,to_warehouse:toWarehouse,source_name:toWarehouse?importSource:null,data_category_id:toWarehouse?importCategoryId:null,team_id:warehouseTeamId});
        return json({ok:true,inserted,updated,skipped,total:items.length,category:toWarehouse&&importCategoryId?{id:importCategoryId,name:importSource}:null,warehouse_scope:session.role==='teamlead'?'team':(warehouseTeamId?'team':'admin'),team_id:warehouseTeamId});
      }
      const customerMatch=url.pathname.match(/^\/api\/customers\/(\d+)$/);
      if(customerMatch && request.method==='PATCH'){
        const id=Number(customerMatch[1]), patch=await request.json(), allowed=['status','follow_up_at','note','team_id','assigned_user_id'];
        const current=await env.DB.prepare('SELECT * FROM customers WHERE id=?').bind(id).first(); if(!current) return bad('Không tìm thấy khách.',404);
        if(session.role==='sale' && current.assigned_user_id!==session.id) return bad('Không có quyền sửa khách này.',403);
        if(session.role==='teamlead') return bad('Teamlead chỉ có quyền theo dõi CRM của Team.',403);
        const entries=Object.entries(patch).map(([k,v])=>[k==='follow_up'?'follow_up_at':k,v]).filter(([k])=>allowed.includes(k)); if(!entries.length)return bad('Không có trường hợp lệ.');
        const sql=`UPDATE customers SET ${entries.map(([k])=>`${k}=?`).join(',')},updated_at=datetime('now') WHERE id=?`;
        const changedFields=entries.map(([k])=>k);
        const before=pickedUndoValues(current,changedFields);
        await env.DB.prepare(sql).bind(...entries.map(([,v])=>v),id).run();
        const afterRow=await env.DB.prepare(`SELECT ${changedFields.join(',')} FROM customers WHERE id=?`).bind(id).first();
        await auditWithUndo(env,session,'CUSTOMER_UPDATE','customer',id,patch,before,pickedUndoValues(afterRow,changedFields));
        return json({ok:true});
      }

      // Separate Login App lead funnel created manually by the Login App team.
      if(url.pathname==='/api/login-leads' && request.method==='GET'){
        await v1036EnsureAux(env);
        const scope=session.role==='teamlead'?'ll.team_id=?':session.role==='sale'?'ll.assigned_user_id=?':'';
        const bind=session.role==='teamlead'?[session.team_id]:session.role==='sale'?[session.id]:[];
        const {results}=await env.DB.prepare(`SELECT ll.*,t.name team,u.display_name owner
          FROM login_app_leads ll
          LEFT JOIN teams t ON t.id=ll.team_id LEFT JOIN users u ON u.id=ll.assigned_user_id
          ${scope?`WHERE ${scope}`:''}
          ORDER BY CASE ll.status WHEN 'PENDING' THEN 0 WHEN 'LOGIN_APP' THEN 1 ELSE 2 END,ll.updated_at DESC,ll.id DESC LIMIT 2000`).bind(...bind).all();
        return json({items:results||[]});
      }
      if(url.pathname==='/api/login-leads' && request.method==='POST'){
        await v1036EnsureAux(env);
        const body=await request.json();
        const customerName=cleanText(body.customer_name).slice(0,160),phoneRaw=cleanText(body.phone).slice(0,40),phoneNorm=normalizePhone(phoneRaw),source=cleanText(body.source).slice(0,80),note=cleanText(body.note).slice(0,700);
        if(!customerName)return bad('Vui lòng nhập tên khách hàng.');
        if(!/^\d{10}$/.test(phoneNorm))return bad('Số điện thoại bắt buộc đúng 10 số.');
        if(!V1036_LOGIN_LEAD_SOURCES.includes(source))return bad('Nguồn khách hàng không hợp lệ.',400);
        const owner=await resolveLoginLeadOwner(env,session,body.assigned_user_id);
        if(!owner)return bad('Nhân viên phụ trách không hợp lệ hoặc ngoài phạm vi.',403);
        const r=await env.DB.prepare(`INSERT INTO login_app_leads(team_id,assigned_user_id,customer_name,phone,phone_normalized,source,note,status,created_by)
          VALUES(?,?,?,?,?,?,?,'PENDING',?)`).bind(owner.team_id||null,owner.id,customerName,phoneNorm,phoneNorm,source,note,session.id).run();
        await audit(env,session.id,'LOGIN_LEAD_CREATE','login_lead',r.meta?.last_row_id||null,{assigned_user_id:owner.id,team_id:owner.team_id||null,source});
        return json({ok:true,id:r.meta?.last_row_id||null});
      }
      const loginLeadSource=url.pathname.match(/^\/api\/login-leads\/(\d+)\/source$/);
      if(loginLeadSource && request.method==='PUT'){
        await v1036EnsureAux(env);
        const id=Number(loginLeadSource[1]),body=await request.json();
        const source=cleanText(body.source).slice(0,80);
        if(!source||!V1036_LOGIN_LEAD_SOURCES.includes(source))return bad('Nguồn khách hàng không hợp lệ.',400);
        const scope=session.role==='teamlead'?'team_id=? AND id=?':session.role==='sale'?'assigned_user_id=? AND id=?':'id=?';
        const bind=session.role==='teamlead'?[session.team_id,id]:session.role==='sale'?[session.id,id]:[id];
        const row=await env.DB.prepare(`SELECT id FROM login_app_leads WHERE ${scope}`).bind(...bind).first();
        if(!row)return bad('Không có quyền chỉnh nguồn Lead này.',403);
        await env.DB.prepare(`UPDATE login_app_leads SET source=?,updated_at=datetime('now') WHERE id=?`).bind(source,id).run();
        await audit(env,session.id,'LOGIN_LEAD_SOURCE','login_lead',id,{source});return json({ok:true});
      }
      const loginLeadStatus=url.pathname.match(/^\/api\/login-leads\/(\d+)\/status$/);
      if(loginLeadStatus && request.method==='POST'){
        await v1036EnsureAux(env);await ensureLoginAppSchema(env);
        const id=Number(loginLeadStatus[1]),body=await request.json(),next=cleanText(body.status).toUpperCase();
        if(!['PENDING','LOGIN_APP','NO_LOGIN'].includes(next))return bad('Trạng thái Lead Login App không hợp lệ.',400);
        const scope=session.role==='teamlead'?'team_id=? AND id=?':session.role==='sale'?'assigned_user_id=? AND id=?':'id=?';
        const bind=session.role==='teamlead'?[session.team_id,id]:session.role==='sale'?[session.id,id]:[id];
        const lead=await env.DB.prepare(`SELECT * FROM login_app_leads WHERE ${scope}`).bind(...bind).first();
        if(!lead)return bad('Không tìm thấy Lead Login App hoặc bạn không có quyền.',404);
        if(next==='PENDING'){
          await env.DB.prepare(`UPDATE login_app_leads SET status='PENDING',no_login_reason=NULL,updated_at=datetime('now') WHERE id=?`).bind(id).run();
          return json({ok:true});
        }
        if(next==='NO_LOGIN'){
          const reason=cleanText(body.reason).slice(0,500);if(!reason)return bad('Vui lòng nhập lý do không Login App.');
          await env.DB.prepare(`UPDATE login_app_leads SET status='NO_LOGIN',no_login_reason=?,updated_at=datetime('now') WHERE id=?`).bind(reason,id).run();
          await audit(env,session.id,'LOGIN_LEAD_NOLOGIN','login_lead',id,{reason});
          return json({ok:true});
        }
        let loginAppId=Number(lead.login_app_id||0);
        if(loginAppId){
          await env.DB.prepare(`UPDATE login_app_cases SET team_id=?,assigned_user_id=?,customer_name=?,phone=?,phone_normalized=?,customer_source=?,status='LOGIN_APP',retry_at=NULL,reject_reason=NULL,closed_at=NULL,updated_at=datetime('now') WHERE id=?`).bind(lead.team_id||null,lead.assigned_user_id,lead.customer_name,lead.phone,lead.phone_normalized||lead.phone,lead.source,loginAppId).run();
        }else{
          const r=await env.DB.prepare(`INSERT INTO login_app_cases(team_id,assigned_user_id,customer_name,phone,phone_normalized,cccd,customer_source,status,created_by) VALUES(?,?,?,?,?,?,?,'LOGIN_APP',?)`).bind(lead.team_id||null,lead.assigned_user_id,lead.customer_name,lead.phone,lead.phone_normalized||lead.phone,'',lead.source,session.id).run();
          loginAppId=Number(r.meta?.last_row_id||0);
        }
        await env.DB.prepare(`UPDATE login_app_leads SET status='LOGIN_APP',login_app_id=?,no_login_reason=NULL,updated_at=datetime('now') WHERE id=?`).bind(loginAppId,id).run();
        await audit(env,session.id,'LOGIN_LEAD_CONVERT','login_lead',id,{login_app_id:loginAppId});
        return json({ok:true,login_app_id:loginAppId});
      }
      // V10.38: Manager edits/deletes only within the server-enforced data scope.
      const appLeadManage=url.pathname.match(/^\/api\/login-leads\/(\d+)$/);
      if(appLeadManage && (request.method==='PATCH'||request.method==='DELETE')){
        await v1036EnsureAux(env);
        const id=Number(appLeadManage[1]);
        const scope=session.role==='teamlead'?' AND team_id=?':session.role==='sale'?' AND assigned_user_id=?':'';
        const bind=session.role==='teamlead'?[session.team_id]:session.role==='sale'?[session.id]:[];
        const row=await env.DB.prepare(`SELECT * FROM login_app_leads WHERE id=?${scope}`).bind(id,...bind).first();
        if(!row)return bad('Không tìm thấy Lead Login App trong phạm vi của bạn.',404);
        if(request.method==='DELETE'){
          if(session.role==='sale')return bad('Chỉ Admin, Sup hoặc Team Leader được xóa Lead.',403);
          await env.DB.prepare('DELETE FROM login_app_leads WHERE id=?').bind(id).run();
          await audit(env,session.id,'LOGIN_LEAD_DELETE','login_lead',id,{customer_name:row.customer_name,login_app_id:row.login_app_id||null});
          return json({ok:true,preserved_login_app_id:row.login_app_id||null});
        }
        const body=await request.json();
        const name=cleanText(body.customer_name??row.customer_name).slice(0,160);
        const phone=normalizePhone(body.phone??row.phone);
        const source=cleanText(body.source??row.source).slice(0,80);
        const note=cleanText(body.note??row.note).slice(0,700);
        if(!name||!/^\d{10}$/.test(phone)||!V1036_LOGIN_LEAD_SOURCES.includes(source))return bad('Tên, số điện thoại hoặc nguồn khách không hợp lệ.');
        if(Number(row.login_app_id||0)>0&&(name!==row.customer_name||phone!==row.phone_normalized))return bad('Khách đã chuyển App: hãy chỉnh thông tin khách từ hồ sơ Login App để tránh lệch dữ liệu.',409);
        let ownerId=Number(row.assigned_user_id),teamId=row.team_id;
        if(body.assigned_user_id!==undefined&&Number(body.assigned_user_id)!==ownerId){
          const nextOwner=await resolveLoginLeadOwner(env,session,body.assigned_user_id);
          if(!nextOwner)return bad('Nhân viên nhận Lead không thuộc phạm vi hoặc đã ngừng hoạt động.',403);
          if(Number(row.login_app_id||0)>0)return bad('Không chuyển nhân viên khi Lead đã liên kết hồ sơ Login App.',409);
          ownerId=nextOwner.id;teamId=nextOwner.team_id;
        }
        await env.DB.prepare(`UPDATE login_app_leads SET customer_name=?,phone=?,phone_normalized=?,source=?,note=?,assigned_user_id=?,team_id=?,updated_at=datetime('now') WHERE id=?`)
          .bind(name,phone,phone,source,note,ownerId,teamId||null,id).run();
        await audit(env,session.id,'LOGIN_LEAD_UPDATE','login_lead',id,{source,assigned_user_id:ownerId});
        return json({ok:true});
      }
      // Independent Login App follow-ups: no changes to Telesales follow_up_at.
      if(url.pathname==='/api/app-followups' && request.method==='GET'){
        await v1036EnsureAux(env);
        const scope=session.role==='teamlead'?' AND f.team_id=?':session.role==='sale'?' AND f.assigned_user_id=?':'';
        const bind=session.role==='teamlead'?[session.team_id]:session.role==='sale'?[session.id]:[];
        const rows=(await env.DB.prepare(`SELECT f.*,la.customer_name,la.phone,u.display_name owner,t.name team FROM app_followups f JOIN login_app_cases la ON la.id=f.login_app_id LEFT JOIN users u ON u.id=f.assigned_user_id LEFT JOIN teams t ON t.id=f.team_id WHERE 1=1 ${scope} ORDER BY CASE WHEN f.status='PENDING' AND f.follow_date<date('now') THEN 0 WHEN f.status='PENDING' AND f.follow_date=date('now') THEN 1 ELSE 2 END,f.follow_date ASC,f.id DESC LIMIT 2000`).bind(...bind).all()).results||[];
        return json({items:rows});
      }
      if(url.pathname==='/api/app-followups' && request.method==='POST'){
        await v1036EnsureAux(env);await ensureLoginAppSchema(env);
        const body=await request.json(),id=Number(body.login_app_id),date=cleanText(body.follow_date),category=cleanText(body.category);
        if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!['REJECTED','CALLBACK','DOCUMENT','RELOGIN'].includes(category))return bad('Ngày hẹn hoặc loại chăm sóc không hợp lệ.');
        const la=await env.DB.prepare('SELECT id,team_id,assigned_user_id FROM login_app_cases WHERE id=?').bind(id).first();
        if(!la)return bad('Không tìm thấy khách Login App.',404);
        if(session.role==='teamlead'&&Number(la.team_id)!==Number(session.team_id))return bad('Khách ngoài Team.',403);
        if(session.role==='sale'&&Number(la.assigned_user_id)!==Number(session.id))return bad('Khách không thuộc bạn.',403);
        const note=cleanText(body.note).slice(0,700),assigned=Number(la.assigned_user_id||session.id);
        const followupId=await v1036UpsertAppFollowup(env,{id,assigned_user_id:assigned,team_id:la.team_id},date,category,note,session.id);
        await audit(env,session.id,'APP_FOLLOWUP_CREATE','app_followup',followupId,{login_app_id:id,follow_date:date,category});return json({ok:true,id:followupId});
      }
      const appFollowDone=url.pathname.match(/^\/api\/app-followups\/(\d+)\/complete$/);
      if(appFollowDone && request.method==='POST'){
        await v1036EnsureAux(env);
        const id=Number(appFollowDone[1]),f=await env.DB.prepare('SELECT id,team_id,assigned_user_id,status FROM app_followups WHERE id=?').bind(id).first();
        if(!f)return bad('Không tìm thấy lịch hẹn.',404);
        if(session.role==='teamlead'&&Number(f.team_id)!==Number(session.team_id)||session.role==='sale'&&Number(f.assigned_user_id)!==Number(session.id))return bad('Không thuộc phạm vi của bạn.',403);
        await env.DB.prepare("UPDATE app_followups SET status='DONE',updated_at=datetime('now') WHERE id=? AND status='PENDING'").bind(id).run();
        await audit(env,session.id,'APP_FOLLOWUP_COMPLETE','app_followup',id,{});return json({ok:true});
      }
      // V10.38: scoped follow-up edit/delete. The Login App profile remains intact.
      const appFollowManage=url.pathname.match(/^\/api\/app-followups\/(\d+)$/);
      if(appFollowManage&&(request.method==='PATCH'||request.method==='DELETE')){
        await v1036EnsureAux(env);
        const id=Number(appFollowManage[1]);
        const scope=session.role==='teamlead'?' AND team_id=?':session.role==='sale'?' AND assigned_user_id=?':'';
        const bind=session.role==='teamlead'?[session.team_id]:session.role==='sale'?[session.id]:[];
        const row=await env.DB.prepare(`SELECT * FROM app_followups WHERE id=?${scope}`).bind(id,...bind).first();
        if(!row)return bad('Không tìm thấy lịch Follow-up Login App trong phạm vi của bạn.',404);
        if(request.method==='DELETE'){
          if(session.role==='sale')return bad('Chỉ Admin, Sup hoặc Team Leader được xóa lịch hẹn.',403);
          await env.DB.prepare('DELETE FROM app_followups WHERE id=?').bind(id).run();
          await audit(env,session.id,'APP_FOLLOWUP_DELETE','app_followup',id,{login_app_id:row.login_app_id});
          return json({ok:true});
        }
        const body=await request.json();
        const date=cleanText(body.follow_date??row.follow_date);
        const category=cleanText(body.category??row.category);
        const note=cleanText(body.note??row.note).slice(0,700);
        const status=cleanText(body.status??row.status).toUpperCase();
        if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!['REJECTED','CALLBACK','DOCUMENT','RELOGIN'].includes(category)||!['PENDING','DONE'].includes(status))return bad('Ngày hẹn, loại lịch hoặc trạng thái không hợp lệ.');
        await env.DB.prepare(`UPDATE app_followups SET follow_date=?,category=?,note=?,status=?,updated_at=datetime('now') WHERE id=?`).bind(date,category,note,status,id).run();
        await audit(env,session.id,'APP_FOLLOWUP_UPDATE','app_followup',id,{follow_date:date,category,status});
        return json({ok:true});
      }
      if(url.pathname==='/api/leads' && request.method==='GET'){
        await ensureManualLeadSchema(env);
        const sc=leadScopeSql(session,'c');
        const {results}=await env.DB.prepare(`SELECT lc.customer_id,lc.source_call_status,lc.lead_origin,lc.created_by lead_created_by,lc.created_at lead_created_at,
          c.full_name name,c.phone,c.source,c.status call_status,ll.note last_call_note,ll.created_at last_call_at,c.team_id,t.name team,c.assigned_user_id,u.display_name owner,
          lh.status lead_status,lh.reason lead_reason,lh.changed_at lead_updated_at,cu.display_name changed_by,
          EXISTS(SELECT 1 FROM lead_status_history hx WHERE hx.customer_id=lc.customer_id AND hx.status='LOGIN_APP') ever_login_app,
          ln.note latest_lead_note,ln.created_at latest_lead_note_at,nu.display_name latest_lead_note_by
          FROM lead_cases lc JOIN customers c ON c.id=lc.customer_id
          LEFT JOIN teams t ON t.id=c.team_id LEFT JOIN users u ON u.id=c.assigned_user_id
          LEFT JOIN call_logs ll ON ll.id=(SELECT l2.id FROM call_logs l2 WHERE l2.customer_id=lc.customer_id ORDER BY l2.created_at DESC,l2.id DESC LIMIT 1)
          LEFT JOIN lead_status_history lh ON lh.id=(SELECT h.id FROM lead_status_history h WHERE h.customer_id=lc.customer_id ORDER BY h.changed_at DESC,h.id DESC LIMIT 1)
          LEFT JOIN users cu ON cu.id=lh.changed_by
          LEFT JOIN lead_notes ln ON ln.id=(SELECT n2.id FROM lead_notes n2 WHERE n2.customer_id=lc.customer_id ORDER BY n2.created_at DESC,n2.id DESC LIMIT 1)
          LEFT JOIN users nu ON nu.id=ln.created_by
          WHERE ${sc.where}
          ORDER BY lc.created_at DESC,lc.customer_id DESC LIMIT 1000`).bind(...sc.bind).all();
        return json({items:results});
      }

      if(url.pathname==='/api/leads/manual' && request.method==='POST'){
        await ensureManualLeadSchema(env);
        const body=await request.json();
        const name=cleanText(body.customer_name).slice(0,160);
        const phone=normalizePhone(cleanText(body.phone));
        const source=cleanText(body.source||'Khác').slice(0,80)||'Khác';
        const note=cleanText(body.note).slice(0,1000);
        if(!name)return bad('Vui lòng nhập tên khách hàng.');
        if(!/^0\d{9}$/.test(phone))return bad('Số điện thoại bắt buộc đúng 10 số và bắt đầu bằng 0.');
        const owner=await resolveManualLeadOwner(env,session,body.assigned_user_id);
        if(!owner)return bad('Nhân viên phụ trách không hợp lệ hoặc ngoài phạm vi.',403);
        const teamId=Number(owner.team_id||0)||null;
        const existing=await env.DB.prepare(`SELECT id,full_name,team_id,assigned_user_id FROM customers WHERE phone_normalized=? ORDER BY id DESC LIMIT 1`).bind(phone).first();
        let customerId;
        if(existing){
          const already=await env.DB.prepare('SELECT customer_id FROM lead_cases WHERE customer_id=?').bind(existing.id).first();
          if(already)return bad('Số điện thoại này đã có trong danh sách Lead.');
          if(session.role==='sale'&&Number(existing.assigned_user_id||0)!==Number(session.id))return bad('Khách hàng này đang thuộc nhân viên khác.',403);
          if(session.role==='teamlead'&&Number(existing.team_id||0)!==Number(session.team_id))return bad('Khách hàng này đang thuộc Team khác.',403);
          customerId=Number(existing.id);
          await env.DB.prepare(`UPDATE customers SET full_name=?,source=?,team_id=?,assigned_user_id=?,updated_at=datetime('now') WHERE id=?`)
            .bind(name,source,teamId,owner.id,customerId).run();
        }else{
          const r=await env.DB.prepare(`INSERT INTO customers(full_name,phone,phone_normalized,source,team_id,assigned_user_id,status,received_at,note,data_state,created_at,updated_at)
            VALUES(?,?,?,?,?,?,'NEW',date('now'),?,'LEAD',datetime('now'),datetime('now'))`)
            .bind(name,phone,phone,source,teamId,owner.id,note||null).run();
          customerId=Number(r.meta?.last_row_id||0);
        }
        if(!customerId)return bad('Không thể tạo khách hàng cho Lead.');
        await env.DB.prepare(`INSERT INTO lead_cases(customer_id,source_call_status,created_by,created_at,lead_origin) VALUES(?,'Y01',?,datetime('now'),'MANUAL')`)
          .bind(customerId,session.id).run();
        if(note){
          await env.DB.prepare("INSERT INTO lead_notes(customer_id,note,created_by,created_at) VALUES(?,?,?,datetime('now'))").bind(customerId,note,session.id).run();
        }
        await audit(env,session.id,'LEAD_MANUAL_CREATE','lead',customerId,{assigned_user_id:owner.id,team_id:teamId,source,phone});
        return json({ok:true,customer_id:customerId});
      }

      const leadDeleteMatch=url.pathname.match(/^\/api\/leads\/(\d+)$/);
      if(leadDeleteMatch && request.method==='DELETE'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Team Leader được xóa Lead.',403);
        const customerId=Number(leadDeleteMatch[1]),sc=leadScopeSql(session,'c');
        const lead=await env.DB.prepare(`SELECT lc.customer_id,c.team_id,c.assigned_user_id,c.full_name FROM lead_cases lc JOIN customers c ON c.id=lc.customer_id WHERE lc.customer_id=? AND ${sc.where}`).bind(customerId,...sc.bind).first();
        if(!lead) return bad('Không tìm thấy Lead hoặc Lead không thuộc phạm vi Team của bạn.',404);
        // Chỉ xóa dữ liệu quản lý Lead; luôn giữ customers + call_logs nguyên vẹn.
        await env.DB.batch([
          env.DB.prepare('DELETE FROM lead_notes WHERE customer_id=?').bind(customerId),
          env.DB.prepare('DELETE FROM lead_status_history WHERE customer_id=?').bind(customerId),
          env.DB.prepare('DELETE FROM lead_cases WHERE customer_id=?').bind(customerId)
        ]);
        await audit(env,session.id,'LEAD_DELETE','lead',customerId,{customer_name:lead.full_name||'',team_id:lead.team_id||null,assigned_user_id:lead.assigned_user_id||null,preserved_customer:true,preserved_call_logs:true});
        return json({ok:true,customer_id:customerId,preserved_customer:true,preserved_call_logs:true});
      }
      const leadHistoryMatch=url.pathname.match(/^\/api\/leads\/(\d+)\/history$/);
      if(leadHistoryMatch && request.method==='GET'){
        const customerId=Number(leadHistoryMatch[1]),sc=leadScopeSql(session,'c');
        const lead=await env.DB.prepare(`SELECT lc.customer_id,lc.created_at lead_created_at FROM lead_cases lc JOIN customers c ON c.id=lc.customer_id WHERE lc.customer_id=? AND ${sc.where}`).bind(customerId,...sc.bind).first();
        if(!lead) return bad('Không tìm thấy Lead hoặc bạn không có quyền xem Lead này.',404);
        // V6.6: gom tiến trình Lead + ghi chú thủ công + lịch sử gọi trong một query.
        // Cuộc gọi được đọc trực tiếp từ call_logs nên không phát sinh thêm Rows written khi khách gọi lại.
        const {results}=await env.DB.prepare(`SELECT * FROM (
          SELECT 'STATUS' event_type,h.id,h.status code,h.reason detail,h.changed_at event_at,u.display_name actor
          FROM lead_status_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.customer_id=?
          UNION ALL
          SELECT 'NOTE' event_type,n.id,NULL code,n.note detail,n.created_at event_at,u.display_name actor
          FROM lead_notes n LEFT JOIN users u ON u.id=n.created_by WHERE n.customer_id=?
          UNION ALL
          SELECT 'CALL' event_type,l.id,l.status code,l.note detail,l.created_at event_at,u.display_name actor
          FROM call_logs l LEFT JOIN users u ON u.id=l.user_id
          WHERE l.customer_id=? AND datetime(l.created_at)>=datetime(?)
        ) ORDER BY event_at DESC,id DESC LIMIT 300`).bind(customerId,customerId,customerId,lead.lead_created_at).all();
        return json({events:results||[]});
      }
      const leadNoteMatch=url.pathname.match(/^\/api\/leads\/(\d+)\/notes$/);
      if(leadNoteMatch && request.method==='POST'){
        const customerId=Number(leadNoteMatch[1]),body=await request.json(),note=cleanText(body.note).slice(0,1000);
        if(!note) return bad('Vui lòng nhập ghi chú.');
        const sc=leadScopeSql(session,'c');
        const lead=await env.DB.prepare(`SELECT lc.customer_id FROM lead_cases lc JOIN customers c ON c.id=lc.customer_id WHERE lc.customer_id=? AND ${sc.where}`).bind(customerId,...sc.bind).first();
        if(!lead) return bad('Không tìm thấy Lead hoặc bạn không có quyền ghi chú Lead này.',404);
        const now=new Date().toISOString().slice(0,19).replace('T',' ');
        // Một thao tác ghi chú = đúng một row write; không audit lặp để tiết kiệm D1.
        const r=await env.DB.prepare('INSERT INTO lead_notes(customer_id,note,created_by,created_at) VALUES(?,?,?,?)').bind(customerId,note,session.id,now).run();
        return json({ok:true,id:r.meta?.last_row_id||null,item:{id:r.meta?.last_row_id||null,customer_id:customerId,note,created_by:session.display_name,created_at:now}});
      }
      const leadStatusMatch=url.pathname.match(/^\/api\/leads\/(\d+)\/status$/);
      if(leadStatusMatch && request.method==='POST'){
        const customerId=Number(leadStatusMatch[1]), body=await request.json();
        const nextStatus=cleanText(body.status).toUpperCase();
        if(!LEAD_STATUSES.has(nextStatus)) return bad('Trạng thái Lead không hợp lệ.');
        await ensureLeadHistoryStatusSchema(env);
        const sc=leadScopeSql(session,'c');
        const customer=await env.DB.prepare(`SELECT c.id,c.status FROM customers c WHERE c.id=? AND ${sc.where}`).bind(customerId,...sc.bind).first();
        if(!customer) return bad('Không tìm thấy khách hoặc bạn không có quyền cập nhật.',404);
        let lead=await env.DB.prepare('SELECT customer_id FROM lead_cases WHERE customer_id=?').bind(customerId).first();
        if(!lead){
          if(!['Y01','Y02'].includes(customer.status)) return bad('Khách này chưa phát sinh cuộc gọi Y01/Y02 nên chưa phải Lead.',400);
          await env.DB.prepare('INSERT OR IGNORE INTO lead_cases(customer_id,source_call_status,created_by) VALUES(?,?,?)').bind(customerId,customer.status,session.id).run();
        }
        const current=await env.DB.prepare('SELECT id,status FROM lead_status_history WHERE customer_id=? ORDER BY changed_at DESC,id DESC LIMIT 1').bind(customerId).first();
        if(current?.status===nextStatus) return json({ok:true,unchanged:true});
        const everLogin=await env.DB.prepare("SELECT 1 ok FROM lead_status_history WHERE customer_id=? AND status='LOGIN_APP' LIMIT 1").bind(customerId).first();
        if(nextStatus==='SIGNED'&&!everLogin) return bad('Chỉ được xác nhận giải ngân sau khi Lead đã chuyển thành Login App.');
        const reason=cleanText(body.reason).slice(0,500);
        if((nextStatus==='OTHER'||nextStatus==='NO_LOGIN')&&!reason) return bad('Vui lòng nhập lý do khách không Login.');
        const now=new Date().toISOString().slice(0,19).replace('T',' ');
        const r=await env.DB.prepare('INSERT INTO lead_status_history(customer_id,status,reason,changed_by,changed_at) VALUES(?,?,?,?,?)').bind(customerId,nextStatus,reason||null,session.id,now).run();
        if(nextStatus==='LOGIN_APP'){
          await ensureLoginAppSchema(env);
          const c=await env.DB.prepare('SELECT id,team_id,assigned_user_id,full_name,phone,phone_normalized FROM customers WHERE id=?').bind(customerId).first();
          if(c){
            await v1036EnsureAux(env);
            const chosenSource=(await env.DB.prepare('SELECT source FROM login_lead_sources WHERE customer_id=?').bind(customerId).first())?.source||null;
            const existing=await env.DB.prepare('SELECT id FROM login_app_cases WHERE customer_id=? ORDER BY id DESC LIMIT 1').bind(customerId).first();
            if(existing){
              await env.DB.prepare(`UPDATE login_app_cases SET team_id=?,assigned_user_id=?,customer_name=?,phone=?,phone_normalized=?,customer_source=COALESCE(?,customer_source),status='LOGIN_APP',retry_at=NULL,reject_reason=NULL,closed_at=NULL,updated_at=datetime('now') WHERE id=?`)
                .bind(c.team_id||null,c.assigned_user_id||session.id,c.full_name||'',c.phone||'',c.phone_normalized||null,chosenSource,existing.id).run();
            }else{
              await env.DB.prepare(`INSERT INTO login_app_cases(customer_id,team_id,assigned_user_id,customer_name,phone,phone_normalized,cccd,customer_source,status,created_by) VALUES(?,?,?,?,?,?,?,?,'LOGIN_APP',?)`)
                .bind(c.id,c.team_id||null,c.assigned_user_id||session.id,c.full_name||'',c.phone||'',c.phone_normalized||null,'',chosenSource,session.id).run();
            }
          }
        }
        if(nextStatus==='SIGNED'){
          await ensureLoanCareSchema(env);
          const c=await env.DB.prepare('SELECT id,team_id,assigned_user_id FROM customers WHERE id=?').bind(customerId).first();
          if(c)await env.DB.prepare(`INSERT OR IGNORE INTO loan_profiles(customer_id,team_id,assigned_user_id,disbursement_date,status,created_by) VALUES(?,?,?,date(?),'ACTIVE',?)`).bind(customerId,c.team_id||null,c.assigned_user_id||null,now,session.id).run();
        }
        if(!['LOGIN_APP','SIGNED'].includes(nextStatus)){
          await auditWithUndo(env,session,'LEAD_STATUS_UPDATE','lead',customerId,{previous_status:current?.status||null,new_status:nextStatus,reason:reason||null},{history_id:current?.id||null},{history_id:Number(r.meta?.last_row_id)});
        }else{
          // Cascading transitions require relational rollback and cannot be safely reversed by a status delete.
          await audit(env,session.id,'LEAD_STATUS_UPDATE','lead',customerId,{previous_status:current?.status||null,new_status:nextStatus,reason:reason||null});
        }
        return json({ok:true,id:r.meta?.last_row_id||null,item:{customer_id:customerId,status:nextStatus,reason:reason||null,changed_by:session.display_name,changed_at:now}});
      }
      if(url.pathname==='/api/calls/export' && request.method==='GET'){
        if(!isManager(session)&&session.role!=='teamlead') return bad('Chỉ Admin và Teamlead được xuất lịch sử cuộc gọi.',403);
        const q=cleanText(url.searchParams.get('q')).slice(0,120).toLowerCase();
        const from=cleanText(url.searchParams.get('from'));
        const to=cleanText(url.searchParams.get('to'));
        if(!/^\d{4}-\d{2}-\d{2}$/.test(from)||!/^\d{4}-\d{2}-\d{2}$/.test(to)||from>to) return bad('Ngày bắt đầu hoặc kết thúc không hợp lệ.');
        const fromTime=Date.parse(from+'T00:00:00Z'),toTime=Date.parse(to+'T00:00:00Z');
        if(!Number.isFinite(fromTime)||!Number.isFinite(toTime)||toTime-fromTime>366*86400000) return bad('Mỗi lần xuất tối đa 366 ngày.');
        const rawTeam=cleanText(url.searchParams.get('team_id'));
        const rawUser=cleanText(url.searchParams.get('user_id'));
        const status=cleanText(url.searchParams.get('status'));
        const offset=Number(url.searchParams.get('offset')||0);
        const limit=Math.min(1500,Math.max(1,Number(url.searchParams.get('limit')||1000)));
        if((rawTeam&&!/^\d+$/.test(rawTeam))||(rawUser&&!/^\d+$/.test(rawUser))||!Number.isSafeInteger(offset)||offset<0||offset>50000) return bad('Bộ lọc xuất Excel không hợp lệ.');
        if(status&&!/^(Y0[1-6]|N0[1-4])$/.test(status)) return bad('Trạng thái cuộc gọi không hợp lệ.');
        const clauses=[`l.created_at>=datetime(?, '-7 hours')`,`l.created_at<datetime(date(?, '+1 day'), '-7 hours')`],bind=[from,to];
        // Bắt buộc kiểm tra quyền ở phía server. Không tin tưởng team_id / user_id gửi từ trình duyệt.
        if(session.role==='teamlead'){
          clauses.push('c.team_id=?');bind.push(session.team_id);
        }else if(rawTeam){
          clauses.push('c.team_id=?');bind.push(Number(rawTeam));
        }
        if(rawUser){
          const employee=await env.DB.prepare("SELECT id,role,team_id FROM users WHERE id=?").bind(Number(rawUser)).first();
          if(!employee||employee.role!=='sale') return bad('Nhân viên không hợp lệ.',400);
          if(session.role==='teamlead'&&Number(employee.team_id)!==Number(session.team_id)) return bad('Không có quyền xuất cuộc gọi của Team khác.',403);
          if(rawTeam&&isManager(session)&&Number(employee.team_id)!==Number(rawTeam)) return bad('Nhân viên không thuộc Team đã chọn.',400);
          clauses.push('l.user_id=?');bind.push(Number(rawUser));
        }
        if(status){clauses.push('l.status=?');bind.push(status);}
        const {results}=await env.DB.prepare(`SELECT l.id,l.customer_id,l.user_id,u.display_name owner,t.name team,
          c.full_name customer_name,c.phone,c.source,l.status,l.note,l.follow_up_at,l.created_at
          FROM call_logs l JOIN customers c ON c.id=l.customer_id
          LEFT JOIN users u ON u.id=l.user_id LEFT JOIN teams t ON t.id=c.team_id
          WHERE ${clauses.join(' AND ')} ORDER BY l.created_at ASC,l.id ASC LIMIT ? OFFSET ?`)
          .bind(...bind,limit+1,offset).all();
        return json({items:results.slice(0,limit),has_more:results.length>limit});
      }
      const customerCallsMatch=url.pathname.match(/^\/api\/calls\/customer\/(\d+)$/);
      if(customerCallsMatch && request.method==='GET'){
        const customerId=Number(customerCallsMatch[1]),sc=scopeSql(session,'c');
        const customer=await env.DB.prepare(`SELECT c.id FROM customers c WHERE c.id=? AND ${sc.where}`).bind(customerId,...sc.bind).first();
        if(!customer) return bad('Không có quyền xem lịch sử khách này.',403);
        const {results}=await env.DB.prepare(`SELECT l.id,l.customer_id,l.user_id,u.display_name owner,c.team_id,t.name team,l.status,l.note,l.follow_up_at,l.created_at
          FROM call_logs l JOIN customers c ON c.id=l.customer_id LEFT JOIN users u ON u.id=l.user_id LEFT JOIN teams t ON t.id=c.team_id
          WHERE l.customer_id=? ORDER BY l.created_at DESC,l.id DESC LIMIT 500`).bind(customerId).all();
        return json({items:results});
      }
      if(url.pathname==='/api/calls' && request.method==='GET'){
        const s=scopeSql(session,'c'), clauses=[s.where], binds=[...s.bind];
        const from=cleanText(url.searchParams.get('from')),to=cleanText(url.searchParams.get('to'));
        if(from){if(!/^\d{4}-\d{2}-\d{2}$/.test(from))return bad('Ngày bắt đầu không hợp lệ.');clauses.push(`l.created_at>=datetime(?, '-7 hours')`);binds.push(from);}
        if(to){if(!/^\d{4}-\d{2}-\d{2}$/.test(to))return bad('Ngày kết thúc không hợp lệ.');clauses.push(`l.created_at<datetime(date(?, '+1 day'), '-7 hours')`);binds.push(to);}
        const {results}=await env.DB.prepare(`SELECT l.id,l.customer_id,l.user_id,u.display_name owner,c.team_id,t.name team,l.status,l.note,l.follow_up_at,l.created_at FROM call_logs l JOIN customers c ON c.id=l.customer_id LEFT JOIN users u ON u.id=l.user_id LEFT JOIN teams t ON t.id=c.team_id WHERE ${clauses.join(' AND ')} ORDER BY l.created_at DESC LIMIT 10000`).bind(...binds).all();
        return json({items:results,from:from||null,to:to||null});
      }
      if(url.pathname==='/api/calls' && request.method==='POST'){
        const {customer_id,status,note,follow_up}=await request.json();
        const normalizedStatus=normalizeStatus(status);
        if(normalizedStatus==='NEW') return bad('Hãy chọn kết quả cuộc gọi hợp lệ.');
        const c=await env.DB.prepare('SELECT id,assigned_user_id FROM customers WHERE id=?').bind(customer_id).first(); if(!c)return bad('Không tìm thấy khách.',404);
        if(session.role!=='sale') return bad('Chỉ nhân viên Sale được ghi nhận cuộc gọi.',403);
        if(c.assigned_user_id!==session.id)return bad('Không có quyền cập nhật khách này.',403);
        // V6.0: Mỗi lần bấm Lưu là một lượt gọi mới. Không ghi đè log cũ.
        // Dùng cùng một timestamp UTC cho call_logs và trạng thái hiện tại để lịch sử luôn nhất quán.
        const now=new Date().toISOString().slice(0,19).replace('T',' ');
        const callBatch=[
          env.DB.prepare('INSERT INTO call_logs(customer_id,user_id,status,note,follow_up_at,created_at) VALUES(?,?,?,?,?,?)').bind(customer_id,session.id,normalizedStatus,note||'',follow_up||null,now),
          env.DB.prepare("UPDATE customers SET status=?,note=?,follow_up_at=?,data_state='ARCHIVED',archived_at=?,assignment_deadline=NULL,updated_at=? WHERE id=?").bind(normalizedStatus,note||'',follow_up||null,now,now,customer_id),
          env.DB.prepare("UPDATE assignment_history SET completed_at=COALESCE(completed_at,?) WHERE id=(SELECT id FROM assignment_history WHERE customer_id=? AND user_id=? AND completed_at IS NULL AND returned_at IS NULL ORDER BY id DESC LIMIT 1)").bind(now,customer_id,session.id)
        ];
        // Chỉ thêm một lead_cases khi lần đầu khách đạt Y01/Y02; INSERT OR IGNORE tránh ghi lặp ở các lần gọi sau.
        if(normalizedStatus==='Y01'||normalizedStatus==='Y02') callBatch.push(env.DB.prepare('INSERT OR IGNORE INTO lead_cases(customer_id,source_call_status,created_by,created_at) VALUES(?,?,?,?)').bind(customer_id,normalizedStatus,session.id,now));
        const results=await env.DB.batch(callBatch);
        // Không ghi audit_logs cho từng cuộc gọi để tiết kiệm Rows written. call_logs chính là lịch sử bất biến.
        const callId=Number(results?.[0]?.meta?.last_row_id||0)||null;
        return json({ok:true,corrected:false,call_id:callId,call:{id:callId,customer_id:Number(customer_id),user_id:Number(session.id),status:normalizedStatus,note:note||'',follow_up_at:follow_up||null,created_at:now,data_state:'ARCHIVED',archived_at:now,assignment_deadline:null}});
      }
      // V6.3: KHTN và Báo cáo đầu ngày đã ngừng sử dụng. Giữ bảng cũ để bảo toàn dữ liệu lịch sử, nhưng khóa API cũ.
      if(url.pathname.startsWith('/api/khtn')||url.pathname.startsWith('/api/daily-reports')) return bad('Tính năng này đã được thay thế bằng Lead.',410);
      if(url.pathname==='/api/khtn/config' && request.method==='GET'){
        const config=await getKhtnConfig(env);
        return json({config});
      }
      if(url.pathname==='/api/khtn/config' && request.method==='PUT'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được cấu hình KHTN.',403);
        const body=await request.json();
        await ensureKhtnSchema(env);
        const config=sanitizeKhtnConfig(body.config||body);
        await env.DB.prepare(`INSERT INTO khtn_form_config(id,config_json,updated_by,updated_at) VALUES(1,?,?,datetime('now'))
          ON CONFLICT(id) DO UPDATE SET config_json=excluded.config_json,updated_by=excluded.updated_by,updated_at=datetime('now')`)
          .bind(JSON.stringify(config),session.id).run();
        await audit(env,session.id,'KHTN_CONFIG_UPDATE','khtn_config',1,{config});
        return json({ok:true,config});
      }
      if(url.pathname==='/api/khtn' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Nhân viên chỉ được nhập KHTN.',403);
        await ensureKhtnSchema(env);
        let where='1=1', binds=[];
        if(session.role==='teamlead'){where='k.team_id=?';binds=[session.team_id]}
        const {results}=await env.DB.prepare(`SELECT k.id,k.user_id,k.team_id,k.customer_name,k.phone,k.phone_normalized,k.birth_year,k.area,k.occupation,k.average_income,k.cccd,k.source,k.note,k.expected_login_date,k.custom_json,k.created_at,k.updated_at,
          u.display_name employee,u.username,t.name team,
          (SELECT COUNT(*) FROM khtn_entries d WHERE d.phone_normalized IS NOT NULL AND d.phone_normalized<>'' AND d.phone_normalized=k.phone_normalized) duplicate_phone_count
          FROM khtn_entries k JOIN users u ON u.id=k.user_id LEFT JOIN teams t ON t.id=k.team_id
          WHERE ${where} ORDER BY k.created_at DESC,k.id DESC LIMIT 20000`).bind(...binds).all();
        return json({items:(results||[]).map(x=>({...x,custom_fields:safeJsonObject(x.custom_json,{})}))});
      }
      if(url.pathname==='/api/khtn' && request.method==='POST'){
        if(session.role!=='sale') return bad('Chỉ nhân viên Sale được nhập báo cáo KHTN.',403);
        const body=await request.json(), config=await getKhtnConfig(env);
        const data={};
        for(const key of KHTN_FIELD_KEYS) data[key]=cleanText(body[key]);
        const custom=cleanKhtnCustom(body,config,{});
        for(const key of khtnActiveKeys(config)){
          const f=config.fields[key], value=KHTN_FIELD_KEYS.includes(key)?data[key]:custom[key];
          if(f?.required&&!cleanText(value)) return bad(`Thiếu thông tin: ${f.label}.`);
        }
        if(!data.customer_name||!data.phone||!data.source) return bad('Họ tên khách hàng, số điện thoại và nguồn KHTN là bắt buộc.');
        const phoneNorm=normalizePhone(data.phone);
        const duplicate=phoneNorm?await env.DB.prepare('SELECT COUNT(*) n FROM khtn_entries WHERE phone_normalized=?').bind(phoneNorm).first():null;
        const r=await env.DB.prepare(`INSERT INTO khtn_entries(user_id,team_id,customer_name,phone,phone_normalized,birth_year,area,occupation,average_income,cccd,source,note,expected_login_date,custom_json)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(session.id,session.team_id||null,data.customer_name,data.phone,phoneNorm||null,data.birth_year||null,data.area||null,data.occupation||null,data.average_income||null,data.cccd||null,data.source,data.note||null,data.expected_login_date||null,JSON.stringify(custom)).run();
        await audit(env,session.id,'KHTN_CREATE','khtn',r.meta?.last_row_id,{customer_name:data.customer_name,phone:data.phone,source:data.source,duplicate_phone:Number(duplicate?.n||0)>0});
        return json({ok:true,id:r.meta?.last_row_id,duplicate_phone:Number(duplicate?.n||0)>0});
      }
      const khtnMatch=url.pathname.match(/^\/api\/khtn\/(\d+)$/);
      if(khtnMatch && request.method==='PATCH'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Bạn không có quyền sửa KHTN.',403);
        await ensureKhtnSchema(env);
        const id=Number(khtnMatch[1]);
        const current=await env.DB.prepare('SELECT * FROM khtn_entries WHERE id=?').bind(id).first();
        if(!current) return bad('Không tìm thấy báo cáo KHTN.',404);
        if(session.role==='teamlead'&&Number(current.team_id)!==Number(session.team_id)) return bad('Teamlead chỉ được sửa KHTN của Team mình.',403);
        const body=await request.json(), config=await getKhtnConfig(env);
        let userId=body.user_id!==undefined?Number(body.user_id):Number(current.user_id), teamId=Number(current.team_id)||null;
        if(userId!==Number(current.user_id)){
          const target=await env.DB.prepare("SELECT id,team_id,role,active FROM users WHERE id=?").bind(userId).first();
          if(!target||!target.active||target.role!=='sale') return bad('Nhân viên KHTN không hợp lệ.');
          if(session.role==='teamlead'&&Number(target.team_id)!==Number(session.team_id)) return bad('Không thể chuyển KHTN sang Team khác.',403);
          teamId=target.team_id||null;
        }
        const data={};
        for(const key of KHTN_FIELD_KEYS) data[key]=body[key]===undefined?cleanText(current[key]):cleanText(body[key]);
        const custom=cleanKhtnCustom(body,config,current.custom_json);
        for(const key of khtnActiveKeys(config)){
          const f=config.fields[key], value=KHTN_FIELD_KEYS.includes(key)?data[key]:custom[key];
          if(f?.required&&!cleanText(value)) return bad(`Thiếu thông tin: ${f.label}.`);
        }
        if(!data.customer_name||!data.phone||!data.source) return bad('Họ tên khách hàng, số điện thoại và nguồn KHTN là bắt buộc.');
        await env.DB.prepare(`UPDATE khtn_entries SET user_id=?,team_id=?,customer_name=?,phone=?,phone_normalized=?,birth_year=?,area=?,occupation=?,average_income=?,cccd=?,source=?,note=?,expected_login_date=?,custom_json=?,updated_at=datetime('now') WHERE id=?`)
          .bind(userId,teamId,data.customer_name,data.phone,normalizePhone(data.phone)||null,data.birth_year||null,data.area||null,data.occupation||null,data.average_income||null,data.cccd||null,data.source,data.note||null,data.expected_login_date||null,JSON.stringify(custom),id).run();
        await audit(env,session.id,'KHTN_UPDATE','khtn',id,{user_id:userId,team_id:teamId,customer_name:data.customer_name,phone:data.phone,source:data.source});
        return json({ok:true});
      }
      // Admin/Teamlead có quyền xóa KHTN báo cáo sai, có kiểm soát quyền ở server.
      if(khtnMatch && request.method==='DELETE'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Bạn không có quyền xóa KHTN.',403);
        await ensureKhtnSchema(env);
        const id=Number(khtnMatch[1]);
        const current=await env.DB.prepare('SELECT id,user_id,team_id FROM khtn_entries WHERE id=?').bind(id).first();
        if(!current) return bad('KHTN đã bị xóa hoặc không tồn tại.',404);
        if(session.role==='teamlead'&&Number(current.team_id)!==Number(session.team_id)) return bad('Chỉ được xóa KHTN trong Team mình.',403);
        await env.DB.batch([
          env.DB.prepare('DELETE FROM khtn_entries WHERE id=?').bind(id),
          env.DB.prepare('INSERT INTO audit_logs(user_id,action,entity_type,entity_id,detail) VALUES(?,?,?,?,?)')
            .bind(session.id,'KHTN_DELETE','khtn',id,JSON.stringify({report_user_id:current.user_id,team_id:current.team_id}))
        ]);
        return json({ok:true});
      }
      // Báo cáo đầu ngày: 1 báo cáo / nhân viên / ngày, có nhiều app và nhiều lịch ký.
      if(url.pathname==='/api/daily-reports' && request.method==='GET'){
        const manager=['admin','sup','teamlead'].includes(session.role);
        let where='r.user_id=? AND r.report_date=?', binds=[session.id,new Date(Date.now()+7*3600*1000).toISOString().slice(0,10)];
        if(isManager(session)){where='1=1';binds=[];}
        if(session.role==='teamlead'){where='r.team_id=?';binds=[session.team_id];}
        const {results}=await env.DB.prepare(`SELECT r.id,r.user_id,r.team_id,r.report_date,r.login_apps_json,r.signings_json,r.created_at,r.updated_at,
          u.display_name employee,t.name team FROM daily_reports r JOIN users u ON u.id=r.user_id LEFT JOIN teams t ON t.id=r.team_id
          WHERE ${where} ORDER BY r.report_date DESC,r.id DESC LIMIT 10000`).bind(...binds).all();
        return json({items:(results||[]).map(x=>({id:x.id,user_id:x.user_id,team_id:x.team_id,report_date:x.report_date,
          login_apps:safeJsonArray(x.login_apps_json),signings:safeJsonArray(x.signings_json),created_at:x.created_at,updated_at:x.updated_at,
          employee:x.employee,team:x.team}))});
      }
      if(url.pathname==='/api/daily-reports' && request.method==='POST'){
        if(session.role!=='sale') return bad('Chỉ nhân viên Sale được gửi báo cáo đầu ngày.',403);
        const body=await request.json();
        const today=new Date(Date.now()+7*3600*1000).toISOString().slice(0,10);
        if(body.report_date && body.report_date!==today) return bad('Chỉ được gửi hoặc sửa báo cáo của ngày hôm nay.');
        if(!Array.isArray(body.login_apps)||!Array.isArray(body.signings)||body.login_apps.length>100||body.signings.length>100) return bad('Danh sách khách hàng không hợp lệ (tối đa 100 khách mỗi nhóm).');
        const logins=[];
        for(const v of body.login_apps){
          const name=cleanText(v?.customer_name).slice(0,150),cccd=cleanText(v?.cccd).replace(/\s/g,'');
          if(!name||!cccd) return bad('Mỗi app phải có Tên KH và CCCD.');
          if(!/^\d{9}$|^\d{12}$/.test(cccd)) return bad('CCCD/CMND của khách login phải có 9 hoặc 12 chữ số.');
          logins.push({customer_name:name,cccd});
        }
        const signs=[];
        for(const v of body.signings){
          const name=cleanText(v?.customer_name).slice(0,150),time=cleanText(v?.sign_time);
          const amount=Number(v?.expected_amount);
          if(!name||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)||!Number.isSafeInteger(amount)||amount<=0||amount>100000000000000)
            return bad('Mỗi lịch ký phải có Tên KH, giờ ký hợp lệ và số tiền dự kiến lớn hơn 0.');
          signs.push({customer_name:name,sign_time:time,expected_amount:amount});
        }
        await env.DB.prepare(`INSERT INTO daily_reports(user_id,team_id,report_date,login_apps_json,signings_json) VALUES(?,?,?,?,?)
          ON CONFLICT(user_id,report_date) DO UPDATE SET login_apps_json=excluded.login_apps_json,signings_json=excluded.signings_json,updated_at=datetime('now')`)
          .bind(session.id,session.team_id||null,today,JSON.stringify(logins),JSON.stringify(signs)).run();
        await audit(env,session.id,'DAILY_REPORT_SAVE','daily_report',null,{date:today,login_count:logins.length,sign_count:signs.length});
        return json({ok:true,report_date:today,login_apps:logins,signings:signs});
      }
      if(url.pathname==='/api/kpi-targets' && request.method==='GET'){
        let where="u.active=1 AND u.role='sale'", binds=[];
        if(session.role==='teamlead'){where+=' AND u.team_id=?';binds.push(session.team_id)}
        if(session.role==='sale'){where+=' AND u.id=?';binds.push(session.id)}
        const {results}=await env.DB.prepare(`SELECT u.id user_id,u.username,u.display_name,u.team_id,t.name team,
          COALESCE(k.calls_daily,50) calls_daily,COALESCE(k.processed_daily,50) processed_daily,
          COALESCE(k.connect_rate_target,50) connect_rate_target,COALESCE(k.y01_daily,5) y01_daily
          FROM users u LEFT JOIN teams t ON t.id=u.team_id LEFT JOIN kpi_targets k ON k.user_id=u.id
          WHERE ${where} ORDER BY t.id,u.display_name`).bind(...binds).all();
        return json({items:results});
      }
      if(url.pathname==='/api/kpi-targets/bulk' && request.method==='POST'){
        if(session.role==='sale') return bad('Sale không có quyền đặt KPI.',403);
        const body=await request.json();
        const ids=[...new Set((Array.isArray(body.user_ids)?body.user_ids:[]).map(Number).filter(x=>Number.isInteger(x)&&x>0))];
        if(!ids.length) return bad('Hãy chọn ít nhất 1 nhân viên.');
        if(ids.length>500) return bad('Mỗi lần chỉ áp KPI tối đa 500 nhân viên.');
        const calls=Math.max(0,Number(body.calls_daily)||0), y01=Math.max(0,Number(body.y01_daily)||0);
        let sql="SELECT id,team_id FROM users WHERE active=1 AND role='sale'", binds=[];
        if(session.role==='teamlead'){sql+=' AND team_id=?';binds.push(session.team_id)}
        const eligible=(await env.DB.prepare(sql).bind(...binds).all()).results;
        const allowed=new Set(eligible.map(x=>Number(x.id))), denied=ids.filter(id=>!allowed.has(id));
        if(denied.length) return bad('Có nhân viên không thuộc phạm vi bạn được phép đặt KPI.',403);
        const stmts=ids.map(userId=>env.DB.prepare(`INSERT INTO kpi_targets(user_id,calls_daily,connect_rate_target,y01_daily,updated_at)
          VALUES(?,?,50,?,datetime('now')) ON CONFLICT(user_id) DO UPDATE SET calls_daily=excluded.calls_daily,y01_daily=excluded.y01_daily,updated_at=datetime('now')`)
          .bind(userId,calls,y01));
        for(let i=0;i<stmts.length;i+=80) await env.DB.batch(stmts.slice(i,i+80));
        await audit(env,session.id,'KPI_BULK_SET','user',null,{user_ids:ids,calls_daily:calls,y01_daily:y01});
        return json({ok:true,updated:ids.length});
      }
      const kpiMatch=url.pathname.match(/^\/api\/kpi-targets\/(\d+)$/);
      if(kpiMatch && request.method==='PUT'){
        if(session.role==='sale') return bad('Sale không có quyền đặt KPI.',403);
        const userId=Number(kpiMatch[1]);
        const targetUser=await env.DB.prepare("SELECT id,team_id,role,active FROM users WHERE id=?").bind(userId).first();
        if(!targetUser||!targetUser.active||targetUser.role!=='sale') return bad('Không tìm thấy nhân viên Sale.',404);
        if(session.role==='teamlead' && targetUser.team_id!==session.team_id) return bad('Không có quyền đặt KPI cho Team khác.',403);
        const body=await request.json();
        const calls=Math.max(0,Number(body.calls_daily)||0), y01=Math.max(0,Number(body.y01_daily)||0);
        const prior=await env.DB.prepare('SELECT calls_daily,y01_daily FROM kpi_targets WHERE user_id=?').bind(userId).first();
        await env.DB.prepare(`INSERT INTO kpi_targets(user_id,calls_daily,connect_rate_target,y01_daily,updated_at)
          VALUES(?,?,50,?,datetime('now')) ON CONFLICT(user_id) DO UPDATE SET calls_daily=excluded.calls_daily,y01_daily=excluded.y01_daily,updated_at=datetime('now')`)
          .bind(userId,calls,y01).run();
        if(prior){
          await auditWithUndo(env,session,'KPI_SET','user',userId,{calls_daily:calls,y01_daily:y01},pickedUndoValues(prior,['calls_daily','y01_daily']),{calls_daily:calls,y01_daily:y01});
        }else{
          // New KPI row has no earlier record. Never guess a previous target.
          await audit(env,session.id,'KPI_SET','user',userId,{calls_daily:calls,y01_daily:y01,first_set:true});
        }
        return json({ok:true});
      }
      if(url.pathname==='/api/bulk-jobs/distribute' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được tạo job chia Data.',403);
        try{
          const body=await request.json();
          const created=await createBulkDistributionJob(env,session,body);
          return json({ok:true,...created});
        }catch(e){return bad(e?.message||'Không thể tạo job chia Data.');}
      }
      if(url.pathname==='/api/bulk-jobs/active' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xem job.',403);
        await ensureBulkJobSchema(env);
        const type=cleanText(url.searchParams.get('type')||'WAREHOUSE_DISTRIBUTE');
        const {results}=await env.DB.prepare(`SELECT * FROM bulk_jobs WHERE created_by=? AND job_type=? AND status IN ('RUNNING','PAUSED') ORDER BY id DESC LIMIT 5`).bind(session.id,type).all();
        return json({items:(results||[]).map(bulkJobPublic)});
      }
      const bulkJobMatch=url.pathname.match(/^\/api\/bulk-jobs\/(\d+)$/);
      if(bulkJobMatch && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xem job.',403);
        await ensureBulkJobSchema(env);
        const id=Number(bulkJobMatch[1]);
        const row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=? AND created_by=?').bind(id,session.id).first();
        if(!row) return bad('Không tìm thấy job.',404);
        return json({job:bulkJobPublic(row)});
      }
      const bulkProcessMatch=url.pathname.match(/^\/api\/bulk-jobs\/(\d+)\/process$/);
      if(bulkProcessMatch && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền xử lý job.',403);
        await ensureBulkJobSchema(env);
        const id=Number(bulkProcessMatch[1]);
        const own=await env.DB.prepare('SELECT id FROM bulk_jobs WHERE id=? AND created_by=?').bind(id,session.id).first();
        if(!own) return bad('Không tìm thấy job.',404);
        const body=await request.json().catch(()=>({}));
        const result=await processBulkDistributionJob(env,id,Math.min(600,Math.max(30,Number(body.max_items)||300)));
        return json({ok:true,...result});
      }
      const bulkCancelMatch=url.pathname.match(/^\/api\/bulk-jobs\/(\d+)\/cancel$/);
      if(bulkCancelMatch && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Không có quyền hủy job.',403);
        await ensureBulkJobSchema(env);
        const id=Number(bulkCancelMatch[1]);
        const r=await env.DB.prepare(`UPDATE bulk_jobs SET status='CANCELLED',locked_until=NULL,updated_at=datetime('now'),completed_at=datetime('now') WHERE id=? AND created_by=? AND status IN ('RUNNING','PAUSED')`).bind(id,session.id).run();
        if(!Number(r.meta?.changes||0)) return bad('Job không còn chạy hoặc không tồn tại.',404);
        await audit(env,session.id,'BULK_JOB_CANCEL','bulk_job',id,{});
        const row=await env.DB.prepare('SELECT * FROM bulk_jobs WHERE id=?').bind(id).first();
        return json({ok:true,job:bulkJobPublic(row)});
      }
      // V10.36: actual D1 stock for a chosen source Team; only unassigned pool can be distributed.
      if(url.pathname==='/api/warehouse/source-summary' && request.method==='GET'){
        if(!['admin','sup','teamlead'].includes(session.role))return bad('Không có quyền xem tồn Kho.',403);
        const rawTeam=url.searchParams.get('team_id')||'';const teamId=rawTeam==='common'?0:Number(rawTeam);
        if(!Number.isSafeInteger(teamId)||teamId<0)return bad('Hãy chọn Team nguồn.',400);
        if(session.role==='teamlead'&&Number(session.team_id)!==teamId)return bad('Chỉ xem Kho Team mình.',403);
        const team=teamId?await env.DB.prepare('SELECT id,name FROM teams WHERE id=? AND active=1').bind(teamId).first():{id:null,name:'Kho chung Admin'};
        if(!team)return bad('Không tìm thấy Kho Team.',404);
        const summary=await env.DB.prepare(`SELECT COUNT(*) available,
          SUM(CASE WHEN NOT EXISTS (SELECT 1 FROM call_logs l WHERE l.customer_id=c.id) THEN 1 ELSE 0 END) never_called,
          SUM(CASE WHEN EXISTS (SELECT 1 FROM call_logs l WHERE l.customer_id=c.id) THEN 1 ELSE 0 END) previously_called
          FROM customers c WHERE ${teamId?'c.team_id=?':'c.team_id IS NULL'} AND c.data_state='POOL'`).bind(...(teamId?[teamId]:[])).first();
        const users=teamId?(await env.DB.prepare("SELECT id,display_name,staff_type FROM users WHERE team_id=? AND role='sale' AND active=1 ORDER BY display_name").bind(teamId).all()).results||[]:[];
        return json({team,available:Number(summary?.available||0),never_called:Number(summary?.never_called||0),previously_called:Number(summary?.previously_called||0),users});
      }
      if(url.pathname==='/api/warehouse/distribute' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được chia Data từ Kho.',403);
        const body=await request.json();
        // V8.6: Teamlead chỉ quét Data hết hạn trong Team mình; tránh quét toàn CRM mỗi lần chia.
        await returnExpiredAssignments(env,session.role==='teamlead'?Number(session.team_id):null);
        const mode=cleanText(body.mode||'all');
        let sourceTeam=null;
        if(body.source_team_id!==undefined){
          const raw=String(body.source_team_id);
          if(raw==='common')sourceTeam='common';
          else if(/^\d+$/.test(raw)&&Number(raw)>0){
            const team=await env.DB.prepare('SELECT id FROM teams WHERE id=? AND active=1').bind(Number(raw)).first();
            if(!team)return bad('Kho nguồn không tồn tại.',400);
            sourceTeam=Number(raw);
          }else return bad('Hãy chọn Kho nguồn hợp lệ.',400);
          if(session.role==='teamlead'&&sourceTeam!==Number(session.team_id))return bad('Team Leader chỉ được lấy Kho của Team mình.',403);
        }
        const requestedLimit=Math.max(0,Number(body.limit)||0);
        // Mỗi request xử lý tối đa 100 Data; client sẽ tự chia thành nhiều request nhỏ.
        const limit=Math.min(100,requestedLimit||100);
        const deadline=deadlineFromDays(body.deadline_days); const categoryId=body.category_id?Number(body.category_id):null; const distributionOffset=Math.max(0,Number(body.distribution_offset)||0);
        let recipients=[];
        if(mode==='all'){
          let sql="SELECT id,team_id,display_name FROM users WHERE active=1 AND role='sale' AND team_id IS NOT NULL"; const binds=[];
          if(session.role==='teamlead'){sql+=' AND team_id=?';binds.push(session.team_id)}
          sql+=' ORDER BY team_id,id'; recipients=(await env.DB.prepare(sql).bind(...binds).all()).results;
        }else if(mode==='team'){
          let teamId=Number(body.team_id); if(session.role==='teamlead') teamId=session.team_id;
          if(!teamId) return bad('Hãy chọn Team.');
          recipients=(await env.DB.prepare("SELECT id,team_id,display_name FROM users WHERE active=1 AND role='sale' AND team_id=? ORDER BY id").bind(teamId).all()).results;
        }else if(mode==='user'){
          const userId=Number(body.user_id); const u=await env.DB.prepare("SELECT id,team_id,display_name FROM users WHERE id=? AND active=1 AND role='sale'").bind(userId).first();
          if(!u) return bad('Không tìm thấy nhân viên Sale.');
          if(session.role==='teamlead' && Number(u.team_id)!==Number(session.team_id)) return bad('Không thể chia Data cho Team khác.',403);
          recipients=[u];
        }else return bad('Cách chia Data không hợp lệ.');
        if(!recipients.length) return bad('Không có nhân viên Sale để nhận Data.');
        if(sourceTeam!=='common'&&sourceTeam!==null&&recipients.some(u=>Number(u.team_id)!==sourceTeam))return bad('Kho Team chỉ được chia cho người cùng Team.',403);
        let poolSql="SELECT id,team_id,data_category_id,assignment_round,last_assigned_user_id FROM customers WHERE data_state='POOL'"; const poolBinds=[];
        if(sourceTeam!==null){
          if(sourceTeam==='common')poolSql+=' AND team_id IS NULL';
          else{poolSql+=' AND team_id=?';poolBinds.push(sourceTeam);}
        }else if(session.role==='teamlead'){
          poolSql+=' AND team_id=?';poolBinds.push(session.team_id);
        }else if(mode==='all'){
          // Chia toàn hệ thống chỉ dùng Kho chung Admin, không hút Data ra khỏi Kho riêng của Teamlead.
          poolSql+=' AND team_id IS NULL';
        }else if(mode==='team'){
          // Admin chủ động chia cho Team: dùng Kho chung + đúng Kho của Team được chọn.
          poolSql+=' AND (team_id IS NULL OR team_id=?)';poolBinds.push(Number(body.team_id));
        }else if(mode==='user'){
          // Admin gán cho một Sale: chỉ lấy Kho chung + Kho của Team Sale đó, không đụng Kho Team khác.
          poolSql+=' AND (team_id IS NULL OR team_id=?)';poolBinds.push(Number(recipients[0].team_id));
        }
        if(categoryId){poolSql+=' AND data_category_id=?';poolBinds.push(categoryId)}
        poolSql+=' ORDER BY id LIMIT '+limit;
        const pool=(await env.DB.prepare(poolSql).bind(...poolBinds).all()).results;
        if(!pool.length) return json({ok:true,updated:0,recipients:recipients.length});
        const stmts=[],assignments=[];
        for(let i=0;i<pool.length;i++){
          const row=pool[i]; let choices=recipients;
          if(row.last_assigned_user_id && recipients.length>1) choices=recipients.filter(x=>Number(x.id)!==Number(row.last_assigned_user_id));
          const u=choices[(i+distributionOffset)%choices.length]||recipients[(i+distributionOffset)%recipients.length]; const round=Number(row.assignment_round||0)+1;
          stmts.push(env.DB.prepare("UPDATE customers SET team_id=?,assigned_user_id=?,last_assigned_user_id=NULL,data_state='ASSIGNED',status='NEW',archived_at=NULL,follow_up_at=NULL,assignment_deadline=?,assignment_round=?,updated_at=datetime('now') WHERE id=?").bind(u.team_id,u.id,deadline,round,row.id));
          stmts.push(env.DB.prepare("INSERT INTO assignment_history(customer_id,user_id,team_id,category_id,round_no,deadline_at) VALUES(?,?,?,?,?,?)").bind(row.id,u.id,u.team_id,row.data_category_id||null,round,deadline));
          assignments.push({customer_id:row.id,user_id:u.id,team_id:u.team_id,round,deadline});
        }
        for(let i=0;i<stmts.length;i+=80) await env.DB.batch(stmts.slice(i,i+80));
        await audit(env,session.id,'WAREHOUSE_DISTRIBUTE','customer',null,{mode,updated:pool.length,recipients:recipients.map(x=>x.id),deadline_days:Number(body.deadline_days)||0,category_id:categoryId});
        return json({ok:true,updated:pool.length,recipients:recipients.length,deadline,assignments,has_more:pool.length===limit});
      }
      if(url.pathname==='/api/warehouse/recall-user' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được thu hồi Data.',403);
        const body=await request.json();
        const sourceId=Number(body.user_id),status=cleanText(body.status||'ALL').toUpperCase();
        const limit=Math.min(500,Math.max(1,Number(body.limit)||500));
        if(!Number.isSafeInteger(sourceId)||sourceId<1) return bad('Nhân viên cần thu hồi không hợp lệ.');
        if(!['ALL','NEW','Y01','Y02','Y03','Y04','Y05','Y06','N01','N02','N03','N04'].includes(status)) return bad('Trạng thái Data không hợp lệ.');
        const source=await env.DB.prepare("SELECT id,team_id,display_name FROM users WHERE id=? AND role='sale'").bind(sourceId).first();
        if(!source||!source.team_id) return bad('Không tìm thấy nhân viên Sale hoặc nhân viên chưa thuộc Team.',404);
        if(session.role==='teamlead'&&Number(source.team_id)!==Number(session.team_id)) return bad('Teamlead chỉ được thu hồi Data của nhân viên trong Team mình.',403);
        const clauses=["c.assigned_user_id=?","c.data_state IN ('ASSIGNED','ARCHIVED')"],binds=[sourceId];
        if(status!=='ALL'){clauses.push('c.status=?');binds.push(status);}
        if(session.role==='teamlead'){clauses.push('c.team_id=?');binds.push(Number(session.team_id));}
        const rows=(await env.DB.prepare(`SELECT c.id FROM customers c WHERE ${clauses.join(' AND ')} ORDER BY c.updated_at ASC,c.id ASC LIMIT ?`).bind(...binds,limit).all()).results;
        if(!rows.length) return json({ok:true,updated:0,customer_ids:[],source:source.display_name,team_id:source.team_id});
        const chosen=rows.map(x=>Number(x.id));let updated=0;
        for(let offset=0;offset<chosen.length;offset+=50){
          const batch=chosen.slice(offset,offset+50),marks=batch.map(()=>'?').join(',');
          const result=await env.DB.batch([
            env.DB.prepare(`UPDATE assignment_history SET returned_at=datetime('now'),return_reason='MANUAL_RECALL'
              WHERE id IN (
                SELECT MAX(id) FROM assignment_history
                WHERE user_id=? AND customer_id IN (${marks}) AND returned_at IS NULL AND completed_at IS NULL
                GROUP BY customer_id
              )`).bind(sourceId,...batch),
            env.DB.prepare(`UPDATE customers SET
              last_assigned_user_id=assigned_user_id,
              assigned_user_id=NULL,
              data_state='POOL',
              status='NEW',
              assignment_deadline=NULL,
              archived_at=NULL,
              follow_up_at=NULL,
              updated_at=datetime('now')
              WHERE assigned_user_id=? AND id IN (${marks})`).bind(sourceId,...batch)
          ]);
          updated+=Number(result[1]?.meta?.changes??batch.length);
        }
        await audit(env,session.id,'DATA_RECALL','customer',null,{source_user_id:sourceId,team_id:source.team_id,status,count:updated,customer_ids:chosen,preserved_call_history:true,target:'TEAM_POOL'});
        return json({ok:true,updated,customer_ids:chosen,source:source.display_name,team_id:source.team_id,status});
      }
      if(url.pathname==='/api/warehouse/transfer' && request.method==='POST'){
        // Chuyển trực tiếp Data của một Sale sang Sale khác theo trạng thái hiện tại.
        // Giữ nguyên customer, call_logs, trạng thái và phân loại; tạo vòng giao mới.
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được chuyển Data.',403);
        const body=await request.json();
        const sourceId=Number(body.from_user_id), targetId=Number(body.to_user_id);
        if(!Number.isSafeInteger(sourceId)||sourceId<1||!Number.isSafeInteger(targetId)||targetId<1) return bad('Hãy chọn nhân viên nguồn và nhận.');
        if(sourceId===targetId) return bad('Nhân viên nhận phải khác nhân viên nguồn.');
        const status=cleanText(body.status).toUpperCase()||'ALL';
        if(status!=='ALL'&&!/^(NEW|Y0[1-6]|N0[1-4])$/.test(status)) return bad('Hãy chọn đúng trạng thái cuộc gọi.');
        const limit=Number(body.limit??0), days=Number(body.deadline_days??7);
        if(!Number.isSafeInteger(limit)||limit<0||limit>500) return bad('Số lượng phải từ 0 đến 500 (0 = toàn bộ, tối đa 500).');
        if(!Number.isSafeInteger(days)||days<0||days>365) return bad('Thời hạn phải từ 0 đến 365 ngày.');
        const users=await env.DB.prepare("SELECT id,team_id,display_name FROM users WHERE active=1 AND role='sale' AND id IN (?,?)").bind(sourceId,targetId).all();
        const from=users.results.find(x=>Number(x.id)===sourceId), to=users.results.find(x=>Number(x.id)===targetId);
        if(!from||!to||!from.team_id||!to.team_id) return bad('Nhân viên nguồn hoặc người nhận không hợp lệ.',404);
        // Phân quyền chuyển Data:
        // - Admin: được chuyển giữa mọi nhân viên, kể cả khác Team. Hồ sơ hiện tại chuyển sang Team của người nhận; lịch sử cũ vẫn giữ nguyên.
        // - Team Leader: chỉ được chuyển giữa các Sale thuộc đúng Team của mình.
        if(session.role==='teamlead' && (Number(from.team_id)!==Number(session.team_id)||Number(to.team_id)!==Number(session.team_id)))
          return bad('Teamlead chỉ được chuyển Data trong Team mình.',403);
        const pickSelected=body.mode==='selected';
        let ids=[];
        if(pickSelected){
          if(!Array.isArray(body.customer_ids)) return bad('Thiếu danh sách Data đã chọn.');
          ids=[...new Set(body.customer_ids.map(Number))];
          if(!ids.length||ids.length>500||ids.some(x=>!Number.isSafeInteger(x)||x<1)) return bad('Hãy chọn từ 1 đến 500 Data hợp lệ.');
        }else if(body.mode && body.mode!=='filtered') return bad('Chế độ chuyển Data không hợp lệ.');
        const clauses=["c.assigned_user_id=?","c.data_state IN ('ASSIGNED','ARCHIVED')"], binds=[sourceId];
        if(status!=='ALL'){clauses.push('c.status=?');binds.push(status);}
        if(session.role==='teamlead'){clauses.push('c.team_id=?');binds.push(session.team_id);}
        if(pickSelected){clauses.push(`c.id IN (${ids.map(()=>'?').join(',')})`);binds.push(...ids);}
        // Select at most 501 so an unbounded transfer cannot silently move too much Data.
        const pickSql=`SELECT c.id FROM customers c WHERE ${clauses.join(' AND ')} ORDER BY c.updated_at ASC,c.id ASC LIMIT ?`;
        const {results}=await env.DB.prepare(pickSql).bind(...binds,limit||501).all();
        if(!results.length) return bad('Không còn Data phù hợp của nhân viên nguồn. Dữ liệu có thể đã được chuyển hoặc thay đổi trạng thái.');
        if(results.length>500) return bad('Có hơn 500 Data phù hợp. Hãy nhập số lượng tối đa 500 mỗi lần.');
        const chosen=results.map(x=>Number(x.id)),deadline=deadlineFromDays(days);
        let updated=0;
        for(let offset=0;offset<chosen.length;offset+=80){
          const batch=chosen.slice(offset,offset+80), marks=batch.map(()=>'?').join(',');
          const batchResult=await env.DB.batch([
            env.DB.prepare(`UPDATE assignment_history SET returned_at=datetime('now'),return_reason='TRANSFER'
              WHERE user_id=? AND completed_at IS NULL AND returned_at IS NULL AND customer_id IN (${marks})`).bind(sourceId,...batch),
            env.DB.prepare(`UPDATE customers SET last_assigned_user_id=?,assigned_user_id=?,team_id=?,
              data_state='ASSIGNED',assignment_deadline=?,assignment_round=COALESCE(assignment_round,0)+1,
              archived_at=NULL,follow_up_at=NULL,updated_at=datetime('now')
              WHERE assigned_user_id=? AND data_state IN ('ASSIGNED','ARCHIVED') AND id IN (${marks})`)
              .bind(sourceId,targetId,to.team_id,deadline,sourceId,...batch),
            env.DB.prepare(`INSERT INTO assignment_history(customer_id,user_id,team_id,category_id,round_no,deadline_at)
              SELECT id,?,?,data_category_id,assignment_round,? FROM customers
              WHERE assigned_user_id=? AND last_assigned_user_id=? AND data_state='ASSIGNED' AND id IN (${marks})
                AND NOT EXISTS (SELECT 1 FROM assignment_history h WHERE h.customer_id=customers.id
                  AND h.user_id=? AND h.round_no=customers.assignment_round)`)
              .bind(targetId,to.team_id,deadline,targetId,sourceId,...batch,targetId)
          ]);
          updated+=Number(batchResult[1]?.meta?.changes??batch.length);
        }
        await audit(env,session.id,'WAREHOUSE_TRANSFER','customer',null,{
          from_user_id:sourceId,to_user_id:targetId,status,count:updated,deadline_days:days,
          customer_ids:chosen,preserved_call_history:true
        });
        return json({ok:true,updated,source:from.display_name,target:to.display_name,status,deadline,customer_ids:chosen,target_user_id:targetId,target_team_id:to.team_id});
      }
      if(url.pathname==='/api/warehouse/recycle' && request.method==='POST'){
        if(!['admin','sup','teamlead'].includes(session.role)) return bad('Chỉ Admin hoặc Teamlead được random lại Data đã gọi.',403);
        const body=await request.json(); const limit=Math.min(10000,Math.max(0,Number(body.limit)||0)); const deadline=deadlineFromDays(body.deadline_days);
        const categoryId=body.category_id?Number(body.category_id):null;
        const teamId=session.role==='teamlead'?Number(session.team_id):(body.team_id?Number(body.team_id):null);
        // V6.6: random theo phân loại chỉ khi toàn bộ Data trong phạm vi đã gọi xong.
        // Tránh vô tình mở vòng mới trong lúc một phần Data vẫn còn ở Kho/đang giao.
        if(categoryId){
          let pendingSql=`SELECT COUNT(*) n FROM customers WHERE data_category_id=? AND data_state<>'ARCHIVED'`;
          const pendingBind=[categoryId];
          if(teamId){pendingSql+=' AND team_id=?';pendingBind.push(teamId)}
          const pending=await env.DB.prepare(pendingSql).bind(...pendingBind).first();
          if(Number(pending?.n||0)>0) return bad(`Phân loại này còn ${Number(pending.n)} Data chưa gọi xong. Chỉ random khi toàn bộ Data của phân loại đã hoàn tất.`,400);
        }
        let rsql="SELECT id,team_id FROM users WHERE active=1 AND role='sale' AND team_id IS NOT NULL"; const rbind=[];
        if(teamId){rsql+=' AND team_id=?';rbind.push(teamId)} rsql+=' ORDER BY team_id,id';
        const recipients=(await env.DB.prepare(rsql).bind(...rbind).all()).results; if(!recipients.length) return bad('Không có Sale phù hợp để nhận Data.');
        let csql=`SELECT c.id,c.assigned_user_id,c.team_id,c.data_category_id,c.assignment_round
          FROM customers c
          WHERE c.data_state='ARCHIVED'
            AND NOT EXISTS (SELECT 1 FROM lead_status_history h WHERE h.customer_id=c.id AND h.status='SIGNED')`;
        const cbind=[];
        if(categoryId){csql+=' AND c.data_category_id=?';cbind.push(categoryId)}
        if(teamId){csql+=' AND c.team_id=?';cbind.push(teamId)}
        csql+=' ORDER BY c.archived_at ASC,c.id ASC'; if(limit>0)csql+=` LIMIT ${limit}`;
        const rows=(await env.DB.prepare(csql).bind(...cbind).all()).results;
        if(!rows.length) return json({ok:true,updated:0,recipients:recipients.length,excluded_signed:true});
        const stmts=[];
        for(const row of rows){
          let choices=recipients.filter(x=>Number(x.id)!==Number(row.assigned_user_id)); if(!choices.length) choices=recipients;
          const u=randomPick(choices); const round=Number(row.assignment_round||0)+1;
          stmts.push(env.DB.prepare("UPDATE customers SET last_assigned_user_id=assigned_user_id,team_id=?,assigned_user_id=?,data_state='ASSIGNED',status='NEW',archived_at=NULL,follow_up_at=NULL,assignment_deadline=?,assignment_round=?,updated_at=datetime('now') WHERE id=?").bind(u.team_id,u.id,deadline,round,row.id));
          stmts.push(env.DB.prepare("INSERT INTO assignment_history(customer_id,user_id,team_id,category_id,round_no,deadline_at) VALUES(?,?,?,?,?,?)").bind(row.id,u.id,u.team_id,row.data_category_id||null,round,deadline));
          assignments.push({customer_id:row.id,user_id:u.id,team_id:u.team_id,round,deadline});
        }
        for(let i=0;i<stmts.length;i+=80) await env.DB.batch(stmts.slice(i,i+80));
        await audit(env,session.id,'WAREHOUSE_RECYCLE','customer',null,{updated:rows.length,category_id:categoryId,team_id:teamId,deadline_days:Number(body.deadline_days)||0,excluded_signed_leads:true});
        return json({ok:true,updated:rows.length,recipients:recipients.length,deadline,excluded_signed:true});
      }
      if(url.pathname==='/api/data/reset' && request.method==='POST'){
        if(!requireAdmin(session)) return bad('Chỉ Admin được thu hồi Data.',403);
        const body=await request.json();
        if(cleanText(body.confirm)!=='THU HOI DATA') return bad('Cần nhập đúng THU HOI DATA để xác nhận.');
        const teamId=body.team_id?Number(body.team_id):null;
        if(teamId && (!Number.isSafeInteger(teamId)||teamId<1)) return bad('Team không hợp lệ.');
        // Tuyệt đối không DELETE customers/call_logs/assignment_history. Chỉ thu hồi phân công
        // của các khách đã từng được giao; Data chưa giao và các bảng thống kê giữ nguyên.
        const condition="(assigned_user_id IS NOT NULL OR data_state IN ('ASSIGNED','ARCHIVED'))";
        const where=condition+(teamId?' AND team_id=?':'');
        const bind=teamId?[teamId]:[];
        const countRow=await env.DB.prepare(`SELECT COUNT(*) n FROM customers WHERE ${where}`).bind(...bind).first();
        const n=Number(countRow?.n||0);
        if(!n) return json({ok:true,recalled:0,team_id:teamId});
        await env.DB.batch([
          env.DB.prepare(`UPDATE assignment_history SET returned_at=datetime('now'),return_reason='ADMIN_RECALL'
            WHERE completed_at IS NULL AND returned_at IS NULL AND customer_id IN (SELECT id FROM customers WHERE ${where})`).bind(...bind),
          env.DB.prepare(`UPDATE customers SET
            last_assigned_user_id=COALESCE(assigned_user_id,last_assigned_user_id),
            assigned_user_id=NULL,data_state='POOL',assignment_deadline=NULL,archived_at=NULL,updated_at=datetime('now')
            WHERE ${where}`).bind(...bind)
        ]);
        await audit(env,session.id,'DATA_RECALL','customer',null,{team_id:teamId,recalled:n,preserved_customers:true,preserved_call_logs:true});
        return json({ok:true,recalled:n,team_id:teamId});
      }
      if(url.pathname==='/api/distribute' && request.method==='POST'){
        if(!requireAdmin(session))return bad('Chỉ Admin được chia Data.',403);
        let teamRows=(await env.DB.prepare('SELECT id FROM teams WHERE active=1 ORDER BY id').all()).results;
        if(session.role==='teamlead') teamRows=teamRows.filter(x=>x.id===session.team_id);
        if(!teamRows.length)return bad('Chưa có Team hoạt động.');
        const unassigned=(await env.DB.prepare(session.role==='teamlead'?'SELECT id FROM customers WHERE team_id=? AND assigned_user_id IS NULL ORDER BY id LIMIT 5000':'SELECT id FROM customers WHERE team_id IS NULL ORDER BY id LIMIT 5000').bind(...(session.role==='teamlead'?[session.team_id]:[])).all()).results;
        const stmts=[];
        if(session.role==='teamlead'){
          const sales=(await env.DB.prepare("SELECT id FROM users WHERE active=1 AND role='sale' AND team_id=? ORDER BY id").bind(session.team_id).all()).results;
          if(!sales.length) return bad('Team chưa có Sale để chia Data.');
          for(let i=0;i<unassigned.length;i++) stmts.push(env.DB.prepare("UPDATE customers SET assigned_user_id=?,updated_at=datetime('now') WHERE id=?").bind(sales[i%sales.length].id,unassigned[i].id));
        }else{
          for(let i=0;i<unassigned.length;i++) stmts.push(env.DB.prepare("UPDATE customers SET team_id=?,updated_at=datetime('now') WHERE id=?").bind(teamRows[i%teamRows.length].id,unassigned[i].id));
        }
        for(let i=0;i<stmts.length;i+=80) await env.DB.batch(stmts.slice(i,i+80));
        await audit(env,session.id,'DATA_DISTRIBUTE','customer',null,{updated:unassigned.length,role:session.role});
        return json({ok:true,updated:unassigned.length});
      }
      return bad('API không tồn tại.',404);
    }catch(e){return bad(e?.message||'Lỗi hệ thống.',500)}
  },
  async scheduled(controller, env, ctx){
    ctx.waitUntil((async()=>{
      const minute=new Date(controller.scheduledTime||Date.now()).getUTCMinutes();
      if(minute===0){
        await returnExpiredAssignments(env);
        await ensureAuditUndoSchema(env);
        // Keep immutable audit rows. Only recovery snapshots are permanently removed.
        await env.DB.prepare("DELETE FROM audit_undo WHERE expires_at<=datetime('now')").run();
      }
      await processPendingBulkJobs(env,3,1000);
      await processLoanCareReminders(env);
    })());
  }
};
