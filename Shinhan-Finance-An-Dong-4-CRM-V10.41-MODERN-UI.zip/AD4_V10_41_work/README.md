# Shinhan Finance – An Đông 4 CRM V10.41

Bản V10.41 là **đợt chuẩn hóa giao diện Modern SaaS CRM** trên mã nguồn V10.40 hiện tại. Backend Cloudflare Worker, API, D1 schema, đăng nhập và phạm vi phân quyền **không bị thay đổi**.

## Kiến trúc đã xác minh

- Frontend: HTML + CSS + JavaScript thuần, không dùng framework UI bên thứ ba.
- Backend: Cloudflare Workers (`src/index.js`).
- Database: Cloudflare D1, binding `DB`.
- Static assets/PWA: `public/`, Service Worker và manifest.
- Routing frontend dùng `navigate()` và renderer theo page ID; quyền truy cập được lọc bằng `allowedPagesForRole()` và tiếp tục được backend kiểm tra phạm vi dữ liệu.

## Thay đổi V10.41

- Thêm design system thống nhất: navy/blue, màu trạng thái, border, shadow, radius, typography, focus state, button/input/table/modal.
- Tái cấu trúc sidebar theo **route thật đang tồn tại**, không tạo route giả: **Tổng quan / Khách hàng / Telesales / Quản lý đội ngũ / Hệ thống**.
- Sidebar có accordion và chế độ thu gọn icon-only trên desktop; giữ menu mobile hiện hành.
- Header được làm gọn hơn, giữ nguyên tìm kiếm, khoảng ngày, trạng thái D1, thông báo và menu tài khoản.
- Chuẩn hóa card, toolbar, bảng, modal, empty state và form trên toàn bộ hệ thống.
- Dashboard Quản lý khách hàng được giữ nguyên logic APP/Loan/Volume, drill-down Team/nhân viên và phân quyền V10.40 nhưng được đồng bộ phong cách mới.
- Follow-up/Lead/App Login/CSKH/KPI/Kho/Nhân sự nhận giao diện thống nhất hơn mà không đổi persistence hoặc API contract.
- Tối ưu responsive desktop/tablet/mobile và trạng thái focus/hover.
- Service Worker cache nâng lên V10.41 để nhận asset mới.

## Những mục không tự tạo

Tài liệu thiết kế đề xuất một số mục như **Công việc hôm nay**, **Đánh giá điều kiện vay** hoặc **Cấu hình hệ thống**. V10.41 không tạo các route/trang giả cho những mục chưa xác minh có backend nghiệp vụ tương ứng. Đây là chủ đích để không nhầm giao diện demo với tính năng production.

## Deploy production

1. Giải nén ZIP ra thư mục mới.
2. Chạy `CAP_NHAT_WEB_THAT.cmd` trên máy đã đăng nhập Cloudflare.
3. Script yêu cầu `YES`, sao lưu D1 trước, sau đó mới yêu cầu `DEPLOY`.
4. Sau deploy, nhấn Ctrl+F5.

**Không chạy lại `wrangler d1 migrations apply ... --remote`** trên D1 production hiện tại vì lịch sử trước đó đã báo migration `0019` trùng cột `has_prior_shinhan`. V10.41 không có migration mới.

## Kiểm thử V10.41

- `node --check`: app.js, v1038.js, v1039.js, v1040.js, v1041.js và backend `src/index.js`.
- Chrome headless: Admin → Team → nhân viên → quay lại; APP/Loan detail; Sales chỉ dữ liệu cá nhân; Lead/Follow-up không có tab Team ngang; wheel scroll ở bảng hiệu suất; sidebar mới render theo quyền.
- Backend, `wrangler.jsonc` và toàn bộ thư mục `migrations/` được đối chiếu với V10.40 và giữ nguyên.
- Chưa tự deploy lên production.

---

## Lịch sử V10.40 trở về trước

# Shinhan Finance – An Đông 4 CRM V10.40

Phiên bản tiếp nối V10.38, giữ nguyên các module hiện có và kết nối D1 hiện hành. Bản này tập trung tối ưu giao diện **Dashboard Quản lý khách hàng** và các ô **Follow-up**, không chỉnh sửa schema hay migration.

## Điểm mới

- Bỏ các tab Team nằm ngang trong Dashboard Quản lý khách hàng. Bộ lọc Team ở góc phải vẫn được giữ cho Admin/Sup. Bảng hiệu suất Team vẫn có **Xem Team →** để mở Dashboard theo đúng Team.
- Bỏ bảng **Kết quả theo nhân viên** trùng lặp. Thay bằng bảng xếp hạng doanh số tinh gọn với các cột riêng **Hạng / Nhân viên / Vai trò / Team / APP / Loan / Doanh số** và phân biệt Top 1–3 khi có doanh số.
- Dashboard được sắp xếp: **Tổng doanh số** → **APP và Loan** → **Hiệu suất đội ngũ** → **So sánh tháng trước** → **Xếp hạng nhân viên**.
- Admin/Sup: chỉ xem các Teams thuộc phạm vi đã chọn; có thể drill-down từ bảng hiệu suất. Teamlead: chỉ Team mình, vẫn thấy hiệu suất Team và bảng xếp hạng Sales/Freelancer. Sales/Freelancer: chỉ chỉ số cá nhân và so sánh tháng trước, không thấy hiệu suất Team/xếp hạng/bảng kết quả cá nhân bị lặp.
- Thu gọn thẻ **Hôm nay / Quá hạn / Sắp tới** cho cả Follow-up Telesales và Follow-up Quản lý khách hàng. Giữ nguyên thao tác bấm để lọc.
- Làm mới tên cache Service Worker lên V10.40 để thiết bị nhận giao diện mới.

## Cài đặt / Deploy lên Cloudflare thật

1. Giải nén ZIP ra **thư mục mới**, không chồng lên thư mục cũ.
2. Kiểm tra `wrangler.jsonc` có đúng Cloudflare account / database production của bạn.
3. Trên Windows, mở `CAP_NHAT_WEB_THAT.cmd`; gõ **YES** để cho phép sao lưu D1.
4. Chỉ sau khi file sao lưu D1 thành công và đúng database, nhập **DEPLOY** để cập nhật Workers.
5. Nhấn **Ctrl+F5** và kiểm tra Dashboard ở tài khoản Admin, Teamlead, Sales. Nếu trên điện thoại vẫn cũ, đóng/mở lại hoặc làm mới trang để cập nhật cache.

**Không chạy `wrangler d1 migrations apply ... --remote` trên D1 production** đang dùng: hệ thống trước đây đã báo lỗi migration 0019 do cột `has_prior_shinhan` đã tồn tại. V10.40 không có migration mới. Không tự xóa/chỉnh `d1_migrations`.

**Phân quyền:** Trang sử dụng API phân phạm vi theo vai trò vốn có từ V10.38. Client còn chủ động loại bỏ các bảng không dành cho Sales. Không coi việc ẩn giao diện là cơ chế phân quyền máy chủ.

## Kiểm thử

- Đã kiểm tra cú pháp `src/index.js`, `app.js`, `v1038.js`, `v1039.js`.
- Đã kiểm thử giao diện Chrome headless bằng dữ liệu mẫu cho Admin, Teamlead, Sales: drill-down Team, xếp hạng, bố cục cá nhân, thẻ Follow-up và không có lỗi JS trong lượt kiểm tra.
- Chưa được triển khai hoặc thử trực tiếp với D1 production; cần sao lưu và kiểm tra thực tế.

---

## Lịch sử V10.38 và các tính năng được giữ

# Shinhan Finance – An Đông 4 CRM V10.38

Bản V10.38 kế thừa đầy đủ V10.37. **Không chạy lại migration lịch sử `0019` lên D1 production** vì D1 trước đó từng báo cột `has_prior_shinhan` đã tồn tại. Sao lưu dữ liệu trước khi triển khai bằng `CAP_NHAT_WEB_THAT.cmd`.

## Các nâng cấp chính

- Nhóm sidebar **QUẢN LÝ KHÁCH HÀNG**: Dashboard, App Login, Lead, Follow-up, Chăm sóc khách hàng, KPI doanh số.
- Tab Team cho Dashboard và KPI doanh số, Dashboard Telesales, KPI cuộc gọi, Follow-up Telesales, Lead Login App và Follow-up Login App; Lead Telesales và CSKH tiếp tục giữ tab Team từ các bản cũ.
- Dashboard doanh số: tổng Volume giải ngân, APP/Loan, hiệu suất từng Team có nút xem Dashboard Team, so sánh tháng và xếp hạng Sales/Freelancer theo doanh số.
- Lead Login App: tổng/chưa xử lý/đã login/không login bấm được; thêm/sửa/xóa theo phạm vi; Lead riêng, không tự lấy Y01/Y02 của Telesales.
- Follow-up Login App: giao diện giống Follow-up Telesales, nhóm hôm nay/quá hạn/sắp tới, lọc tháng, Team, nhân viên, loại lịch; sửa/xóa và đánh dấu chăm sóc.
- Phân quyền API: Admin/Sup toàn hệ thống, Team Leader đúng Team, Sales/Freelancer cá nhân. Quyền chỉnh sửa theo tài khoản vẫn được tôn trọng.
- Lead xóa không tự xóa hồ sơ App Login đã liên kết. Những hồ sơ CSKH và dữ liệu D1 hiện có không bị xóa khi nâng cấp.

## Triển khai trên Cloudflare

Giải nén ZIP ra thư mục **mới**. Chạy `CAP_NHAT_WEB_THAT.cmd` trên Windows đã đăng nhập Cloudflare, xác nhận `YES`, chờ xuất bản sao lưu D1, rồi nhập `DEPLOY` nếu đúng môi trường. Không chạy `wrangler d1 migrations apply --remote` đối với database đã gặp lỗi cột trùng. Bản này tạo bảng hỗ trợ Lead/Follow-up App bằng cơ chế tồn tại trước (`CREATE TABLE IF NOT EXISTS`) trong backend.

## Giới hạn kiểm tra

- Đã kiểm tra cú pháp 3 JavaScript, chạy kiểm thử API với SQLite mô phỏng D1 và giao diện Chrome headless với dữ liệu giả lập trên hai Team.
- Chưa deploy/chạy trên D1 production thật. Trước khi dùng rộng rãi, thử bằng các hồ sơ không nhạy cảm.

---

# Shinhan Finance – An Đông 4 CRM V10.36

CRM nội bộ chạy trên **Cloudflare Workers + D1**, kế thừa mã nguồn và cấu trúc dữ liệu của V10.35. Bản V10.36 bổ sung tính năng, không xóa lịch sử phiên bản.

## V10.36 — cập nhật mới

Xem `THAY_DOI_V10.36.md` để biết 9 nhóm tính năng mới, phạm vi phân quyền, cách kiểm tra và giới hạn hoàn tác.

## V10.35 — tính năng kế thừa

### 1. Hai nhóm chức năng xổ xuống

- **TELESALES:** Dashboard Telesales, Chi tiết cuộc gọi, Follow-up Telesales, Lead Telesales và KPI cuộc gọi.
- **LOGIN APP:** Dashboard Login App, Danh sách Login App, Chăm sóc khách hàng, KPI doanh số.
- Các chức năng quản trị Kho, Nhập/Xuất dữ liệu, nhân sự, nhật ký vẫn nằm dưới menu **Quản trị & vận hành**. Không thêm lại Cài đặt hay phần tài khoản cố định ở góc trái.
- Admin và Sup: xem toàn hệ thống; Team Leader: Team của mình; Sales và Freelancer: dữ liệu của mình. Các endpoint mới kiểm tra **phạm vi trên máy chủ**, không chỉ ẩn ở frontend. Giữ quyền theo từng tài khoản đã cấp trước đây.

### 2. Dashboard Login App và KPI doanh số

- Báo cáo theo **tháng** (mặc định tháng hiện tại, chọn tháng khác được): **Số lượng APP** = số hồ sơ Login App tạo trong tháng; **Số lượng Loan** = số hồ sơ khoản vay có ngày giải ngân trong tháng; **Volume** = tổng số tiền giải ngân (`loan_profiles.disbursement_amount`) trong tháng.
- Lọc Team/nhân viên theo phạm vi được phép. Có bảng kết quả theo Sales/Freelancer.
- KPI doanh số theo nhân viên và tháng gồm 3 chỉ tiêu: số APP, số Loan và tiền giải ngân (VNĐ). Admin/Sup đặt chỉ tiêu toàn hệ thống; Team Leader chỉ được đặt cho Sales/Freelancer trong Team mình. Sales/Freelancer chỉ được xem.
- Dữ liệu lấy từ D1 thật, không tạo số liệu mẫu trên production. Mở **Nhật ký thao tác** để xem những lần đặt KPI mới.

### 3. Chăm sóc khách hàng

- Đưa **Tháng giải ngân** lên đầu trang và mặc định vào tháng hiện tại. Chọn tháng/năm khác sẽ lọc lại dữ liệu và các chỉ số.
- Làm rõ các nhóm: **Tất cả hồ sơ**, **Thanh toán hôm nay**, **Cần chăm sóc lần 1 (30 ngày)**, **Cần chăm sóc lần 2 (60 ngày)**, **Đủ 90 ngày/Topup**, **Sắp hết hợp đồng**. Vẫn dùng logic ngày thanh toán, 30/60/90 ngày và lưu các chăm sóc cũ.
- Bộ lọc **tháng giải ngân** ảnh hưởng danh sách và các số ở trên. Các nhóm chăm sóc bên trong danh sách được xác định theo ngày hiện tại. Để xem khách giải ngân ở tháng khác, đổi tháng trên đầu trang hoặc chọn Xóa chọn để xem tất cả.
- Giữ Xuất Excel theo các bộ lọc đã chọn.

### 4. Kho dữ liệu

- Admin/Sup có **Chia Data theo Team** ngay trong Kho dữ liệu. Chọn kho nguồn (ví dụ *Kho Mobility 3*), chọn chia đều hay giao cho một Sales/Freelancer **cùng Team**, số lượng và deadline.
- Tác vụ lớn dùng lại hệ thống job lưu trong D1. API mới nhận `source_team_id`, chỉ chọn `data_state='POOL'` thuộc chính kho đó; không trộn Kho chung hoặc Team khác. Nếu nhân viên chuyển Team trong khi job đang chạy, tác vụ dừng trước khi chia tiếp.
- Phần Nhập / Xuất dữ liệu có thêm selector **Kho nguồn Data** cho quy trình chia chung/trong Team; lựa chọn Kho chung chỉ lấy data `team_id IS NULL`.
- **Bỏ “Phân loại Data hàng loạt”** cùng API phân loại toàn Kho bằng một lần nhấn (trả HTTP 410). Chức năng phân loại Data **đã tick chọn** và quản lý phân loại vẫn còn nguyên.

## Triển khai trên Cloudflare production hiện có (đã phát sinh lỗi migration 0019)

**Cảnh báo:** Ở D1 production hiện tại, lệnh `wrangler d1 migrations apply ... --remote`
đã thất bại tại migration 0019 do cột `login_app_cases.has_prior_shinhan` tồn tại.
Không lặp lại lệnh đó, không xóa cột hoặc xóa dòng trong `d1_migrations`, không tạo D1 mới.

1. Sao lưu dữ liệu D1 production trước khi triển khai, xác nhận tài khoản Cloudflare và database ID
   trong `wrangler.jsonc` là DB bạn muốn dùng: `9f7223db-3f9b-44c7-b059-9b3a2904b2c4`.
2. Trên Windows, mở thư mục, **chạy `CAP_NHAT_WEB_THAT.cmd`**. Script hỏi xác nhận,
   cài dependencies, xuất bản sao lưu D1 ra máy bạn, và chỉ deploy Worker khi sao lưu thành công.
3. Script **không** chạy `d1 migrations apply --remote` để tránh chạy lại migration 0019 đã lệch
   trạng thái. Backend V10.35 kiểm tra trước khi bổ sung các cột Login App / CSKH còn thiếu và
   có cơ chế `CREATE TABLE IF NOT EXISTS` cho KPI doanh số, phân quyền và hoàn tác.
4. Sau deploy, tải lại bằng Ctrl+F5, kiểm tra đăng nhập, danh sách khách, KPI, chia Data theo Team
   bằng thao tác nhỏ trước. Chỉ dùng với database production **đã hoạt động trước đó**, không dùng
   cách này để khởi tạo database trắng.
5. Nếu gặp lỗi thiếu bảng/cột: dừng thao tác, gửi log và kết quả `KIEM_TRA_D1_CHI_DOC.cmd`.
   Việc đối soát migration cũ phải dựa trên trạng thái thật của D1, không đánh dấu tùy tiện.

Xem `HUONG_DAN_CHAY_THAT.md` cho lệnh chạy riêng và cách đối chiếu số liệu.

## Tài liệu / migrations được giữ

- `LICH_SU_PHIEN_BAN_DAY_DU.md`: giữ nguyên nội dung 109 README phiên bản cũ đã gộp từ V10.34.
- `migrations/0001_init.sql` đến `migrations/0023_v10_34_audit_undo.sql`: **giữ nguyên**, chỉ thêm migration 0024.
- `DEPLOY_CLOUDFLARE_VI.txt` và `CAP_NHAT_NHANH.txt`: giữ nguyên.
- Toàn bộ module CRM cũ, Undo 7 ngày, phân quyền tài khoản, Chat, Lead, Follow-up, CSKH, Login App, Kho, KPI cuộc gọi vẫn được giữ.

## Kiểm thử và hạn chế

- Đã kiểm tra cú pháp JavaScript ở frontend/backend và chạy thử giao diện với dữ liệu/API giả lập, bao gồm menu xổ xuống, tháng CSKH, lưu KPI mới, điều hướng theo role, Kho nguồn và phần phân loại Data.
- **Chưa chạy trực tiếp với Cloudflare D1 production của bạn**. Thời gian và số liệu thực tế cần xác nhận sau triển khai.
- KPI doanh số phản ánh các hồ sơ khoản vay có ngày giải ngân trong tháng; không tự suy ra một khoản Loan mới nếu Topup được lưu chỉ bằng cập nhật hồ sơ cũ.
