# THAY ĐỔI V10.39 – DASHBOARD & FOLLOW-UP

| Trang | Thay đổi | Phân quyền |
| --- | --- | --- |
| Dashboard Quản lý khách hàng | Bỏ hàng Tab Team, vẫn giữ nút Xem Team | Admin/Sup thấy Team được phép; Teamlead chỉ Team mình |
| Dashboard | Bỏ bảng Kết quả theo nhân viên, thiết kế thẻ doanh số APP Loan gọn hơn | Tất cả |
| Dashboard cấp quản lý | Hiệu suất Team, so sánh tháng, bảng xếp hạng vai trò riêng | Admin/Sup/Teamlead |
| Dashboard cá nhân | Chỉ tổng Volume, APP, Loan, so sánh tháng | Sales/Freelancer |
| Follow-up Telesales | Thu gọn 3 thẻ thống kê, căn icon, chữ và số | Theo phạm vi cũ |
| Follow-up Quản lý khách hàng | Thu gọn 3 thẻ; giữ tương tác lọc | Theo phạm vi cũ |

Không thay đổi D1 schema, migrations, dữ liệu nghiệp vụ, KPI/Lead/Kho/CSKH.

Kiểm tra giao diện được thực hiện với dữ liệu giả lập, chưa deploy lên production.
