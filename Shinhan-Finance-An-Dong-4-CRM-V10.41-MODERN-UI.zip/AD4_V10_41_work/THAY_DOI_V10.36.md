# An Đông 4 CRM – V10.36: những thay đổi và giới hạn

Phiên bản này kế thừa V10.35. Giữ nguyên `wrangler.jsonc` và database_id hiện tại; **không áp dụng lại migration remote 0019**, đã gặp lỗi cột tồn tại.

1. **Menu Telesales / Login App:** vẫn là hai nhóm xổ xuống; thay đổi độ mượt và giảm hiện tượng nhảy cuộn khi bấm tab bên trong trang. Trường hợp chuyển hẳn sang màn hình khác vẫn có thể bắt đầu ở đầu trang.
2. **Kho dữ liệu:** bỏ thẻ “Chia Data theo Team” trùng lặp trong Kho; dùng duy nhất form Chia Data từ Kho tại **Nhập/Xuất dữ liệu**. Chọn Kho chung Admin hoặc một Kho Team, Team/nhân viên nhận, số lượng và deadline. Nếu chọn Kho Team thì chỉ có thể giao cho người cùng Team. Thống kê số Data tồn, chưa từng gọi, từng gọi/được trả lại dựa trên D1. Không gộp Data của Team khác.
3. **KPI doanh số:** chọn nhiều Sales/Freelancer và giao APP/Loan/Volume cho cả nhóm trong một lần. API kiểm tra từng tài khoản theo vai trò.
4. **Dashboard Login App:** thêm phần so sánh cùng chỉ tiêu APP/Loan/Volume của tháng thống kê và tháng trước.
5. **Lead Login App:** tự hiển thị Lead cuộc gọi Y01/Y02 còn trong phạm vi, chọn nguồn Data/TikTok/Facebook/Thị trường/CTV/Giới thiệu/Khác; có thể chuyển Lead sang hồ sơ Login App. Không làm mất Lead Telesales.
6. **Khóa nhân viên:** Admin/Sup và Team Leader trong Team có thể khóa Sales/Freelancer, hủy phiên đăng nhập nhưng không xóa lịch sử/cuộc gọi/Data. Bảng tài khoản khóa có nút thu hồi Data về Kho Team hoặc mở khóa. Tài khoản khóa được đánh dấu riêng để không bị nhầm với tài khoản đã xóa, không tái sử dụng username của tài khoản khóa.
7. **Nhật ký/hoàn tác:** nhóm thao tác phân loại Data đã chọn phát sinh từ V10.36 lưu bản dữ liệu trước/sau và hỗ trợ hoàn tác trong 7 ngày nếu không có xung đột. Các bản ghi cũ chỉ chứa số khách phân loại, không chứa ảnh trạng thái từng khách: không thể hoàn tác an toàn và tiếp tục hiển thị dấu “—”. Không hoàn tác đại trà các thao tác nhiều bảng nếu không có snapshot đủ.
8. **Giữ vị trí cuộn:** xử lý thao tác tab nội bộ Kho/Team/CSKH và các bộ lọc bằng việc giữ lại vị trí cuộn chính/sidebar.
9. **Follow-up Login App:** trang riêng biệt, lập lịch hẹn hồ sơ bị từ chối, gọi lại, bổ sung hồ sơ hoặc đăng nhập lại, ghi nhận đã chăm sóc; không gộp với Follow-up Telesales.

## Phân quyền
Admin/Sup được xem toàn hệ thống; Team Leader theo Team, Sales/Freelancer theo khách hàng cá nhân. Giao KPI chỉ cho phép tài khoản thuộc phạm vi. Các API mới đều kiểm tra quyền trên backend; ẩn nút trên giao diện không thay thế kiểm tra này.

## Dữ liệu và triển khai
Các bảng phụ `login_lead_sources`, `app_followups`, `user_lock_records` được khởi tạo **khi sử dụng lần đầu**. Việc deploy không tự xóa D1. Bắt buộc sao lưu trước khi cập nhật Workers production, và thử trên một tập dữ liệu nhỏ.

## Kiểm tra
`node --check` đã thành công cho `src/index.js` và `public/assets/app.js`. Kiểm thử API trên SQLite/D1 mô phỏng đã qua với các thao tác chia kho, KPI nhóm, Lead, phân loại có hoàn tác, khóa/mở khóa. Chưa kiểm thử trực tiếp trên cơ sở dữ liệu production hoặc chạy smoke test giao diện trình duyệt đầy đủ.
