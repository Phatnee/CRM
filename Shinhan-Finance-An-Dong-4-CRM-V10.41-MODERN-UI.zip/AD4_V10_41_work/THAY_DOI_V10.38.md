# Thay đổi V10.38

1. Sidebar QUẢN LÝ KHÁCH HÀNG (Dashboard, App Login, Lead, Follow-up).
2. Các trang Dashboard/KPI/Lead/Follow-up có tab Team theo vai trò, giữ phạm vi server.
3. Dashboard Loan: Tổng doanh số trên cùng, hiệu suất Team có drill-down, xếp hạng Sales/Freelancer.
4. Bảng Lead Login App có lọc trạng thái bằng ô tổng hợp bấm được, sửa/xóa và danh sách riêng.
5. Follow-up Login App đồng bộ giao diện với Follow-up Telesales, lọc tháng/năm/Team/nhân viên, sửa/xóa.
6. API có kiểm tra role + scope; xóa Lead đã chuyển không xóa App, bảo toàn lịch sử.
7. Không thay đổi database_id Cloudflare, không sửa migration cũ; có script sao lưu D1 trước deploy.

Kiểm thử: `node --check` cho các tệp JS, SQLite/D1 mô phỏng kiểm tra cập nhật Lead/Follow-up và quyền truy cập, Chrome headless kiểm tra Dashboard và thao tác Team/Lead/Follow-up. Chưa kiểm thử trên production thật.
