# AN ĐÔNG 4 CRM — NÂNG CẤP V10.40

**Nguồn:** Nâng cấp từ V10.39, giữ nguyên mã backend và toàn bộ migration D1.

## Dashboard Quản lý khách hàng

- **Admin/Sup**: trang tổng hệ thống vẫn có **Xem Team**; khi vào Team, bảng Hiệu suất đổi thành từng nhân viên kèm **Xem Dashboard**. Có nút **Trở về Dashboard trước** từ cá nhân về Team rồi về tổng.
- **Team Leader**: Hiệu suất đội ngũ hiển thị từng nhân viên thuộc Team được server trả về, kèm APP, Loan, Volume và nút **Xem Dashboard** từng người. Có nút quay lại Dashboard Team.
- **Sales/Freelancer**: chỉ số KPI cá nhân và so sánh tháng. Không có bảng xếp hạng hoặc hiệu suất Team.
- **Bấm thẻ doanh số, APP, Loan**: mở danh sách liên quan theo tháng và phạm vi của Dashboard. APP mở trang App Login với bộ lọc **Tất cả**; Loan/Volume mở Chăm sóc khách hàng theo tháng giải ngân. Có nút quay lại Dashboard.
- **Cuộn trang**: bỏ hành vi giữ cuộn ở bảng hiệu suất, lăn chuột tiếp tục cuộn trang khi trỏ trên bảng.

## Lead và Follow-up Quản lý khách hàng

- Bỏ tab Team nằm riêng phía trên, giữ bộ lọc Team dạng dropdown ngay trong thanh tìm kiếm cho Admin/Sup.
- Team Leader/Sales/Freelancer chỉ xem đúng phạm vi được phân quyền từ API.
- Lead có thêm lọc Từ ngày/Đến ngày, giữ các ô trạng thái có thể bấm để lọc, tương tự bố cục Telesales.
- Follow-up tiếp tục có các ô Hôm nay / Quá hạn / Sắp tới, lọc và chỉnh sửa lịch hẹn như bản trước.

## An toàn khi triển khai

- V10.40 không sửa schema hoặc migration D1; toàn bộ tính năng và dữ liệu được giữ nguyên.
- KHÔNG tự chạy `wrangler d1 migrations apply ... --remote` trên D1 production có tiền sử lỗi trùng cột `has_prior_shinhan` ở migration 0019.
- Sao lưu D1 trước khi deploy. Triển khai bằng `CAP_NHAT_WEB_THAT.cmd` trong thư mục đã giải nén.
- Kiểm thử bằng trình duyệt tự động và dữ liệu mô phỏng; chưa kiểm thử trên database production.
